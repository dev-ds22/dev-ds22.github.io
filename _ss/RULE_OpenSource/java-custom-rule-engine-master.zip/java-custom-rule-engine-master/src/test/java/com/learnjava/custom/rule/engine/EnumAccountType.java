package com.learnjava.custom.rule.engine;

public enum EnumAccountType {
	SAVINGS, CURRENT, MONEY_MARKET_ACCOUNT;
}
