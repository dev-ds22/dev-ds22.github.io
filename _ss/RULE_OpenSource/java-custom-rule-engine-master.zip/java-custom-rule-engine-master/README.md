# java-custom-rule-engine

Detailed Post about this Rule Engine can be found at 
[https://medium.com/@muthukumaran.mnm/custom-rule-engine-using-java-55a4c3507dcf?source=friends_link&sk=f2355e1db033fd9da2df1ee195a0e7d0](https://medium.com/@muthukumaran.mnm/custom-rule-engine-using-java-55a4c3507dcf?source=friends_link&sk=f2355e1db033fd9da2df1ee195a0e7d0)