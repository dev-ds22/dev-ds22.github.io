package com.apress.integration.constant;

public abstract class HTTPConstant {

    public static final String APP_JSON = "application/json";
    public static final String TEXT_PLAIN = "text/plain";

}
