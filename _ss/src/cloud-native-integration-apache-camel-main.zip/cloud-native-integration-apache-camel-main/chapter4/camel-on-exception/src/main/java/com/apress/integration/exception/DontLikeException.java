package com.apress.integration.exception;

public class DontLikeException extends Exception{

    public DontLikeException(){
        super();
    }

    public DontLikeException(String message){
        super(message);
    }

}
