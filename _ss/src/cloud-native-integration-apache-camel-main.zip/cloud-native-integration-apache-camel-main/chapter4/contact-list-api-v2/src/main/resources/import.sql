INSERT INTO CONTACT(NAME,EMAIL,PHONE,COMPANY) VALUES ('John Doe', 'john.d@email.com', '1111111', 'MyCompany');
INSERT INTO CONTACT(NAME,EMAIL,PHONE,COMPANY) VALUES ('Jane Doe', 'jane.d@email.com', '2222222', 'MyCompany');
INSERT INTO CONTACT(NAME,EMAIL,PHONE,COMPANY) VALUES ('Tester Test', 'test@email.com', '00000000', 'Another Company');