package com.apress.integration.constant;


public abstract class HTTPConstant {

    public static final String TEXT_PLAIN = "text/plain";

}