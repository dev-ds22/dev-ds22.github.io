package com.apress.integration.constant;

public abstract class HTTPConstant {

    public static final String APP_JSON = "application/json";

}
