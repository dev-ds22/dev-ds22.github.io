/**
 * Classes for cluster operation functionality.
 */
package org.openhubframework.openhub.spi.node;