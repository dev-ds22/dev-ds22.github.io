/**
 * Throttling problem solution.
 */
package org.openhubframework.openhub.spi.throttling;