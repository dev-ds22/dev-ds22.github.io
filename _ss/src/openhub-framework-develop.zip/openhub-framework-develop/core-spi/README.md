# OpenHub integration framework - core SPI

Service API for internal OpenHub development, e.g. components.

