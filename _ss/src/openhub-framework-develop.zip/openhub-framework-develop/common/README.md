# OpenHub integration framework - common

Module with common and handy functionality useful for all other modules.