/**
 * Enhancements to logging capabilities.
 */
package org.openhubframework.openhub.common.log;