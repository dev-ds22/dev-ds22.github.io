/**
 * Conversion functionality for basic data types.
 */
package org.openhubframework.openhub.common.converter;