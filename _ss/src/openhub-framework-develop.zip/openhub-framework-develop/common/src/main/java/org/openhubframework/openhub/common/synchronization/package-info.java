/**
 * Contains classes for synchronization one ore more threads by one or more values.
 */
package org.openhubframework.openhub.common.synchronization;