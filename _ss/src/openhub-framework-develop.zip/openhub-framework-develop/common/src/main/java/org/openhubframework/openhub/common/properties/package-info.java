/**
 * Classes to support external configuration.
 *
 * @author Tomas Hanus
 * @since 2.0
 */
package org.openhubframework.openhub.common.properties;