**v0.2.0**
----------
- Added Material Design
- Added Jest test framework

**v0.1.0**
----------
- Removed axios
- Added fetch
- Added fetch-redux service
- Refactored sidemenu
- Added Toastr

**v0.0.3**
----------
- Added new mock server (express)
- Added login mock
- Added login modal and form


**v0.0.2**
---------
- Added Item Component
- Modified UserButton
- Modified Navbar
- Modified Sidebar
- Modified Avatar
