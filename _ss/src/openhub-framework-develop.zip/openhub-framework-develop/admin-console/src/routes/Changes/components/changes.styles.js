import { gap } from '../../../styles/constants'

export default {
  main:{
    width: '98%'
  },
  markdown: {
    paddingLeft: gap,
    paddingRight: gap,
    paddingTop: gap
  }
}
