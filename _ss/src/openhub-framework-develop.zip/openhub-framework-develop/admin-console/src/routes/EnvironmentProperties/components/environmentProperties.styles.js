import { gap } from '../../../styles/constants'

export default {
  main: {
    width: '100%'
  },
  json: {
    paddingLeft: gap,
    paddingRight: gap,
    paddingTop: gap,
    paddingBottom: gap
  }
}
