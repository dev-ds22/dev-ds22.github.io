import { gap } from '../../../../styles/constants'

export default {
  item: {
    paddingBottom: gap,
    marginTop: gap,
    boxShadow: '0 2px 7px -1px silver'
  }
}
