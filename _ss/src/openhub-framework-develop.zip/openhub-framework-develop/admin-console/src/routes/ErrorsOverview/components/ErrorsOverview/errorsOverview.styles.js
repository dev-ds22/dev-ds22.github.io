import { gap } from '../../../../styles/constants'
import styles from '../../../../styles/styles'

export default {
  ...styles,
  main: {
    width: '100%'
  },
  card: {
    marginBottom: gap
  }
}
