import { gap, smallGap } from '../../../../styles/constants'

export default {
  main: {
    paddingBottom: smallGap
  },
  card: {
    marginBottom: gap
  }
}
