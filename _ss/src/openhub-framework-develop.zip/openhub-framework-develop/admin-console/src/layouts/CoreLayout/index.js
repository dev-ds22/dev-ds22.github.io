import CoreLayout from './containers/coreLayout.container'

export default CoreLayout
