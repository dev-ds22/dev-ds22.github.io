export default {
  wrapper: {
    position: 'absolute',
    width: '100vw',
    height: '100vh',
    display: 'flex',
    alignItems: 'center'
  },
  card: {
    padding: 20
  }
}
