# OpenHub integration framework - core

Module which represents core of OpenHub framework.

