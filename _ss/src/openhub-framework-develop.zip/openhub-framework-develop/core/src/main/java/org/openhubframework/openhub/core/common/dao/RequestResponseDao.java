/*
 * Copyright 2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.openhubframework.openhub.core.common.dao;

import java.time.Instant;
import java.util.List;
import javax.annotation.Nullable;

import org.openhubframework.openhub.api.entity.Request;
import org.openhubframework.openhub.api.entity.Response;


/**
 * DAO for {@link Request} and {@link Response} entities.
 *
 * @author Petr Juza
 * @since 0.4
 */
public interface RequestResponseDao {

    /**
     * Inserts new request.
     *
     * @param request the request
     */
    void insertRequest(Request request);


    /**
     * Inserts new response.
     *
     * @param response the response
     */
    void insertResponse(Response response);


    /**
     * Gets last request specified by target URI and response-join ID.
     *
     * @param uri the target URI
     * @param responseJoinId the identifier for pairing/joining request and response together
     * @return request
     */
    @Nullable
    Request findLastRequest(String uri, String responseJoinId);


    /**
     * Finds request which matches the criteria filter.
     *
     * @param from       the timestamp from
     * @param to         the timestamp to
     * @param subUri     the substring of URI
     * @param subRequest the substring of request content
     * @return list of {@link Request}
     */
    List<Request> findByCriteria(Instant from, Instant to, @Nullable String subUri, @Nullable String subRequest);

    /**
     * Delete request.
     *
     * @param request the request to be deleted.
     */
    void deleteRequest(Request request);

    /**
     * Delete response.
     *
     * @param response the response to be deleted.
     */
    void deleteResponse(Response response);
}
