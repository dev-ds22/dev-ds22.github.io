/**
 * Handle file storing in the repository.
 */
package org.openhubframework.openhub.core.common.file;