/**
 * Support classes for Spring "context:component-scan" include/exclude elements.
 */
package org.openhubframework.openhub.core.common.spring;