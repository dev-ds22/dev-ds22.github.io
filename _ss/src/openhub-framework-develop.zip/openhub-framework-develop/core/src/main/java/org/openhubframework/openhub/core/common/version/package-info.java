/**
 * Classes for extracting build number from MANIFEST.MF file.
 */
package org.openhubframework.openhub.core.common.version;