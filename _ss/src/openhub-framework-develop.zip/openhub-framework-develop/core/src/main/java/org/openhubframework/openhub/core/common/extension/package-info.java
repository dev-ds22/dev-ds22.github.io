/**
 * OpenHub extension classes.
 */
package org.openhubframework.openhub.core.common.extension;