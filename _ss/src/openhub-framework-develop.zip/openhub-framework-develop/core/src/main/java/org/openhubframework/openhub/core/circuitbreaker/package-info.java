/**
 * Circuit breaker components.
 */
package org.openhubframework.openhub.core.circuitbreaker;