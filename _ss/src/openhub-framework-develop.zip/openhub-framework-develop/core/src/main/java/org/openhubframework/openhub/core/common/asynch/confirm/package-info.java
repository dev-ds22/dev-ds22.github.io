/**
 * Confirmation functionality.
 * <p>
 * When message finish its processing (message is in the final state OK, FAILED or CANCEL) then it's necessary
 * to inform source system about result of processing.
 */
package org.openhubframework.openhub.core.common.asynch.confirm;