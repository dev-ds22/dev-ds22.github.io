/**
 * Re-processing of PARTLY_FAILED messages.
 */
package org.openhubframework.openhub.core.common.asynch.queue;