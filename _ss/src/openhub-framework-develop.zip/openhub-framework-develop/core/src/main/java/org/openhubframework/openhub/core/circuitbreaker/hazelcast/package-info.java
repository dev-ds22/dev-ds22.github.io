/**
 * Hazelcast implementation of CircuitBreaker related classes.
 */
package org.openhubframework.openhub.core.circuitbreaker.hazelcast;