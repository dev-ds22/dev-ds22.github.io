/**
 * Defines base class for route definition and few basic routes.
 */
package org.openhubframework.openhub.core.common.route;