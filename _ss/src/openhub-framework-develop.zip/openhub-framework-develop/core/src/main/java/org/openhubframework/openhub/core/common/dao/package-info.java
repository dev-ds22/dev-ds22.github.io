/**
 * DAO classes.
 */
package org.openhubframework.openhub.core.common.dao;