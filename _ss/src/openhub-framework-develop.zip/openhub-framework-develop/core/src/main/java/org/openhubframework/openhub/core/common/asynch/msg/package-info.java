/**
 * Message services and operations with them.
 */
package org.openhubframework.openhub.core.common.asynch.msg;