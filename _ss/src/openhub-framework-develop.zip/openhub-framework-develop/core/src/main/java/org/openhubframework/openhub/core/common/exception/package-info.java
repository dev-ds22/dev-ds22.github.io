/**
 * Defines exceptions hierarchy and defines global error handling policy.
 */
package org.openhubframework.openhub.core.common.exception;