/**
 * Alerts implementation.
 */
package org.openhubframework.openhub.core.alerts;