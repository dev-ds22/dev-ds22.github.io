/**
 * Notification service - useful when is needed to contact (inform) selected people.
 */
package org.openhubframework.openhub.core.common.asynch.notification;