/**
 * Validation exceptions.
 */
package org.openhubframework.openhub.api.exception.validation;