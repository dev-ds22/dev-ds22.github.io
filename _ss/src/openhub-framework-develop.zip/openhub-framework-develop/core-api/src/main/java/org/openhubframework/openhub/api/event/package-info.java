/**
 * Defines OpenHub {@link java.util.EventObject events}.
 */
package org.openhubframework.openhub.api.event;

