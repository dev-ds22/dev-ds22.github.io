/**
 * Message services and operations with them.
 */
package org.openhubframework.openhub.api.asynch.msg;