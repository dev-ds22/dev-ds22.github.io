/**
 * Confirmation functionality.
 * <p>
 * When message finish its processing (message is in the final state OK or FAILED) then it's necessary
 * to inform source system about result of processing.
 */
package org.openhubframework.openhub.api.asynch.confirm;