/**
 * Handle file storing in the repository.
 */
package org.openhubframework.openhub.api.file;