/**
 * Main (business) entities.
 */
package org.openhubframework.openhub.api.entity;