/**
 * OpenHub configuration/settings.
 */
package org.openhubframework.openhub.api.config;