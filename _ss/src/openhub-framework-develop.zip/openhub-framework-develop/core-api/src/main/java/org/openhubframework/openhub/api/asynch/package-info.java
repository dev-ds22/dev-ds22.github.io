/**
 * Processing of asynchronous messages.
 */
package org.openhubframework.openhub.api.asynch;