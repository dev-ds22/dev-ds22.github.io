/**
 * Defines base class for route definition and few basic routes.
 */
package org.openhubframework.openhub.api.route;