/**
 * JAXB enhancements - date conversion to/from JODA time.
 */
package org.openhubframework.openhub.api.common.jaxb;