# OpenHub integration framework - core API

API defines interface for development with OpenHub. If new routes are necessary to implement
then core API defines what is possible to use.

