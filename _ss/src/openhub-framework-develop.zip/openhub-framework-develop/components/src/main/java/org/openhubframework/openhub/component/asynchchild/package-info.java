/**
 * "asynch-child" Camel component.
 */
package org.openhubframework.openhub.component.asynchchild;