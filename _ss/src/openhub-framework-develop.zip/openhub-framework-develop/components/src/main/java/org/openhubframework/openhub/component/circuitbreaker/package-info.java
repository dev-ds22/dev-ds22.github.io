/**
 * "circuit" camel component.
 */
package org.openhubframework.openhub.component.circuitbreaker;