/**
 * Custom Camel components.
 */
package org.openhubframework.openhub.component;