/**
 * "throttling" component for throttling input requests.
 */
package org.openhubframework.openhub.component.throttling;