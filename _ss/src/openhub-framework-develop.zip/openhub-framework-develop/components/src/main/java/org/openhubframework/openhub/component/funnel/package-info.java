/**
 * "msg-funnel" component implementation.
 */
package org.openhubframework.openhub.component.funnel;