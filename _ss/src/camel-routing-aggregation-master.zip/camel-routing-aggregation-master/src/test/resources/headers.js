function() {
    var token = karate.get('token');
    var time = karate.get('time');

}