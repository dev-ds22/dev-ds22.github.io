package com.example.camel.config;

public class ExampleException extends  Exception{
}
