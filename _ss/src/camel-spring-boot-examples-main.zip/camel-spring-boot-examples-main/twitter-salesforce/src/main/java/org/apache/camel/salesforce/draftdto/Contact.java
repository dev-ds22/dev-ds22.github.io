package org.apache.camel.salesforce.draftdto;

public abstract class Contact {
    public abstract void setLastName(String LastName);
    public abstract void setTwitterScreenName__c(String TwitterScreenName__c);
}
