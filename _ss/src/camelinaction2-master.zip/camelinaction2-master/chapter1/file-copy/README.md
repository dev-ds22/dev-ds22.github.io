Chapter 1 - file-copy
---------------------

Contains the only example from chapter 1.


### 1.2.2 - Your first Camel ride

This example is copying files from the data/inbox to data/outbox directory.

To run the example:

    mvn compile exec:java
    
When the example is done, then you can see that the file has been copied from `data/inbox/message1.xml` to `data/outbox/message1.xml`.

