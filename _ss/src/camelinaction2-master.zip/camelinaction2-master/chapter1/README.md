Chapter 1 - Meeting Camel
----------------------------------

Chapter 1 introduces you to Camel and explains what Camel is and where it fits into the bigger enterprise software picture. You’ll also learn the concepts and terminology of Camel.

Outline:

- An introduction to Camel
- Camel’s main features
- Your first Camel ride
- Camel’s architecture and concepts



