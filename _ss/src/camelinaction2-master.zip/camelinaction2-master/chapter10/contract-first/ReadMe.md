chapter10 - contract-first
--------------------------

SOAP Web Service development using contract-first style.

### Using a contract-first approach

You can try this example by running the following Maven goal:

    mvn test

