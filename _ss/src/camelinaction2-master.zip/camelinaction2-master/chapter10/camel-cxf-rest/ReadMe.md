Chapter 10 - camel-cxf-rest
---------------------------

This directory holds examples how to use the camel-cxf component for REST services

### 10.1.5 - Using camel-cxfrs with REST services

This example can be run using:

    mvn test -Dtest=RestOrderServiceTest
    mvn test -Dtest=SpringRestOrderServiceTest

