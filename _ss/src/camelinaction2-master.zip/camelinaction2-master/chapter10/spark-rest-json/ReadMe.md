chapter10 - spark-rest-json
---------------------------

This example demonstrates how to use XML and JSon data format with Rest DSL.

### 10.2.5 Using XML and JSon data formats with Rest DSL

You can try this example by running these goals:

    mvn test -Dtest=OrderServiceTest
    mvn test -Dtest=SpringOrderServiceTest
