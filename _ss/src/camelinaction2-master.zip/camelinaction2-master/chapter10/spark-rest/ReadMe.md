chapter10 - spark-rest
----------------------

This is a quick example demonstrating the Camel Rest DSL with Spark-Rest library.

### 10.2.1 A quick example of the Rest DSL

You can try this example by running these goals:

    mvn test -Dtest=OrderServiceTest
    mvn test -Dtest=SpringOrderServiceTest
