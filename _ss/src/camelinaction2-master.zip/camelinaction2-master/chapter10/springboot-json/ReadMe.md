chapter10 - springboot-json
---------------------------

This example demonstrates how to use Rest DSL with Spring Boot
and configured in the application.properties file.

### 10.2.5 Using XML and JSon data formats with Rest DSL

You can try this example by running these goals:

    mvn spring-boot:run
    
And then from a web browser open:

    http://localhost:8080/api/orders/1
    
  or

    http://localhost:8080/api/orders/2
    
    