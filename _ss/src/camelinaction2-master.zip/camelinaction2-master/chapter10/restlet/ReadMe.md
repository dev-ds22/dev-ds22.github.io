chapter10 - restlet
-------------------

This is an example how to use camel-restlet to use Camel routes as REST services with Restlet.

### 10.1.4 Using camel-reslet with REST services

You can run these goals to try this example:

    mvn test -Dtest=OrderServiceTest
    mvn test -Dtest=SpringOrderServiceTest
