chapter10 - code-first
----------------------

SOAP Web Service development using code-first style.

### Using a code-first approach

You can try this example by running the following Maven goal:

    mvn test

