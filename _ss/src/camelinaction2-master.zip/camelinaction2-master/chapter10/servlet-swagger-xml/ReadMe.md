chapter10 - servlet-swagger-xml
-------------------------------

This example shows how to use Servlet REST to define REST endpoints in Camel routes using the Rest DSL in XML,
and using camel-swagger-java to expose the REST service APIs.

### 10.3.3 Documenting Rest DSL services

You can try this example by running

    mvn compile jetty:run

The example comes with further instructions how to use this example accessing the web page from a browser at:

    http://localhost:8080/chapter10-servlet-swagger-xml

