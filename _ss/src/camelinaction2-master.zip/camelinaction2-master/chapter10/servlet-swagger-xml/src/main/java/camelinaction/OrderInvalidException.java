package camelinaction;

/**
 * Exception if the order input is invalid.
 */
public class OrderInvalidException extends Exception {

    public OrderInvalidException(String message) {
    }

}
