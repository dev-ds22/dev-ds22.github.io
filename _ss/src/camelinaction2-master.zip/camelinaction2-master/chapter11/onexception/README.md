Chapter 11 - onexception
------------------------

This directory holds examples how to use the error handler with redelivery

### 11.4.1 - Understanding how onException catches exceptions

The example can be run with:

    mvn test -Dtest=OnExceptionFallbackTest

### 11.4.1 - OnException and gap detection

The example can be run with:

    mvn test -Dtest=OnExceptionGapTest
    mvn test -Dtest=SpringOnExceptionGapTest

