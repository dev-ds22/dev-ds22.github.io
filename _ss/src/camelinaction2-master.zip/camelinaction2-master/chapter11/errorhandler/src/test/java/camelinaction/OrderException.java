package camelinaction;

public class OrderException extends Exception {
    
	private static final long serialVersionUID = -2573258934191495202L;

	public OrderException(String s) {
        super(s);
    }
}
