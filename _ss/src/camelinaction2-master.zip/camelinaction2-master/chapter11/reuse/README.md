Chapter 11 - reuse
------------------

This directory holds an example how to reuse context scoped error handlers

### 11.3.5 Reusing context scoped error handlers

The example can be run with:

    mvn test -Dtest=ReuseErrorHandlerTest
    mvn test -Dtest=SpringReuseErrorHandlerTest

