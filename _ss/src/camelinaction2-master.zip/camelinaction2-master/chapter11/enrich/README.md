Chapter 11 - enrich
-------------------

This directory holds an example how to enrich a message with details from caused exception

### 11.2.2 - Enriching message with cause of error

The example can be run with:

    mvn test -Dtest=EnrichFailureBeanTest
    mvn test -Dtest=SpringEnrichFailureBeanTest

