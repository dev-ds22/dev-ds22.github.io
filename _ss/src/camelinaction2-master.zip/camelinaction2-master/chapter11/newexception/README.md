Chapter 11 - newexception
-------------------------

This directory hold an example what happens when a new exception occur while Camel is already handling an existing exception.

### 11.4.5 New exception while handling exception

The example can be run with:

    mvn test -Dtest=NewExceptionTest
    mvn test -Dtest=SpringNewExceptionTest

