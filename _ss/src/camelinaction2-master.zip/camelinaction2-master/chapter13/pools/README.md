Chapter 13 - pools
------------------

This directory holds examples how to use thread pools with Camel

### 13.2.4 - Using ExecutorServiceStrategy in a custom Component

The example can be run with:

    mvn test -Dtest=MyComponentTest


### 13.3.1 - Using concurrency with the Threads EIP

The example can be run with:

    mvn test -Dtest=SpringInlinedThreadPoolTest

### 13.3.1 - Paralllel processing files

The example can be run with:

    mvn test -Dtest=FileThreadsTest
    mvn test -Dtest=SpringFileThreadsTest

