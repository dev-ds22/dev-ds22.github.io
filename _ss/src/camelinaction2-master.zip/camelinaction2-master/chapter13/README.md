Chapter 13 - Parallel Processing
--------------------------------

This chapter covers:

- Camel’s threading model
- Configuring thread pools and thread profiles
- Using concurrency with EIPs
- Scalability with Camel
- Writing asynchronous Camel components
