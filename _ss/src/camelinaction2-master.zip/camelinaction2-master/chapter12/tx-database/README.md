Chapter 12 - tx-database
------------------------

This directory holds an example how to use transaction that starts from a database in a local transaction

### 12.3.3 Transaction starting from a database resource

The example can be run with:

    mvn test -Dtest=SpringCommitTest
    mvn test -Dtest=SpringRollbackTest
