Chapter 12 - riderautoparts-order
---------------------------------

This directory holds an use case with Rider Auto Partners where they have an order application using a web service
endpoint and a database to store incoming orders.

### 12.3.6 - Returning a custom response when a transaction fails

The example can be run with:

    mvn camel:run


