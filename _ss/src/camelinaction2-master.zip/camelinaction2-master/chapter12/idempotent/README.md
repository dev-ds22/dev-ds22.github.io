Chapter 12 - idempotent
-----------------------

This directory holds an example how to use idempotent consumer EIP.

### 12.5.1 - Using the Idempotent Consumer EIP

The example can be run with:

    mvn test -Dtest=SpringIdempotentTest
    mvn test -Dtest=IdempotentTest


