Appendix A - The Simple Language
----------------

These examples show you how to use the Simple language from Camel. There are
also plenty of examples of Simple throughout the rest of the book's source.
If you want further examples, check out Camel's tests at:

https://github.com/apache/camel/tree/master/camel-core/src/test/java/org/apache/camel/language/simple

