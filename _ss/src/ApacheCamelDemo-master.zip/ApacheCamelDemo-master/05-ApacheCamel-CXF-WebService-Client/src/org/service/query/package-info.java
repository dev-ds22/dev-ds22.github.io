@javax.xml.bind.annotation.XmlSchema(namespace = "http://query.service.org/")
package org.service.query;
