@javax.xml.bind.annotation.XmlSchema(namespace = "http://apache.org/hello_world_soap_http/types", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.apache.hello_world_soap_http.types;
