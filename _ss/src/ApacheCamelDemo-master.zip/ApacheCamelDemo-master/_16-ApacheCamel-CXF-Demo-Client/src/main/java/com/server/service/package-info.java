@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.server.com/")
package com.server.service;
