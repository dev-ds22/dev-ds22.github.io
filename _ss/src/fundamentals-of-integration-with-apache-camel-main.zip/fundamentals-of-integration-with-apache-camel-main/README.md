# Fundamentals of Integration with Apache Camel

## Welcome!

Welcome to the main repository for the Pluralsight course, Fundamentals of Integration with Apache Camel.

My name is Michael Hoffman and I am the author for this course. I can be reached through my contact information below:

* Email: mike@michaelhoffmaninc.com
* Twitter: @mhi_inc

## Demonstrations

All demonstration modules can be found under the folder /demos in this project. Specific setup and build instructions can be found under each module. Note that demonstration modules will be kept in sync with the course material found on the Pluralsight course page.
