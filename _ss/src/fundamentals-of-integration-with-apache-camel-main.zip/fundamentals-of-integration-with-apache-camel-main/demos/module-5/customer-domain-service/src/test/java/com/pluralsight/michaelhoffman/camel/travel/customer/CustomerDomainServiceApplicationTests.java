package com.pluralsight.michaelhoffman.camel.travel.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerDomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
