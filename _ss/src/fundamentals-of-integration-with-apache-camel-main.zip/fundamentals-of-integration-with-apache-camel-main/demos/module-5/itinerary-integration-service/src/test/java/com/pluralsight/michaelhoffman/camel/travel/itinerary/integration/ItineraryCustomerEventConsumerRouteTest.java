package com.pluralsight.michaelhoffman.camel.travel.itinerary.integration;

import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.Test;

@CamelSpringBootTest
public class ItineraryCustomerEventConsumerRouteTest {

    @Test
    void contextLoads() {

    }
}
