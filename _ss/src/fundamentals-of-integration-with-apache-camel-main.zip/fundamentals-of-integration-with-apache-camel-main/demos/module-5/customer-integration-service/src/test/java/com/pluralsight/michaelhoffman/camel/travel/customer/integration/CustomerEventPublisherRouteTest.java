package com.pluralsight.michaelhoffman.camel.travel.customer.integration;

import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.Test;

@CamelSpringBootTest
public class CustomerEventPublisherRouteTest {

    @Test
    void contextLoads() {

    }
}
