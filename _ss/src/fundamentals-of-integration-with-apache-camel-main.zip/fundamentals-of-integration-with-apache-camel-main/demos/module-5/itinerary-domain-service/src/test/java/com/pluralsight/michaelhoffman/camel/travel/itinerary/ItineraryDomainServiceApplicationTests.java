package com.pluralsight.michaelhoffman.camel.travel.itinerary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItineraryDomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
