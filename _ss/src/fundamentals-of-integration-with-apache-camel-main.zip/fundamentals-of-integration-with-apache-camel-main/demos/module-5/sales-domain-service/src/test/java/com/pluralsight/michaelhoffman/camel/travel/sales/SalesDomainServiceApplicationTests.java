package com.pluralsight.michaelhoffman.camel.travel.sales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesDomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
