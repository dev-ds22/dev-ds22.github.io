package com.pluralsight.michaelhoffman.camel.travel.sales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesDomainServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesDomainServiceApplication.class, args);
	}

}
