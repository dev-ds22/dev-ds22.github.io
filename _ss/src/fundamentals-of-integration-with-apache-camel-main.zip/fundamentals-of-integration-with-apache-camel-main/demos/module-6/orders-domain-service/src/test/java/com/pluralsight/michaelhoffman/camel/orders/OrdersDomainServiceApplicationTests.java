package com.pluralsight.michaelhoffman.camel.orders.order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersDomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
