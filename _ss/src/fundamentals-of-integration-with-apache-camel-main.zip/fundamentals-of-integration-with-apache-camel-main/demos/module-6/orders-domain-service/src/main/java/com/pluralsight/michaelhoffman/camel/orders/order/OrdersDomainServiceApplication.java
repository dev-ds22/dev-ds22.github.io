package com.pluralsight.michaelhoffman.camel.orders.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersDomainServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdersDomainServiceApplication.class, args);
	}

}
