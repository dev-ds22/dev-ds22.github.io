package com.pluralsight.michaelhoffman.camel.orders.heldqueue.integration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class IntegrationConfig {


}
