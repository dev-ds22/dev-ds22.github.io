package com.pluralsight.michaelhoffman.camel.orders.heldqueue.integration;

import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.Test;

@CamelSpringBootTest
public class OrdersHeldQueueEventConsumerRouteTest {

    @Test
    void contextLoads() {

    }

}
