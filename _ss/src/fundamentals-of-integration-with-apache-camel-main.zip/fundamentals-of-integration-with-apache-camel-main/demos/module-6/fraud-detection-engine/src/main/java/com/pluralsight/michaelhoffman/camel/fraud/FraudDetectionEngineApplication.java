package com.pluralsight.michaelhoffman.camel.fraud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudDetectionEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudDetectionEngineApplication.class, args);
	}

}
