#!/bin/bash

/bin/kafka-topics --bootstrap-server broker:29092 --topic orders --create
