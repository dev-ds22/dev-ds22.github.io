package com.pluralsight.michaelhoffman.camel.orders.heldqueue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersHeldQueueDomainServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
