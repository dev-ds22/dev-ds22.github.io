package com.pluralsight.michaelhoffman.camel.orders.order.integration;

import com.fasterxml.jackson.core.JsonParseException;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Route that starts with a REST endpoint for publishing the event
 * and publishes to the topic
 */
@Component
public class OrderEventPublisherRoute extends RouteBuilder {

    private static final Logger log =
        LoggerFactory.getLogger(OrderEventPublisherRoute.class);

    @Value("${app.integration.host}")
    private String host;

    @Value("${server.port}")
    private String port;

    @Override
    public void configure() throws Exception {
        restConfiguration()
            .component("servlet")
            .host(host)
            .port(port)
            .bindingMode(RestBindingMode.json);

        errorHandler(defaultErrorHandler().log(log));

        onException(JsonParseException.class)
            .handled(true)
            .log(LoggingLevel.ERROR, "An exception occurred parsing the request body")
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(400))
            .setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
            .setBody().constant("Json pare exception was thrown");

        /**
         * Publish order integration events
         */
        rest("/order-integration")
            .post("/event")
                .type(OrderEvent.class)
                .consumes("application/json")
            .route()
            .removeHeader(Exchange.HTTP_METHOD)
            .removeHeader(Exchange.HTTP_PATH)
            .removeHeader(Exchange.HTTP_URI)
            .removeHeader(Exchange.HTTP_URL)
            .removeHeader("CamelServletContextPath")
            .marshal()
                .json()
            .toD("kafka:{{app.kafka.topic}}?brokers={{app.kafka.brokers}}");
    }
}
