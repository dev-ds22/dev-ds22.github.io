package com.pluralsight.michaelhoffman.camel.routetoconsole;

public class RouteToConsoleApplication {

    /**
     * Main method for running the application
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
    }
}
