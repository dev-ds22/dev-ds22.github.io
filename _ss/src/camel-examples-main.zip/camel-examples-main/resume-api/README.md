Resume API Examples
=========================

This module contains examples for the resume API. 

* resume-api-common: common code used for all the resume API examples
* resume-api-file-offset: an example that shows how to use the Resume API for processing large files 
* resume-api-fileset: an example that shows how to use the Resume API for processing a large directory
* resume-api-fileset-wal: an example that shows how to use the Resume API with the Write Ahead Log for processing a large directory
