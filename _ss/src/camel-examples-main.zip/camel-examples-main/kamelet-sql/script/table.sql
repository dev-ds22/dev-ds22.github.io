CREATE TABLE accounts ( user_id serial PRIMARY KEY, username VARCHAR ( 50 ) NOT NULL, city VARCHAR ( 50 ) NOT NULL);
