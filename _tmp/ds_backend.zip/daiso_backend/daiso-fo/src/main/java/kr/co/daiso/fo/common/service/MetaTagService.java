package kr.co.daiso.fo.common.service;

import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.service
 * fileName       : MetaTagService
 * author         : Doo-Won Lee
 * date           : 2022-05-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-02      Doo-Won Lee     최초생성
 */
@Component
public interface MetaTagService {

    //화면ID에 따른 화면 MetaTag를 조회한다.
    public Map<String, String> getMetaTagInfo(String pgId) throws Exception;
}
