package kr.co.daiso.fo.common.service;

import kr.co.daiso.fo.common.model.ClsCommonReqVO;
import kr.co.daiso.fo.common.model.ClsCommonVo;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service
 * fileName       : MobileAppVerService
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park   최초생성
 */
public interface MobileAppVerService {

    //모바일 APP버전정보를 조회한다.
//    public List<MobileAppVerVO> getMobileAppVersion(MobileAppVerVO mobileAppVerVO);
    public MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO);
}
