package kr.co.daiso.fo.common.model;

import kr.co.daiso.common.util.StringUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : CommonPathInfo
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    : 공통 경로 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02      Doo-Won Lee       최초생성
 */
@Component
public class CommonPathInfo {

    //도메인 변수
    public static String DOMAIN;
    //PC API 도메인 (클라우드에서 접근시 필요)
    public static String IDC_FO_DOMAIN;
    //Batch 도메인
    public static String BATCH_DOMAIN;
    //MO API 도메인
    public static String AWS_FO_DOMAIN;
    //PC VUE 도메인
    public static String IDC_WEB_DOMAIN;
    //MO Vue 도메인
    public static String AWS_WEB_DOMAIN;
    //AWS ELB
    public static String AWS_ELB;

    //사용 변수
    public static String	XDB_URL;  //XecureDB Url 현재 쓰는곳 전부 주석

    //Mailer
    public static String MAILER_SERVER;
    public static String MAILER_USERID;
    public static String MAILER_PASSWD;

    //Upload
    public static String UPLOAD_ROOT;
    public static String UPLOAD_FILE_PATH;
    public static String UPLOAD_FILE_TEMP_PATH;
    public static String UPLOAD_INSURANCE_PATH;
    public static String UPLOAD_IMAGE_PATH;
    public static String UPLOAD_IMAGE_TEMP_PATH;

    //브랜드인증몰 Car image file
    public static String UPLOAD_CAR_IMG_BEFORE_PATH;
    public static String UPLOAD_CAR_IMG_AFTER_PATH;
    public static String UPLOAD_CAR_IMG_URL;
    public static String UPLOAD_ENCAR_IMG_URL;
//    public static String UPLOAD_CAR_WATER_MARK_PATH;
    //브랜드인증몰 썸네일 이미지 경로
//    public static String THUMBNAIL_IMG_PATH;

    //SMS 발송 관련
    public static String CAR_INFO_FROM_SMS_TITLE;
    public static String CAR_INFO_FROM_SMS;

    //Capital
    public static String CAPITAL_URL; // 신청 url 오픈용 https
    public static String CAPITAL_URL_ADD; // 신청 url 오픈용 url뒤

    public static String DB_LINK_NAME;

    //방문예약신청 url
    public static String RESERVATION_RGST_URL;
    public static String RESERVATION_CNCL_URL;
    public static String RESERVATION_STAT_URL;

    public static String URECAR_URL;

    public static String SERVER_TYPE;

    public static String	ROOT_URL;
    public static String	ROOT_FULL_URL;
    public static String	ROOT_FULL_SSL;
    public static String	ROOT_FULL_SSL2;

    public static String	MOBILE_FULL_URL;

    @Value("${domain}")
    public void setDevDomain(String domain) { DOMAIN = domain; }

    @Value("${idc_fo_domain}")
    public void setIdcFoDomain(String idcFoDomain) { IDC_FO_DOMAIN = idcFoDomain; }

    @Value("${batch_domain}")
    public void setBatchDomain(String batchDomain) { BATCH_DOMAIN = batchDomain;  }

    @Value("${aws_fo_domain}")
    public void setAwsFoDomain(String awsFoDomain) { AWS_FO_DOMAIN = awsFoDomain; }

    @Value("${idc_web_domain}")
    public void setIdcWebDomain(String idcWebDomain) { IDC_WEB_DOMAIN = idcWebDomain; }

    @Value("${aws_web_domain}")
    public void setAwsWebDomain(String awsWebDomain) { AWS_WEB_DOMAIN = awsWebDomain;  }

    @Value("${aws_elb}")
    public void setAwsElb(String awsElb) { AWS_ELB = awsElb;  }

    @Value("${spring.xdb_url}")
    public void setXdbUrl(String xdbUrl) {
        XDB_URL = xdbUrl;
    }

    @Value("${spring.smtp.server}")
    public void setMailerServer(String mailerServer) { MAILER_SERVER = mailerServer; }

    @Value("${spring.smtp.mailer_id}")
    public void setMailerUserid(String mailerUserid) { MAILER_USERID = mailerUserid; }

    @Value("${spring.smtp.mailer_pwd}")
    public void setMailerPasswd(String mailerPasswd) { MAILER_PASSWD = mailerPasswd; }

    @Value("${spring.upload.rootpath}")
    public void setUploadRoot(String uploadRoot) { UPLOAD_ROOT = uploadRoot; }

    @Value("${spring.upload.filepath}")
    public void setUploadFilePath(String uploadFilePath) { UPLOAD_FILE_PATH = uploadFilePath; }

    @Value("${spring.upload.file_temp_path}")
    public void setUploadFileTempPath(String uploadFileTempPath) { UPLOAD_FILE_TEMP_PATH = uploadFileTempPath; }

    @Value("${spring.upload.insurance_path}")
    public void setUploadInsurancePath(String uploadInsurancePath) { UPLOAD_INSURANCE_PATH = uploadInsurancePath; }

    @Value("${spring.upload.img_path}")
    public void setUploadImagePath(String uploadImagePath) { UPLOAD_IMAGE_PATH = uploadImagePath; }

    @Value("${spring.upload.img_temp_path}")
    public void setUploadImageTempPath(String uploadImageTempPath) { UPLOAD_IMAGE_TEMP_PATH = uploadImageTempPath; }

//    public static void setUploadCarImgBeforePath(String uploadCarImgBeforePath) { UPLOAD_CAR_IMG_BEFORE_PATH = uploadCarImgBeforePath;  }

    @Value("${spring.upload.car_img_after_path}")
    public void setUploadCarImgAfterPath(String uploadCarImgAfterPath) { UPLOAD_CAR_IMG_AFTER_PATH = uploadCarImgAfterPath; }

    @Value("${spring.upload.car_img_url}")
    public void setUploadCarImgUrl(String uploadCarImgUrl) { UPLOAD_CAR_IMG_URL = uploadCarImgUrl; }

//    public static void setUploadEncarImgUrl(String uploadEncarImgUrl) { UPLOAD_ENCAR_IMG_URL = uploadEncarImgUrl; }

//    @Value("${spring.upload.car_water_mark_path}")
//    public void setUploadCarWaterMarkPath(String uploadCarWaterMarkPath) { UPLOAD_CAR_WATER_MARK_PATH = uploadCarWaterMarkPath; }

//    @Value("${spring.upload.thumb_img_path}")
//    public void setThumbnailImgPath(String thumbnailImgPath) { THUMBNAIL_IMG_PATH = thumbnailImgPath; }

    @Value("${sms.car_info_from_sms_title}")
    public void setCarInfoFromSmsTitle(String carInfoFromSmsTitle) { CAR_INFO_FROM_SMS_TITLE = carInfoFromSmsTitle; }

    @Value("${sms.car_info_from_sms}")
    public void setCarInfoFromSms(String carInfoFromSms) { CAR_INFO_FROM_SMS = carInfoFromSms;  }

    @Value("${capital.capital_url}")
    public void setCapitalUrl(String capitalUrl) { CAPITAL_URL = capitalUrl;  }

    @Value("${capital.capital_url_add}")
    public void setCapitalUrlAdd(String capitalUrlAdd) { CAPITAL_URL_ADD = capitalUrlAdd; }

    @Value("${pms_full_ssl}")
    public void setRootFullSsl(String rootFullSsl) {  ROOT_FULL_SSL = rootFullSsl;  }

    @Value("${mobile_full_ssl}")
    public void setMobileFullSsl(String mobileFullSsl) { MOBILE_FULL_SSL = mobileFullSsl; }

    @Value("${pcc_service_no}")
    public void setPccServiceNo(String pccServiceNo) {
        PCC_SERVICE_NO = pccServiceNo;
    }

    @Value("${pcc_mobile_service_no}")
    public void setPccMobileServiceNo(String pccMobileServiceNo) {
        PCC_MOBILE_SERVICE_NO = pccMobileServiceNo;
    }

    @Value("${pcc_ipin_service_no}")
    public void setPccIpinServiceNo(String pccIpinServiceNo) {
        PCC_IPIN_SERVICE_NO = pccIpinServiceNo;
    }

    @Value("${pcc_mobile_ipin_service_no}")
    public void setPccMobileIpinServiceNo(String pccMobileIpinServiceNo) { PCC_MOBILE_IPIN_SERVICE_NO = pccMobileIpinServiceNo; }

    @Value("${pms_full_ssl2}")
    public void setRootFullSsl2(String rootFullSsl2) { ROOT_FULL_SSL2 = rootFullSsl2;  }

    @Value("${mobile_full_ssl2}")
    public void setMobileFullSsl2(String mobileFullSsl2) {  MOBILE_FULL_SSL2 = mobileFullSsl2; }

    @Value("${dblink}")
    public void setDbLinkName(String dbLinkName) { DB_LINK_NAME = dbLinkName; }

    @Value("${reservation.rgst_url}")
    public void setReservationRgstUrl(String reservationRgstUrl) { RESERVATION_RGST_URL = reservationRgstUrl;  }

    @Value("${reservation.cncl_url}")
    public void setReservationCnclUrl(String reservationCnclUrl) { RESERVATION_CNCL_URL = reservationCnclUrl;  }

    @Value("${reservation.stat_url}")
    public void setReservationStatUrl(String reservationStatUrl) { RESERVATION_STAT_URL = reservationStatUrl;  }

    @Value("${urecaUrl}")
    public void setUrecarUrl(String urecarUrl) { URECAR_URL = urecarUrl; }

    @Value("${spring.server_type}")
    public void setServerType(String serverType) { SERVER_TYPE = serverType; }

    @Value("${pms_full_url}")
    public void setRootFullUrl(String rootFullUrl) {
        ROOT_FULL_URL = rootFullUrl;

        IMG_PATH		= ROOT_FULL_URL	+ "resources/images/";
        CSS_PATH		= ROOT_FULL_URL	+ "CSS/";
        SCRIPT_PATH		= ROOT_FULL_URL	+ "resources/js/system/common/";
        EDITOR_PATH		= ROOT_FULL_URL	+ "editor/";
        FLASH_PATH		= ROOT_URL	+ "SWF/";

        PASS_URL_LIST = new ArrayList<>();
        PASS_URL_LIST.add("/mobile/search/search_page.do");
        PASS_URL_LIST.add("/mobile/search/search_list_a.do");
        PASS_URL_LIST.add("/mobile/search/search_list_b.do");
        PASS_URL_LIST.add("/mobile/carinfo/car_info_detail.do");
    }

    @Value("${mobile_full_ssl}")
    public void setMobileFullUrl(String mobileFullUrl) { MOBILE_FULL_URL = mobileFullUrl; }

    public static String	MOBILE_FULL_SSL;
    public static String	MOBILE_FULL_SSL2;
    public static String	MOBILE_DOMAIN_URL;
    public static String	IMG_PATH;
    public static String	CSS_PATH;
    public static String	FLASH_PATH;
    public static String	SCRIPT_PATH;
    public static String	EDITOR_PATH;

    public static String	UPLOAD_CAR_IMAGE_PATH;
    public static String	UPLOAD_CAR_IMAGE_TEMP_PATH;
    public static String 	CHARSET		= "UTF-8";
    public static String	PASSCODE;
    public static String	SECRET_AES_KEY;

    public static String	IMG_URL;
    public static String	CDN_IF_URL;

    public static String LEASE_CAR_IMG_URL;

    public static String LEASE_BEFORE_PATH;
    public static String LEASE_AFTER_PATH;
    public static String SELF_IF_URL;
    public static String SCRAP_IF_URL;

    public static String RENT_CAR_IMG_URL;
    public static String RENT_AFTER_PATH;
    public static String POST_URL;
    public static String POST_REGKEY;
    public static String POST_TARGET;
    public static String POST_COUNTPERPAGE;
    public static String POST_VALNM_REGKEY;
    public static String POST_VALNM_TARGET;
    public static String POST_VALNM_QUERY;
    public static String POST_VALNM_COUNTPERPAGE;
    public static String POST_VALNM_CURRENTPAGE;

    public static String CAR_INFO_FROM_NAME;
    public static String CAR_INFO_FROM_EMAIL;

    public static String SERVER_PROFILE;
    /**
     * @deprecated {@link kr.co.daiso.fo.common.model.CommonPathInfo#SERVER_TYPE} 으로 대체됨
     */
    public static String STATUS;

    public static String BATCH_STATUS;
    public static String PCC_SERVICE_NO;
    public static String PCC_IPIN_SERVICE_NO;

    public static String PCC_MOBILE_SERVICE_NO;
    public static String PCC_MOBILE_IPIN_SERVICE_NO;

    /* 검색 API */
    public static String KSF_SERVER_URL;
    public static String KSF_SERVER_PORT;
    public static String KSF_ACTION_SEARCH;
    public static String KSF_SERVER_VOLUME;
    public static String KSF_SERVER_TABLE;
    public static String KSF_SERVER_MODEL_VOLUME;
    public static String KSF_SERVER_MODEL_TABLE;
    /* 검색 API */

    /* Cache Update */
    private static String CSS_CACHE_VERSION = "";
    private static String SCRIPT_CACHE_VERSION = "";
    /* Cache Update */

    public static String UCMS_URL;

    public static String CAR_HISTORY_URL;

    public static String CAPITAL_URL_HTTP; // 신청 url 오픈용 http

    // 제휴시세 중계 서버 ROOT URL
    public static String MYSELL_ALLIANCE_SERVER;

    // 제휴시세 조회 중계 서버
    public static String MYSELL_IF_SERVER;

    // 제휴시세 조회 중계 서버 - 카카오모빌리티
    public static String MYSELL_KM_IF_SERVER;

    /** 확인 url */
    public static String CAPITAL_API_URL;
    @Value("${capital.capital_api_url}")
    public void setCapitalApiUrl(String capitalApiUrl) { CAPITAL_API_URL = capitalApiUrl; }

    /** 확인 url url뒤 */
    public static String CAPITAL_URL_CHECK;
    @Value("${capital.capital_url_check}")
    public void setCapitalUrlCheck(String capitalUrlCheck) { CAPITAL_URL_CHECK = capitalUrlCheck; }


    //PG사 설정파일
    public static String EASYPAY_MALL_ID;
    @Value("${pg.easypay_mall_id}")
    public void setEasypayMallId(String easypayMallId) { EASYPAY_MALL_ID = easypayMallId; }

    public static String EASYPAY_MALL_NAME;
    @Value("${pg.easypay_mall_name}")
    public void setEasypayMallName(String easypayMallName) { EASYPAY_MALL_NAME = easypayMallName; }

    public static String EASYPAY_PG_URL;
    @Value("${pg.easypay_pg_url}")
    public void setEasypayPgUrl(String easypayPgUrl) { EASYPAY_PG_URL = easypayPgUrl; }

    public static String EASYPAY_SP_URL;
    @Value("${pg.easypay_sp_url}")
    public void setEasypaySpUrl(String easypaySpUrl) { EASYPAY_SP_URL = easypaySpUrl; }

    public static String EASYPAY_GW;
    @Value("${pg.easypay_gw}")
    public void setEasypayGw(String easypayGw) { EASYPAY_GW = easypayGw; }

    public static String EASYPAY_CERT_FILE;
    @Value("${pg.easypay_cert_file}")
    public void setEasypayCertFile(String easypayCertFile) { EASYPAY_CERT_FILE = easypayCertFile; }

    public static String EASYPAY_LOG_DIR;
    @Value("${pg.easypay_log_dir}")
    public void setEasypayLogDir(String easypayLogDir) { EASYPAY_LOG_DIR = easypayLogDir; }

    public static String EASYPAY_OFFICE_URL;
    @Value("${pg.easypay_office_url}")
    public void setEasypayOfficeUrl(String easypayOfficeUrl) { EASYPAY_OFFICE_URL = easypayOfficeUrl; }

    /** 사용가능한 카드 목록 (카드코드1:카드코드2:...:카드코드N) */
    public static String AVAIL_CARD_CODE;
    @Value("${pg.avail_card_code}")
    public void setAvailCardCode(String availCardCode) { AVAIL_CARD_CODE = availCardCode; }

    /* 브랜드인증몰 - 20200731 Start */
    //차량검색 onlie 설정파일

    public static String BC_AFTER_PATH;
    public static String BC_BEFORE_PATH;
    public static String BC_CAR_IMG_URL;


    public static String CAR_IMG_BEFORE_PATH;
    public static String CAR_IMG_AFTER_PATH;
    public static String CAR_IMG_URL;
    public static String ENCAR_IMG_URL;

    /* 브랜드인증몰 - 20200731 End */

    public static List<String> PASS_URL_LIST;

    // IF_UCMS_URL
    // 인터페이스 용 url
    public static String IF_UCMS_URL; // url 도메인

    /** 도메인 이후 url */
    public static String IF_UCMS_URL_AFTER;
    @Value("${if_ucms_url_after}")
    public void setIfUcmsUrlAfter(String ifUcmsUrlAfter) { IF_UCMS_URL_AFTER = ifUcmsUrlAfter; }

    /** 우리은행 가상계좌 계좌명 */
    public static String VIRTUAL_AC_NAME;
    @Value("${ac.virtual_ac_name}")
    public void setVirtualAcName(String virtualAcName) { VIRTUAL_AC_NAME = virtualAcName; }

    /** 가상계좌 확인 API */
    public static String VIRTUAL_AC_DATA;
    @Value("${ac.virtual_ac_data}")
    public void setVirtualAcData(String virtualAcData) { VIRTUAL_AC_DATA = virtualAcData;}

    /** 홈서비스 내차팔기 제휴 시세조회 중계서버 */
    @Value("${mysell.alliance_server}")
    public void setMysellAllianceServer(String mysellAllianceServer) { MYSELL_ALLIANCE_SERVER = mysellAllianceServer; }

    /** 제휴시세 조회 중계 서버 */
    @Value("${mysell.if_server}")
    public void setMysellIfServer(String mysellIfServer) { MYSELL_IF_SERVER = mysellIfServer; }

    /** 제휴시세 조회 중계 서버 - 카카오모빌리티 */
    @Value("${mysell.km_if_server}")
    public void setMysellKmIfServer(String mysellKmIfServer) { MYSELL_KM_IF_SERVER = mysellKmIfServer; }

    @Value("${container}")
    public static String CONTAINER;

    public void setCONTAINER(String CONTAINER) { CommonPathInfo.CONTAINER = StringUtil.defaultString(CONTAINER).trim(); }

    public static boolean equalsServer(String serverType) {
        return StringUtil.containsIgnoreCase(CommonPathInfo.SERVER_TYPE, serverType);
    }

    public static boolean equalsAnyServer(String serverType1, String serverType2) {
        return StringUtil.containsAnyIgnoreCase(CommonPathInfo.SERVER_TYPE, serverType1, serverType2);
    }
}
