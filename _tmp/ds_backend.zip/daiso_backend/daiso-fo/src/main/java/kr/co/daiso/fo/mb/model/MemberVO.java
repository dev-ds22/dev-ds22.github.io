package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * packageName    : kr.co.daiso.fo.mb.model
 * fileName       : MemberVO
 * author         : kjm
 * date           : 2022-02-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MemberVO extends BaseModel {

    private String membCd;
    private String membKnd;

    @NotBlank(message = "아이디는 필수입니다.")
    private String membId;

    @NotBlank(message = "비밀번호는 필수입니다.")
    @Pattern(message = "비밀번호 형식이 맞지 않습니다.", regexp = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[`~!@#$%*^+=_-])[\\w`~!@#$%*^+=_-]{8,20}$")
    private String pwd;

    private String membNm;
    private String atclAgreYn;
    private String indvInfoAgreYn;
    private String birdt;
    private String nicknm;
    private String ctad;
    private String mbpno;
    private String email;
    private String emailRcvAgreYn;
    private String phtoNm;
    private String phtoPath;
    private String phtoExt;
    private String intrst;
    private String etcInq;
    private String cdno;
    private String wtdrYn;
    private String wtdrDt;
    private String wtdrRsn;
    private String sex;
    private String joinChnl;
    private String chmuId;
    private String moblcrr;
    private String sidoDvs;
    private String carKnd;
    private String mnuftr;
    private String model;
    private String grd;
    private String dtlGrd;
    private String smsRcvAgreYn;
    private String ovlapKey;
    private String indvInfoChcAgreYn;
    private String pwdErrCnt;
    private String usrRgn;
    private String joinPath;
    private String joinPathDrectInp;
    private String fnlCnntnDt;
    private String pchsHopeDd;
    private String dlercoCd;
    private String shwroomCd;
    private String dealEmpcrdNo;
    private String fstLoginYn;
    private String adaptSrcCarUse;
    private String adaptSrcPrefCarctgr;
    private String adaptSrcPchsBdgt;
    private String adaptSrcRgnCd;
    private String adaptSrcAgegCd;
    private String adaptSrcSex;

    private String cnntnDttm;   // 접속일시
    private String cnntnIp;     // 접속아이피
    private String loginRslt;   // 로그인결과

    private String tblNm;
    private boolean saveId;
    private String numCheck;
    private String isMobile;
    private String staffCheck;
    private String redisKey;
    private String retInfo;
    private String ipinInfo;
    private String pccV3Info;
    private String errHapnRelocUrl;
    private String errHapnUrl;

    private boolean autoLogin;
}
