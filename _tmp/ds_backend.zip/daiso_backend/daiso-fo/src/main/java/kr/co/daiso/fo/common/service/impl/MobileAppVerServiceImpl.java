package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.fo.common.mapper.oracle.CommonCodeManageMapper;
import kr.co.daiso.fo.common.mapper.oracle.MobileAppVerMapper;
import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;
import kr.co.daiso.fo.common.service.CommonCodeService;
import kr.co.daiso.fo.common.service.MobileAppVerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : MobileAppVerServiceImpl
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    : CommonCodeService 구현체 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park   최초생성
 */
@Slf4j
@Service
public class MobileAppVerServiceImpl implements MobileAppVerService {

    @Autowired
    MobileAppVerMapper mobileAppVerMapper;

    /**
     * methodName : getMobileAppVersion
     * author : Byung-chul Park
     * description : 모바일 APP버전정보를 조회한다.
     *
     * @param  mobileAppVerVO
     * @return MobileAppVerVO
     */
    @Override
    public MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO) {
//        public List<MobileAppVerVO> getMobileAppVersion(MobileAppVerVO mobileAppVerVO) {
        return mobileAppVerMapper.getMobileAppVersion(mobileAppVerVO);
    }


}
