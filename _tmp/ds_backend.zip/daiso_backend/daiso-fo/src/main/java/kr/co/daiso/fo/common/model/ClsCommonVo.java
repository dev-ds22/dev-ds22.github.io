package kr.co.daiso.fo.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * packageName    : kr.co.daiso.fo.bc.model
 * fileName       : ClsCommonVo
 * author         : 이강욱
 * date           : 2022-04-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18       이강욱            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCommonVo {
	// ECC_SUBCODE > TB_CM_SUB_CD
	/** 마스터 코드 */
	private String	v_mst_code;
	/** 서브 코드 */
	private String	v_sub_code;
    /** 서브 코드명 */
	private String	v_sub_codenm;
	/** 정렬순서 */
	private int		n_seqno;
	/** 추가필드1 */
	private String	v_buffer1;
	/** 추가필드2 */
	private String	v_buffer2;
	/** 추가필드3 */
	private String	v_buffer3;
	/** 추가필드11 */
	private String	v_buffer11;
	/** 추가필드12 */
	private String	v_buffer12;
	/** 추가필드13 */
	private String	v_buffer13;
	/** 추가필드14 */
	private String	v_buffer14;
	/** 추가필드15 */
	private String	v_buffer15;

//	private String	v_sido_code;
//	private String	v_gugun_code;
//	private String	v_sido;
//	private String	v_gugun;
//	private double	n_gugun_x;
//	private double	n_gugun_y;
//
//	private String	v_zipcode;
//	private String	v_dong;
//	private String	v_bunji;
//	private int		n_seq;
//	private double	n_point_x;
//	private double	n_point_y;
//
//	private	String	v_center_code;
//	private	String	v_center_region;
//	private	String	v_center_name;
//	private	String	v_center_type;
//	private	String	v_post;
//	private	String	v_addr1;
//	private	String	v_addr2;
//	private	String	v_phone;
//	private	String	v_office_hours;
//	private	String	v_usercd;
//	private	String	v_userid;
//
//	//main support
//	private	int		n_sail_condition;
//	private	double	n_installment_rate;
//	private	int		n_before_discount;
//	private	int		n_partner_discount;
//	private	String	v_support_month;
//	private String	v_link;
//	private	String	v_sail_carnm;
//
//	private String	v_menuid;
//	private String	v_umenuid;
//	private String	v_menunm;
//	private String  v_menu_type;
//	private String	v_page_url;
//	private String	v_flag_page;
//	private String	v_left_menu_yn;
//
//	//excel
//	private String	v_file_id;
//	private String	v_file_path;
//	private String	v_file_ext;
//	private String	v_ori_file_id;
//	private String	v_reg_userid;
//	private String	v_reg_dtm;
//	private String	v_usernm;
//
//	private String	v_makecd;
//	private String	v_modelcd;
//	private String	v_makenm;
//	private String	v_modelnm;
//
//	private String	v_page_title;
//	private String	v_page_name;
//	private String	v_smscd;
//	private String	v_tran_phone;
//	private String	v_tran_callback;
//	private String	v_message;
//	private String	v_flag_status;
//	private String	v_recivercd;
//	private String	v_channel;
//
//	private String	v_region;
//	private int			n_count;
//	private int			n_tot_count;
//	private String	v_email;
//	private String	v_flag;
//	private	String	v_blog;
//	private String	v_twitter;
//	private	String	v_photo_path;
//	private String	v_photo_name;
//	private	String	v_photo_ext;
//
//	//덧글
//	private String	v_boardcd;
//	private String	v_replyid;
//	private String	v_ureplyid;
//	private String	v_content;
//	private String	v_reg_usercd;
//	private String	v_reg_usernm;
//	private String	v_update_usercd;
//	private String	v_update_usernm;
//	private String	v_update_dtm;
//	private String	v_reply_yn;
//	private int		n_reply_cnt;
//	private String	v_del_flag;
//	private int		n_all_reply_cnt;
//	private String	v_user_ip;
//	private int		n_page_level;
//	private String	v_sell_userid;
//	private String	v_sell_center_code;
//	private String	v_sell_trust_userid;
//	private String	v_sell_trust_center_code;
//	private String	v_help_userid;
//	private String	v_help_center_code;
//	private String	v_admin_check;
//	private String	v_memberid;
//	private String	v_help_center_name;
//	private String	v_help_usernm;
//	private String	v_mst_cd;
//	private String	v_sub_cd;
//	private String	v_sub_nm;
//	private String	v_sub_nm_eng;
//	private String	v_flag_use;
//	private String	v_zipcode1;
//	private String	v_zipcode2;
//	private String	v_mun;
//	private String	v_dolo;
//	private String	v_gunmul_first;
//	private String	v_gunmul_second;
//	private String	v_gunmul;
//	private String	v_gugun_gunmul_name;
//	private String	v_bubjung;

//	private String  v_meta_keyword;
//	private String  v_meta_desc;
//	private String  v_contents_add_flag;
}
