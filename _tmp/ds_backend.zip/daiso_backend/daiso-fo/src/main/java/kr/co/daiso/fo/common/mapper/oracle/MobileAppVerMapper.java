package kr.co.daiso.fo.common.mapper.oracle;

import kr.co.daiso.fo.common.model.MobileAppVerVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.fo.common.mapper.oracle
 * fileName       : MobileAppVerMapper
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29    Byung-Chul Park      최초생성
 */
@Mapper
public interface MobileAppVerMapper {

    //모바일 APP버전정보를 조회한다.
    MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO);

}
