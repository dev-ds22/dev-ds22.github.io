package kr.co.daiso.fo.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : ClsCarInfoVo
 * author         : 이강욱
 * date           : 2022-04-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18       이강욱            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCarInfoVo {
	/** 차량코드 V_CARCD */
	private String carCd;
//	private String  v_encarcd;
//	private String  v_sellercd;
//	private String  v_status;
//	private String  v_status_name;
//	private String  v_status_dtm;
//	private String  v_type;
//	private String  v_type_name;
//	private String  v_categorycd;
//	private String  v_categorynm;
//	private String  v_makecd;
	/** 제조사명 V_MAKENM */
	private String  mnuftrNm;
//	private String  v_makenm_eng;
//	private String  v_make_type;
//	private String  v_model_grp_cd;
//	private String  v_model_grp_nm;
//	private String  v_modelcd;
	/** 모델명 V_MODELNM */
	private String  modelNm;
//	private String  v_modelnm_eng;
//	private String  v_class_headcd;
	/** 등급명 V_CLASS_HEADNM */
	private String  grdNm;
//	private String  v_class_detailcd;
	/** 세부 등급명 V_CLASS_DETAILNM */
	private String  grdDtlNm;
	/** 등급 + 상세등급 명 V_CLASSNM */
	private String  grdWhlNm;
	/** 차량번호 V_CAR_NUMBER */
	private String  cno;
	/** 제조일 V_MFR_DATE */
	private String  mfgDt;
//	private String  v_mfr_year;
//	private String  v_vin_num;
//	private int     n_mileage;
//	private int     n_engine_volume;
//	private int     n_engine_power;
	/** 판매가격 N_PRICE */
	private int     salprc;
//	private int     n_price_full_type;
//	private String  v_steeringcd;
//	private String  v_steeringcd_name;
//	private String  v_transmissioncd;
//	private String  v_transmissioncd_name;
//	private String  v_fuel_typecd;
//	private String  v_fuel_typecd_name;
//	private String  v_doorcd;
//	private String  v_drive_axlecd;
//	private String  v_exterior_colorcd;
//	private String  v_exterior_colornm;
//	private String  v_youtube_id;
//	private String  v_simple_comment;
//	private String  v_insp_date;
//	private int     n_view_cnt;
//	private int     n_popular_cnt;
//	private String  v_thumbnailid;
//	private String  v_thumbnail_path;
//	private String  v_thumbnail_web_path;
//	private String  v_thumbnail_ext;
//	private String  v_optioncd;
//	private String  v_optioncd_name;
//	private String  v_option_type;
//	private String  v_search_type;
//	private String  v_sido;
//	private String  v_gugun;
//	private String  v_sido_code;
//	private String  v_gugun_code;
//	private String  v_center_code;
//	private String  v_center_name;
//	private String  v_center_type;
//	private String  v_center_fax;
//	private String  v_address;
//	private String  v_reg_dtm;
//	private String  v_premium_reg_dtm;
	/** 판매자명 V_USERNM */
	private String  usrNm;
	private String  selerNm; // usrNm로 대체
//	private String  v_userid;
//	private String  v_position;
//	private String  v_usernm_sub;
//	private String  v_position_sub;
//	private String  v_sub_default_usercd;
	/** 휴대폰번호 V_MOBILE */
	private String  mpno;
//	private String  v_phone;
//	private String  v_way_sub;
//	private String  v_way_car;
//	private String  v_way_bus;
//	private String  v_map_file_name;
//	private String  v_map_file_path;
//	private String  v_map_file_ext;
//	private String  v_photo_name;
//	private String  v_photo_path;
//	private String  v_photo_ext;
//	private String  v_small_img;
//	private String  v_middle_img;
//	private String  v_big_img;
//	private String  v_img_s_width;
//	private String  v_img_m_width;
//	private String  v_img_b_width;
//	private String  v_center_img_id;
//	private String  v_center_small_img;
//	private String  v_center_middle_img;
//	private String  v_center_big_img;
//	private String  v_office_hours;
//	private String  v_car_detail;
//	private String  v_car_detail2;
//	private String  v_sub_code;
//	private String  v_sub_codenm;
//	private String  v_buffer1;
//	private String  v_buffer2;
//	private String  v_buffer3;
	/** 사용자코드 V_USERCD */
	private String  usrCd;
//	private String  v_key_value;
//	private String  v_nsp_dtm;
//	private String  v_rec_comment;
//	private String  v_warranty_yn;
//	private String  v_result_type;
//	private String  v_result_cd1;
//	private String  v_result_cd2;
//	private String  v_declear_number;
//	private String  v_flag_del;
//	private String  v_check_usercd;
//	private String  v_sub_check_usercd;
//	private String  v_office_name;
//	private String  v_office_post;
//	private String  v_office_addr;
//	private String  v_office_phone;
//	private String  v_asso_name;
//	private String  v_asso_phone;
//	private String  v_comment;
//	private String  v_pn;
//	private String  v_cal_date;
//	private int     n_car_id;
//
//	private String  v_today_date;
//	private String  v_1day_date;
//	private String  v_2day_date;
//
//	private int     n_total_cnt;
//	private int     n_viewer_cnt;
//	private int     n_viewer010_cnt;
//	private int     n_viewer020_cnt;
//	private int     n_viewer030_cnt;
//	private int     n_viewer040_cnt;
//	private int     n_today_cnt;
//	private int     n_today_viewer_cnt;
//	private int     n_1day_cnt;
//	private int     n_1day_viewer_cnt;
//	private int     n_2day_cnt;
//	private int     n_2day_viewer_cnt;
//	private int     n_type010_cnt;
//	private int     n_type020_cnt;
//	private int     n_type030_cnt;
//	private int     n_type040_cnt;
//	private String  v_date;
//	private String  v_day;              // 요일
//	private String  v_message;
//	private String  v_email;
//	private String  v_center_region;
//	private String  v_center_regionnm;
//	private String  v_hot_markcd;
//	private String  v_hot_marknm;
//	private String  v_offoce_hours;
//	private String  v_engine_type;
//	private String  v_wheel;
//	private String  v_wheelnm;
	/** 등록연식 V_BEGIN_YEAR */
	private String  regModelyr;
	private String  modelyr; // regModelyr로 대체
//
//	private String  v_seller_name;
//	private String  v_seller_addr;
//	private String  v_seller_mobile;
//	private String  v_sell_empid;
//	private String  atcar_deal_empcrd_no;
//	private String  v_org_mfr;
//	private int		n_mgt_cost;
//	private int		n_reg_apl_act_cmsn;
//
//	//시세관련
//	private int     t_price_01;
//	private int     t_price_02;
//	private int     t_price_03;
//	private int     t_price_04;
//	private int     t_price_05;
//	private int     t_price_06;
//	private int     t_price_07;
//	private int     t_price_08;
//	private int     t_price_09;
//	private int     t_price_10;
//	private int     m_price_01;
//	private int     m_price_02;
//	private int     m_price_03;
//	private int     m_price_04;
//	private int     m_price_05;
//	private int     m_price_06;
//	private int     m_price_07;
//	private int     m_price_08;
//	private int     m_price_09;
//	private int     m_price_10;
//	private int     l_price_01;
//	private int     l_price_02;
//	private int     l_price_03;
//	private int     l_price_04;
//	private int     l_price_05;
//	private int     l_price_06;
//	private int     l_price_07;
//	private int     l_price_08;
//	private int     l_price_09;
//	private int     l_price_10;
//	private int     max_yr;
//	private int     min_yr;
//	private String  v_year;
//	private String  v_month;
//	private String  v_week;
//	private String  v_weeknm;
//	private String  v_price_week;
//
//	//이벤트 리스관련
//	private String  n_lease_1;
//	private String  n_lease_2;
//	private String  n_lease_3;
//
//	//이달에 판매차량
//	private String  v_event_yn;
//	private int     n_sail_condition;
//
//	//시세관련
//	private String  v_content;
//	private String  v_file;
//	private int     n_order;
//	private String  v_yr;
//	private int     n_control_price;
//	private int     n_depreciation_top;
//	private int     n_depreciation_medium;
//	private int     n_depreciation_low;
//	private String  v_week_of_year;
//
//	//진단결과
//	private String  nspdt;
//	private String  nspknb;
//	private String  empid;
//	private String  realdt;
//	private String  effectdt;
//	private String  checker;
//	private int     inspfee;
//	private int     trnsno;
//	private String  checkerid;
//	private String  resutype;
//
//	private String  v_mst_code;
//	private String  resu;
//	private String  ref;
//	private String  dtlcheck;
//	private String  dtlcheck_txt;
//	private String  dtlcheck_txt_2;
//	private String  memo;
//	private String  soso;
//
//	private String  v_pure_yn;
//	private String  guaranty;
//
//	private String  v_create_dt;
//	private String  v_sold_dtm;
//	private int     n_buy_price;
//	private int     n_sold_price;
//	private int     n_market_price;
//	private int     n_dis_price;
//
//	//네이버 신디케이션
//	private String  v_id;
//	private String  v_title;
//	private String  v_link;
//	private String  v_channel_link;
//	private String  v_channel;
//	private String  v_channelnm;
//
//	private String  view_type;
//	private int     n_event_no;
//	private String  v_bank;
//	private String  v_bank_account;
//	private String  v_visit_m;
//	private String  v_visit_d;
//	private String  v_visit_t;
//	private int     n_deposit;
//	private String  v_present;
//	private String  v_reser_flag;
//	private String  v_statusnm;
//	private String  v_reserve_dtm;
//	private int     n_jjim_cnt;
//	private int     n_reserve_cnt;
//	private int     n_c010_cnt;
//	private int     n_c020_cnt;
//	private int     n_c030_cnt;
//	private int     n_c040_cnt;
//	private String  v_car_status;
//	private String  v_car_statusnm;
//	private String  v_compl_flag;
//	private String  v_banknm;
//	private String  v_refund;
//	private int     n_event_check;
//	private String  v_result;
//	private String  v_themecd;
//	private String  v_elan_path;
//	private int     n_min_price;
//	private int     n_max_price;
//	private int     n_min_mfr_year;
//	private int     n_max_mfr_year;
//	private int     n_min_mileage;
//	private int     n_max_mileage;
//	private int     n_cnt;
//	private String  v_user_center_name;
//	private String  v_nmap_x;
//	private String  v_nmap_y;
//	private int     n_sale_day;
//	private String  v_johap_no;
//	private String  v_trust_flag;
//	private String  v_center_region_name;
//	private String  v_search_cd;
//	private String  v_year2;
//	private int     n_test_event_check;
//
//	// 리스승계
//	private String  v_buy_type;
//	private String  rgsid;
//	private int     buyout;
//	private int     monthlease;
//	private int     deposit;
//	private int     residualvalue;
//	private int     restmonth;
//	private int     totalmonth;
//	private int     principal;
//	private String  startdt;
//	private String  enddt;
//	private String  leasegbn;
//	private String  v_jindan_usernm;
//	private String  v_jindan_center_name;
//	private String  v_truck_flag;
//	private String  v_alsuntype;
//	private String  v_mstnm;
//	private String  v_centercd;
//	private String  v_lease_div        ;
//	private String  v_call_number      ;
//	private String  v_fst_con_per      ;
//	private String  v_reman_per        ;
//	private String  v_ad_dtm           ;
//	private int     n_lease_per1       ;
//	private int     n_lease_per2       ;
//	private String  v_option_cd        ;
//	private String  v_reg_usercd       ;
//	private String  v_update_dtm       ;
//	private String  v_update_usercd    ;
//	private int     n_fst_buy_price    ;
//	private String  v_maker_warranty   ;
//	private String  v_now_user         ;
//	private String  v_acc_yn    ;
//	private String  v_buyer_name    ;
//	private String  v_buyer_post    ;
//	private String  v_buyer_addr1   ;
//	private String  v_buyer_addr2   ;
//	private String  v_buyer_phone   ;
//	private String  n_ad_dtm;
//	private String  v_lease_divnm;
//	private String  v_lease_start_dtm;
//	private String v_counsel_contents;
//	private String v_lease_succ_status;
//	private String v_car_loc_branch;
//	private String n_lease_price;
//	// 알선
//	private String  crpctpth001;
//	private String  pic_desc001;
//	private String  crpctpth002;
//	private String  pic_desc002;
//	private String  crpctpth003;
//	private String  pic_desc003;
//	private String  crpctpth004;
//	private String  pic_desc004;
//	private String  crpctpth005;
//	private String  pic_desc005;
//	private String  crpctpth006;
//	private String  pic_desc006;
//	private String  crpctpth007;
//	private String  pic_desc007;
//	private String  crpctpth008;
//	private String  pic_desc008;
//	private String  crpctpth009;
//	private String  pic_desc009;
//	private String  crpctpth010;
//	private String  pic_desc010;
//	private String  crpctpth011;
//	private String  pic_desc011;
//	private String  crpctpth012;
//	private String  pic_desc012;
//	private String  crpctpth013;
//	private String  pic_desc013;
//	private String  crpctpth014;
//	private String  pic_desc014;
//	private String  car_img_url001;
//	private String  car_img_url002;
//	private String  car_img_url003;
//	private String  car_img_url004;
//	private String  car_img_url005;
//	private String  car_img_url006;
//	private String  car_img_url007;
//	private String  car_img_url008;
//	private String  car_img_url009;
//	private String  car_img_url010;
//	private String  car_img_url011;
//	private String  car_img_url012;
//	private String  car_img_url013;
//	private String  car_img_url014;
//	private String  crpctpth;
//	private String  pic_desc;
//	private String  car_img_url;
//	private String  img_url;
//	private String  optncd;
//	private String  optnnm;
//	private String  cscd;
//	private String  dtlcd;
//	private String  pure;
//
//	private int n_rgsid;
//	private String  v_elan_rgsid;
//	private String  v_rgsid;
//	private String  v_tmanageno;
//	private String  v_nowcrno;
//	private String  v_mnfcnm;
//	private String  v_mdlnm;
//	private String  v_clsheadnm;
//	private String  v_clsdetailnm;
//	private String  v_car_info;
//	private String  trns;
//	private String  mlg;
//	private String  whatfuel;
//	private String  v_crprc;
//	private String  v_hopecrprc;
//	private String  v_complexnm;
//	private String  v_officenm;
//	private String  v_dealnm;
//	private String  v_dealer_mphn;
//	private String  v_reco_state;
//	private String  v_sell_fg;
//	private String  v_buy_dt;
//	private String  v_asso_nm;
//	private String  v_asso_phn;
//	private String  v_supply_num;
//	private String  v_supply_dt;
//	private String  v_complex_nm;
//	private String  v_office_nm;
//	private String  v_dealer_nm;
//	private String  v_office_phn;
//	private String  v_office_mphn;
//	private String  v_becrno;
//	private String  v_carbodynb;
//	private String  v_mnfccd;
//	private String  v_mdlcd;
//	private String  v_clsheadcd;
//	private String  v_clsdetailcd;
//	private String  v_outday;
//	private String  v_outday1;
//	private String  v_outday2;
//	private String  v_outday3;
//	private String  v_beginyr;
//	private int     n_mlg;
//	private String  v_fuelcd;
//	private String  v_trns;
//	private int     n_dsp;
//	private int     n_dmndprc;
//	private String  v_clr;
//	private String  v_accfg;
//	private String  v_accdesc;
//	private String  v_effect_dt;
//	private String  v_insu_contractor;
//	private String  gender;
//	private String  sd;
//	private String  sgng;
//	private String  manageno;
//	private String  upmyndng;
//	private String  phn;
//	private String  mphn;
//	private String  postno;
//	private String  name;
//	private String  rstaddr;
//	private String  id;
//	private String  pesonalfg;
//	private int     seq;
//	private String  email;
//	private String  bizregnum;
//	private String  bizname;
//	private String  bizbranch;
//	private String  centercd;
//	private String  loc_cd;
//	private int     n_hopecrprc;
//	private int     n_crprc;
//	private String  v_trust_fee_fg;
//	private double  n_trust_fee;
//	private String  v_account_holder;
//	private String  v_bank_cd;
//	private String  v_account_num;
//	private String  v_secuflag;
//	private int     n_seizing_cnt;
//	private int     n_pledge_cnt;
//	private String  v_pledge_company_etc;
//	private String  v_flag_no_smoking;
//	private String  v_flag_solo;
//	private String  v_flag_compromise;
//	private String  v_flag_monthly;
//	private String  v_flag_mnfc_as;
//	private String  v_flag_lpg;
//	private String  v_reco_use_type;
//	private String  v_taxissue;
//	private String  v_buyer_comment;
//	private String  v_master_comment;
//	private String  v_sub_cd;
//	private String  v_option;
//	private String  v_sub_nm;
//	private String  v_cop001;
//	private String  v_cop002;
//	private String  v_cop003;
//	private String  v_cop004;
//	private String  v_cop005;
//	private String  v_cop006;
//	private String  v_cop007;
//	private String  v_cop008;
//	private String  v_cop009;
//	private String  v_cop010;
//	private String  v_cop011;
//	private String  v_cop012;
//	private String  v_cop013;
//	private String  v_cop014;
//	private String  v_cop015;
//	private String  v_cop016;
//	private String  v_cop017;
//	private String  v_cop018;
//	private String  v_cop019;
//	private String  v_cop020;
//	private String  v_cop021;
//	private String  v_cop022;
//	private String  v_cop023;
//	private String  v_cop024;
//	private String  v_cop025;
//	private String  sclid;
//	private String  mnfccd;
//	private String  mdlcd;
//	private String  clsheadcd;
//	private String  clsdetailcd;
//	private String  mnfcnm;
//	private String  mdlnm;
//	private String  clsheadnm;
//	private String  clsdetailnm;
//	private String  dsp;
//	private String  crrgsnb;
//	private String  carbodynb;
//	private String  beginyr;
//	private String  firstregdt;
//	private String  inspyn;
//	private String  close_fg;
//	private String  recordno;
//	private String  mileage;
//	private String  yr;
//	private String  boardstate;
//	private String  transmission;
//	private String  motortype;
//	private String  carregistration;
//	private String  carstate;
//	private String  tuningyn;
//	private String  accyn;
//	private String  enginecheck;
//	private String  trnscheck;
//	private String  coout;
//	private String  hcout;
//	private String  smout;
//	private String  comments;
//	private String  insp_nm ;
//	private String  notice_nm;
//	private String  rgsdt;
//	private String  guarantytype;
//	private String  trnsetc;
//	private String  issuedt;
//	private String  validity1;
//	private String  validity2;
//	private String  v_mst_cd;
//	private String  parts_1;
//	private String  parts_2;
//	private String  parts_3;
//	private String  parts_4;
//	private String  parts_5;
//	private String  parts_6;
//	private String  parts_7;
//	private String  parts_8;
//	private String  parts_9;
//	private String  parts_10;
//	private String  parts_11;
//	private String  parts_12;
//	private String  parts_13;
//	private String  parts_14;
//	private String  parts_15;
//	private String  parts_16;
//	private String  parts_17;
//	private String  parts_18;
//	private String  parts_19;
//	private String  parts_20;
//	private String  parts_21;
//	private String  parts_22;
//	private String  parts_23;
//	private String  parts_24;
//	private String  parts_25;
//	private String  parts_26;
//	private String  parts_27;
//	private String  parts_28;
//	private String  parts_29;
//	private String  parts_30;
//	private String  parts_31;
//	private String  parts_32;
//	private String  parts_33;
//	private String  parts_34;
//	private String  parts_35;
//	private String  parts_36;
//	private String  sbcd1;
//	private String  sbcd2;
//	private String  sbcd3;
//	private String  sbcd4;
//	private String  sbcd5;
//	private String  sbcd6;
//	private String  sbcd7;
//	private String  sbcd8;
//	private String  sbcd9;
//	private String  sbcd10;
//	private String  sbcd11;
//	private String  sbcd12;
//	private String  sbcd13;
//	private String  sbcd14;
//	private String  sbcd15;
//	private String  sbcd16;
//	private String  sbcd17;
//	private String  sbcd18;
//	private String  sbcd19;
//	private String  sbcd20;
//	private String  sbcd21;
//	private String  sbcd22;
//	private String  sbcd23;
//	private String  sbcd24;
//	private String  sbcd25;
//	private String  sbcd26;
//	private String  sbcd27;
//	private String  sbcd28;
//	private String  sbcd29;
//	private String  sbcd30;
//	private String  sbcd31;
//	private String  sbcd32;
//	private String  sbcd33;
//	private String  sbcd34;
//	private String  sbcd35;
//	private String  sbcd36;
//	private String  result;
//	private String  v_reco_statenm;
//
//	//장기재고 차량
//	private String  v_discountcd;
//	private String  v_stepcd;
//	private String  v_caldate_dtm;
//	private String  v_next_day;
//	private String  v_current_day;
//	private String  v_start_dtm;
//	private String  v_end_dtm;
//	private String  v_new_cnt;
//	private String  v_end_cnt;
//	private String  v_sell_cnt;
//	private String  v_ing_cnt;
//	private String  v_page_cnt;
//	private String  v_order_cnt;
//	private String  v_percent;
//
//	private int n_days;
//	private String  v_dealcd;
//	private String  v_empnm;
//	private String  v_centernm;
//	private String  v_mphn;
//	private String  v_phn;
//	private String  v_settle_content;
//	private String  v_war_nb;
//	private String  v_customer_nm;
//	private String  v_start_dt;
//	private String  v_end_dt;
//	private String  v_center_nm;
//	private String  v_car_no;
//	private String  v_car_body_nb;
//	private String  v_ctgrnm;
//	private String  v_startkm;
//	private String  v_cncl_dt;
//	private int     n_eps_total;
//	private String  v_flag_sms;
//
//	private String  v_buyer_nm;
//	private String  v_contact;
//	private int     n_term;
//	private String  v_start_km;
//	private String  v_end_km;
//	private String  v_sell_type;
//	private int     n_limit_amt;
//	private int     n_encar_reward_total;
//	private int     n_lig_reward_total;
//	private String  v_group;
//	private String  v_loc;
//	private String  v_accept_cd;
//	private String  v_warrantynb;
//	private String  v_issue_dt;
//	private int     n_seq;
//	private String  v_progress_content;
//	private String  v_head_type;
//	private String  v_detail_type;
//	private int     n_reward;
//	private String  v_head_typenm;
//	private String  v_detail_typenm;

	/**
	 * 직영몰 키값으로 POS RGSID
	 * @deprecated CAR_ID로 대체됨
	 */
	private String  v_pos_rgsid;
//	private String  trust_close_fg;
//	private String  v_event_cd;
//	private String  v_send_sms_flag;
//	private String  v_inflow_type;
//	private int     n_limit_dt;
//
//	private int     n_partner_prc;
//	private String  v_salecd;
//	private int     n_partner_view;
//	private float   n_real_mile;
//	private float   n_auth_mile;
//	private String      v_rec_cd; //사고코드
//
//	// 추가 사항 K Car몰 1.2
//	private String  v_flag;
//	private String  v_key_point;
//	private String  v_opinion;
//	private String  v_etc;
//	private String  v_seller_hide_yn;
//	private String  v_footer;
//	private String  v_owner_info;
//	private String  v_free_opinion;
//	private String  v_addr1;
//	private String  v_addr2;
//
//	private String  n_point_x;
//	private String  n_point_y;
//
//	// 리스타입
//	private String v_lease_type;
//	private String v_lease_company;
//	private String v_location_cd;
//	private String v_location_nm;
//	private int n_support_fund;
//	private int n_month_price;
//	private String v_residual;
//	private String v_begin_month;
//	private int n_cash_price;
//	// 홈서비스 카운트
//	private int n_homeencar_cnt;
//
//	//  판매진단 new_yn
//	private String  v_new_yn;
//	private String  v_etc1;
//	private String  v_etc2;
//	private String  v_etc3;
//	private String  v_etc4;
//	private String  v_etc5;
//	private String  v_etc6;
//	private String  v_etc7;
//	private String  v_etc8;
//	private String  v_acdt_yn;
//	private String  v_optncd;
//	private String  n_optn_qty;
//	private String  v_repair_yn;
//	private String  v_insp_lvl_cd;
//	private String  n_insp_avg_score;
//	private String  insp_step_cd_01;
//	private String  insp_step_score_01;
//	private String  insp_step_cd_02;
//	private String  insp_step_score_02;
//	private String  insp_step_cd_03;
//	private String  insp_step_score_03;
//	private String  insp_step_cd_04;
//	private String  insp_step_score_04;
//	private String  insp_step_cd_05;
//	private String  insp_step_score_05;
//	private String  insp_step_cd_06;
//	private String  insp_step_score_06;
//	private String  use_nm;
//	private String  v_hst_info;
//	private String  v_month_pay;
//	//성능상태점검기록부 신규버전 페이지 변수
//	private String  v_buffer_13;
//	private String  v_sub_seq;
//	private String  waterlogyn;
//	private String  screenrgsdt;
//
//	//인터페이스 관련
//	private String ifKey;
//	private String ifStatus;
//	private int inspCnt;
//	private int dtlCnt;
//
//	//진단 상세설명
//	private String acdt_dgnos_eval_cnts;
//	private String milg_dgnos_eval_cnts;
//	private String pfmnc_dgnos_eval_cnts;
//	private String conveq_dgnos_eval_cnts;
//	private String expdabs_dgnos_eval_cnts;
//
//	private String  v_truck_name;
//
//	//K Car 차량 설명글 개선 - 차량총평
//	private String v_free_opinion_total;
//	private String v_detail_reg_dtm;
//	private String v_key_pnt_cnts;
//	private String v_hist_cnts;
//	private String v_dgnos_opnn_cnts;
//
//	//차명분류체계 - 검색조건저장관련
//	private int n_price_from;
//	private int n_price_to;
//	private int n_mileage_from;
//	private int n_mileage_to;
//
//	//동영상(유튜브) 등록여부 - 차량리스트 마크개선 관련
//	private String v_youtube_flag;
//
//	//성능점검기록부 개선
//	private String v_pfmnc_ckqt_dt; // 차량점검일자
//	private String v_ckqt_cnfm_dt; // 점검확인일자
//	private String v_msrins_stat_cd; // 계기상태코드
//	private String v_tuning_cd; // 튜닝코드
//	private String v_spcl_his_cd; // 특별이력코드
//	private String v_pps_chng_cd; // 용도변경코드
//	private String v_acdt_his_yn; // 사고이력여부
//	private String v_smpl_pepr_yn; // 단순수리여부
//	private String v_milg_stat_cd; // 주행거리상태코드
//	private String v_fuel_cd; // 연료코드
//
//	private String v_pfmnc_stat_ckqt_yn; // 성능상태점검여부
//	private String v_prc_ivtg_cptn_yn; // 가격조사산정여부
//	private String v_pfmnc_stat_gurnte_perd; // 성능상태보증기간
//	private String v_pfmnc_stat_gurnte_dst; // 성능상태보증거리
//	private String v_prc_ivtg_gurnte_perd; // 가격조사보증기간
//	private String v_prc_ivtg_gurnte_dst; // 가격조사보증거리
//	private String v_color_dvs_cd;	 	// 색상구분코드
//	private String v_color_chng_cd;		// 색상변경코드
//	private String v_mn_option_cd;		// 주요옵션
//	private String v_recall_obj_cd;		// 리콜대상
//	private String v_recall_exec_cd;	// 리콜이행
//
//	private String v_del_flag;
//
//
//
//	// 승차인원
//	private int    n_pass_cnt;
//
//	private String req_sts_cd;
//
//	// 차량옵션 설명팝업
//	private String  cscdsq;
//	private String  option_dtl_cnts;
//
//	// 상세진단서 팝업
//	private String  v_vin_stat_cd; // 차대번호상태코드
//
//	// 모바일050번호 적용
//	private String  v_pn_mobile;
//
//	// 조합주소
//	private String  v_asso_addr;
//
//	// 3d view
//	private String v_3dview_flag;
//
//	// 명의이전비
//	private String trff_price;
//
//	//세금및 부대비용
//	private String trans_Prc;
//
//	// 좋아요 가져오기
//	private String v_intrst_car;
//	private String v_rent_status;
//	private String v_reserve_yn;
//
//	//2020.01.06 : 10분마다 납부관리 배치 검사
//	private String fulpay_yn;
//	private String req_seq_no;
//	private String req_nm;
//	private String tm1;
//	private String tm2;
//	private String tm3;
//	private String tm4;
//	private String v_deadline_pay_part;
//	private String v_deadline_pay_entire;
//	private String notice_pay_part_flag;
//	private String notice_pay_entire_flag;
//	private String loan_req_state;
//	private String loan_use_yn;
//	private String imgn_ac_bnk_cd;
//	private String enc_deps_imgn_acno;
//
//
//	// car List
//	private List<ClsCarInfoVo> carList = new ArrayList<ClsCarInfoVo>();
//
//	//2020.01.08 견적서
//	private String v_car_nm;
//
//	private String n_amt_car;
//	private String n_amt_mgmt;
//	private String n_amt_reg_app;
//	private String n_amt_warranty;
//	private String n_amt_dlv;
//	private String n_amt_trns;
//	private String n_amt_sum;
//
//	private String n_amt_loan_car;
//	private String n_amt_cash_car;
//	private String n_amt_card_car;
//	private String n_amt_loan_etc;
//	private String n_amt_cash_etc;
//	private String n_amt_card_etc;
//	private String n_amt_loan_sum;
//	private String n_amt_cash_sum;
//	private String n_amt_card_sum;
//
//	private int 	n_like_cnt;
//	private int 	n_acc_cnt;
//	private String	v_opt_sunroof_yn;
//	private String	v_opt_navi_yn;
//	private String	v_price_rg;
//
//	/* 브랜드인증몰 - 20200731 Start */
//	private String 	v_car_tcd;
//	private String 	v_sell_cl_cd;
////	private String 	v_insr_hst_opnpb_yn;
////	private String 	v_pfmnc_ckqt_reg_way_cd;
//	private int 	n_lese_udtkng_excal_amt;
//	private String 	v_show_room_cd;
//	private String 	v_gnrl_sell_swit_psb_yn;
//	private String  v_lese_cond_yn;
//	/* 브랜드인증몰 - 20200731 End */
//
//	private String 	v_mileage_rg;
//	private String	v_opt_ldws_yn;
//	private String	v_opt_hud_yn;
//	private String	v_opt_aroundview_yn;
//	private String	v_opt_pwtrunk_yn;
//	private String	v_opt_ms_dv_yn;
//	private String	v_opt_ms_sub_yn;
//	private String	v_opt_ws_dv_yn;
//	private String	v_opt_ws_sub_yn;
//	private String	v_large_brst_cd;
//
//	private String	batch_flag;
//
//	//렌트
//	private String	v_rc_carcd;
//	private String	v_rent_month;
//	private int		n_rent_prc4;
//
//	//타이어 정보
//	private String	tir_res_qty;
//	private String	tir_sid_width;
//	private String	tir_flat_rt;
//	private String	tir_inch;
//	private String	tir_prdcn_week;
//	private String	tir_prdcn_yt;
//	private String	wint_tir_yn;
//	private String	memo_cnts;
//
//	private List<CmMap<String, Object>>  optList;
//
//	private String	v_stock_flag;
//	private String	v_stock_nm;
//
//	private String	pfmnc_ckqt_gurnte_insrco_cd;
//	private String	pfmnc_ckqt_gurnte_insrco_nm;
//
//	private String	n_rent_price;
//	private String  v_lunch_time;
//
//	//사진개편
//	private String	v_thumbnail_desc;
//	private String	v_thumbnail_dcd;
//	private String	v_thumbnail_type;
//	private String	v_thumbnail_typenm;
//	private String	v_ver;
//
//	//진단개편
//	private String	v_insr_hist_iqy_en;
//	private String	n_mycar_dmge_cnt;
//	private String	n_dmge_amt;
//	private String	v_pps_hist_cd;
//	private String	v_specl_acdt_hist_dcd;
//	private String	v_fmlt_stru_chng_yn;
//	private String	v_fmlt_stru_chng_cnts;
//	private String	v_ilglt_stru_chng_yn;
//	private String	v_ilglt_stru_chng_cnts;
//	private String	v_szr_moge_yn;
//	private String	n_szr_cnt;
//	private String	n_moge_cnt;
//	private String	v_dshb_chng_yn;
//	private String	n_prst_milg;
//	private String	v_impt_dcd;
//	private String	v_tir_inp_wrk_yn;
//	private String 	v_sup_grp_cd;
//	private String	v_phto_path;
//	private String	v_phto_desc;
//
//	private String	v_lglt_tuning_yn;
//	private String	v_ilglt_tuning_yn;
//	private String	v_stru_tuning_yn;
//	private String	v_eqp_tuning_yn;
//	private String	v_memo;
//	private String n_amt_total_sum;
	/** 온라인판매적용여부 V_ONLN_SELL_APLY_YN */
	private String onlnSellAplyYn;
//	private String v_onln_sell_strt_dt;
//	private String  v_attach_path;

	public String getCarNm() {
		String carNm = this.mnuftrNm + " " + this.modelNm;

		if(this.grdNm != null) {
			carNm += " " + this.grdNm;
		}

		if(this.grdDtlNm != null) {
			carNm += " " + this.grdDtlNm;
		}

		return carNm;
	}
}