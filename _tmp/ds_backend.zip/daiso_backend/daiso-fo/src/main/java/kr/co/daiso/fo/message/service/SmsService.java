package kr.co.daiso.fo.message.service;

import kr.co.daiso.fo.message.mapper.oracle.SmsMapper;
import kr.co.daiso.fo.message.model.SmsVO;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * packageName    : kr.co.daiso.mg.message.service
 * fileName       : SmsService
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */
@Slf4j
@Service
public class SmsService {

    @Autowired
    SmsMapper smsMapper;

    @Value("${dblink}")
    private String dblink;

    @Autowired
    FoAccountInfoUtil adminAccountInfoUtil;

    @Transactional(rollbackFor=Exception.class)
    public void insertSms(SmsVO smsVO) throws Exception {
        try {
            //전송하려는 문자의 길이를 계산
            int msgLen = smsVO.getText().getBytes("EUC-KR").length;
            /*
             * [s]
             * 전송하려는 문자가 80바이트 이하일 경우 SMS로 발송
             * 80바이트 초과 2000바이트 이하일 경우 MMS로 발송
             * 80바이트 초과 3000바이트 이하일 경우 MMS로 발송 // 2015.02.05 수정
             * 그외에는 발송하지 않는다.
             * TranTrpe 1:SMS / 3:MMS
             * [e]
             */
            if (msgLen <= 80) {
                smsVO.setMsgType("1");
            } else if (msgLen <= 3000) {
                smsVO.setMsgType("3");
                smsVO.setSubject(smsVO.getText().substring(0, 15) + "...");

                // 최대 2000자까지 저장 가능 VARCHAR2(4000)
                if (smsVO.getText().length() > 2000) {
                    smsVO.setText(smsVO.getText().substring(0, 2000));
                }
            }
            smsVO.setDbLinkValue(dblink);

            smsVO.setRgpsId(adminAccountInfoUtil.getMembId());
            smsVO.setMdpsId(adminAccountInfoUtil.getMembId());
            // 문자 저장
            smsMapper.insertSmsQueue(smsVO);

            // K Car차 DB에 SMS기록 저장
            smsMapper.insertSmsMyDb(smsVO);
        } catch (Exception e) {
            StackTraceElement[] ste = e.getStackTrace();

            String className = ste[0].getClassName();
            String methodName = ste[0].getMethodName();
            int lineNumber = ste[0].getLineNumber();
            String fileName = ste[0].getFileName();

            log.error("### " + className + "." + methodName + "###");
            log.error("# FileName : " + fileName);
            log.error("# LineNumber : " + lineNumber);

//			System.out.println(reqVo.getI_sTranPhone()+"#SMS전송실패");
//			System.out.println("#i_sTranPhone####"+reqVo.getI_sTranPhone());
//			System.out.println("#i_sTranCallBack#"+reqVo.getI_sTranCallBack());
//			System.out.println("#i_sMessage######"+reqVo.getI_sMessage());
            e.printStackTrace();
            throw e;
        }

    }
}
