package kr.co.daiso.fo.auth.oauth;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAthProvider
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : OAuth 연동 서버측 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23     Doo-Won Lee       최초생성
 */
@Data
public class OAuthProvider {
    private String authUrl;
    private String tokenApiUrl;
    private String meApiUrl;
    private String mapApiUrl;
    private String batchApiUrl;
}
