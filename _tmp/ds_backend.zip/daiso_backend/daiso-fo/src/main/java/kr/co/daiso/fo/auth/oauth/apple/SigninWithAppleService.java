package kr.co.daiso.fo.auth.oauth.apple;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.PrivateKey;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * packageName    : kr.co.daiso.fo.auth.oauth.apple
 * fileName       : SigninWithAppleService
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : Apple 연동 Service 클래스 (As-IS 소스)
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23     Doo-Won Lee        최초생성
 */
@Slf4j
@Service
public class SigninWithAppleService {

    private String APPLE_AUTH_KEY = "-----BEGIN PRIVATE KEY-----\nMIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQgJmB85zyl78HbqTLf\n8icIrdVftOkd23G/eDqmpF9vfvCgCgYIKoZIzj0DAQehRANCAAS+cnISofqBSvIG\nx28ujjGx8zgMKbksXkV3tw8MDAibXPbUx9+t/ZWInSaJOfOg7/aRqlcifmndYbEj\nRw2u/7P7\n-----END PRIVATE KEY-----";
    private static PrivateKey pKey;

    public Map<String, Object> toKenDecrypt(String encryptionToKenStr) throws Exception {
        Map<String, Object> toKenMap = new HashMap<String, Object>();
        JWT jwt = new JWT();
        try {
            String id_token = encryptionToKenStr;

            DecodedJWT idToken_Decode = jwt.decodeJwt(id_token);

            Map<String, Claim> claims = idToken_Decode.getClaims();

            Set set = claims.keySet();
            Iterator iter = set.iterator();

            while (iter.hasNext()) {
                String key = (String) iter.next();
                Claim claim = claims.get(key);
                toKenMap.put(key, claim.asLong());
                if ("iat".equals(key) || "exp".equals(key) || "auth_time".equals(key)) {
                    toKenMap.put(key, claim.asLong());
                } else {
                    toKenMap.put(key, claim.asString());
                }
            }

            getServerLog("toKenMap", toKenMap);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return toKenMap;
    }

    /**
     * Apple Client_Secret 암호화
     * @return
     */
    public String getClientSecret() throws Exception {

        String token = "";

        try {
            // Get a Private Key
            pKey = getPrivateKey("APPLE");

            // Client_Secret
            token = Jwts
                    .builder()
                    .setHeaderParam(JwsHeader.ALGORITHM, "ES256")
                    .setHeaderParam(JwsHeader.KEY_ID, "SDY33FAC3S")
                    .setIssuer("DBLYY2T9WY")
                    .setAudience("https://appleid.apple.com")
                    .setSubject("com.encarmall.encarmall.applelogin")
                    .setExpiration(
                            new Date(System.currentTimeMillis() + (1000 * 60 * 5)))
                    .setIssuedAt(new Date(System.currentTimeMillis()))
                    .signWith(SignatureAlgorithm.ES256, pKey).compact();

            getServerLog("ClienctSecret", token);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return token;
    }

    public JSONObject getAccessToken(String codeStr, String type, String clientSecretStr, String refreshTokenStr) throws Exception {

        StringBuilder strBuilder = new StringBuilder();
        JSONObject tokenObj = null;

        try {
            String parameters =
                    "?client_id=com.encarmall.encarmall.applelogin"
                            + "&client_secret=" + clientSecretStr
                            + "&code=" + codeStr
                            + "&grant_type=" + type
                    ;

            if("refresh_token".equals(type)) {
                parameters += "&refresh_token=" + refreshTokenStr;
            }

            String URL = "https://appleid.apple.com/auth/token" + parameters;

            getServerLog("URL", URL);

            strBuilder = httpUrlConnect(URL);
            tokenObj = (JSONObject) JSONValue.parse(strBuilder.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return tokenObj;
    }

    /**
     * Private Key를 PEM방식으로 변환
     * @return
     */
    public PrivateKey getPrivateKey(String TYPE) throws Exception {

        String AUTH_KEY = "";
        try {
            final PEMParser pemParser = new PEMParser(new StringReader(APPLE_AUTH_KEY));
            final JcaPEMKeyConverter converter = new JcaPEMKeyConverter();
            final PrivateKeyInfo object = (PrivateKeyInfo) pemParser.readObject();

            // PRIVATE KEY
            pKey = converter.getPrivateKey(object);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return pKey;
    }


    public StringBuilder httpUrlConnect(String URL) throws Exception {

        StringBuilder strBuilder = new StringBuilder();

        try {
            URL url = new URL(URL);
            HttpURLConnection httpUrlCon = (HttpURLConnection) url.openConnection();

            if (httpUrlCon != null) {
                httpUrlCon.setRequestMethod("POST");
                httpUrlCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                httpUrlCon.setConnectTimeout(10000);
                httpUrlCon.setUseCaches(false);

                String str = "";

                log.info("getResponseCode : ",httpUrlCon.getResponseCode());

                if (httpUrlCon.getResponseCode() == HttpURLConnection.HTTP_OK) {

                    BufferedReader br = new BufferedReader(new InputStreamReader(httpUrlCon.getInputStream()));

                    while (true) {
                        str = br.readLine();
                        if (str == null) break;
                        strBuilder.append(str + '\n');
                        log.info(str + '\n');
                    }
                    br.close();
                } else {

                    BufferedReader br = new BufferedReader(new InputStreamReader(httpUrlCon.getErrorStream()));

                    while (true) {
                        str = br.readLine();
                        if (str == null) break;
                        strBuilder.append(str + '\n');
                        log.info(str + '\n');
                    }
                    br.close();
                }
            }
            httpUrlCon.disconnect();

        }catch(Exception e) {
            e.printStackTrace();
        }

        return strBuilder;
    }
    public static void getServerLog(String logName, Object log) throws Exception {

        try {
            Calendar _cal1 = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String today = sdf.format(_cal1.getTime());

            System.out.println("[" + today + "][SigninWithAppleServece] [" + logName + " ] : " + "[" + log + "]");

        } catch(Exception e) {
            e.printStackTrace();
        }

    }
}
