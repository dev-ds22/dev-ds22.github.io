package kr.co.daiso.fo.mb.mapper.oracle;

import kr.co.daiso.fo.auth.model.AutoLoginToken;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.fo.mb.mapper
 * fileName       : LoginMapper
 * author         : kjm
 * date           : 2022-02-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
@Mapper
public interface LoginMapper {

    // 휴면회원 -> 일반회원 테이블
    void reInsertInactive(AccountInfo accountInfo);

    // 휴면회원 테이블에서 삭제
    void deleteInactive(AccountInfo accountInfo);

    // 비밀번호 업데이트
    void updateUserPwd(AccountInfo accountInfo);

    // 패스워드 오류회수, 최종접속일, 최초접속여부 초기화
    void updatePassReset(AccountInfo accountInfo);

    // 비밀번호 오류회수 +1 (회원, 휴면회원 둘다)
    void updatePassError(AccountInfo accountInfo);

    // 자동로그인 토큰 저장
    void saveAutoLoginToken(AutoLoginToken autoLoginToken);

    // 자동 로그인 토큰 조회
    AutoLoginToken getAutoLoginToken(AutoLoginToken searchToken);

    // 자동로그인 토큰 연장
    void extendAutoLoginToken(AutoLoginToken autoLoginToken);

    // 로그인 로그 저장
    void insertLoginLog(MemberVO memberVO);
}
