package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.service.SmsApiService;
import kr.co.daiso.fo.message.model.SmsVO;
import kr.co.daiso.fo.message.service.SmsService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;


@Service
public class SmsApiServiceImpl implements SmsApiService {

    @Autowired
    SmsService smsService;

    @Value("${sms.sentinel_callback}")
    String sentinel_callback;

    @Override
    @Transactional
    public void insertSmsApi(SmsVO smsVO, List<CommonCodeManageVO> phoneList) {
        try {

            smsVO.setCallback(sentinel_callback);

            for(CommonCodeManageVO commonCodeManageVO : phoneList ){
                smsVO.setDstaddr(commonCodeManageVO.getAddtFld1());
                smsService.insertSms(smsVO);
            }

        } catch (Exception e) {
            throw new CommonException("sms insert error", HttpStatus.BAD_REQUEST);
        }
    }

}