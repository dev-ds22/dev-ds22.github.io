package kr.co.daiso.fo.common.service;

import kr.co.daiso.fo.common.model.ClsCommonReqVO;
import kr.co.daiso.fo.common.model.ClsCommonVo;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.servicee
 * fileName       : ClsCommonService
 * author         : 이강욱
 * date           : 2022-04-18
 * description    : 공통작업 인터페이스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18     이강욱             최초생성
 */
public interface ClsCommonService {
    /**
     * sms 전송 db에 등록
     * @param reqVo
     */
    public void insertSms(ClsCommonReqVO reqVo) throws Exception;

    /**
     * 첫번째 서브코드 정보 가져오기
     * @param reqVo - 검색조건 (i_sMstCode, i_sSubCode, ...)
     * @return 첫번째 서브코드 정보
     *
     * @deprecated {@link kr.co.daiso.fo.common.service.CommonCodeService#getFirstSubCode(CommonCodeSearchVO)}로 대체됨
     */
    public ClsCommonVo getCmSubCodeListNoCache(ClsCommonReqVO reqVo);

    /**
     * 서브코드 정보 목록 가져오기
     * @param reqVo - 검색조건 (i_sMstCode, i_sSubCode, ...)
     * @return 서브코드 정보 목록
     *
     * @deprecated {@link kr.co.daiso.fo.common.service.CommonCodeService#getSubCodeList(CommonCodeSearchVO)}}로 대체됨
     */
    public List<ClsCommonVo> getCmSubCodeList(ClsCommonReqVO reqVo);
}
