package kr.co.daiso.fo.common.mapper.oracle;

import kr.co.daiso.fo.common.model.MobileAppCtrlVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.mapper.oracle
 * fileName       : MobileAppCtrlMapper
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29    Byung-Chul Park      최초생성
 */
@Mapper
public interface MobileAppCtrlMapper {

    //모바일 APP제어 정보를 조회한다.
    List<MobileAppCtrlVO> getMobileAppCtrl(MobileAppCtrlVO mobileAppCtrlVO);

}
