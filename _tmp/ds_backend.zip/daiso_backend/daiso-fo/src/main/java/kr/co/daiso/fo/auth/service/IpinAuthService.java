package kr.co.daiso.fo.auth.service;

/**
 * packageName    : kr.co.daiso.mg.auth.service
 * fileName       : IpinAuthService
 * author         : kjm
 * date           : 2022-01-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-24       kjm            최초생성
 */public interface IpinAuthService {
    /** 암화화 키 생성 */
    public String CreateKey();
    /** 암호화 */
    public String IpinEncode(String key, String reqInfo);
    /** 복호화 */
    public String[] IpinDecode(String key, String reqInfo);
}
