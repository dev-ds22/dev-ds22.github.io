package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.mb.model
 * fileName       : JoinErrorLogVO
 * author         : kjm
 * date           : 2022-03-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-11       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class JoinErrorLogVO extends BaseModel {
    private String membId;          // 회원아이디
    private String membNm;          // 회원명
    private String pwd;             // 패스워드
    private String mbpno;           // 핸드폰
    private String membEmail;       // 회원이메일
    private String joinChnl;        // 가입채널 PC: C010, MOBILE: C990
    private String certChnl;        // 인증채널 본인인증: C001, 아이핀: C002
    private String errLog;          // 오류로그
    private String errCd;           // 오류코드
    private String errLine;         // 오류라인
    private String errHapnRelocUrl; // 에러발생이전 URL:
    private String errHapnUrl;      // 에어발생URL
    private String prcsEn;          // 처리유무
    private String ctnr;            // 컨테이너
    private String rqstMthd;        // 요청방법
    private String membAgt;         // 회원 agent
}
