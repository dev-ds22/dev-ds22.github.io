package kr.co.daiso.fo.common.util;

import kr.co.daiso.common.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : StringUtil
 * author         : 이강욱
 * date           : 2022-04-27
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-27       이강욱         최초생성
 */
@Slf4j
public class HttpUtil {
    private HttpUtil() {}

    /**
     * 접속 단말기가 모바일, 태블릿이 아닌지 여부
     *
     * @param request HTTP요청
     * @return 모바일/태블릿이면 false, 아니면 true
     */
    public static boolean isNomalDevice(HttpServletRequest request) {
        Device device = DeviceUtils.getCurrentDevice(request);
        return device.isNormal();
    }

    /**
     * 접속 단말기가 모바일, 태블릿인지 여부
     *
     * @param request HTTP요청
     * @return 모바일/태블릿이면 true, 아니면 false
     */
    public static boolean isNotNomalDevice(HttpServletRequest request) {
        Device device = DeviceUtils.getCurrentDevice(request);
        return !device.isNormal();
    }

    /**
     * HTTP요청 User-Agent 헤더에서 접속플랫폼유형[ANDROID, IOS, WEB]을 가져온다
     *
     * @param request HTTP요청
     * @return 접속플랫폼유형[ANDROID, IOS, WEB]
     */
    public static String getDevicePlatform(HttpServletRequest request) {
        String userAgent = request.getHeader("User-Agent").toLowerCase();
        if (StringUtil.isNotEmpty(userAgent)) {
            if (userAgent.toLowerCase().indexOf("daisoandroid") > -1) {
                return "ANDROID";
            }else if (userAgent.toLowerCase().indexOf("daisoios") > -1) {
                return "IOS";
            }
        }
        return "WEB";
    }

    /**
     * 접속 단말기의 채널구분 [1:PC, 2:모바일웹, 3:APP] 값을 가져온다
     *
     * @param request
     * @return 채널구분값. 알수없는 경우 null
     */
    public static String getChannelGubun(HttpServletRequest request) {
        Device device = DeviceUtils.getCurrentDevice(request);

        if (device != null && device.isNormal()) {
            return "1"; // PC
        } else {
            String devicePlatform = getDevicePlatform(request);
            if ("ANDROID".equals(devicePlatform) || "IOS".equals(devicePlatform)) {
                return "3"; // APP
            } else {
                return "2"; // mobile web
            }
        }
    }

    public static String getChannelName(HttpServletRequest request) {
        Device device = DeviceUtils.getCurrentDevice(request);

        if (device != null && device.isNormal()) {
            return "PC";
        } else {
            String devicePlatform = getDevicePlatform(request);
            if ("ANDROID".equals(devicePlatform) || "IOS".equals(devicePlatform)) {
                return devicePlatform; // ANDROID 또는 IOS
            } else {
                return "MOB_WEB";
            }
        }
    }

    public static void logRequestAllParam(HttpServletRequest request, String prefix) {
        Enumeration<String> paramKeys = request.getParameterNames();
        while (paramKeys.hasMoreElements()) {
            String key = paramKeys.nextElement();
            log.info("{} request.getParameter({})={}", prefix, key, request.getParameter(key));
        }
    }
}
