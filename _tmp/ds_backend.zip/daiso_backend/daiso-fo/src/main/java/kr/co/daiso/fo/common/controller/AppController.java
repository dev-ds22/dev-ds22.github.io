package kr.co.daiso.fo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.common.model.MobileAppCtrlVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;
import kr.co.daiso.fo.common.service.MobileAppCtrlService;
import kr.co.daiso.fo.common.service.MobileAppVerService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.controller
 * fileName       : AppController
 * author         : Park Byung-chul
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29    Park Byung-chul    최초생성
 */
@Slf4j
@RequestMapping("/common/App")
@RestController
public class AppController {

    @Autowired
    MobileAppVerService mobileAppVerService;
    @Autowired
    MobileAppCtrlService mobileAppCtrlService;

    @ApiOperation("모바일 APP버전정보 조회")
    @GetMapping("mobile-app-version")
    public ResponseEntity<CommonResponseModel> getMobileAppVersion(@ApiParam("모바일 APP버전관리 조회 정보")MobileAppVerVO mobileAppVerVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        MobileAppVerVO resultVo = mobileAppVerService.getMobileAppVersion(mobileAppVerVO);
//        List<MobileAppVerVO> list	= mobileAppVerService.getMobileAppVersion(mobileAppVerVO);

        log.info("mobileAppVerVO>>>>" + mobileAppVerVO);
        resultMap.put("result", resultVo);
//        resultMap.put(STR_LOG_LIST, list);
//        resultMap.put(STR_SEARCH_INFO, mobileAppVerVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("모바일 APP제어정보 조회")
    @GetMapping("mobile-app-ctrl")
    public ResponseEntity<CommonResponseModel> getMobileAppCtrl(@ApiParam("모바일 APP제어 조회 정보")MobileAppCtrlVO mobileAppCtrlVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        List<MobileAppCtrlVO> list = mobileAppCtrlService.getMobileAppCtrl(mobileAppCtrlVO);

        log.info("mobileAppCtrlVO>>>>", mobileAppCtrlVO);
        resultMap.put("result", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap),HttpStatus.OK);
    }

    @ApiOperation("모바일 APP버전정보 조회")
    @GetMapping("asis-mobile-app-version")
    public Map<String, String> getAsiaMobileAppVersion(@ApiParam("모바일 APP버전관리 조회 정보")String i_sOsType, HttpServletResponse response) throws Exception{
        Map<String, String> resultMap = new HashMap<>();
        MobileAppVerVO mobileAppVerVO = new MobileAppVerVO();
        mobileAppVerVO.setOsDvsCd(i_sOsType);
        MobileAppVerVO resultVo = mobileAppVerService.getMobileAppVersion(mobileAppVerVO);
//        List<MobileAppVerVO> list	= mobileAppVerService.getMobileAppVersion(mobileAppVerVO);

        log.info("mobileAppVerVO>>>>" + mobileAppVerVO);
        resultMap.put("version",resultVo.getAppVer());
        resultMap.put("url",resultVo.getStoreLink());
        resultMap.put("forced",resultVo.getCoerYn());
//        resultMap.put(STR_LOG_LIST, list);
//        resultMap.put(STR_SEARCH_INFO, mobileAppVerVO);
        return resultMap;
    }
}
