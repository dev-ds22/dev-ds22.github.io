package kr.co.daiso.fo.auth.oauth;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthRegistration
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : OAuth연동 클라이언트 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23      Doo-Won Lee     최초생성
 */
@Data
public class OAuthRegistration {
    //private String provider;
    private String clientId;
    private String clientSecret;
    private String redirectUrl;
    private String mRedirectUrl;
    private String scopes;
}