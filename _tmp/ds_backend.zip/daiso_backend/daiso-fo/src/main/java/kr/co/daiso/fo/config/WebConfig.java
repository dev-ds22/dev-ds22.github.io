package kr.co.daiso.fo.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mobile.device.DeviceResolverHandlerInterceptor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : WebConfig
 * author         : leechangjoo
 * date           : 2021-10-28
 * description    : CORS registry 설정
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-28          leechangjoo         최초생성
 **/
@Slf4j
@RequiredArgsConstructor
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final ObjectMapper objectMapper;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
//                .allowedOrigins("*")
//                .allowedMethods("*")
                .allowedOrigins("http://dev.daiso.com:3013" //로컬 MG
                        ,"http://dev.daiso.com:3000" //로컬 모바일
                        ,"https://dev.daiso.com:3000" //로컬 모바일
                        ,"http://dev.daiso.com:3012"  //로컬 PC
                        ,"https://dev.daiso.com:3012" //로컬 PC(API)
                        ,"http://dev.daiso.com:8090" //로컬 PC

                        ,"http://adm.daisodev.com:8090"   //개발 MG
                        ,"https://adm.daisodev.com"      //개발 MG
                        ,"http://www.daisodev.com:8090"   //개발 PC
                        ,"https://www.daisodev.com"       //개발 PC
                        , "https://company.daisodev.com"
                        , "https://m-company.daisodev.com"

                        ,"http://adm-qa.daisodev.com"         //STG MG
                        ,"https://adm-qa.daisodev.com"         //STG MG
                        ,"http://qa.daisodev.com"            //STG IDC PC
                        ,"https://qa.daisodev.com"           //STG IDC PC

                        ,"http://qa.daisodev.com:8086"            //PRD IDC TEST
                        ,"http://qa.daisodev.com:8087"           //PRD IDC TEST
                        ,"https://qa.daisodev.com:8087"           //PRD IDC TEST

                        ,"http://qa.daiso.com"            //성능테스트 IDC PC
                        ,"https://qa.daiso.com"           //성능테스트 IDC PC

                        , "https://qacompany.daisodev.com"
                        , "https://m-qacompany.daisodev.com"

                        , "https://m.daiso.com"           //aws prd
                        , "https://adm.daiso.com"         //prd MG
                        , "https://www.daiso.com"         //prd PC
                        , "https://daiso.com"         //prd PC
                        , "https://api.daiso.com"
                        , "http://api.daiso.com"

                        ,"https://company.daiso.com"
                        ,"https://m-company.daiso.com"

                        ,"http://local.daisodev.com:3000" //케이카 직원 테스트용 MO
                        ,"http://local.daisodev.com:3012"  //케이카 직원 테스트용 PC

                        ,"https://m.daisodev.com"        //개발 AWS
                        ,"https://mapi.daisodev.com"
                        ,"https://m.daisodev.com:3000"
                        ,"https://mapi.daisodev.com"
                        ,"https://aws-mapi.daisodev.com:3000"
                        ,"https://aws-mapi.daisodev.com:8090"

                        ,"https://m-qa.daiso.com"        //stg AWS
                        ,"https://mapi-qa.daiso.com"
                        ,"https://m-qa.daisodev.com"        //stg AWS
                        ,"https://mapi-qa.daisodev.com"

                        ,"https://mapi.daiso.com"        //aws prd
                        ,"http://mapi.daiso.com"         //aws prd (결제)
//                        ,"http://m.daiso.com"           //aws prd temp
//                        ,"http://mapi.daiso.com"        //aws prd temp

                        , "https://pg.easypay.co.kr"
                        , "https://sp.easypay.co.kr"
                        , "https://gw.easypay.co.kr"


                        ,"https://appleid.apple.com"
                        ,"https://testpg.easypay.co.kr"
                        ,"https://testsp.easypay.co.kr"
                        ,"https://testgw.easypay.co.kr"
                        ,"http://testoffice.easypay.co.kr")
                .allowedMethods( "GET", "POST", "PUT", "DELETE", "PATCH","OPTIONS")
                .exposedHeaders("Content-Disposition")
                .allowCredentials(true);
    }

    @Bean
    public MappingJackson2HttpMessageConverter jsonEscapeConverter(){
        ObjectMapper copy = objectMapper.copy();
        copy.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
        return new MappingJackson2HttpMessageConverter(copy);
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new DeviceResolverHandlerInterceptor());
    }

    @Value("${spring.resource.path}")
    private String resourcePath;

    @Value("${spring.resource.requestPath}")
    private String requestPath;

    private String projectInsideResourcePath = "classpath:/static/image/";  //App에서 이미지 요청경로

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //WebMvcConfigurer.super.addResourceHandlers(registry);
        log.info("resourcePath :"+resourcePath);
        registry.addResourceHandler(requestPath)
                .addResourceLocations(resourcePath)
                .addResourceLocations(projectInsideResourcePath);

//                .addResourceLocations(resourcePath,"file:src/main/webapp/");
    }
}
