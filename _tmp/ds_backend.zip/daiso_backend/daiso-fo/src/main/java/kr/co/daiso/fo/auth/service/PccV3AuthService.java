package kr.co.daiso.fo.auth.service;

/**
 * packageName    : kr.co.daiso.fo.auth.service
 * fileName       : PccV3AuthService
 * author         : kjm
 * date           : 2022-01-27
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-27       kjm            최초생성
 */
public interface PccV3AuthService {
    /**
     * 암화화 키 생성
     */
    public String PccV3CreateKey(String day);

    /**
     * 암호화
     */
    public String PccV3Encode(String key, String reqInfo);

    /**
     * 복호화
     */
    public String[] PccV3Decode(String key, String reqInfo);
}
