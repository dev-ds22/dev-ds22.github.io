package kr.co.daiso.fo.mb.service.Impl;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.fo.auth.model.AutoLoginToken;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.mapper.oracle.LoginMapper;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import kr.co.daiso.fo.mb.model.SnsMemberVO;
import kr.co.daiso.fo.mb.service.LoginService;
import kr.co.daiso.fo.mb.service.MemberService;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import kr.co.daiso.fo.util.TokenUtil;
import kr.co.daiso.fo.util.XdbUtil;
// import com.oreilly.servlet.Base64Encoder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.mobile.device.LiteDeviceResolver;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * packageName    : kr.co.daiso.fo.mb.service.LoginServiceImpl
 * fileName       : LoginServiceImpl
 * author         : kjm
 * date           : 2022-02-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
@Service
@Slf4j
public class LoginServiceImpl implements LoginService {

    @Autowired
    LoginMapper loginMapper;

    @Autowired
    TokenUtil tokenUtil;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    CookieUtil cookieUtil;

    @Autowired
    FoAccountInfoUtil foAccountInfoUtil;

    @Autowired
    MemberService memberService;

    /**
     * methodName : login
     * author :  kjm
     * description : 로그인
     * @param request
     * @param response
     * @param memberVO
     * @return AccountInfo
     */
    @Transactional(noRollbackFor = { IllegalArgumentException.class, IllegalStateException.class })
    @Override
    public AccountInfo login(HttpServletRequest request, HttpServletResponse response, MemberVO memberVO) throws UnsupportedEncodingException {
        AccountInfo loginMember = memberService.getMemberById(memberVO);
        String message = "";
        String password = cmEnCrypt(memberVO.getPwd());
        try {
            if (loginMember == null) {
                insertLoginLog(request, memberVO, "N");
                message = "등록되지 않은 아이디 이거나 비밀번호가 틀립니다!";
                throw new IllegalArgumentException(message);

            } else if (Integer.parseInt(loginMember.getPwdErrCnt() == null ? "0" : loginMember.getPwdErrCnt()) >= 5) {
                insertLoginLog(request, memberVO, "N");
                message = "5회 이상 로그인 오류 시 본인 확인 후 로그인 가능합니다.";
                throw new IllegalStateException(message);

            } else if (password.equals("") || !XdbUtil.getHashEncryptCheck(password, loginMember.getPwd())) {
                insertLoginLog(request, memberVO, "N");
                message = "등록되지 않은 아이디 이거나 비밀번호가 틀립니다.";
                String passError = loginMember.getPwdErrCnt() == null ? "0" : loginMember.getPwdErrCnt();
                int intPass = Integer.parseInt(passError);

                // 5회 미만만 패스워드 오류회수 증가
                if (intPass < 5) {
                    // 비밀번호 틀렸을시 패스워드 오류회수 +1

                    // 미조추가 - 분리회원정보 조회 / TBL_NM - MEMBER : 기존회원    INACTIVE_MEMBER : 분리회원
                    loginMapper.updatePassError(loginMember);
                }
                throw new IllegalArgumentException(message);

            } else if ("Y".equals(loginMember.getWtdrYn())) {
                insertLoginLog(request, memberVO, "N");
                message = "탈퇴한회원입니다. 탈퇴후 1주일동안은 재가입이 불가능합니다.";
                throw new IllegalArgumentException(message);
            } else {

                insertLoginLog(request, memberVO, "Y");
                // 실제 로그인 성공시의 처리부..
                tokenUtil.addLoginSuccessToken(loginMember, response);

                /****** 3. SNS 계정과 직영몰 회원계정 매핑 시작 ******/
                String snsId = Optional.ofNullable(CookieUtil.getCookie(request, "_si"))
                        .map(Cookie::getValue)
                        .orElse(null);
                String knd = Optional.ofNullable(CookieUtil.getCookie(request, "_k"))
//                        .map(Cookie::getValue)
                        .map(cookie -> {
                            switch(cookie.getValue()) {
                                case "N":
                                    return "NAVER";
                                case "K":
                                    return "KAKAO";
                                case "A":
                                    return "APPLE";
                                default:
                                    return null;
                            }
                        })
                        .orElse(null);
                if(!StringUtils.isBlank(snsId) && !StringUtils.isBlank(knd)) {

                    Map<String, Object> paramMap = new HashMap<>();
                    paramMap.put("snsId", snsId);
                    paramMap.put("knd", knd);
                    SnsMemberVO snsMemberVO = memberService.getSnsMember(paramMap);

                    if(snsMemberVO.getMembId() == null) {
                        snsMemberVO.setMembId(memberVO.getMembId());
                        memberService.updateSocialMember(snsMemberVO);
                    } else if(!snsMemberVO.getMembId().equals(loginMember.getMembId())) {
                        // 이미 등록된 sns 계정
                    }
                }
                CookieUtil.addResponseCookie(response, "_si", null, 0);
                CookieUtil.addResponseCookie(response, "_k", null, 0);
                /****** SNS 계정과 직영몰 회원계정 매핑 종료 ******/

                if(memberVO.isAutoLogin()) {
                    AutoLoginToken autoLoginToken = tokenUtil.makeAutoLoginToken(memberVO);
//                    loginMapper.saveAutoLoginToken(autoLoginToken); // 자동로그인 토큰
                    this.saveAutoLoginToken(request, response, autoLoginToken);
                }
                else {
                    CookieUtil.addResponseCookie(response, "token", null, 0);
                }

                // 미조추가 - 분리회원정보 조회 / TBL_NM - MEMBER : 기존회원    INACTIVE_MEMBER : 분리회원
                if ("INACTIVE_MEMBER".equals(loginMember.getTblNm())) {

                    loginMapper.reInsertInactive(loginMember);
                    loginMapper.deleteInactive(loginMember);

//                CookieUtil.addResponseCookie(response, "InactiveUserNM", URLEncoder.encode(loginMember.getMembNm(), "UTF-8"), -1);
//                CookieUtil.addResponseCookie(response, "InactiveUserLastDT", loginMember.getFnlCnntnDt(), -1);
                }

                // 암호화가 sha128로 되어있는 경우 sha256으로 변경
                if (loginMember.getPwd().length() < 41) {
                    String pwd = XdbUtil.getHashEncryptSha256(password);
                    loginMember.setPwd(pwd);
                    loginMapper.updateUserPwd(loginMember);
                }
                // 패스워드 오류회수 초기화
                loginMapper.updatePassReset(loginMember);

                // 아이디 저장,삭제 쿠키처리
                if (memberVO.isSaveId()) {
                    String encMemberId = XdbUtil.getPosNormalEncrypt(loginMember.getMembId());
                    CookieUtil.addResponseCookie(response, "MemberId", encMemberId, 1000L * 60 * 60 * 24 * 30);
                } else {
                    CookieUtil.addResponseCookie(response, "MemberId", null, 0);
                }

                loginMember.setPwd(null);
                return loginMember;

            }
        } catch (Exception e) {
            e.printStackTrace();
            CookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, null, 0);
            CookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, null, 0);
            throw e;
        }
    }

    /**
     * methodName : logout
     * author :  kjm
     * description : 로그아웃
     * @param request
     * @param response
     */
    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response) {

        Cookie refreshTokenCookie = CookieUtil.getCookie(request, CommonConstants.FO_REFRESH_TOKEN_NAME);

        String refreshToken = Optional.ofNullable(refreshTokenCookie)
                .map(Cookie::getValue)
                .orElse(null);

        CookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, null, 0);

        // RefreshToken Expire
        CookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, null, 0);
        redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + foAccountInfoUtil.getMembId() + ":" + refreshToken);

        CookieUtil.addResponseCookie(response, "token", null, 0);
    }


    /**
     * methodName : getAutoLoginToken
     * author :  kjm
     * description : 자동로그인 토큰 조회
     * @param searchToken
     * @return AutoLoginToken
     */
    @Override
    public AutoLoginToken getAutoLoginToken(HttpServletRequest request, HttpServletResponse response, AutoLoginToken searchToken) {
//        return loginMapper.getAutoLoginToken(searchToken);
        try {
            request.setAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE, new LiteDeviceResolver().resolveDevice(request));

            String membId = "";
            log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            log.info("자동로그인 조회시작 token: {}", searchToken.getAutoLoginTknVal());
            Device device = DeviceUtils.getCurrentDevice(request);
            if(device != null && device.isMobile()) {
                if(request.getHeader("user-agent").contains("daisoIosApp") || request.getHeader("user-agent").contains("daisoAndroid")) {
                    // 모바일앱
                    log.info("앱 토큰 조회");
                    log.info("redisKey: {}", CommonConstants.MOBILE_APP_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
                    membId = redisUtil.getData(CommonConstants.MOBILE_APP_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
                } else {
                    // 모바일웹
                    log.info("모바일 웹 토큰 조회");
                    log.info("redisKey: {}", CommonConstants.MOBILE_WEB_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
                    membId = redisUtil.getData(CommonConstants.MOBILE_WEB_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
                }
            } else if(device != null && !device.isMobile()) {
                // pc인경우
                log.info("PC 토큰 조회");
                log.info("redisKey: {}", CommonConstants.PC_WEB_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
                membId = redisUtil.getData(CommonConstants.PC_WEB_AUTO_LOGIN_TOKEN + ":" + searchToken.getAutoLoginTknVal());
            } else {
                return null;
            }

            if(org.springframework.util.StringUtils.hasText(membId)) {
                searchToken.setMembId(membId);
                log.info("자동로그인 조회결과 token: {}", searchToken.getAutoLoginTknVal());
                log.info("자동로그인 조회결과 membId: {}", searchToken.getMembId());
                log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
                return searchToken;
            } else {
                CookieUtil.addResponseCookie(response, "token", "", 0);
                return null;
            }
        } catch (Exception e) {
            CookieUtil.addResponseCookie(response, "token", "", 0);
            e.printStackTrace();
            return null;
        }
    }

    /**
     * methodName : extendAutoLoginToken
     * author :  kjm
     * description : 자동로그인 토큰 연장
     * @param autoLoginToken
     */
    @Override
    @Transactional
    public void extendAutoLoginToken(AutoLoginToken autoLoginToken) {
        loginMapper.extendAutoLoginToken(autoLoginToken);
    }

    /**
     * methodName : snsLogin
     * author :  kjm
     * description : sns 로그인
     * @param request
     * @param response
     * @param paramMap
     */
    @Override
    @Transactional
    public void snsLogin(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paramMap) throws IOException {

        String webUrl = "";
        if(DeviceUtils.getCurrentDevice(request).isMobile()) {
            webUrl = CommonPathInfo.MOBILE_FULL_SSL2;
        } else {
            webUrl = CommonPathInfo.ROOT_FULL_SSL2;
        }

        // SNS 계정의 회원 여부 확인
        String returnUrl = (String) paramMap.get("returnUrl");
        SnsMemberVO snsMemberVO = memberService.getSnsMember(paramMap);
        if(snsMemberVO == null) {
            // sns No, daiso가입 No
            // 동의처리 후 sns아이디 저장, 이후 daiso 회원가입

            snsMemberVO = new SnsMemberVO();
            snsMemberVO.setSnsId((String)paramMap.get("snsId"));
            snsMemberVO.setKnd((String)paramMap.get("knd"));
            memberService.insertSocialMember(snsMemberVO);

            CookieUtil.addResponseCookie(response, "_si", snsMemberVO.getSnsId(), 1000 * 60 * 5); // sns id 저장
            CookieUtil.addResponseCookie(response, "_k", snsMemberVO.getKnd().substring(0, 1), 1000 * 60 * 5); // 종류 저장

            AccountInfo loginMember = foAccountInfoUtil.getAccountInfo();
            if(loginMember == null) {
                if (!StringUtils.isBlank(returnUrl)) {
                    response.sendRedirect(webUrl + "account/social-complete?returnUrl=" + returnUrl + "&knd=" + snsMemberVO.getKnd() + "&loginType=001");
                } else {
                    response.sendRedirect(webUrl + "account/social-complete?knd=" + snsMemberVO.getKnd() + "&loginType=001");
                }
            } else {
                snsMemberVO.setMembId(loginMember.getMembId());
                memberService.updateSocialMember(snsMemberVO);
                if (!StringUtils.isBlank(returnUrl)) {
                    response.sendRedirect(returnUrl);
                } else {
                    response.sendRedirect(webUrl);
                }
            }

        } else if(StringUtils.isBlank(snsMemberVO.getMembId())) {

            // sns Yes, daiso가입 No
            String knd = "";

            CookieUtil.addResponseCookie(response, "_si", snsMemberVO.getSnsId(), 1000 * 60 * 5); // sns id 저장
            CookieUtil.addResponseCookie(response, "_k", snsMemberVO.getKnd().substring(0, 1), 1000 * 60 * 5); // 종류 저장

            AccountInfo loginMember = foAccountInfoUtil.getAccountInfo();
            if(loginMember == null) {
                if (!StringUtils.isBlank(returnUrl)) {
                    response.sendRedirect(webUrl + "account/social-complete?returnUrl=" + returnUrl + "&knd=" + snsMemberVO.getKnd() + "&loginType=001");
                } else {
                    response.sendRedirect(webUrl + "account/social-complete?knd=" + snsMemberVO.getKnd() + "&loginType=001");
                }
            } else {
                snsMemberVO.setMembId(loginMember.getMembId());
                memberService.updateSocialMember(snsMemberVO);
                if (!StringUtils.isBlank(returnUrl)) {
                    response.sendRedirect(returnUrl);
                } else {
                    response.sendRedirect(webUrl);
                }
            }
        } else {
            // sns Yes, daiso가입 Yes
            MemberVO searchMemberVO = new MemberVO();
            searchMemberVO.setMembId(snsMemberVO.getMembId());
            AccountInfo loginMember = memberService.getMemberById(searchMemberVO);
            insertLoginLog(request, searchMemberVO, "Y");
            tokenUtil.addLoginSuccessToken(loginMember, response);
            if (!StringUtils.isBlank(returnUrl)) {
                response.sendRedirect(webUrl + "account/social-redirect?to=" + returnUrl + "&knd=" + snsMemberVO.getKnd());
            } else {
                response.sendRedirect(webUrl + "account/social-redirect?to=" + webUrl  + "&knd=" + snsMemberVO.getKnd());
            }
        }
    }

    /**
     * methodName : deleteToken
     * author :  kjm
     * description : 토큰 삭제
     * @param request
     * @param response
     */
    @Override
    public void deleteToken(HttpServletRequest request, HttpServletResponse response) {
        Cookie refreshTokenCookie = CookieUtil.getCookie(request, CommonConstants.FO_REFRESH_TOKEN_NAME);

        String refreshToken = Optional.ofNullable(refreshTokenCookie)
                .map(Cookie::getValue)
                .orElse(null);

        CookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, null, 0);

        // RefreshToken Expire
        CookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, null, 0);
        redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + foAccountInfoUtil.getMembId() + ":" + refreshToken);
    }

    // 문자열 암호화
    private String cmEnCrypt(String encString) {

        String encrypted = "";
        byte[] digested = null;

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(encString.getBytes("UTF-8"));
            digested = md.digest();
            // encrypted = Base64Encoder.encode(digested);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return encrypted;
    }

    // 로그인 로그 저장
    private void insertLoginLog(HttpServletRequest request, MemberVO memberVO, String loginResult) {
        memberVO.setCnntnIp(CommonUtil.getClientIp(request));
        memberVO.setLoginRslt(loginResult);
        loginMapper.insertLoginLog(memberVO);
    }

    /**
     * methodName : saveAutoLoginToken
     * author :  kjm
     * description : 자동로그인 토큰 저장
     * @param request
     * @param response
     * @param autoLoginToken
     */
    @Override
    public void saveAutoLoginToken(HttpServletRequest request, HttpServletResponse response, AutoLoginToken autoLoginToken) {

        try {
            request.setAttribute(DeviceUtils.CURRENT_DEVICE_ATTRIBUTE, new LiteDeviceResolver().resolveDevice(request));
            Device device = DeviceUtils.getCurrentDevice(request);
            if(device != null && device.isMobile()) {
                if(request.getHeader("user-agent").contains("daisoIosApp") || request.getHeader("user-agent").contains("daisoAndroid")) {
                    // 모바일앱
                    redisUtil.setDataExpire(
                            CommonConstants.MOBILE_APP_AUTO_LOGIN_TOKEN + ":" + autoLoginToken.getAutoLoginTknVal(),
                            autoLoginToken.getMembId(),
                            CommonConstants.AUTO_LOGIN_EXPIRE_TIME);
                } else {
                    // 모바일웹
                    redisUtil.setDataExpire(
                            CommonConstants.MOBILE_WEB_AUTO_LOGIN_TOKEN + ":" + autoLoginToken.getAutoLoginTknVal(),
                            autoLoginToken.getMembId(),
                            CommonConstants.AUTO_LOGIN_EXPIRE_TIME);
                }
//                CookieUtil.addResponseCookie(response, "token", UriEncoder.encode(autoLoginToken.getAutoLoginTknVal(), Charset.forName("UTF-8")), 1000L * 60 * 60 * 24 * 30);
                CookieUtil.addResponseCookie(response, "token", autoLoginToken.getAutoLoginTknVal(), 1000L * 60 * 60 * 24 * 30);
            } else if(device != null && !device.isMobile()) {
                // pc
                redisUtil.setDataExpire(
                        CommonConstants.PC_WEB_AUTO_LOGIN_TOKEN + ":" + autoLoginToken.getAutoLoginTknVal(),
                        autoLoginToken.getMembId(),
                        CommonConstants.AUTO_LOGIN_EXPIRE_TIME);
//                CookieUtil.addResponseCookie(response, "token", UriEncoder.encode(autoLoginToken.getAutoLoginTknVal(), Charset.forName("UTF-8")), 1000L * 60 * 60 * 24 * 30);
                CookieUtil.addResponseCookie(response, "token", autoLoginToken.getAutoLoginTknVal(), 1000L * 60 * 60 * 24 * 30);
            } else {
                CookieUtil.addResponseCookie(response, "token", autoLoginToken.getAutoLoginTknVal(), 0L);
            }
        } catch (Exception e) {
            e.printStackTrace();
            CookieUtil.addResponseCookie(response, "token", autoLoginToken.getAutoLoginTknVal(), 0L);
        }
    }
}
