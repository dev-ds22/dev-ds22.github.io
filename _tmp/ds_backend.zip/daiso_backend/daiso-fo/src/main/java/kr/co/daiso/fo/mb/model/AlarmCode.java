package kr.co.daiso.fo.mb.model;

/**
 * packageName      : kr.co.daiso.fo.mb.model
 * fileName         : AlarmCode
 * author           : kkh
 * date             : 2022-06-17
 * description      : 알림코드
 * ===========================================================
 * DATE                 AUTHOR              NOTE
 * -----------------------------------------------------------
 * 2022-06-17           kkh                최초 생성
 */

public enum AlarmCode {
    /**
     * 내차사기 주문관리
     */
    ORDER_MANAGE("ALM001"),
    /**
     * 동일모델 알림
     */
    IDENTITY_MODEL("ALM002"),
    /**
     * 판매준비차량알림
     */
    SALES_READY("ALM003");

    private final String code;

    public String getCode() {
        return code;
    }

    AlarmCode(String code) {
        this.code = code;
    }
}
