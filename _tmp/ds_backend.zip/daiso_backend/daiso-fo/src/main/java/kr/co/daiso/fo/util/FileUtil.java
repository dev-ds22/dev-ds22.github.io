package kr.co.daiso.fo.util;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.DaisoRestTemplate;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.model.MultipartInputStreamFileResource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.FileNameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * packageName    : kr.co.daiso.fo.util
 * fileName       : FileUtil
 * author         : Doo-Won Lee
 * date           : 2022-03-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-21      Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public class FileUtil {

    @Autowired
    MessageSource messageSource;

    // 허용되는 마입타입 목록
    List<String> allowContentTypeList   = Arrays.asList("image", "application");
    // 허용되는 파일의 확장자 목록
    List<String> allowExtList   		= Arrays.asList(".jpeg", ".jpg", ".png", ".gif", ".hwp", ".xlsx", ".xls", ".csv", ".pdf", ".pptx", ".ppt", ".docx", ".word", ".zip", ".mp3", ".mp4", ".wav", "avi", ".mpeg");
    // 허용되는 이미지 확장자 목록
    List<String> allowImgExtList   		= Arrays.asList(".jpeg", ".jpg", ".png", ".gif");
    // 허용되는 엑셀 확장자 목록
    List<String> allowExcelExtList   	= Arrays.asList(".xlsx", ".xls");
    // 허용되는 보험증서 확장자 목록
    List<String> allowInsuranceExtList   	= Arrays.asList(".jpeg", ".jpg", ".png",".pdf");


    public enum DaisoFileType{
        ALL("ALL", null),
        IMAGE("IMAGE", null),
        INSURANCE("INSURANCE", null),
        BRANDMALL("BRANDMALL", null),
        EXCEL("EXCEL", null),

        SUGGEST("SUGGEST", "SUGGEST"),      //칭찬/제안
        SND("SND", "SND"),                  //고객의 소리
        UNETHICAL("UNETHICAL", "UNETHICAL"), //비윤리제보
        BRANDMALL_SCHEDULE("BRANDMALL_SCHEDULE", "acmDealerCarSales"),
        BRANDMALL_PERFORM("BRANDMALL_PERFORM", "acmDealerCarPerform"),
        HOMEENCAR("HOMEENCAR","HOMEENCAR"),   //탁송후 사진등록
        ;


        private String type;

        private String pathPrefix;

        private DaisoFileType(){
            log.debug("DaisoFileType");
        }

        private DaisoFileType(String type, String pathPrefix){
            this.type = type;
            this.pathPrefix = pathPrefix;
        }

        public String getType(){
            return this.type;
        }
        public String getPathPrefix() { return this.pathPrefix; }

    }

    /**
     * methodName : isAllowUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드시 허용 여부 처리
     *
     * @param file, failModel
     */
    public boolean isAllowUpload(MultipartFile file, CommonResponseModel failModel){
        String contentType = file.getContentType();
        String fileExt = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

        Locale locale = LocaleContextHolder.getLocale();

        if (null!=contentType && null!=fileExt){

            String fileMimeType = contentType.split("/")[0];
            if ((allowContentTypeList.contains(fileMimeType) && allowExtList.contains(fileExt)) == false) {
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileType", null, locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
            long fileSize = file.getSize();
            if (fileSize>CommonConstants.LIMIT_SIZE_OF_UPLOAD){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileSize"
                                                                    , new String[]{String.valueOf(CommonConstants.LIMIT_SIZE_OF_UPLOAD/(1024*1024))}
                                                                    , locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
        }
        return true;
    }

    /**
     * methodName : isAllowUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드시 파일 타입에 맞는 허용 여부 처리
     *
     * @param file, failModel,type
     */
    public boolean isAllowUpload(MultipartFile file, CommonResponseModel failModel, DaisoFileType type){
        String contentType = file.getContentType();
        String fileExt = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

        Locale locale = LocaleContextHolder.getLocale();

        if (null!=contentType && null!=fileExt){

            String fileMimeType = contentType.split("/")[0];

            boolean isFileTypeAllow = true;

            if (!allowContentTypeList.contains(fileMimeType)){
                isFileTypeAllow = false;
            }
            else{
                switch(type){
                    case ALL:
                        if (!allowExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    case IMAGE:
                        if (!allowImgExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    case EXCEL:
                        if (!allowExcelExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    case BRANDMALL: //Image만  사용
                        if (!allowImgExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    default:
                        if (!allowExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                }
            }

            if (!isFileTypeAllow){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileType", null, locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }

            long fileSize = file.getSize();
            if (fileSize>CommonConstants.LIMIT_SIZE_OF_UPLOAD){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileSize"
                            , new String[]{String.valueOf(CommonConstants.LIMIT_SIZE_OF_UPLOAD/(1024*1024))}
                            , locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
        }
        return true;
    }

    /**
     * methodName : multipartFileUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드
     *
     * @param file, path
     * @return  String
     */
    public String multipartFileUpload(MultipartFile file, String path, HttpServletRequest req)  throws IOException {
        File folder = new File(path);
        String attachId = RandomStringUtils.randomAlphanumeric(20);
//        System.out.println(file.getOriginalFilename());
//        System.out.println(FileNameUtils.getBaseName(file.getOriginalFilename()));
//        System.out.println(FileNameUtils.getExtension(file.getOriginalFilename()));
        String predictOriName = (req.getParameter("chgName") == null) ? file.getOriginalFilename() : req.getParameter("chgName");
        String newFileName = FileNameUtils.getBaseName(predictOriName)+attachId+"."+FileNameUtils.getExtension(file.getOriginalFilename());
        if (!folder.exists()) {
            folder.mkdirs();
        }
        log.info(folder.getAbsolutePath());
//        file.transferTo(new File(folder.getAbsolutePath(),newFileName));

        File newFile = new File(folder.getAbsolutePath()+"/"+newFileName);
        FileOutputStream fos = new FileOutputStream(newFile);

        try{
            fos.write(file.getBytes());
        }catch(IOException ie){
            throw ie;
        }finally {
            fos.close();
        }
//        file.transferTo(new File(folder.getAbsolutePath()+"/"+newFileName));
        return newFileName;
    }


    /**
     * methodName : fileDownload
     * author : Doo-Won Lee
     * description : File Download
     *
     * @param  filePath, request, response
     * @return  void
     */
    public void fileDownload(String filePath, HttpServletRequest request, HttpServletResponse response) throws IOException{
        File downFile = new File(filePath);
        log.info(downFile.getName());
        String newFileName = FileNameUtils.getBaseName(downFile.getName());
        log.info(newFileName);

        if(request.getHeader("User-Agent").indexOf("MSIE") > -1){
            newFileName = URLEncoder.encode(downFile.getName(), "UTF-8");
        } else {
            newFileName = new String(downFile.getName().getBytes(StandardCharsets.UTF_8));
        }
        response.addHeader(HttpHeaders.CONTENT_TYPE,"Application/octet-stream" );
        response.addHeader(HttpHeaders.CONTENT_ENCODING, "binary");
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.builder("attachment")
                                                                                .filename(newFileName, StandardCharsets.UTF_8)
                                                                                .build().toString());
        OutputStream out = response.getOutputStream();
        FileInputStream fis = null;
        fis = new FileInputStream(downFile);
        FileCopyUtils.copy(fis, out);
        fis.close();
        out.flush();
    }

    /**
     * methodName : transferImageFileToIdc
     * author : Doo-Won Lee
     * description : IDC에 이미지 파일을 업로드 한다
     *
     * @param  file
     * @return  ResponseEntity<CommonResponseModel>
     */
    public ResponseEntity<CommonResponseModel> transferImageFileToIdc(MultipartFile file)  throws IOException {

        String idcFoUrl = CommonPathInfo.IDC_FO_DOMAIN + "/common/img-file-upld/";
        DaisoRestTemplate DaisoRestTemplate = new DaisoRestTemplate(idcFoUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new MultipartInputStreamFileResource(file.getInputStream(), file.getOriginalFilename()));

        ResponseEntity idcResult = DaisoRestTemplate.exchage(body,headers,String.class);

//        System.out.println("idcResult=" + idcResult.toString());
        log.info("idcResult = "+idcResult);

        return idcResult;
    }

    /**
     * methodName : transferFileToIdc
     * author : Doo-Won Lee
     * description : IDC에 파일을 업로드 한다
     *
     * @param  file, req
     * @return  ResponseEntity<CommonResponseModel>
     */
    public ResponseEntity<CommonResponseModel> transferFileToIdc(MultipartFile file, HttpServletRequest req)  throws IOException {

        String idcFoUrl = CommonPathInfo.IDC_FO_DOMAIN + "/common/file-upld/";

        String type = req.getParameter("type");
        String sendFileType = null;

//        System.out.println(DaisoFileType.valueOf(type) == DaisoFileType.IMAGE);

        //타입 안맞을시 IDC로 던질 필요없이 에러
        switch(DaisoFileType.valueOf(type)){
            case IMAGE:
                sendFileType = DaisoFileType.IMAGE.getType();
                break;
            case INSURANCE:
                sendFileType = DaisoFileType.INSURANCE.getType();
                break;
            case EXCEL:
                sendFileType = DaisoFileType.EXCEL.getType();
                break;
            case ALL:
                sendFileType = DaisoFileType.ALL.getType();
                break;
            case SUGGEST:      //칭찬/제안
                sendFileType = DaisoFileType.SUGGEST.getType();
                break;
            case SND:                  //고객의 소리
                sendFileType = DaisoFileType.SND.getType();
                break;
            case UNETHICAL: //비윤리제보
                sendFileType = DaisoFileType.UNETHICAL.getType();
                break;
            case BRANDMALL_SCHEDULE:
                sendFileType = DaisoFileType.BRANDMALL_SCHEDULE.getType();
                break;
            case BRANDMALL_PERFORM:
                sendFileType = DaisoFileType.BRANDMALL_PERFORM.getType();
                break;
            case HOMEENCAR:   //탁송후 사진등록
                sendFileType = DaisoFileType.HOMEENCAR.getType();
                break;
            default:
                throw new CommonException("unacceptable file type", HttpStatus.BAD_REQUEST);
        }

//       idcFoUrl = "http://api.Daisodev.com:8090" + "/common/file-upld/";

        DaisoRestTemplate DaisoRestTemplate = new DaisoRestTemplate(idcFoUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new MultipartInputStreamFileResource(file.getInputStream(), file.getOriginalFilename()));
        body.add("type",sendFileType);
        body.add("path",req.getParameter("path"));
        body.add("chgName",req.getParameter("chgName"));

        ResponseEntity idcResult = DaisoRestTemplate.exchage(body,headers,String.class);

        log.info("idcResult = "+idcResult);

        return idcResult;

    }

    /**
     * methodName : fileUpload
     * author : Doo-Won Lee
     * description : 파일을 업로드 한다
     *
     * @param  file, req
     * @return  ResponseEntity<CommonResponseModel>
     */
     public ResponseEntity<CommonResponseModel> fileUpload( MultipartFile file, HttpServletRequest req) throws IOException{
         Map<String, String> resultMap = new HashMap<>();
         String fileTypeStr = req.getParameter("type");
         String filePathStr = req.getParameter("path");
         FileUtil.DaisoFileType DaisoFileType = FileUtil.DaisoFileType.valueOf(fileTypeStr);

         String uploadFilePath = CommonPathInfo.UPLOAD_FILE_TEMP_PATH;
         CommonResponseModel failModel = new CommonResponseModel();

         if (isAllowUpload(file, failModel, DaisoFileType)) {
             switch(DaisoFileType) {
                 case INSURANCE:
                     uploadFilePath = CommonPathInfo.UPLOAD_INSURANCE_PATH;
                     break;
                 case IMAGE:
                     uploadFilePath = CommonPathInfo.UPLOAD_IMAGE_PATH;
                     break;
                 case BRANDMALL:
                     uploadFilePath = CommonPathInfo.UPLOAD_CAR_IMG_AFTER_PATH;
                     break;
                 case SUGGEST:      //칭찬/제안
                 case HOMEENCAR:     //탁송후 사진등록
                     uploadFilePath = CommonPathInfo.UPLOAD_IMAGE_PATH + ((DaisoFileType.getPathPrefix() == null)? "" : DaisoFileType.getPathPrefix())+ "/";
                     break;
                 case SND:          //고객의 소리
                 case UNETHICAL:    //비윤리제보
                     uploadFilePath = CommonPathInfo.UPLOAD_FILE_TEMP_PATH + ((DaisoFileType.getPathPrefix() == null)? "" : DaisoFileType.getPathPrefix())+ "/";
                     break;
                 case BRANDMALL_SCHEDULE:
                 case BRANDMALL_PERFORM:
                     uploadFilePath = CommonPathInfo.UPLOAD_CAR_IMG_URL + ((DaisoFileType.getPathPrefix() == null)? "" : DaisoFileType.getPathPrefix())+ "/";
                     break;
                 default:
                     uploadFilePath = CommonPathInfo.UPLOAD_FILE_TEMP_PATH;
                     break;
             }

             if (null!=filePathStr && filePathStr.length()>0){
                 uploadFilePath = uploadFilePath + filePathStr;
             }
             String  newFileName = multipartFileUpload(file, uploadFilePath,req);  //파일만 업로드 처리

             switch(CommonPathInfo.SERVER_TYPE){
//                case "local":
//                case "dev":
//                case "dev_cloud":
//                    break;
                 case "stg":
                 case "stg_cloud":
                 case "prd":
                 case "prd_cloud":
                     uploadFilePath = uploadFilePath.replace("/BASE/Daiso_nas","");
                     uploadFilePath = uploadFilePath.replace("/BASE/Daiso","");
                     break;
                 default:
                     break;
             }

             resultMap.put("filePath", uploadFilePath + newFileName);
             resultMap.put("fileName", newFileName);
             resultMap.put("filePathOnly", uploadFilePath);

             log.info("expect return if:"+resultMap);
         } else {
             return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
         }
         log.info("expect return normal:"+resultMap);
         return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
     }
}
