package kr.co.daiso.fo.mb.service;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberAlarmVO;
import kr.co.daiso.fo.mb.model.MemberVO;
import kr.co.daiso.fo.mb.model.SnsMemberVO;
import kr.co.daiso.fo.message.model.SmsVO;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.mb.service
 * fileName       : MemberService
 * author         : kjm
 * date           : 2022-02-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18       kjm            최초생성
 */
public interface MemberService {

    // 오버랩키로 회원조회
    AccountInfo getMemberByOverlapKey(AccountInfo accountInfo);

    // 아이디로 회원조회
    AccountInfo getMemberById(MemberVO memberVO);

    // 비밀번호 초기화
    CommonResponseModel resetPassword(MemberVO memberVO);

    // 회원 저장
    CommonResponseModel insertMember(HttpServletRequest request, HttpServletResponse response, MemberVO memberVO);

    // 인증 sms 전송
    ResponseEntity sendAuthSms(SmsVO smsVO);

    // 인증 sms 확인
    boolean checkAuthSms(Map<String, Object> paramMap);

    // 인증 sms 확인용 키 삭제
    void deleteJoinKey(Map<String, Object> paramMap);

    // 미성년자 가입시도 저장
    void insertMemberNonAge();

    // sns 가입회원 조회
    SnsMemberVO getSnsMember(Map<String, Object> paramMap);

    // sns 계정 연결 수정
    void updateSocialMember(SnsMemberVO snsMemberVO);

    // sns 계정 연결 추가
    void insertSocialMember(SnsMemberVO snsMemberVO);

    // 비밀번호 오류횟수 초기화
    void resetPwdErrorCount(AccountInfo accountInfo);

    // 회원알림로그 저장
    int insertMemberAlarmLog(MemberAlarmVO memberAlarmVO);
}
