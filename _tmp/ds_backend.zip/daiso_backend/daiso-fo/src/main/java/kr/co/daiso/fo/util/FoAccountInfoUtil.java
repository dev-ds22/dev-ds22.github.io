package kr.co.daiso.fo.util;

import kr.co.daiso.fo.mb.model.AccountInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * packageName    : kr.co.daiso.mg.util
 * fileName       : FoAccountInfoUtil
 * author         : Doo-Won Lee
 * date           : 2021-12-17
 * description    : 로그인한 관리자의 정보제공 유틸
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-17     Doo-Won Lee        최초생성
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FoAccountInfoUtil {
    Authentication auth = null;
    AccountInfo accountInfo = new AccountInfo();
    public AccountInfo getAccountInfo() {
        auth = SecurityContextHolder.getContext().getAuthentication();
        if (null!=auth && !"anonymousUser".equals(auth.getPrincipal()) )
            accountInfo = (AccountInfo)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        else accountInfo = null;
        return accountInfo;
    }

    public String getMembId() {
        return Optional.ofNullable(getAccountInfo())
                .map(AccountInfo::getMembId)
                .orElse(null);
    }

    public boolean isLogined(){
        return (null == getMembId())?false:true;
    }
}
