package kr.co.daiso.fo.common.service;

import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.message.model.SmsVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service
 * fileName       : SmsApiService
 * author         : BYUNG-CHUL PARK
 * date           : 2022-06-09
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-06-09     BYUNG-CHUL PARK   최초생성
 */

public interface SmsApiService {

   //SMS 정보를 입력하는 api
   public void insertSmsApi(SmsVO smsVO, List<CommonCodeManageVO> phoneList);

}
