package kr.co.daiso.fo.common.mapper.oracle;

import kr.co.daiso.fo.common.model.SmsInputVO;
import kr.co.daiso.fo.message.model.SmsVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.fo.common.mapper.oracle
 * fileName       : SmsApiMapper
 * author         : BYUNG-CHUL PARK
 * date           : 2022-06-09
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-06-09     BYUNG-CHUL PARK    최초생성
 */
@Mapper
public interface SmsApiMapper {
    void insertSmsQueue(SmsVO smsVO);

    void insertSmsMyDb(SmsVO smsVO);
}
