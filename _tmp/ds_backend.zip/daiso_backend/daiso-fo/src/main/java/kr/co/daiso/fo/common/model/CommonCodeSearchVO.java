package kr.co.daiso.fo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : CommonCodeSearchVo
 * author         : Doo-Won Lee
 * date           : 2022-02-16
 * description    : 공통코드 검색용 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-16     Doo-Won Lee      최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonCodeSearchVO extends CommonPagingVo {

    private String sMstCode;        //검색 마스터 코드
    private String sMstCodeNm;      //검색 마스터 코드명

    private String sSubCode;        //검색 서브 코드
    private String sSubCodeNm;      //검색 서브 코드명

    private String useYn;           //사용 여부
    private String delYn;           //삭제 여부
    private String ucmsCdYn;        //UCMS 코드 여부

    private String	addtFld1;       //추가 필드1
    private String	addtFld2;       //추가 필드2
    private String	addtFld3;       //추가 필드3

    private String[] arrSubCd;

    //복수의 마스터 코드 조회 필요로 추가
    private List<String> masterCdList;

}