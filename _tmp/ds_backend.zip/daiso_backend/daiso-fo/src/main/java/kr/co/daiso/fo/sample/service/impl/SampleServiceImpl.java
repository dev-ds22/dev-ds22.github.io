package kr.co.daiso.fo.sample.service.impl;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.fo.auth.JwtTokenProvider;
import kr.co.daiso.fo.common.util.ExcelHandler;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.sample.mapper.oracle.SampleOracleMapper;
import kr.co.daiso.fo.sample.model.SampleModel;
import kr.co.daiso.fo.sample.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SampleServiceImpl implements SampleService {

    @Autowired
    JwtTokenProvider loginTokenProvider;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    SampleOracleMapper sampleOracleMapper;

//    @Autowired
//    SampleMysqlMapper sampleMysqlMapper;

    CookieUtil cookieUtil = new CookieUtil();

    @Autowired
    RedisUtil redisUtil;

    /**
     * methodName : getSampleCode
     * author :  Doo-Won Lee
     * description : SampleCode를 가져온다
     *
     * @return List<SampleModel>
     */
    @Override
    public List<SampleModel> getSampleCode() {
        return sampleOracleMapper.getSampleCode();
    }

    /**
     * methodName : testOracle
     * author :  Doo-Won Lee
     * description : Oracle 연동 테스트한다.
     */
    @Override
    public void testOracle() {
        sampleOracleMapper.testOracle();
    }

//    @Override
//    public ResponseEntity<CommonResponseModel> loginProcess(SampleLoginVO loginParams, HttpServletResponse response) {
//
//        CommonResponseModel resultModel = new CommonResponseModel();
//        try {
//            AccountInfo accountInfo = sampleMysqlMapper.getAccount(loginParams.getId());
//
//            if (accountInfo == null) {
//                resultModel.setSuccess(false);
//                resultModel.setMessage("아이디또는 비번다름");
//            }
//            else{
//                log.info(accountInfo.toString());
//                log.info(passwordEncoder.encode(loginParams.getPassword()));
//                if ( !passwordEncoder.matches(loginParams.getPassword(), accountInfo.getPassword()) ) {
//                    resultModel.setSuccess(false);
//                    resultModel.setMessage("아이디또는 비번다름");
//                }
//                else{
//                    accountInfo.setPassword(null);
//                    resultModel.setSuccess(true);
//                    resultModel.setMessage("LOGIN SUCCESS.");
//                    resultModel.setData(accountInfo);
//
//                    // Access Token, Refresh Token 생성
//                    final String accessToken = loginTokenProvider.createFoAccessToken(accountInfo);
//                    final String refreshToken = loginTokenProvider.createFoRefreshToken(accountInfo);
//
////                    ResponseCookie accessTokenCookie = cookieUtil.createResponseCookie(CommonConstants.FO_ACCESS_TOKEN_NAME, accessToken, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
////                    ResponseCookie refreshTokenCookie = cookieUtil.createResponseCookie(CommonConstants.FO_REFRESH_TOKEN_NAME, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
////
////                    response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
////                    response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());
//
//                    cookieUtil.addResponseCookie(response,CommonConstants.FO_ACCESS_TOKEN_NAME, accessToken, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
//                    cookieUtil.addResponseCookie(response,CommonConstants.FO_REFRESH_TOKEN_NAME, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
//
//                    redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH+accountInfo.getId(), refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
//
//                    CookieUtil.addCSRFCookie(response);
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            resultModel.setSuccess(false);
//            return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.BAD_REQUEST);
//        }
//
//        return new ResponseEntity<CommonResponseModel>(resultModel,HttpStatus.OK);
//    }
//
//    @Override
//    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {Exception.class})
//    public ResponseEntity<CommonResponseModel> rgMember(AccountInfo aVo)throws Exception{
//
//        CommonResponseModel resultModel = new CommonResponseModel();
//        try{
//            sampleMysqlMapper.rgMember(aVo);
//            resultModel.setSuccess(true);
//            resultModel.setMessage("INSERT SUCCESS.");
//
//        }catch (Exception e){
//            throw e;
//        }
//
//        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
//    }
//

    /**
     * methodName : getSampleCode
     * author :  Doo-Won Lee
     * description : Oracle에서 샘플 코드를 가져온다
     *
     * @param params
     * @return List<SampleModel>
     */
    @Override
    public List<SampleModel> getSampleCode(Map<String,String> params) {
        return sampleOracleMapper.getSampleCode();
    }

    /**
     * methodName : getSampleCode
     * author :  Doo-Won Lee
     * description : Oracle에서 샘플 코드를 가져와서 엑셀 핸들러를 통해 다운로드 처리한다.
     *
     * @param response
     * @param param
     * @return List<SampleModel>
     */
    @Override
    public void getSampleCode(HttpServletResponse response, Map<String, String> param){
        List<String> comlumnList = new ArrayList<>();
        comlumnList.add("grCode");
        comlumnList.add("grCodeNm");
        comlumnList.add("useYn");
        ExcelHandler excelHandler = new ExcelHandler<SampleModel>(response,"테스트",comlumnList);
        sampleOracleMapper.getSampleCode(excelHandler);
        try {
            excelHandler.download();
        } catch (IOException e) {
            e.printStackTrace();
            excelHandler.close();
        }
    }

    /**
     * methodName : getPdf
     * author :  Doo-Won Lee
     * description : PDF 파일을 생성하는 샘플
     *
     * @param sampleModelList
     * @return ByteArrayInputStream
     */
    @Override
    public ByteArrayInputStream getPdf(List<SampleModel> sampleModelList){
        Document document = null;
//        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        try( ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            document = new Document();


            // 한글 처리를 위한 글꼴 설정 추가
            String fontPath = "/static/css/fonts/malgun.ttf";
            BaseFont bf = BaseFont.createFont(fontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);

            Font titleFont = new Font(bf, 15, Font.BOLD);
            Paragraph title = new Paragraph("문 서 제 목", titleFont);

            Font subTitleFont = new Font(bf, 14, Font.NORMAL);
            DateFormat titledf = new SimpleDateFormat("yyyy-MM-dd");
            Paragraph subTitle = new Paragraph("문서 소제목", subTitleFont);

            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.setWidths(new int[] { 2, 2, 3 });

            Font contentsFont = new Font(bf, 11, Font.NORMAL);

            Font headFont = new Font(bf, 11, Font.BOLD);
            table.addCell(setHeadCell("필드1", headFont));
            table.addCell(setHeadCell("필드2", headFont));
            table.addCell(setHeadCell("필드3", headFont));

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd/HH:mm:ss");
            int index = 0;
            for (SampleModel sampleModel : sampleModelList) {
//                table.addCell(setChildCell(sampleModelList.get(index).getGrCode() == null ? "-" : sampleModelList.get(index).getGrCode()));
//                table.addCell(setChildCellH(sampleModelList.get(index).getGrCodeNm() == null ? "-" : sampleModelList.get(index).getGrCodeNm(),contentsFont));
//                table.addCell(setChildCell(sampleModelList.get(index).getUseYn() == null ? "-" : sampleModelList.get(index).getUseYn()));
                index++;
            }

            PdfWriter.getInstance(document, outputStream);

            document.open();
            document.add(title);
            document.add(Chunk.NEWLINE);
            document.add(subTitle);
            document.add(Chunk.NEWLINE);
            document.add(table);

            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (DocumentException | IOException ex) {
            log.error("PDF 파일 생성 실패");
        } finally {

            if(document != null) {

                document.close();

            }

        }

        return new ByteArrayInputStream(new ByteArrayOutputStream().toByteArray());
    }

    /**
     * methodName : setHeadCell
     * author :  Doo-Won Lee
     * description : PDF의 헤더부분의 셀을 작성한다.
     *
     * @param content
     * @param font
     * @return PdfPCell
     */
    private PdfPCell setHeadCell(String content, Font font) {
        PdfPCell hcell = new PdfPCell(new Phrase(content, font));
        hcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
        hcell.setBackgroundColor(new BaseColor(226, 226, 226));
        hcell.setFixedHeight(25f);
        return hcell;
    }

    /**
     * methodName : setHeadCell
     * author :  Doo-Won Lee
     * description : PDF의  셀을 작성한다.
     *
     * @param content
     * @return PdfPCell
     */
    private PdfPCell setChildCell(String content) {
        PdfPCell cell = new PdfPCell(new Phrase(content));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setFixedHeight(20f);
        return cell;
    }

    /**
     * methodName : setHeadCell
     * author :  Doo-Won Lee
     * description : PDF의  셀을 한글 내용을 작성한다.
     *
     * @param content
     * @param font
     * @return PdfPCell
     */
    private PdfPCell setChildCellH(String content, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(content, font));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setFixedHeight(20f);
        return cell;
    }

    /**
     * methodName : getSampleCodeCount
     * author :  Doo-Won Lee
     * description : 샘플코드의 갯수를 구한다.
     *
     * @param sampleModel
     * @return PdfPCell
     */
    @Override
    public int getSampleCodeCount(SampleModel sampleModel) {
        return sampleOracleMapper.getSampleCodeCount(sampleModel);
    }

    /**
     * methodName : getSampleCode2
     * author :  Doo-Won Lee
     * description : 샘플코드를 구한다.
     *
     * @param sampleModel
     * @return PdfPCell
     */
    @Override
    public List<SampleModel> getSampleCode2(SampleModel sampleModel) {
        return sampleOracleMapper.getSampleCode2(sampleModel);
    }

    @Override
    public SampleModel getSampleCode3(String mastCd) {
        return sampleOracleMapper.getSampleCode3(mastCd);
    }
}


