package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName      : kr.co.daiso.fo.mb.model
 * fileName         : MemberAlarmVO
 * author           : kkh
 * date             : 2022-06-17
 * description      : 회원알림로그
 * ===========================================================
 * DATE                 AUTHOR              NOTE
 * -----------------------------------------------------------
 * 2022-06-17           kkh                최초 생성
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class MemberAlarmVO extends BaseModel {
    /** 시퀀스 */
    private int seq;
    /** 알림코드 */
    private String almCd;
    /** 알림내용 */
    private String almCnts;
    /** 조회일시 */
    private String iqyDttm;
    /** 조회여부 */
    private String iqyYn;
    /** 회원ID */
    private String membId;
    /** 알림일시 */
    private String almDttm;
    /** 계약신청일련번호 */
    private String aplSn;
}
