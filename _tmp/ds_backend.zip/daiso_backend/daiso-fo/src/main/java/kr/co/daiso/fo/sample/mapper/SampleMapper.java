package kr.co.daiso.fo.sample.mapper;

import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.sample.model.SampleModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import java.util.List;

@Mapper
public interface SampleMapper {

    List<SampleModel> getSampleCode();

    AccountInfo getAccount(String id);
    //Oracle 엳동
    void testOracle();

    void rgMember(AccountInfo aVo);

    //샘플코드를 조회한다.
    void getSampleCode(ResultHandler<SampleModel> excelHander);

}
