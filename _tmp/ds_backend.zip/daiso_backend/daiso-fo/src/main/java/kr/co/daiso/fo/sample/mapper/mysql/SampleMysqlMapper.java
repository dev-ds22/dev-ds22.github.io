package kr.co.daiso.fo.sample.mapper.mysql;

import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.sample.model.SampleModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import java.util.List;

//Mysql을 사용하지 않아 사용 안함
@Mapper
public interface SampleMysqlMapper {

    List<SampleModel> getSampleCode();

    AccountInfo getAccount(String id);

    void testOracle();

    void rgMember(AccountInfo aVo);

    void getSampleCode(ResultHandler<SampleModel> excelHander);

    int getSampleCodeCount(SampleModel sampleModel);

    List<SampleModel> getSampleCode2(SampleModel sampleModel);
}
