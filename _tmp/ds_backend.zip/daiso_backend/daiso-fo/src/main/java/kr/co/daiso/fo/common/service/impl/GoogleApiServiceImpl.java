package kr.co.daiso.fo.common.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.cert.X509Certificate;
import java.util.Collections;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.common.collect.Lists;

import kr.co.daiso.fo.common.service.GoogleApiService;
import lombok.extern.slf4j.Slf4j;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : GoogleApiServiceImpl
 * author         :  Doo-WOn Lee
 * date           : 2022-03-11
 * description    : GoogleApi Service의 구현 Class
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-11      Doo-WOn Lee         최초생성
 */
@Slf4j
@Service
public class GoogleApiServiceImpl implements GoogleApiService {

    /**
     * methodName : getAccessToken_Google
     * author : Doo-Won Lee
     * description : Google AcessToken을 획득한다.
     *
     * @return String
     */
    @Override
    public String getAccessToken_Google() throws Exception {
        String accessToken = "";

        ClassPathResource resource = new ClassPathResource("google/content-api-key.json");
        try {
            String scopes = "https://www.googleapis.com/auth/content";
            HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
            JsonFactory jsonFactory = GsonFactory.getDefaultInstance();

            GoogleCredential credential = GoogleCredential
                    .fromStream(new FileInputStream(resource.getFile()), httpTransport, jsonFactory).createScoped(Lists.newArrayList(scopes));

            credential.refreshToken();
            credential.createScoped(Collections.singleton("https://www.googleapis.com/auth/content"));
            accessToken = credential.getAccessToken();

        } catch (Exception e) {
            e.printStackTrace();
            log.error("*******************************e.toString()**************"+e.toString());

        }
        log.info("*************************************accessToken********"+accessToken);
        return accessToken;
    }

    /**
     * methodName : updateGoogleApi
     * author : Doo-Won Lee
     * description : Google Content API - INSERT, DELETE
     *
     * @return String
     */
    @Override
    public String updateGoogleApi(String strEntry, String token) throws Exception {
        String rsjson = "";

        try {
            String URL = "https://www.googleapis.com/content/v2.1/products/batch";

            if(token == null || token.equals("")) {
                token = getAccessToken_Google();
                log.info("Token is null!!");
                log.info(token);
            } else {
                token = token.replaceAll("(\\n)*", "");
            }

            rsjson = httpsPostConnect("POST", URL, token, strEntry);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rsjson;
    }

    /**
     * methodName : updateGoogleApi
     * author : Doo-Won Lee
     * description : Google Content API - INSERT, DELETE
     *
     * @return String
     */
    @Override
    public String updateGoogleApiRe(String strEntry, String token) throws Exception {
        String rsjson = "";

        try {
            String URL = "https://www.googleapis.com/content/v2.1/241941171/products";

            if(token == null || token.equals("")) {
                token = getAccessToken_Google();
                log.info("Token is null!!");
                log.info(token);
            } else {
//                token = token.replaceAll("\n", "");
                token = token.replaceAll("(\\n)*", "");
            }

            rsjson = httpsPostConnectRe("POST", URL, token, strEntry);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rsjson;
    }

    public static String httpsPostConnect(String method, String URL, String header, String parameters) throws Exception {

        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs,
                                           String authType) {
                log.debug("GoogleApiService checkClientTrusted");
            }

            public void checkServerTrusted(X509Certificate[] certs,
                                           String authType) {
                log.debug("GoogleApiService checkClientTrusted");
            }
        } };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
//        HostnameVerifier allHostsValid = new HostnameVerifier() {
//            public boolean verify(String hostname, SSLSession session) {
//                return true;
//            }
//        };
        HostnameVerifier allHostsValid = (hostname, session) -> true;

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

        String rsjson = "";
        URL url = new URL(URL);
        final Charset charset = Charset.forName("UTF-8");
        final HttpURLConnection con = (HttpURLConnection) url.openConnection();
        try(AutoCloseable a = () -> con.disconnect()) {

            con.setRequestMethod(method);

            if(header != null && !"".equals(header)) {
                con.setRequestProperty("Authorization", "Bearer " + header);
                con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            }

            con.setConnectTimeout(20000);       //컨텍션타임아웃 10초
            con.setReadTimeout(10000);           //컨텐츠조회 타임아웃 5총

            // Send post request
            con.setDoOutput(true);              // 항상 갱신된내용을 가져옴.

            try(BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(), "UTF-8"))) {
                wr.write(parameters);
                wr.flush();
                wr.close();

                // 결과코드
                int responseCode = con.getResponseCode();
                StringBuilder response = new StringBuilder();

                if (responseCode == 200) {
                    try(BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), charset))) {
                        String inputLine = "";
                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine + "\n");
                        }
                    }
                } else {
                    try(BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream(), charset))){
                        String inputLine = "";
                        while ((inputLine = in.readLine()) != null) {
                            response.append(inputLine + "\n");
                        }
                    }
                }
                rsjson = response.toString();
            }

        } catch (Exception e) {
            throw new Exception(e);
        }
        return rsjson;
    }


    public static String httpsPostConnectRe(String method, String URL, String header, String parameters) throws Exception {

        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs,
                                           String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs,
                                           String authType) {
            }
        } };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
//        HostnameVerifier allHostsValid = new HostnameVerifier() {
//            public boolean verify(String hostname, SSLSession session) {
//                return true;
//            }
//        };
        HostnameVerifier allHostsValid = (hostname, session) -> true;

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

        String rsjson = "";
        URL url = new URL(URL);
        HttpURLConnection con = null;
        BufferedReader in = null;
        Charset charset = Charset.forName("UTF-8");

        try {
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod(method);

            if(header != null && !"".equals(header)) {
                con.setRequestProperty("Authorization", "Bearer " + header);
                con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            }

            con.setConnectTimeout(20000);       //컨텍션타임아웃 10초
            con.setReadTimeout(10000);           //컨텐츠조회 타임아웃 5총

            // Send post request
            con.setDoOutput(true);              // 항상 갱신된내용을 가져옴.

            BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(), "UTF-8"));
            wr.write(parameters);
            wr.flush();
            wr.close();

            // 결과코드
            int responseCode = con.getResponseCode();
            StringBuilder response = new StringBuilder();

            if (responseCode == 200) {
                in = new BufferedReader(new InputStreamReader(con.getInputStream(), charset));
            } else {
                in = new BufferedReader(new InputStreamReader(con.getErrorStream(), charset));
            }

            String inputLine = "";
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine + "\n");
            }

            rsjson = response.toString()+"/"+responseCode;

        } catch (Exception e) {
            throw new Exception(e);
        }finally{
            if(in != null){
                in.close();
            }
            if(con != null){
                con.disconnect();
            }
        }

        return rsjson;
    }
}
