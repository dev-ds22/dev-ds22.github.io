package kr.co.daiso.fo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import kr.co.daiso.common.config.DaisoBeanNameGenerator;

@SpringBootApplication
@ComponentScan(nameGenerator = DaisoBeanNameGenerator.class, basePackages = {"kr.co.daiso.common","kr.co.daiso.fo"})
public class DaisoFoApplication extends SpringBootServletInitializer {

    public static void main(String[] args){
//      SpringApplication.run(FoApplication.class, args);
//      System.setProperty("server.servlet.context-path", "/api");
      SpringApplication application = new SpringApplication(DaisoFoApplication.class);
      application.addListeners(new ApplicationPidFileWriter());
      application.run(args);
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
      return builder.sources(DaisoFoApplication.class);
  }	

}
