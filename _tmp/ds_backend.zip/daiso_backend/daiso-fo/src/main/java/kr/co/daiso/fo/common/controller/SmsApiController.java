package kr.co.daiso.fo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.service.CommonCodeService;
import kr.co.daiso.fo.common.service.SmsApiService;
import kr.co.daiso.fo.message.model.SmsVO;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * packageName    : kr.co.daiso.fo.common
 * fileName       : SmsApiController
 * author         : BYUNG-CHUL PARK
 * date           : 2022-06-07
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-06-07      BYUNG-CHUL PARK   최초생성
 */
@Slf4j
@RestController
@RequestMapping("/common/sms")
public class SmsApiController {


    @Autowired
    SmsApiService smsApiService;

    @Autowired
    CommonCodeService commonCodeService;

    /**
     * methodName : insertSmsApi
     * author : BYUNG-CHUL PARK
     * description : SMS INSERT API
     *
     * @return String
     */

    @ApiOperation("SMS Subject, Text 입력 API")
    @RequestMapping("sentinel_sms_noti")
    public ResponseEntity<CommonResponseModel> insertSmsApi(@ApiParam("SMS 입력 정보") SmsVO smsVO){

        log.info("subject value", smsVO.getSubject());
        log.info("text value", smsVO.getText());

        CommonCodeSearchVO searchVO = new CommonCodeSearchVO();
        searchVO.setSMstCode("SV_MANAGER");
        List<CommonCodeManageVO> phoneList = commonCodeService.getSubCodeList(searchVO);

        smsApiService.insertSmsApi(smsVO, phoneList);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
