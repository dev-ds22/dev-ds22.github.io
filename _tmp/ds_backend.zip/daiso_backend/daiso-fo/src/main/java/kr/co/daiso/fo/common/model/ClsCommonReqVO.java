package kr.co.daiso.fo.common.model;

import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.message.model.SmsVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : ClsCommonReqVO
 * author         :
 * date           :
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCommonReqVO extends AccountInfo implements Serializable {
    private static final long serialVersionUID = 1837713875060860656L;

    // lsm_sub_code
    /** 마스터 코드 */
//    private String		i_sMstCode;			// master code
//    /** 마스터 코드명 */
//    private String		i_sMstCodeNm;		// master code
//    /** 서브 코드 */
//    private String		i_sSubCode;			// sub code
//    /** 서브 코드명 */
//    private String		i_sSubCodeNm;
    /** 추가필드1 */
    private String		i_sBuffer1;			// buffer1
    //    /** 추가필드2 */
//    private String		i_sBuffer2;			// buffer2
//    /** 추가필드3 */
//    private String		i_sBuffer3;			// buffer3
//    private int			i_iSeqNo;
//    // [e] lsm_sub_code
//
//    private String		i_sSidoCode;
//    private String		i_sGugunCode;
//    private double		i_iGugunX;
//    private double		i_iGugunY;
//    private double		i_iNpointX;
//    private double		i_iNpointY;
//    private String		i_sZipCode;
//    private int			i_iSeq;
//
//    // [s] paging
//    private int			i_iGroupSize;
    private int			i_iTotalPageCnt;
    private int			i_iRecordCnt;
    private int			i_iPageSize;
    private int			i_iNowPageNo;
    private int			i_iSkipCnt;
    //    private	String		i_sSortCol;
//    private	String		i_sSortDir;
//    private int			i_iNowPageNo2;
    private int			i_iStartRownum;
    private int			i_iEndRownum;
//    // [e] paging

    private String		i_sActionFlag;
    private String		i_sPageUrl;
    private String		i_sPagePars;
    private String		i_sReturnUrl;
    //    private String		i_sReturnUrl2;
//    private String		i_sReturnPars;
    private String		i_sReturnPars2;
//    private String		i_sReturnType;
//    private String		i_sRequestUri;
//    private String		i_sRegUserCd;
//    private String		i_sUpdateUserCd;
    /** 사용자ID */
    private String		i_sUserId;
    /** 사용자명 REQ_NM */
    private String		i_sUserName;
    //    private String		i_sDeptCode;
//    private String		i_sTestType;
    private String		i_sOrderBy;
    //    private String		i_sOrderBy2;
//    private String      i_sModelOrderFlag;
//    private String		i_sCenterCode;
//    private String		i_sViewLevel;
//
//    private String		i_sThumbnailId;
//    private String		i_sThumbnailTempId;
//    private String		i_sThumbnailName;
//    private String		i_sThumbnailOldPath;
//    private String		i_sThumbnailPath;
//    private String		i_sThumbnailExt;
//    private String		i_sThumbnailWidth;
//    private String		i_sThumbnailHeight;
//    private String		i_sThumbnailStatus;
//
//    private String[]	i_arrDelAttachId;
//    private String[]	i_arrDelAttachFullPath;
//    private String[]	i_arrFlagOrignal;
//    private String[]	i_arrThumbnailStatus;
//    private String[]	i_arrThumbnailWidth;
//    private String[]	i_arrThumbnailHeight;
//    private String[]	i_arrThumbnailId;
//    private String[]	i_arrThumbnailTempId;
//    private String[]	i_arrThumbnailName;
//    private String[]	i_arrThumbnailOldPath;
//    private String[]	i_arrThumbnailPath;
//    private String[]	i_arrThumbnailExt;
//    private String[]	i_arrThumbnailSize;
//    private String[]	i_arrElanPath;
//
//    private String		i_sAttStatus;
//    private String		i_sAttachId;
//    private String		i_sRecordId;
//    private String		i_sAttachName;
//    private String		i_sAttachOldPath;
//    private String		i_sAttachPath;
//    private String		i_sAttachExt;
//    private long		i_lAttachSize;
//
//    private String[]	i_arrAttStatus;
//    private String[]	i_arrAttachId;
//    private String[]	i_arrRecordId;
//    private String[]	i_arrAttachName;
//    private String[]	i_arrAttachOldPath;
//    private String[]	i_arrAttachPath;
//    private String[]	i_arrAttachExt;
//    private String[]	i_arrAttachSize;
//
//    private String		s_USER_CD;
//    private String		s_USER_ID;
//    private String		s_USER_NAME;
//    private String		s_USER_TYPE;
//    private String		s_USER_GROUP;
//    private String		s_CENTER_CODE;
//    private String		s_LEADER_FLAG;
    private String		s_MEMBER_CD;
    private String		s_MEMBER_ID;
    private String		s_MEMBER_NAME;
    private String		s_MEMBER_MOBILE;
    private String		s_MEMBER_TYPE;
    private String		s_MEMBER_CHANNEL;
    //    private String		s_MEMBER_GENDER;
//    private String		s_MEMBER_BIRTH;
//    private String		s_MEMBER_REGION;
//
//    // 브랜드인증몰
    private String		s_MEMBER_DELER_CO_CD;
    private String		s_MEMBER_SHOW_ROOM_CD;
//
//    //main support
//    private	int			i_iSailCondition;
//    private	double		i_iInstallmentRate;
//    private	int			i_iBeforeDiscount;
//    private	int			i_iPartnerDiscount;
//    private	String		i_sSupportMonth;
//    private String		i_sLink;
//    private	String		i_sSailCarNm;
//
//    //excel
//    private	String		i_sFileId;
//    private	String		i_sFilePath;
//    private	String		i_sFileExt;
//    private	String		i_sOriFileId;
//
//    private String		i_sMakeCd;
//    private String		i_sModelCd;
//    private String		i_sClassHeadCd;
//    private String		i_sClassDetailCd;
//
//    private String	i_sPageTitle;
//    private String	i_sSmsCd;
    private String	i_sTranPhone;
    private String	i_sTranCallBack;
    private String	i_sMessage;
    private String	i_sFlagStatus;
    private String	i_sReceiverCd;
//    private int		i_iTranType;
//    private int		i_iTranEtc4;
//    private String	i_sSelectQuery;
//    private String	i_sFileType;
//    private String	i_sFileName;
//    private int		i_iFileCnt;
//    private int		i_iFileSize;
//
//    private String	i_sRegion;
//    private String	i_sEmail;
//    private String	i_sFlag;
    /** 생성사용자코드 CRT_USR_CD */
    private	String	i_sUserCd;
    //    private String	i_sUserType;
//    private String	i_sCenterRegion;
//
//    //덧글
//    private String	i_sReplyid;
//    private String	i_sUReplyid;
//    private String	i_sBoardCd;
//    private String	i_sBoardcd;
//    private String	i_sContent;
//    private int		i_iLevel;
//    private String	i_sUserIp;
//    private String	i_sAdminCheck;
//    private String	i_sReplyCheck;
//    private String	i_sPagingCheck;
//
//    //네이버 Syndication
//    private String	i_sChannel;
//    private String	i_sSyndiType;
//    private String  i_sBoardType;
//
//    private String	i_sLogInOpen;
//    private String	i_sEventFlag;
//
//    // SMS
//    private String	i_sSuccess;
    private String	i_sTitle;
    private String  s_REQUEST_TIME;
    private String s_MT_PR;

//    // cm_image_upload_pop
//    private String	i_sReturnFunction;
//    private String	i_sImageReal;
//
//    private String	i_sCenterType;
//
//    private String	i_sElanFlag;
//    private String 	i_sKeyWord;
//
//    //E-mail
//    private String	i_sFromEmail;
//    private String	i_sFromName;
//    private String	i_sToEmail;
//    private String	i_sCc;
//    private String	i_sRegIp;
//    private String	i_sPreIp;
//
//    // file upload pop
//    private String	i_sFileReal;
//
//    //push
//    private String	i_sPushId;
//    private String	i_sOsType;
//    private String	i_sVersion;
//    private String	i_sPushCheck;
//    private String	i_sMethod;
//
//    private String	i_sMemberId;
//    private String	i_sMemberNm;
//    private String	i_sMemberCd;
//    private String	i_sMypay;
//    private String	i_sMadeDistance1;
//    private String	i_sMadeDistance2;
//    private String	i_sMadeYear1;
//    private String	i_sMadeYear2;
//    private String	i_sMakeCd3;
//    private String	i_sModelCd3;
//    private String	i_sType;
//    private String	i_sHoldCarCode;
//    private String	i_sCenterGubun;
//    private String	i_sRequestCd;
//    private String	i_sDirectINput;
//    private String	i_sReqNum;
//    private String	i_iAlsunNowPageNo;
//    private String	i_sMstCd;
//    private int		i_iAlsunTotalPageCnt;
//    private String[]	i_arrSubCd;
//
//    private String	i_sSido;
//    private String	i_sDolo;
//    private String	i_sGugun;
//    private String	i_sMun;
//    private String	i_sRownum;
//    private String	i_sAutoLogin;
//    private String	i_sAppYn;
//
//    private String	i_sPosYn;
//
//    private String	i_sSignup;
//    private String	i_sAddress;
//    private String	i_sDetailAddress;
//
//    //gps position
//    private double i_iGPSpointX;
//    private double i_iGPSpointY;
//
//    private String i_sAppToken;
//    /** 사고유무코드 */
//    private String i_sAccidentCode;
//
//    /** 최근 본 차량 카운트 */
//    private String 	i_iRecentCarViewCount;
//    /** 관심차량 카운트 */
//    private String	i_iUserInterestCarCount;
//
//    private int     i_iScrollY;
//
//    //브라우저
//    private String i_sUserAgent;
    private String i_sDevice;
//
//    private String	i_sSeqNo;
//    private String	i_sReqUrl;
//    private String 	i_sReqHeader;
//    private String	i_sReqBody;
//    private String	i_sResHeader;
//    private String	i_sResBody;

    public SmsVO toSmsVo() {
        SmsVO smsVo = new SmsVO();
        smsVo.setText(this.i_sMessage);
        smsVo.setDstaddr(this.i_sTranPhone);
        smsVo.setCallback(this.i_sTranCallBack);
        smsVo.setSubject(this.i_sTitle);
        smsVo.setRequestTime(this.s_REQUEST_TIME);
        smsVo.setMtPr(this.s_MT_PR);
        smsVo.setReceiverCd(this.i_sReceiverCd);

        return smsVo;
    }
}
