package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.fo.common.mapper.oracle.CommonCodeManageMapper;
import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.model.MultiCommonCodeManageVO;
import kr.co.daiso.fo.common.service.CommonCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : CommonCodeServiceImpl
 * author         : Doo-Won Lee
 * date           : 2022-02-16
 * description    : CommonCodeService 구현체 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-16       Doo-Won Lee         최초생성
 */
@Service
public class CommonCodeServiceImpl implements CommonCodeService {

    @Autowired
    CommonCodeManageMapper commonCodeManageMapper;
    /**
     * methodName : getSubCodeListCount
     * author : Doo-Won Lee
     * description : 서브 코드의 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int getSubCodeListCount(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getSubCodeListCount(searchVo);
    }

    /**
     * methodName : getSubCodeList
     * author : Doo-Won Lee
     * description : 서브 코드의 목록을 구한다
     *
     * @param searchVo
     * @return List<CommonCodeManageVo>
     */
    @Override
    public List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getSubCodeList(searchVo);
    }

    @Override
    public List<CommonCodeManageVO> getSubCodeListByMasterCd(String masterCd) {
        CommonCodeSearchVO searchVo = new CommonCodeSearchVO();
        searchVo.setSMstCode(masterCd);
        searchVo.setUseYn("Y");
        searchVo.setDelYn("N");
        return commonCodeManageMapper.getSubCodeList(searchVo);
    }

    @Override
    public List<CommonCodeManageVO> getSubCodeList(String sMstCode) {
        CommonCodeSearchVO searchVo = new CommonCodeSearchVO();
        searchVo.setSMstCode(sMstCode);
        searchVo.setUseYn("Y");
        searchVo.setDelYn("N");
        return commonCodeManageMapper.getSubCodeList(searchVo);
    }

    /**
     * 첫번째 서브 코드를 가져온다.
     */
    public CommonCodeManageVO getFirstSubCode(CommonCodeSearchVO searchVo) {
        searchVo.setUseYn("Y");
        searchVo.setDelYn("N");
        List<CommonCodeManageVO> subCodeList = commonCodeManageMapper.getSubCodeList(searchVo);
        return (subCodeList == null) ? null :  subCodeList.get(0);
    }

    /**
     * methodName : getMultiSubCodeList
     * author : Doo-Won Lee
     * description : 복수의 마스터 코드에 대한 서브 코드의 목록을 구한다
     *
     * @param searchVo
     * @return List<CommonCodeManageVo>
     */
    @Override
    public List<MultiCommonCodeManageVO> getMultiSubCodeList(CommonCodeSearchVO searchVo){
        searchVo.setMasterCdList(Arrays.asList(searchVo.getSMstCode().split(",")));
        List<MultiCommonCodeManageVO> resultList = new ArrayList<>();
        List<CommonCodeManageVO> commonCodeManageVOS =  commonCodeManageMapper.getSubCodeList(searchVo);
        String mstCodeChecker = null;
        MultiCommonCodeManageVO tmpVO = null;
        for(int i=0;i<commonCodeManageVOS.size();i++){
            if (null == mstCodeChecker || !mstCodeChecker.equals(commonCodeManageVOS.get(i).getMasterCd())){
                if (tmpVO!=null) resultList.add(tmpVO);
                mstCodeChecker = commonCodeManageVOS.get(i).getMasterCd();
                tmpVO = new MultiCommonCodeManageVO();
                tmpVO.setMasterCd(mstCodeChecker);
                tmpVO.setSubCodeList(new ArrayList<CommonCodeManageVO>());
            }
            tmpVO.getSubCodeList().add(commonCodeManageVOS.get(i));
        }
        if (tmpVO!=null) resultList.add(tmpVO);
        return resultList;
    }
}
