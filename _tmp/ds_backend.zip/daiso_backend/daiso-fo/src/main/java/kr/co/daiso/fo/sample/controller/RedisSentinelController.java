package kr.co.daiso.fo.sample.controller;

import kr.co.daiso.fo.common.util.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * packageName    : kr.co.daiso.fo.sample.controller
 * fileName       : RedisSentinelController
 * author         : Doo-Won Lee
 * date           : 2022-05-28
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-28      Doo-Won Lee     최초생성
 */
@RestController
public class RedisSentinelController {

    @Autowired
    private RedisUtil redisUtil;

    // 캐시 등록
    @GetMapping("/sentinelPut")
    public String register(String key, String value){
        redisUtil.setData(key, value);
        return key;
    }

    // 캐시에 저장된 key의 값 가져오기
    @GetMapping("/sentinelGet")
    public String sentinelGet(String key){
        String value = redisUtil.getData(key);
        return value;
    }
}
