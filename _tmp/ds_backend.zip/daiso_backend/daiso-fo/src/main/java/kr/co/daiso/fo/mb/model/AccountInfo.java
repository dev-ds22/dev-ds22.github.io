package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;

/**
 * packageName    : kr.co.daiso.fo.mb.model
 * fileName       : AccountInfo
 * author         : Doo-Won Lee
 * date           : 2021-10-25
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-25     Doo-Won Lee         최초생성
 */
@SuppressWarnings("serial")
@Data
@EqualsAndHashCode(callSuper=false)
//@ToString(exclude = {"authorities"} )
public class AccountInfo extends BaseModel implements UserDetails  {

    private String membCd;
    private String membKnd;
    private String membId;
    private String pwd;
    private String membNm;
    private boolean atclAgreYn;
    private boolean indvInfoAgreYn;
    private String birdt;
    private String nicknm;
    private String ctad;
    private String mbpno;
    private String email;
    private String emailRcvAgreYn;
    private String phtoNm;
    private String phtoPath;
    private String phtoExt;
    private String intrst;
    private String etcInq;
    private String cdno;
    private String wtdrYn;
    private String wtdrDt;
    private String wtdrRsn;
    private String sex;
    private String joinChnl;
    private String chmuId;
    private String moblcrr;
    private String sidoDvs;
    private String carKnd;
    private String mnuftr;
    private String model;
    private String grd;
    private String dtlGrd;
    private String smsRcvAgreYn;
    private String ovlapKey;
    private String indvInfoChcAgreYn;
    private String pwdErrCnt;
    private String usrRgn;
    private String joinPath;
    private String joinPathDrectInp;
    private String fnlCnntnDt;
    private String pchsHopeDd;
    private String dlercoCd;
    private String shwroomCd;
    private String dealEmpcrdNo;
    private String fstLoginYn;
    private String adaptSrcCarUse;
    private String adaptSrcPrefCarctgr;
    private String adaptSrcPchsBdgt;
    private String adaptSrcRgnCd;
    private String adaptSrcAgegCd;
    private String adaptSrcSex;

    private String tblNm;
    private boolean saveId;
    private String numCheck;
    private String isMobile;
    private String staffCheck;
    private String redisKey;

//    private Collection<SimpleGrantedAuthority> authorities;
//    private Collection<SimpleGrantedAuthority> ttt;

    @Override
    public Collection<SimpleGrantedAuthority> getAuthorities() {
        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        return authorities;
//        if (null!=this.role)
//            Arrays.stream(this.role.split(","))
//                    .distinct()
//                    .forEach(p -> {
//                                GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + p);
//                                authorities.add((SimpleGrantedAuthority) authority);
//                            });
//        return authorities;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return this.membId;
    }

//    public void setUsername(String userName) {
//        this.id = userName;
//    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
