package kr.co.daiso.fo.common.mapper.oracle;

import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.mapper.oracle
 * fileName       : CommonCodeMangeMapper
 * author         : Doo-Won Lee
 * date           : 2022-02-16
 * description    : 공통코드 관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-16        Doo-Won Lee         최초생성
 */
@Mapper
public interface CommonCodeManageMapper {

     //서브 코드의 카운트를 구한다.
     int getSubCodeListCount(CommonCodeSearchVO reqVo);

     //서브 코드의 목록을 구한다.
     List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO reqVo);
}
