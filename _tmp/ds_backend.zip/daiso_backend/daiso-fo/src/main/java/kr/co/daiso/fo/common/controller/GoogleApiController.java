package kr.co.daiso.fo.common.controller;

import kr.co.daiso.fo.common.service.GoogleApiService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.controller
 * fileName       : GoogleApiController
 * author         : Doo-WOn lee
 * date           : 2022-03-11
 * description    : Google 동적리마케팅 관련 처리 Controller
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-11      Doo-WOn lee         최초생성
 */
@Slf4j
@RestController
public class GoogleApiController {

    @Autowired
    GoogleApiService googleApiService;

    @ApiOperation("Google Access Token 발급")
    @GetMapping("/accesstoken_google")
    public String getAccessToken_Google() throws Exception {
        return googleApiService.getAccessToken_Google();
    }

    @ApiOperation("update_google_api")
    @PostMapping(value="/update_google_api", produces="application/json; charset=UTF-8")
    public String updateGoogleApi(@RequestBody Map<String, String> reqEntry ) throws Exception {

        String resultStr = null;
        String strEntry = "";
        String token = "";

        strEntry	= reqEntry.get("parameter");
        token 		= reqEntry.get("token");

        strEntry 	= URLDecoder.decode(strEntry, "UTF-8");
        token 		= URLDecoder.decode(token, "UTF-8");

        resultStr = googleApiService.updateGoogleApi(strEntry, token);

        Calendar _cal1 = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String today = sdf.format(_cal1.getTime());


        log.info("[" + today + "] strEntry: " + strEntry);
        log.info("[" + today + "] token: " + token);
        log.info("[" + today + "] resultStr: " + resultStr);

        return resultStr;
    }
}
