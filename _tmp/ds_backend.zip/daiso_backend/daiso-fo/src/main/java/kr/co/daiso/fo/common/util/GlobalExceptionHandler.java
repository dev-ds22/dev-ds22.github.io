package kr.co.daiso.fo.common.util;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.exception.ErrorResponse;
import kr.co.daiso.common.util.CmFunction;
import kr.co.daiso.common.util.StringUtil;
import kr.co.daiso.fo.common.model.ClsCommonReqVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

/**
 * packageName    : kr.co.daiso.fo.common.util
 * fileName       : GlobalExceptionHandler
 * author         : leechangjoo
 * date           : 2021-11-09
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-09          leechangjoo         최초생성
 **/
@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = { Exception.class })
    protected ResponseEntity handleCommonException(Exception e) {

        if(e instanceof CommonException) {
            CommonException commonException = (CommonException) e;
            log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode());
            log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getHttpStatus());
            log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getDetail());

            return ErrorResponse.toResponseEntity(commonException.getErrorCode().getHttpStatus(), commonException.getErrorCode().getDetail());
        }else if(e instanceof NullPointerException){
            log.error("handleException throw NullPointerException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, e.getCause().toString());
        }else if(e instanceof NumberFormatException){
            log.error("handleException throw NumberFormatException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof IOException){
            log.error("handleException throw IOException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof ArithmeticException){
            log.error("handleException throw ArithmeticException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else {
            log.error(" Another Exception : {}",e);
            log.error(" Another Exception Cause : {}", e.getCause().toString());
            StackTraceElement[]	ste =  e.getStackTrace();
            String	className	= ste[0].getClassName();
            String	methodName	= ste[0].getMethodName();
            int		lineNumber	= ste[0].getLineNumber();
            String	fileName	= ste[0].getFileName();
            log.error("### " + className + "." + methodName + "###");
            log.error("# FileName : " + fileName);
            log.error("# LineNumber : " + lineNumber);
            e.printStackTrace();
        }

        return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers
                                                                , HttpStatus status, WebRequest request) {
        List<ObjectError> allErrors = ex.getBindingResult().getAllErrors();
        for (ObjectError error : allErrors) {
            log.error("error: {}", error);
            // 코드 정보를 확인할 수 있다.
            log.error("error: {}", Arrays.toString(error.getCodes()));
        }

//        CommonResponseModel errorResponseModel = new CommonResponseModel();
//        for(ObjectError e : allErrors) {
//            log.error("error: {}", e);
//            errorResponseModel.setData( ErrorResponse.toResponseEntity(HttpStatus.BAD_REQUEST,e.getDefaultMessage()));
//            break;
//        }
//        return new ResponseEntity<Object>(errorResponseModel,HttpStatus.OK);
        return super.handleMethodArgumentNotValid(ex, headers, status, request);

    }



    /**
     * processExceptionHandle 메소드 오버로딩
     * @param arguments
     * @param exception
     */
    public void processExceptionHandle(List<?> arguments, Exception exception) {
        if (CollectionUtils.isEmpty(arguments) == false) {
            try {
                this.processExceptionHandle(arguments.toArray(), exception);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 오류로깅 처리 메소드. 필요한 경우 해당 클래스를 상속받아 processExceptionHandle 메소드를 오버라이드 하도록 한다.
     * @param arguments
     * @param exception
     * @throws Exception
     */
    public void processExceptionHandle(Object[] arguments, Exception exception) {
        try {
            Map<String, Object> metaInfoFromArguments = this.getMetaInfoFromArguments(arguments);
            Map<String, Object> stackTraceInfos       = this.getStackTraceInfo(exception);

            // TODO > 메시지 전송은 보류
            //StringBuffer message = this.buildMessage(metaInfoFromArguments, stackTraceInfos, exception);
            //this.sendMessage(message);

            // 예외 로그 DB 저장..
            this.insertErrorLog(metaInfoFromArguments, stackTraceInfos, exception);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("error occured.", e);
        }
    }

    /**
     * 예외 로깅에 사용될 객체들에 대해 유효한 파라미터 또는 필드 값 추출
     * @param arguments
     * @return Map<String, Object>
     * @throws Exception
     */
    protected Map<String, Object> getMetaInfoFromArguments(Object[] arguments) throws Exception {
        @SuppressWarnings("unchecked")
        Map<String, Object> metaInfoMap = new HashMap<>();
        metaInfoMap.remove("dbLinkValue");

        if (ArrayUtils.isNotEmpty(arguments)) {
            StringBuffer requestParamBuffer = new StringBuffer();
            StringBuffer commandParamBuffer = new StringBuffer();

            for (Object arg : arguments) {
                // 예외발생 당시 Request에 대한 파라미터 추출
                if (arg instanceof HttpServletRequest) {
                    HttpServletRequest request = (HttpServletRequest)arg;
                    Map<String, String[]> parameterMap = request.getParameterMap();
                    Set<String> keySet = parameterMap.keySet();
                    Iterator<String> iterator = keySet.iterator();

                    String requestUrl = request.getRequestURI();
                    metaInfoMap.put("requestUrl", requestUrl);

                    while (iterator.hasNext()) {
                        String key = iterator.next();
                        String[] values = parameterMap.get(key);
                        String value = StringUtils.join(values);

                        // 파라미터가 있는 경우에만 append 처리한다.
                        if (!value.isEmpty()) {
                            requestParamBuffer.append(key + "=");
                            requestParamBuffer.append(value);
                            requestParamBuffer.append(iterator.hasNext() ? "&" : "");
                        }
                    }
                }
                // 예외발생 당시의 Command Object에 대한 프로파일링
                // 자바 리플렉션을 통해 동적으로 타입 캐스팅을 수행한다.
                else if (arg instanceof ClsCommonReqVO) {
                    Class<? extends Object> targetClass = arg.getClass();
                    Object catstedReqVo = targetClass.cast(arg);

                    commandParamBuffer.append(CmFunction.convertListObjectToCmMap(catstedReqVo));
                }
            }

            String requestParam = StringUtil.defaultString(requestParamBuffer.toString());
            String commandParam = StringUtil.defaultString(commandParamBuffer.toString());

            // 한글 2Byte 지정처리를 위한 처리
            byte[] requestParamBytes = requestParam.getBytes("EUC-KR");
            byte[] commandParamBytes = commandParam.getBytes("EUC-KR");

            if (requestParamBytes.length > 4000) {
                requestParam = new String(Arrays.copyOfRange(requestParamBytes, 0, 4000), "EUC-KR");
            }

            if (commandParamBytes.length > 4000) {
                commandParam = new String(Arrays.copyOfRange(commandParamBytes, 0, 4000), "EUC-KR");
            }

            metaInfoMap.put("requestParam", requestParam);
            metaInfoMap.put("commandParam", commandParam);
        }

        return metaInfoMap;
    }

    /**
     * 예외에서 대표 StackTrace를 추출하여 가공.
     * @param exception
     * @return Map<String, Object>
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    protected Map<String, Object> getStackTraceInfo(Exception exception) throws Exception {
        if (exception == null) throw new Exception("예외 값이 전달되지 않았습니다.");

        Map<String, Object> stackTraceMapInfo = new HashMap<>();
        stackTraceMapInfo.remove("dbLinkValue");

        StackTraceElement[] stackTraces = exception.getStackTrace();
        if (ArrayUtils.isNotEmpty(stackTraces)) {
            StackTraceElement stackTraceElement = stackTraces[0];

            String className = stackTraceElement.getClassName();
            String methodName = stackTraceElement.getMethodName();
            int lineNumber = stackTraceElement.getLineNumber();
            String fileName = stackTraceElement.getFileName();

            stackTraceMapInfo.put("firstTrace", stackTraceElement.toString());
            stackTraceMapInfo.put("className", className);
            stackTraceMapInfo.put("methodName", methodName);
            stackTraceMapInfo.put("lineNumber", lineNumber);
            stackTraceMapInfo.put("fileName", fileName);
        }

        return stackTraceMapInfo;
    }

    /**
     * 예외내용 DB 로깅
     * @param metaInfoFromArguments
     * @param stackTraceInfos
     * @param exception
     * @throws Exception
     */
    protected void insertErrorLog(Map<String, Object> metaInfoFromArguments, Map<String, Object> stackTraceInfos, Exception exception) throws Exception {
        String errMsg = StringUtil.defaultString(exception.toString());

        // 예외내용이 600바이트가 넘는 경우는 최대 600 바이트로 자름처리..
        if (!errMsg.isEmpty() && errMsg.getBytes("EUC-KR").length > 600) {
            errMsg = new String(Arrays.copyOfRange(errMsg.getBytes(), 0, 600), "EUC-KR");
        }

        metaInfoFromArguments.putAll(stackTraceInfos);
        metaInfoFromArguments.put("exception", errMsg);

        /**
         * TODO...
         * 예외로깅 저장
         */
//        clsCommon.insertErrorLog(metaInfoFromArguments);
    }
}