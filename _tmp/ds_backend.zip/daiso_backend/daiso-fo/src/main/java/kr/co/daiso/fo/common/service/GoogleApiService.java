package kr.co.daiso.fo.common.service;

import org.springframework.stereotype.Component;

/**
 * packageName    : kr.co.daiso.fo.common.service
 * fileName       : GoogleApiService
 * author         : 82108
 * date           : 2022-03-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-11          82108         최초생성
 */
@Component
public interface GoogleApiService {

    //Google AccessToken을 구한다.
    public String getAccessToken_Google() throws Exception;

    //Google Content API - INSERT, DELETE
    public String updateGoogleApi(String strEntry, String token) throws Exception;

    //Google Content API - INSERT, DELETE
    public String updateGoogleApiRe(String strEntry, String token) throws  Exception;

}
