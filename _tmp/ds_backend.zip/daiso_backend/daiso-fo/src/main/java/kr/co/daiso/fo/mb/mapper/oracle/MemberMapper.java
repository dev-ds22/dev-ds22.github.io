package kr.co.daiso.fo.mb.mapper.oracle;

import kr.co.daiso.fo.mb.model.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.mb.mapper.oracle
 * fileName       : MemberInfoMapper
 * author         : kjm
 * date           : 2022-02-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18       kjm            최초생성
 */
@Mapper
public interface MemberMapper {

    // id로 회원조회
    AccountInfo getMemberById(MemberVO memberVO);

    // 오버랩키로 회원정보 조회
    AccountInfo getMemberByOverlapKey(AccountInfo accountInfo);

    // 비밀번호 변경
    void updateMemberPassword(MemberVO memberVO);

    // 휴면회원 비밀번호 변경
    void updateInactiveMemberPassword(MemberVO memberVO);

    // 중복회원수 조회
    int getCheckMemberCount (MemberVO memberVO);

    // 회원가입 실패로그 저장
    void insertMemberJoinFailLog(JoinErrorLogVO joinErrorLogVO);

    // 회원정보 저장
    void insertMember(MemberVO memberVO);

    // 회원가입 sms키 저장
    void insertJoinKey(Map<String, Object> map);

    // 회원가입 sms키 조회
    int getJoinKey(Map<String, Object> map);

    // 회원가입 sms키 삭제
    void deleteJoinKey(Map<String, Object> paramMap);

    // 회원가입시 미성년자 가입시도 횟수
    void insertMemberNonAge();

    // sns 가입회원 조회
    SnsMemberVO getSnsMember(Map<String, Object> paramMap);

    // SNS 계정 연결
    void updateSocialMember(SnsMemberVO snsMemberVO);

    // sns 회원 매핑
    void insertSocialMember(SnsMemberVO snsMemberVO);

    // 회원알림로그 저장
    int insertMemberAlarmLog(MemberAlarmVO memberAlarmVO);

    // 회원알림로그 저장
    int insertMemberAlarmLogByAplSn(MemberAlarmVO memberAlarmVO);
}
