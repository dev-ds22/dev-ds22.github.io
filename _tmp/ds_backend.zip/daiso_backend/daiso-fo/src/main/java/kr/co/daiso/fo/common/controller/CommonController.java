package kr.co.daiso.fo.common.controller;

import kr.co.daiso.common.model.BaseModel;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.StringUtil;
import kr.co.daiso.fo.common.model.ClsCommonReqVO;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.service.ClsCommonService;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
public class CommonController {
    @Autowired protected ClsCommonService clsCommon;
    @Autowired protected FoAccountInfoUtil foAccountInfoUtil;

    /**
     * JSON 응답명 : result
     */
    public static final String JSON_RESULT_NAME = "result";

    /**
     * JSON 응답 성공 코드 : succ
     */
    public static final String JSON_RESULT_SUCCESS = "succ";

    /**
     * JSON 응답 실패 코드 : fail
     */
    public static final String JSON_RESULT_FAIL = "fail";

    /**
     * JSON 응답 메시지명 : message
     */
    public static final String JSON_MESSAGE_NAME = "message";

    /**
     * JSON 응답 실패 메시지 : 통신이 원할하지 않습니다. 잠시후 다시 시도해 주십시오.
     */
    public static final String JSON_MESSAGE_FAIL = "통신이 원할하지 않습니다. 잠시후 다시 시도해 주십시오.";

    /**
     * 사용자 MOBILE 기본 Tiles Prefix Path
     */
    public static final String TILES_MOBILE = "/mobile/";

    /**
     * JSON 응답 리다이렉트명 : redirect
     */
    public static final String JSON_REDIRECT_NAME = "redirect";

    /**
     * JSON 응답(result) 값이 실패(fail)인 HTTP 응답 Map<String, Object) 인스턴스를 생성한다
     *
     * @return JSON 응답(result) 값이 실패(fail)인 HTTP 응답 Map<String, Object)
     */
    public static Map<String, Object> newInstanceResMap() {
        Map<String, Object> resMap = new HashMap<>();
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);

        return resMap;
    }

    public static Map<String, Object> newInstanceResMap(BaseModel reqVo) {
        log.info("요청 reqVo:: {}", reqVo);

        Map<String, Object> resMap = new HashMap<>();
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);

        return resMap;
    }

    public ResponseEntity<CommonResponseModel> toResFail(Map<String, Object> resMap, BaseModel reqVo) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResFail(Map<String, Object> resMap, BaseModel reqVo, Object message) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);
        resMap.put(JSON_MESSAGE_NAME, StringUtil.toString(message));
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResFail(Map<String, Object> resMap, BaseModel reqVo, Object message, String redirect) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);
        resMap.put(JSON_MESSAGE_NAME, StringUtil.toString(message));
        resMap.put(JSON_REDIRECT_NAME, redirect);
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResSuccess(Map<String, Object> resMap) {
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_SUCCESS);
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResSuccess(Map<String, Object> resMap, BaseModel reqVo) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_SUCCESS);
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResSuccess(Map<String, Object> resMap, BaseModel reqVo, Object message) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_SUCCESS);
        resMap.put(JSON_MESSAGE_NAME, StringUtil.toString(message));
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    public ResponseEntity<CommonResponseModel> toResSuccess(Map<String, Object> resMap, BaseModel reqVo, Object message, String redirect) {
        log.info("응답 reqVo:: {}", reqVo);
        resMap.put(JSON_RESULT_NAME, JSON_RESULT_SUCCESS);
        resMap.put(JSON_MESSAGE_NAME, StringUtil.toString(message));
        resMap.put(JSON_REDIRECT_NAME, redirect);
        return new ResponseEntity<>(new CommonResponseModel(resMap), HttpStatus.OK);
    }

    /**
     * <pre>
     * 회원정보 세션값을 reqVo에 추가 저장
     *
     * === reqVo에 추가 저장되는 멤버변수
     *     - membCd, i_sUserCd, S_MEMBER_CD : 회원코드
     *     - membId, i_sUserId, S_MEMBER_ID : 회원ID
     *     - membNm, i_sUserName, S_MEMBER_NAME : 회원명
     *     - membKnd, S_MEMBER_TYPE : 회원종류
     *     - joinChnl, S_MEMBER_CHANNEL : 가입채널
     *     - mbpno, S_MEMBER_MOBILE : 휴대폰번호
     *
     * === ToBe reqVo에 미저장 멤버변수
     *     S_USER_CD, S_USER_ID, S_USER_NAME, S_USER_TYPE, S_USER_GROUP, S_CENTER_CODE, S_LEADER_FLAG, S_MEMBER_GENDER, S_MEMBER_BIRTH, S_MEMBER_REGION,
     *     S_MEMBER_DELER_CO_CD, S_MEMBER_SHOW_ROOM_CD, S_MENU_TYPE, S_READ_FLAG, S_CREATE_FLAG, S_UPDATE_FLAG, S_UPDATE_FLAG, S_DOWNLOAD_FLAG,
     *     i_sRegUserCd, i_sUpdateUserCd
     * </pre>
     * @param reqVo 요청파라미터 VO
     */
    public ClsCommonReqVO  setCmSessionValue(ClsCommonReqVO reqVo) {
        try {
            log.info("요청 reqVo:: {}", reqVo);

            AccountInfo accountInfo = foAccountInfoUtil.getAccountInfo();  // ToBe에서 FoAccountInfoUtil에서 로그인 회원정보 조회

            // AsIs 소스에서는 reqVO 멤버변수에 저장했으나 ToBe에서는 저장하지 않는 멤버변수들
            // S_USER_CD, S_USER_ID, S_USER_NAME, S_USER_TYPE, S_USER_GROUP, S_CENTER_CODE, S_LEADER_FLAG, S_MEMBER_GENDER, S_MEMBER_BIRTH, S_MEMBER_REGION,
            // 메뉴권한(S_MENU_TYPE, S_READ_FLAG, S_CREATE_FLAG, S_UPDATE_FLAG, S_UPDATE_FLAG, S_DOWNLOAD_FLAG)
            // i_sRegUserCd, i_sUpdateUserCd

            if(accountInfo != null) {
                reqVo.setS_MEMBER_CD(accountInfo.getMembCd());  // AsIs S_MEMBER_CD
                reqVo.setI_sUserCd(accountInfo.getMembCd());    // AsIs i_sUserCd
                reqVo.setMembCd(accountInfo.getMembCd());       // ToBe 추가

                reqVo.setS_MEMBER_ID(accountInfo.getMembId());  // AsIs S_MEMBER_ID
                reqVo.setI_sUserId(accountInfo.getMembId());     // AsIs i_sUserId
                reqVo.setMembId(accountInfo.getMembId());       // ToBe 추가

                reqVo.setS_MEMBER_NAME(accountInfo.getMembNm());  // AsIs S_MEMBER_NAME
                reqVo.setI_sUserName(accountInfo.getMembNm());    // AsIs i_sUserName
                reqVo.setMembNm(accountInfo.getMembNm());         // ToBe 추가

                reqVo.setS_MEMBER_TYPE(accountInfo.getMembKnd());  // AsIs S_MEMBER_TYPE
                reqVo.setMembKnd(accountInfo.getMembKnd());        // ToBe 추가

                reqVo.setS_MEMBER_CHANNEL(accountInfo.getJoinChnl());  // AsIs S_MEMBER_CHANNEL
                reqVo.setJoinChnl(accountInfo.getJoinChnl());          // ToBe 추가

                reqVo.setS_MEMBER_MOBILE(accountInfo.getMbpno());  // AsIs S_MEMBER_MOBILE
                reqVo.setMbpno(accountInfo.getMbpno());    // ToBe 추가

                reqVo.setS_MEMBER_DELER_CO_CD(accountInfo.getDlercoCd());  // AsIs S_MEMBER_DELER_CO_CD
                reqVo.setDlercoCd(accountInfo.getDlercoCd());              // ToBe 추가

                reqVo.setS_MEMBER_SHOW_ROOM_CD(accountInfo.getShwroomCd());  // AsIs S_MEMBER_SHOW_ROOM_CD
                reqVo.setShwroomCd(accountInfo.getShwroomCd());           // ToBe 추가
            } else if(StringUtil.isNotBlank(reqVo.getMembId())) { // 비회원 로그인
                reqVo.setS_MEMBER_CD(reqVo.getMembId());  // AsIs S_MEMBER_CD
                reqVo.setI_sUserCd(reqVo.getMembId());    // AsIs i_sUserCd
                //reqVo.setMembCd(accountInfo.getMembCd());       // ToBe 추가

                reqVo.setS_MEMBER_ID(reqVo.getMembId());  // AsIs S_MEMBER_ID
                reqVo.setI_sUserId(reqVo.getMembId());     // AsIs i_sUserId

                reqVo.setS_MEMBER_NAME(reqVo.getMembNm());  // AsIs S_MEMBER_NAME
                reqVo.setI_sUserName(reqVo.getMembNm());    // AsIs i_sUserName

                //reqVo.setS_MEMBER_TYPE(accountInfo.getMembKnd());  // AsIs S_MEMBER_TYPE
                //reqVo.setMembKnd(accountInfo.getMembKnd());        // ToBe 추가

                //reqVo.setS_MEMBER_CHANNEL(accountInfo.getJoinChnl());  // AsIs S_MEMBER_CHANNEL
                //reqVo.setJoinChnl(accountInfo.getJoinChnl());          // ToBe 추가

                reqVo.setS_MEMBER_MOBILE(reqVo.getMbpno());  // AsIs S_MEMBER_MOBILE
                //reqVo.setMbpno(accountInfo.getMbpno());    // ToBe 추가

                //reqVo.setS_MEMBER_DELER_CO_CD(accountInfo.getDlercoCd());  // AsIs S_MEMBER_DELER_CO_CD
                //reqVo.setDlercoCd(accountInfo.getDlercoCd());              // ToBe 추가

                //reqVo.setS_MEMBER_SHOW_ROOM_CD(accountInfo.getShwroomCd());  // AsIs S_MEMBER_SHOW_ROOM_CD
                //reqVo.setShwroomCd(accountInfo.getShwroomCd());           // ToBe 추가
            }
        } catch (Exception e) {
            log.error(null, e);
        }

        log.info("응답 reqVo:: {}", reqVo);
        return reqVo;
    }

    /**
     * <pre>
     * HTTP 요청 파라미터를 key=value 결합 문자열(key1=value1&key2=value2&...&keyN=valueN)로 만들어 reqVo의 i_sPagePars 멤버변수에 저장
     * - key=value 결합 문자열 생성시 파라미터 key가 _tmp로 끝나거나 i_sReturnUrl, i_sReturnPars, i_sReturnPars2인 경우는 제외된다
     *
     * === reqVo에 추가 저장되는 멤버변수
     *     - i_sPagePars : HTTP 요청 파라미터 key=value 결합 문자열
     *     - i_sPageUrl : request.getRequestURI()
     *     - i_sReturnPars2 : HTTP 요청 파라미터 i_sReturnPars2의 값
     * </pre>
     * @param request HTTP 요청
     * @param reqVo 요청파라미터 VO
     */
    public void setCmUrlParsSetting(HttpServletRequest request, ClsCommonReqVO reqVo ) {
        StringBuilder sb = new StringBuilder();

        for (Enumeration<String> en = request.getParameterNames(); en.hasMoreElements(); ) {
            String key = StringUtil.defaultString((String)en.nextElement());

            // 임시 input
            if (StringUtil.isNotBlank(key) && StringUtil.endsWith(key, "_tmp")) {  // 파라미터 key가 _tmp로 끝나지 않은 경우
                if ( !key.equals("i_sReturnUrl") && !key.equals("i_sReturnPars") ) { // 파라미터 key가 i_sReturnUrl, i_sReturnPars 가 아닌 경우
                    // 배열일 경우
                    if (key.indexOf("i_arr") > -1) {
                        String[] tmpArrStr	= request.getParameterValues(key);

                        if (tmpArrStr != null) {
                            try {
                                int len = tmpArrStr.length;
                                for (int i = 0; i < len; i++)
                                    sb.append ( key + "=" + URLEncoder.encode(tmpArrStr[i], CommonPathInfo.CHARSET) + "&");
                            } catch (Exception e) {
                                log.error(null, e);
                            }
                        }
                    } else {
                        String tmpStr = StringUtil.defaultString(request.getParameter(key));

                        if (key.equals("i_sReturnPars2")) {
                            reqVo.setI_sReturnPars2(tmpStr);
                        } else {
                            try {
                                sb.append ( key + "=" + URLEncoder.encode(tmpStr, CommonPathInfo.CHARSET) + "&");
                            } catch (Exception e) {
                                log.error(null, e);
                            }
                        }
                    }
                }
            }
        }

        reqVo.setI_sPageUrl(request.getRequestURI());
        reqVo.setI_sPagePars(sb.toString());
    }

    /**
     * 회원 로그인 유무 체크
     * @deprecated {@link CommonController#isCmMemberLoginCheck (HttpServletRequest request, ClsCommonReqVO reqVo, Map<String, Object> resMap)}로 대체됨
     */
    public boolean isCmMemberLoginCheck (HttpServletRequest request, ClsCommonReqVO reqVo, ModelAndView mav) {
        boolean	 bReturn = false;
        HttpSession session = request.getSession();

        try {
            this.setCmSessionValue(reqVo);	// session 값을 reqVo 셋팅

            String S_MEMBER_ID = StringUtil.defaultString(reqVo.getS_MEMBER_ID());
            String S_MEMBER_TYPE = StringUtil.defaultString(reqVo.getS_MEMBER_TYPE());

            if (S_MEMBER_ID.equals("")) {
                this.setCmUrlParsSetting(request, reqVo);

                if(reqVo.getI_sPageUrl().indexOf("/mobile/admin/") != -1){
                    mav.setViewName("redirect:/mobile/admin/pms/login.do?i_sReturnUrl=" + reqVo.getI_sPageUrl() + "&i_sReturnPars=" + URLEncoder.encode(reqVo.getI_sPagePars(), CommonPathInfo.CHARSET));
                }else if(reqVo.getI_sPageUrl().indexOf("/mobile/") != -1){
                    mav.setViewName("redirect:/mobile/user/login.do?i_sReturnUrl=" + reqVo.getI_sPageUrl() + "&i_sReturnPars=" + URLEncoder.encode(reqVo.getI_sPagePars(), CommonPathInfo.CHARSET));
                }else{
                    reqVo.setI_sReturnUrl("/user/user_login.do");
                    mav.addObject("message", "로그인 후 이용해 주세요");
                    mav.addObject("reqVo", reqVo);
                    mav.setViewName("INCLUDE/cm_message");
                }

                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            log.error(null, e);
        }

        return bReturn;
    }

    /**
     * <pre>
     * 회원 비로그인 여부 체크
     *
     * === 함수내에서 setCmSessionValue() 호출후 reqVo에 추가 저장되는 멤버변수
     *     - membCd, i_sUserCd, S_MEMBER_CD : 회원코드
     *     - membId, i_sUserId, S_MEMBER_ID : 회원ID
     *     - membNm, i_sUserName, S_MEMBER_NAME : 회원명
     *     - membKnd, S_MEMBER_TYPE : 회원종류
     *     - joinChnl, S_MEMBER_CHANNEL : 가입채널
     *     - mbpno, S_MEMBER_MOBILE : 휴대폰번호
     *
     * === 함수내에서 setCmUrlParsSetting() 호출후 reqVo에 추가 저장되는 멤버변수
     *     - i_sPagePars : HTTP 요청 파라미터 key=value 결합 문자열
     *     - i_sPageUrl : request.getRequestURI()
     *     - i_sReturnPars2 : HTTP 요청 파라미터 i_sReturnPars2의 값
     *
     * === true 반환시(비로그인시) resMap 저장되는 멤버변수
     *     - JSON_RESULT_NAME : JSON_RESULT_FAIL
     *     - JSON_MESSAGE_NAME : "로그인 후 이용해 주세요"
     *     - JSON_REDIRECT_NAME : "/account/login"
     * </pre>
     * @param request HTTP 요청
     * @param reqVo 요청파라미터 Vo
     * @param resMap 응답결과 Map
     * @return 비로그인시 true, 로그인시 false
     */
    public boolean isCmMemberLoginCheck (HttpServletRequest request, ClsCommonReqVO reqVo, Map<String, Object> resMap) {
        try {
            this.setCmSessionValue(reqVo);	// session 값을 reqVo 셋팅

            if (!foAccountInfoUtil.isLogined() && StringUtil.isBlank(reqVo.getMembId())) {
                this.setCmUrlParsSetting(request, reqVo);

                String loginUrl = "/account/login";

                if(StringUtil.isNotBlank(reqVo.getI_sPageUrl())) {
                    loginUrl = "/account/login?returnUrl=" + reqVo.getI_sPageUrl() + "&i_sReturnPars=" + URLEncoder.encode(reqVo.getI_sPagePars(), CommonPathInfo.CHARSET);
                }else{
                    reqVo.setI_sReturnUrl(loginUrl);
                    resMap.put("reqVo", reqVo);
                }

                resMap.put(JSON_RESULT_NAME, JSON_RESULT_FAIL);
                resMap.put(JSON_MESSAGE_NAME, "로그인 후 이용해 주세요");
                resMap.put(JSON_REDIRECT_NAME, loginUrl);

                return true;
            }
        } catch (Exception e) {
            log.error(null, e);
        }

        return false;
    }

    /**
     * Error log 출력
     * @param e
     * @deprecated log.error(null, e) 코드로 대체
     */
    public void fnErrorLogger(Exception e) {
        StackTraceElement[]	ste = e.getStackTrace();

        if (ste != null && ste.length > 0) {
            String	className	= ste[0].getClassName();
            String	methodName	= ste[0].getMethodName();
            int		lineNumber	= ste[0].getLineNumber();
            String	fileName	= ste[0].getFileName();

            //if (LOGGER.isEnabledFor(Priority.ERROR)) {
            if (log.isErrorEnabled()) {
                log.error("### " + className + "." + methodName + "###");
                log.error("# FileName : " + fileName);
                log.error("# LineNumber : " + lineNumber);
                e.printStackTrace();
            }
        } else {
//			System.out.println("### e.getStackTrace() is null");
        }
    }

    /**
     * 페이징 계산
     * @param reqVo
     * @param recordCnt
     * @param pageSize
     * @param nowPageNo
     */
    public void setListPageSetting(ClsCommonReqVO reqVo, int recordCnt, int pageSize, int nowPageNo) {

        int		totalPageCnt		= 0;
        int		startRownum			= 0;
        int		endRownum			= 0;
        int		skipCnt				= 0;

        if (pageSize <= 0)	pageSize	= 10;
        if (nowPageNo <= 0)	nowPageNo	= 1;

        if (recordCnt <= pageSize) {
            totalPageCnt	= 1;
        } else {
            totalPageCnt	= ((recordCnt -1) / pageSize) + 1;
        }

        if (totalPageCnt < nowPageNo)	nowPageNo	= totalPageCnt;

        if (nowPageNo > 1)				skipCnt 	= (nowPageNo - 1) * pageSize;

        startRownum = (nowPageNo - 1) * pageSize + 1;
        endRownum 	= nowPageNo * pageSize;

        reqVo.setI_iTotalPageCnt(totalPageCnt);
        reqVo.setI_iRecordCnt(recordCnt);
        reqVo.setI_iPageSize(pageSize);
        reqVo.setI_iNowPageNo(nowPageNo);
        reqVo.setI_iSkipCnt(skipCnt);
        reqVo.setI_iStartRownum(startRownum);
        reqVo.setI_iEndRownum(endRownum);
    }
}
