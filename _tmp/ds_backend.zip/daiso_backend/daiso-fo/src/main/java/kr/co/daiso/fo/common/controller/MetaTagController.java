package kr.co.daiso.fo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.common.service.MetaTagService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.controller
 * fileName       : MetaTagController
 * author         : Doo-Won Lee
 * date           : 2022-05-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-02       Doo-Won Lee      최초생성
 */
@RestController
@RequestMapping("/common")
public class MetaTagController {

    @Autowired
    MetaTagService metaTagService;

    @ApiOperation("MetaTag Info을 DB에서 조회한다.")
    @GetMapping("/metatag")
    public ResponseEntity<CommonResponseModel> getMetaTagInfo(@ApiParam("화면 코드") @RequestParam String pgId) throws Exception{
        Map<String, String> resultMap = metaTagService.getMetaTagInfo(pgId);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

}
