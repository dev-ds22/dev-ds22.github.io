package kr.co.daiso.fo.mb.service;

import kr.co.daiso.fo.auth.model.AutoLoginToken;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.mb.service
 * fileName       : LoginService
 * author         : kjm
 * date           : 2022-02-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
public interface LoginService {

    // 로그인
    AccountInfo login(HttpServletRequest request, HttpServletResponse response, MemberVO memberVO) throws UnsupportedEncodingException;

    // 로그아웃
    void logout(HttpServletRequest request, HttpServletResponse response);

    // 자동로그인 토큰 조회
    AutoLoginToken getAutoLoginToken(HttpServletRequest request, HttpServletResponse response, AutoLoginToken searchToken);

    // 자동로그인 토큰 연장
    void extendAutoLoginToken(AutoLoginToken autoLoginToken);

    void snsLogin(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paramMap) throws IOException;

    void deleteToken(HttpServletRequest request, HttpServletResponse response);

    public void saveAutoLoginToken(HttpServletRequest request, HttpServletResponse response, AutoLoginToken autoLoginToken);
}
