package kr.co.daiso.fo.sample.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.common.collect.Lists;
import com.nhncorp.lucy.security.xss.XssPreventer;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.Operation;
import kr.co.daiso.common.model.CommonPagingVo;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.DaisoRestTemplate;
import kr.co.daiso.common.util.ExcelUtil;
import kr.co.daiso.common.util.MailUtil;
import kr.co.daiso.common.util.TestUtil;
import kr.co.daiso.fo.auth.oauth.OAuthClientRegistration;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.service.CommonCodeService;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.sample.model.SampleLoginVO;
import kr.co.daiso.fo.sample.model.SampleModel;
import kr.co.daiso.fo.sample.service.SampleService;
import kr.co.daiso.fo.util.FileUtil;
import kr.co.daiso.fo.util.SttUtil;
import kr.co.daiso.fo.util.XdbUtil;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
public class SampleController {

    @Autowired
    SampleService sampleService;

    //ExcelUtil excelUtil = new ExcelUtil();
    @Autowired
    ExcelUtil excelUtil;

    @Autowired
    Map<String, OAuthClientRegistration> clientRegistrationMap;

    @Autowired
    CommonPathInfo commonPathInfo;

    @Autowired
    CommonCodeService commonCodeService;

    @Autowired
    MailUtil mailUtil;

    @Autowired
    FileUtil fileUtil;
//    @Value("${oauth.provider.naver.batch_api_url}")
//    String testBatchApiUrl;
//
//    @Value("${spring.redis.lettuce.pool.min-idle}")
//    String minIdle;
//
//    @Value("${ata.send_yn}")
//    String ata;

    @Operation(summary = "테스트 샘플", description = "text api 테스트 샘플")
    @RequestMapping("/fo/sample")
    public String apiSample()
    {
        TestUtil testUtil = new TestUtil();
        testUtil.testPrint();

//        log.info("CommonPathInfo.XDB_URL : "+ testBatchApiUrl);
//        log.info("CommonPathInfo.XDB_URL : "+ minIdle);
//        log.info("CommonPathInfo.XDB_URL : "+ ata);

        log.info("CommonPathInfo.XDB_URL : "+ commonPathInfo.XDB_URL);
        log.info("CommonPathInfo.RESERVATION_RGST_URL : "+ commonPathInfo.RESERVATION_RGST_URL);

        CommonCodeSearchVO searchVO = new CommonCodeSearchVO();
        searchVO.setSMstCode("001");
        searchVO.setSSubCode("001");
        String password = XdbUtil.getHashEncryptSha256("11111");
        log.info("********************************* password:"+password);
        commonCodeService.getSubCodeList(searchVO)
                .stream()
                .map(codeInfo -> codeInfo.getSubCdNm())
                .forEach(log::info);

//        log.error(name);
//        sampleService.getSampleCode()
//                    .stream().map(code -> code.getMasterCd())
//                    .forEach(log::info);
        return "Fo Test Sample";
    }

    @RequestMapping("/xss/useFilter")
    public String useFilter(@RequestBody Map<String,String> request) throws Exception {
        String inputMsg = request.get("request");
        String convertMsg = XssPreventer.escape(inputMsg);
        String reconvertMsg = XssPreventer.unescape(inputMsg);
        log.info("### Get Message(Use XSS Filter) ###");
        log.info("### 입력 => ", inputMsg);
        log.info("### 치환 => ", convertMsg);
        log.info("### 역치환 => ", reconvertMsg);

        return "useFilter";
    }

    @ApiOperation("로그인")
    @PostMapping("/sample/login_process")
    public ResponseEntity<CommonResponseModel> sampleLogin(@ApiParam("로그인 요청 정보") @RequestBody @Valid SampleLoginVO loginVo
            , HttpServletResponse response){
//        return sampleService.loginProcess(loginVo,response);
        return null;
    }

//    @ApiOperation("SNS로그인 요청")
//    @GetMapping("/mb/sns/authorize/{provider}")
//    public void snsLoginAuthRequest(@PathVariable String provider,
////                                , @RequestParam(name = "redirect_uri") String redirectUri , @RequestParam String callback,
//                                HttpServletRequest request, HttpServletResponse response) throws IOException {
//        String state = CommonUtil.generateState();
//
//        OAuthClientRegistration clientRegistration = clientRegistrationMap.get(provider);
//        OAuthService oAuthService = OAuthServiceFactory.getOAuthService(provider);
//        oAuthService.requestAuthorize(clientRegistration, state, response);
//    }
//
//    @ApiOperation("SNS로그인 리다이렉트")
//   // @GetMapping("/mb/sns/callback/{provider}")
//    @GetMapping("/user/{sns_login}")
//    public void returnSnsLoginAuth(@PathVariable String sns_login, String state, String code, String error
//                                , HttpServletRequest request, HttpServletResponse response, @AuthenticationPrincipal AccountInfo loginUser) throws CommonException, IOException {
//
//        OAuthClientRegistration clientRegistration = clientRegistrationMap.get(StringUtils.substringBefore(sns_login,"_"));
//        OAuthService oAuthService = OAuthServiceFactory.getOAuthService(StringUtils.substringBefore(sns_login,"_"));
//
//        //SNS의 AccessToken & me 정보 get
//        OAuthToken oAuthToken = oAuthService.getAccessToken(clientRegistration,code,state);
//        OAuthUserInfo oAuthUserInfo = oAuthService.getUserInfo(clientRegistration, oAuthToken.getToken());
//
//        //SNS 계정의 회원 여부 확인
//        //회원의 경우 Jwt 토큰  (access & refresh Token) 발행하여 cookie 저장
//        //비회원의 경우 회원 가입 처리
//        System.out.println("1111");
//        response.sendRedirect("http://localhost:8200/");
//    }



    @ApiOperation("멤버등록")
    @RequestMapping("/sample/rgMember")
    public ResponseEntity<CommonResponseModel> rgMember(@RequestBody AccountInfo aVo){
        try{
            //log.info("aVo.toString():::::"+aVo.toString());
//            return sampleService.rgMember(aVo);
        }catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }

    @ApiOperation("CORS")
    @RequestMapping("/fo/cors")
    public String corsTest(){
        return "test complete!!!! ";
    }


    @ApiOperation("template")
    @RequestMapping("/fo/template")
    public String foTemplate()throws Exception{

        log.info("template 시작");
        RestTemplate restTemplate = new RestTemplate();

        //Url
        String url ="http://localhost:8082/mo/template";

        //MethodType
        HttpMethod HttpMethodType = HttpMethod.POST;
//           HttpMethod type = HttpMethod.GET;

        //Headers
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization","test key");

        //Body
        SampleModel requestModel = new SampleModel();
//        requestModel.setGrCode("private String");
//        requestModel.setGrCodeNm("test2");

        //Request
        HttpEntity request = new HttpEntity<>(requestModel,headers);

        //ResponseClass
        Class<Object> responseClass = Object.class;

        ResponseEntity<Object> responseEntity =
                restTemplate.exchange(
                        url,
                        HttpMethodType,
                        request,
                        responseClass
                );



        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            log.info("response received");
            log.info("responseEntity.getBody()", responseEntity.getBody());

            ObjectMapper mapper = new ObjectMapper();
            TypeReference<List<SampleModel>> typeRef = new TypeReference<List<SampleModel>>() {};
            List<SampleModel> sampleModels =
                    mapper.convertValue(responseEntity.getBody(),typeRef);

            log.info("sampleModelVo :::", sampleModels.get(1));
            log.info("GrCodeNm :::", sampleModels.get(1).getMasterCd());

        } else {
            log.info("error occurred");
            log.info("responseEntity.getStatusCode()",responseEntity.getStatusCode());
        }

        log.info("template 끝");

        //throw new Exception();
        //throw new NullPointerException();
        //throw new CommonException(ErrorCode.CANNOT_FOLLOW_MYSELF.value,"Errmsg");
        return null;
    }


    @ApiOperation("template")
    @RequestMapping("/fo/template2")
    public void foTemplate2() throws Exception {
        DaisoRestTemplate restTemplate = new DaisoRestTemplate("http://localhost:8082/mo/template");

        SampleModel requestModel = new SampleModel();
        requestModel.setMasterCd("test1");
        requestModel.setMasterCdNm("test2");

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization","test key");

        ResponseEntity responseEntity =  restTemplate.exchage(requestModel,null, Object.class);

//       if (responseEntity.getStatusCodeValue()>HttpStatus.IM_USED.value()){
//           log.info("======================>",HttpStatus.IM_USED.value());
//       }
//       else {
        ObjectMapper mapper = new ObjectMapper();
        TypeReference<List<SampleModel>> typeRef = new TypeReference<List<SampleModel>>() { };
        List<SampleModel> sampleModels =
                mapper.convertValue(responseEntity.getBody(), typeRef);

        log.info("sampleModelVo :::", sampleModels.get(1));
        log.info("GrCodeNm :::", sampleModels.get(1).getMasterCd());
//       }

    }

    @ApiOperation("Excel Download Sample")
    @GetMapping("/fo/sampleExcel")
    public void apiSampleExcel(HttpServletResponse response) throws IOException
    {
        TestUtil testUtil = new TestUtil();
        testUtil.testPrint();
        List<SampleModel> sampleModelList = sampleService.getSampleCode();
        sampleModelList.stream().map(code -> code.getMasterCd())
                .forEach(log::info);

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("sampleSheet");

        Row row = null;
        Cell cell = null;
        int rowIdx = 0;
        int cellIdx = 0;

        //Header 생성
        row = sheet.createRow(rowIdx++);
        cell = row.createCell(cellIdx++);
        cell.setCellValue("그룹코드");
        cell = row.createCell(cellIdx++);
        cell.setCellValue("그룹코드명");
        cell = row.createCell(cellIdx++);
        cell.setCellValue("사용여부");

//        for(int i=0;i<sampleModelList.size();i++){
//            cellIdx = 0;
//            row = sheet.createRow(rowIdx++);
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getGrCode());
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getGrCodeNm());
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getUseYn());
//        }
        response.setContentType("ms-vnd/excel");
//        response.setHeader("Content-Disposition", "attachment;filename=example.xls");
        response.setHeader("Content-Disposition", "attachment;filename=sample.xlsx");
        wb.write(response.getOutputStream());
        wb.close();
    }

    @ApiOperation("Excel Download Sample")
    @GetMapping("/fo/sampleExcelService")
    public void apiSampleExcelService(HttpServletResponse response) throws IOException{
        List<String> columneNames = new ArrayList<>();
        List<String> headerNames = new ArrayList<>();
        columneNames.add("grCode");
        columneNames.add("grCodeNm");
        columneNames.add("useYn");

        headerNames.add("그룹코드");
        headerNames.add("그룹코드명");
        headerNames.add("사용여부");

        Map<String, String> param = new HashMap<>();
        param.put("useYn","Y");
        Function<Map<String,String>,List<SampleModel>> function = sampleService::getSampleCode;
        excelUtil.makeExcelFileToResponse("sampleService.xlsx",headerNames,columneNames, function, response, param);
    }

    @ApiOperation("Excel Download Sample")
    @GetMapping("/fo/sampleExcelService2")
    public void apiSampleExcelService2(HttpServletResponse response) throws IOException{
        List<String> columneNames = new ArrayList<>();
        List<String> headerNames = new ArrayList<>();
        columneNames.add("grCode");
        columneNames.add("grCodeNm");
        columneNames.add("useYn");

        headerNames.add("그룹코드");
        headerNames.add("그룹코드명");
        headerNames.add("사용여부");

        Map<String, String> param = new HashMap<>();
        param.put("useYn","Y");
        sampleService.getSampleCode(response,param);
//        sampleService.getSampleCode()
        Function<Map<String,String>,List<SampleModel>> function = sampleService::getSampleCode;
        excelUtil.makeExcelFileToResponse("sampleService.xlsx",headerNames,columneNames, function, response, param);
    }



    @ApiOperation("Excel Download Sample2")
    @GetMapping("/fo/sampleExcel2")
    public void apiSampleExcel2(HttpServletResponse response) throws IOException
    {
        TestUtil testUtil = new TestUtil();
        testUtil.testPrint();
//        List<SampleModel> sampleModelList = sampleService.getSampleCode();
//        sampleModelList.stream().map(code -> code.getGrCode())
//                .forEach(log::info);

        SXSSFWorkbook wb = new SXSSFWorkbook();
        wb.setCompressTempFiles(true);
        SXSSFSheet sheet = wb.createSheet("sampleSheet");
        sheet.setRandomAccessWindowSize(1000);  //메모리 size

        Row row = null;
        Cell cell = null;
        int rowIdx = 0;
        int cellIdx = 0;

        //Header 생성
        row = sheet.createRow(rowIdx++);
        cell = row.createCell(cellIdx++);
        cell.setCellValue("그룹코드");
        cell = row.createCell(cellIdx++);
        cell.setCellValue("그룹코드명");
        cell = row.createCell(cellIdx++);
        cell.setCellValue("사용여부");

//        for(int i=0;i<sampleModelList.size();i++){
//            cellIdx = 0;
//            row = sheet.createRow(rowIdx++);
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getGrCode());
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getGrCodeNm());
//            cell = row.createCell(cellIdx++);
//            cell.setCellValue(sampleModelList.get(i).getUseYn());
//        }
        String filename = "sampleExcel2.xlsx";
        String orgFileName = "sampleExcel2.xlsx"; // 서버저장파일명
        String fileDownLoadPath = "/resource/"; // 파일생성

        response.setContentType("ms-vnd/excel");
        response.setHeader("Content-Disposition", "attachment;filename="+filename);
        wb.write(response.getOutputStream());

//        FileOutputStream fos = new FileOutputStream(fileDownLoadPath + orgFileName);
//        wb.write(fos);
        wb.close();
        wb.dispose();
//        Map<String,String> resultMap = new HashMap<>();
//        resultMap.put("filePath", fileDownLoadPath);
//        resultMap.put("realFilNm", orgFileName);
//        resultMap.put("viewFileNm", filename);

    }

    @Operation(summary = "테스트 오라클", description = "오라클 DB 테스트 샘플")
    @GetMapping("/fo/testOracle")
    public String testOracle()
    {
        sampleService.testOracle();

        return "test Oracle";
    }

    @ApiOperation("PDF Download Sample")
    @RequestMapping("/fo/apiSamplePDF")
    public ResponseEntity<InputStreamResource> apiSamplePDF() throws Exception
    {
//        List<SampleModel> sampleModelList = sampleService.getSampleCode();

//        ByteArrayInputStream inputStream = sampleService.getPdf(sampleModelList);
        String filename = String.format("download_test_%s.pdf", LocalDateTime.now().toString());

        HttpHeaders headers = new HttpHeaders();

//        headers.add("Content-Disposition", "inline; filename=" + filename); // view
        headers.add("Content-Disposition", "attachment; filename=" + filename); // 다운로드

//        return ResponseEntity.ok()
//                .headers(headers)
//                .contentType(MediaType.APPLICATION_PDF)
//                .body(new InputStreamResource(inputStream));
        return null;
    }

    @GetMapping("/fo/sample/pagination")
    public CommonResponseModel pagination(SampleModel sampleModel) {
        sampleModel.setTotal(sampleService.getSampleCodeCount(sampleModel));
        List<SampleModel> sampleModelList = sampleService.getSampleCode2(sampleModel);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("sampleModelList", sampleModelList);
        resultMap.put("pagination", (CommonPagingVo) sampleModel);
        return new CommonResponseModel(resultMap);
    }

    @GetMapping("/fo/sample/testCd/{mastCd}")
    public ResponseEntity<CommonResponseModel> mastCdInfo(@PathVariable(value = "mastCd",required = true) String mastCd){
        SampleModel resultModel = sampleService.getSampleCode3(mastCd);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultModel), HttpStatus.OK);
    }

    @Value("${oauth.client.google.client_id}")
    String CONTENT_API_KEY;


    @GetMapping("/testgoogle")
    public String getAccessToken_Google() throws Exception {

        String accessToken = "";

        ClassPathResource resource = new ClassPathResource("google/content-api-key.json");
        try {
            String scopes = "https://www.googleapis.com/auth/content";
            HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
//            HttpTransport httpTransport = new com.google.api.client.http.javanet.NetHttpTransport();
            JsonFactory jsonFactory = GsonFactory.getDefaultInstance();

            GoogleCredential credential = GoogleCredential
                    .fromStream(new FileInputStream(resource.getFile()), httpTransport, jsonFactory).createScoped(Lists.newArrayList(scopes));

            credential.refreshToken();
            credential.createScoped(Collections.singleton("https://www.googleapis.com/auth/content"));
            accessToken = credential.getAccessToken();

        } catch (Exception e) {
            e.printStackTrace();
            log.error("*******************************e.toString()**************"+e.toString());

        }
        log.info("*************************************accessToken********"+accessToken);
        return accessToken;
    }

    @Autowired
    SttUtil sttUtil;

    @PostMapping("/testRecording")
    public void testRecording(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{
        log.info("### upload");
       log.info(sttUtil.stt(file));
       return;
    }

    @ApiOperation("메일테스트체크")
    @GetMapping("/sample/mailTest")
    public void mailTest() throws Exception {
        log.info("mailTest controller Start--------------");
        mailUtil.send("이두원","m2m0006@Daiso.com","m2m0006@Daiso.com","","title","메일 내용");
        return;
    }

    @ApiOperation("파일 다운로드")
    @GetMapping("/sample/filedownload")
    public void filedownload(@ApiParam("파일경로") String filePath, HttpServletRequest request, HttpServletResponse response) throws Exception {
        fileUtil.fileDownload(filePath,request,response);
    }

    @RequestMapping("/testEnc")
    public String testEnc(String str) {
        String enc = XdbUtil.getPosNormalEncrypt(str);
        String result = str + "===>" + enc + "===>" + XdbUtil.getPosNormalDecrypt(enc);
        return result;
    }

    @RequestMapping("/testDec")
    public String testDec(String str) {
        str = str.replace(" ", "+");
        String des = XdbUtil.getPosNormalDecrypt(str);
        String result = str + "===>" + des + "===>" + XdbUtil.getPosNormalEncrypt(des);
        return result;
    }
}
