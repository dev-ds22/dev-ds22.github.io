package kr.co.daiso.fo.mb.service.Impl;

import kr.co.daiso.common.exception.MemberJoinFailCause;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.fo.auth.service.IpinAuthService;
import kr.co.daiso.fo.auth.service.PccV3AuthService;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.mapper.oracle.LoginMapper;
import kr.co.daiso.fo.mb.mapper.oracle.MemberMapper;
import kr.co.daiso.fo.mb.model.*;
import kr.co.daiso.fo.mb.service.MemberService;
import kr.co.daiso.fo.message.model.AtaVO;
import kr.co.daiso.fo.message.model.SmsVO;
import kr.co.daiso.fo.message.service.AtaService;
import kr.co.daiso.fo.message.service.SmsService;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import kr.co.daiso.fo.util.TokenUtil;
import kr.co.daiso.fo.util.XdbUtil;
// import com.oreilly.servlet.Base64Encoder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * packageName    : kr.co.daiso.fo.mb.service.Impl
 * fileName       : MemberServiceImpl
 * author         : kjm
 * date           : 2022-02-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18       kjm            최초생성
 */

@Service
@Slf4j
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private IpinAuthService ipinAuthService;

    @Autowired
    private PccV3AuthService pccV3AuthService;

    @Autowired
    private AtaService ataService;

    @Autowired
    private FoAccountInfoUtil foAccountInfoUtil;

    @Autowired
    private SmsService smsService;

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private LoginMapper loginMapper;


    /**
     * methodName : getMemberByOverlapKey
     * author :  kjm
     * description : 오버랩키로 회원조회
     *
     * @param accountInfo
     * @return AccounInfo
     */
    @Override
    public AccountInfo getMemberByOverlapKey(AccountInfo accountInfo) {
        return memberMapper.getMemberByOverlapKey(accountInfo);
    }

    /**
     * methodName : getMemberById
     * author :  kjm
     * description : 아이디로 회원조회
     *
     * @param memberVO
     * @return AccounInfo
     */
    @Override
    public AccountInfo getMemberById(MemberVO memberVO) {
        return memberMapper.getMemberById(memberVO);
    }

    /**
     * methodName : resetPassword
     * author :  kjm
     * description : 비밀번호 초기화
     *
     * @param memberVO
     * @return CommonResponseModel
     */
    @Override
    @Transactional
    public CommonResponseModel resetPassword(MemberVO memberVO) {

        String pwdRegExp = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[`~!@#$%*^+=_-])[\\w`~!@#$%*^+=-]{8,20}$";

        CommonResponseModel resultModel = new CommonResponseModel();

        if (Pattern.matches(pwdRegExp, memberVO.getPwd())) {

            String password = cmEnCrypt(memberVO.getPwd());
            memberVO.setPwd(XdbUtil.getHashEncryptSha256(password));

            memberMapper.updateMemberPassword(memberVO);
            memberMapper.updateInactiveMemberPassword(memberVO);
            resultModel.setSuccess(true);
            resultModel.setMessage("비밀번호 변경성공.");
        } else {
            resultModel.setSuccess(false);
            resultModel.setMessage("비밀번호 변경이 실패했습니다.");
        }

        return resultModel;
    }

    /**
     * methodName : insertMember
     * author :  kjm
     * description : 회원 저장
     *
     * @param request
     * @param response
     * @param memberVO
     * @return CommonResponseModel
     */
    @Override
    @Transactional
    public CommonResponseModel insertMember(HttpServletRequest request, HttpServletResponse response, MemberVO memberVO) {
        List<MemberJoinFailCause> causeList = new ArrayList<MemberJoinFailCause>();
        CommonResponseModel resultModel = new CommonResponseModel();
        try {

            AccountInfo vo = memberMapper.getMemberById(memberVO);

            if (vo != null) {
                if ("Y".equals(vo.getWtdrYn())) {
                    causeList.add(MemberJoinFailCause.LEFT_MEMBER);
                } else {
                    causeList.add(MemberJoinFailCause.ALREADY_EXISTS_JOINED_INFO);
                }
                throw new Exception();
            } else {
                if (!StringUtils.hasText(memberVO.getMembId())) causeList.add(MemberJoinFailCause.NON_INPUT_ID);
                if (!StringUtils.hasText(memberVO.getPwd())) causeList.add(MemberJoinFailCause.NON_INPUT_PASSWORD);
                if (!StringUtils.hasText(memberVO.getMbpno())) causeList.add(MemberJoinFailCause.NON_INPUT_MOBILE);
                if (!StringUtils.hasText(memberVO.getEmail())) causeList.add(MemberJoinFailCause.NON_INPUT_EMAIL);
                if (CollectionUtils.isEmpty(causeList)) {
                    Map<String, Object> passwordVerify = passwordVerify(memberVO.getMembId(), memberVO.getPwd(), memberVO.getMbpno(), memberVO.getEmail());
                    boolean passwordChk = (Boolean) passwordVerify.get("result");

                    if (!passwordChk) { //비밀번호 변경규칙 재확인
                        causeList.add(MemberJoinFailCause.INVALID_PASSWORD_FORMAT);
                    }

                    if (getMemberById(memberVO) != null) {
                        causeList.add(MemberJoinFailCause.ALREADY_JOINED_ID);
                    }

                    if (checkPhoneDuplication(memberVO.getMbpno())) {
                        causeList.add(MemberJoinFailCause.ALREADY_JOINED_MOBILE);
                    }
                }

                if (!CollectionUtils.isEmpty(causeList)) {
                    throw new Exception();
                } else {
                    String reqNum = null;
                    if(redisUtil.getData("fo:auth:pccReqNum:" + memberVO.getRedisKey()) != null) {
                        reqNum = redisUtil.getData("fo:auth:pccReqNum:" + memberVO.getRedisKey());
                    } else if(redisUtil.getData("fo:auth:ipinReqNum:" + memberVO.getRedisKey()) != null) {
                        reqNum = redisUtil.getData("fo:auth:ipinReqNum:" + memberVO.getRedisKey());
                    } else {
                        reqNum = null;
                    }
                    String retInfo = null;

                    /** 오버랩키 가공 **/
                    if (reqNum == null || !StringUtils.hasText(reqNum)) {
                        causeList.add(MemberJoinFailCause.INVALID_AUTH_ACCESS);
                        throw new Exception();
                    } else if (memberVO.getIpinInfo() != null) {
                        retInfo = Optional.ofNullable(ipinAuthService.IpinDecode(reqNum, memberVO.getIpinInfo()))
                                .map(ipinArr -> ipinArr[10])
                                .orElse("");
                        memberVO.setOvlapKey(retInfo);
                    } else if (memberVO.getPccV3Info() != null) {
                        retInfo = Optional.ofNullable(pccV3AuthService.PccV3Decode(reqNum, memberVO.getPccV3Info()))
                                .map(pccV3Arr -> pccV3Arr[4])
                                .orElse("");
                        memberVO.setOvlapKey(retInfo);
                    }

                    /** 비밀번호 암호화 **/
                    memberVO.setPwd(XdbUtil.getHashEncryptSha256(cmEnCrypt(memberVO.getPwd())));
                    /** 비밀번호 암호화 **/
                    memberVO.setMembKnd("USR_TYPE020");

                    /****** 3. SNS 계정과 직영몰 회원계정 매핑 시작 ******/
                    String snsId = Optional.ofNullable(CookieUtil.getCookie(request, "_si"))
                            .map(Cookie::getValue)
                            .orElse(null);
                    String knd = Optional.ofNullable(CookieUtil.getCookie(request, "_k"))
//                        .map(Cookie::getValue)
                            .map(cookie -> {
                                switch (cookie.getValue()) {
                                    case "N":
                                        return "NAVER";
                                    case "K":
                                        return "KAKAO";
                                    case "A":
                                        return "APPLE";
                                    default:
                                        return null;
                                }
                            })
                            .orElse(null);
                    if (StringUtils.hasText(snsId) && StringUtils.hasText(knd)) {
                        SnsMemberVO snsMemberVO = new SnsMemberVO();
                        snsMemberVO.setSnsId(snsId);
                        snsMemberVO.setKnd(knd);
                        snsMemberVO.setMembId(memberVO.getMembId());
                        memberMapper.updateSocialMember(snsMemberVO);
                    }
                    CookieUtil.addResponseCookie(response, "_si", null, 0);
                    CookieUtil.addResponseCookie(response, "_k", null, 0);
                    /****** SNS 계정과 직영몰 회원계정 매핑 종료 ******/

                    DeviceUtils.getCurrentDevice(request).isMobile();
                    if (DeviceUtils.getCurrentDevice(request).isMobile()) {
                        String userAgent = request.getHeader("User-Agent");
                        if (userAgent.indexOf("daisoAndroid") > -1) {
                            memberVO.setJoinChnl("C220");
                        } else if (userAgent.indexOf("daisoIosApp") > -1) {
                            memberVO.setJoinChnl("C230");
                        } else {
                            memberVO.setJoinChnl("C990");
                        }
                    } else {
                        memberVO.setJoinChnl("C010");
                    }
                    memberMapper.insertMember(memberVO);
                }


                //카카오 알림톡 발송
                AtaVO ataVO = new AtaVO();
                Map<String, Object> ataMap = new HashMap<>();
                ataVO.setTemplateCode("EC00000022");
                ataVO.setRecipientNum(memberVO.getMbpno().replaceAll("-", ""));

                ataMap.put("V_URL", "https://m.daiso.com");
                ataService.insertAta(ataVO, ataMap);
                resultModel.setSuccess(true);

                AccountInfo loginMember = getMemberById(memberVO);
                tokenUtil.addLoginSuccessToken(loginMember, response);

            }
        } catch (Exception exception) {
            exception.printStackTrace();
            JoinErrorLogVO joinErrorLogVO = getMemberJoinFailReqVo(causeList, memberVO, request, exception);
            memberMapper.insertMemberJoinFailLog(joinErrorLogVO);
            resultModel.setData(causeList);
            resultModel.setSuccess(false);
            return resultModel;
        }
        return resultModel;
    }

    /**
     * methodName : sendAuthSms
     * author :  kjm
     * description : 인증 sms 전송
     *
     * @param smsVO
     * @return CommonResponseModel
     */
    @Override
    @Transactional
    public ResponseEntity sendAuthSms(SmsVO smsVO) {

        CommonResponseModel resultModel = new CommonResponseModel();

        try {
            if (StringUtils.hasText(smsVO.getDstaddr())) {

                SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
                Calendar cal = Calendar.getInstance();
                String maCd = formatter.format(cal.getTime()) + RandomStringUtils.random(6, true, true);

                SecureRandom random = new SecureRandom();
                String smsKeyVal = String.valueOf(random.nextInt(900000) + 100000);
                smsVO.setCallback("0226789098");
                smsVO.setDstaddr(smsVO.getDstaddr().replaceAll("-", ""));
                log.info("인증번호 확인용: {}", smsKeyVal);
                smsVO.setText("[K Car]인증번호는 [" + smsKeyVal + "]입니다.");
                smsVO.setSubject(" ");

                Map<String, Object> map = new HashMap<>();
                map.put("maCd", maCd);
                map.put("smsKeyVal", smsKeyVal);

                smsService.insertSms(smsVO);
                memberMapper.insertJoinKey(map);

                resultModel.setSuccess(true);
                resultModel.setData(maCd);
            } else {
                resultModel.setSuccess(false);
                resultModel.setMessage("인증번호 발송이 실패했습니다. 잠시후 다시 시도해주세요.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultModel.setSuccess(false);
            resultModel.setMessage("인증번호 발송이 실패했습니다. 잠시후 다시 시도해주세요.");
        }
        return ResponseEntity.ok().body(resultModel);
    }

    /**
     * methodName : checkAuthSms
     * author :  kjm
     * description : 인증 sms 확인
     *
     * @param map
     * @return boolean
     */
    @Override
    public boolean checkAuthSms(Map<String, Object> map) {
        return memberMapper.getJoinKey(map) > 0;
    }

    /**
     * methodName : deleteJoinKey
     * author :  kjm
     * description : 인증 sms 확인용 키 삭제
     *
     * @param paramMap
     * @return boolean
     */
    @Override
    @Transactional
    public void deleteJoinKey(Map<String, Object> paramMap) {
        memberMapper.deleteJoinKey(paramMap);
    }

    /**
     * methodName : insertMemberNonAge
     * author :  kjm
     * description : 미성년자 가입시도 저장
     */
    @Override
    @Transactional
    public void insertMemberNonAge() {
        memberMapper.insertMemberNonAge();
    }

    /**
     * methodName : getSnsMember
     * author :  kjm
     * description : sns 가입회원 조회
     *
     * @param paramMap
     * @return boolean
     */
    @Override
    public SnsMemberVO getSnsMember(Map<String, Object> paramMap) {
        return memberMapper.getSnsMember(paramMap);
    }

    /**
     * methodName : updateSocialMember
     * author :  kjm
     * description : sns 계정 연결 수정
     *
     * @param snsMemberVO
     */
    @Override
    @Transactional
    public void updateSocialMember(SnsMemberVO snsMemberVO) {
        memberMapper.updateSocialMember(snsMemberVO);
    }

    /**
     * methodName : insertSocialMember
     * author :  kjm
     * description : sns 계정 연결 추가
     *
     * @param snsMemberVO
     */
    @Override
    @Transactional
    public void insertSocialMember(SnsMemberVO snsMemberVO) {
        memberMapper.insertSocialMember(snsMemberVO);
    }

    /**
     * methodName : resetPwdErrorCount
     * author :  kjm
     * description : 비밀번호 오류횟수 초기화
     *
     * @param accountInfo
     */
    @Override
    @Transactional
    public void resetPwdErrorCount(AccountInfo accountInfo) {
        loginMapper.updatePassReset(accountInfo);
    }

    private boolean checkPhoneDuplication(String phone) {
        boolean result = true;
        MemberVO memberVO = new MemberVO();
        memberVO.setMbpno(phone);
        if (memberMapper.getCheckMemberCount(memberVO) == 0) {
            result = false;
        }

        return result;
    }

    private String cmEnCrypt(String encString) {

        String encrypted = "";
        byte[] digested = null;

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(encString.getBytes("UTF-8"));
            digested = md.digest();
            // encrypted = Base64Encoder.encode(digested);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return encrypted;
    }

    //비밀번호 체크
    public Map<String, Object> passwordVerify(String userId, String pwd, String mobile, String email) throws Exception {

        Map<String, Object> resultMap = new HashMap<String, Object>();
        boolean result = true;
        String message = "";

        try {
            String pattern0 = ".*[\\s]";    //공백
            // String pattern1 = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[`~!@#$%^&*()\\-_+=?{}\\[\\]\\\\|;:'\"<>,./])[A-Za-z0-9`~!@#$%\\^&*()\\-_+=?{}\\[\\]\\\\|;:'\"<>,./]{8,20}$"; // 영문, 숫자, 특수문자
            String pattern1 = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[`~!@#$%*^+=_-])[\\w`~!@#$%*^+=-]{8,20}$"; // 영문, 숫자, 특수문자
            String pattern5 = "(\\w)\\1\\1\\1"; // 같은 문자, 숫자

            Matcher match0 = Pattern.compile(pattern0).matcher(pwd);
            Matcher match1 = Pattern.compile(pattern1).matcher(pwd);
            Matcher match5 = Pattern.compile(pattern5).matcher(pwd);

            if (match0.find()) { // 공백 체크
                result = false;
                message = "비밀번호에 공백이 들어갔습니다.";
            } else if (!match1.find()) { // 특수문자, 영문, 숫자 조합 (8~10 자리)
                result = false;
                message = "영문 대/소문자, 숫자, 특수문자를 조합하여 8~20자로 입력해 주세요.";
            } else if (match5.find()) {    // 같은문자 4자리
                result = false;
                message = "연속적인 문자/숫자(예 - 1111,1234,abcd)를 사용하실 수 없습니다.";
            } else if (continuousPwd(pwd)) {  // 연속문자 4자리
                result = false;
                message = "연속적인 문자/숫자(예 - 1111,1234,abcd)를 사용하실 수 없습니다.";
            } else if (StringUtils.hasText(userId) && sameStr(userId, pwd)) {   // 아이디와 동일 문자 4자리
                result = false;
                message = "비밀번호에 아이디가 포함된 문자가 연속4회 포함되었습니다.";
            } else if (StringUtils.hasText(mobile) && sameStr(mobile, pwd)) {
                result = false;
                message = "비밀번호에 휴대전화가 포함된 문자가 연속4회 포함되었습니다.";
            } else if (StringUtils.hasText(email) && sameStr(email, pwd)) {
                result = false;
                message = "비밀번호에 이메일이 포함된 문자가 연속4회 포함되었습니다.";
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        resultMap.put("result", result);
        resultMap.put("message", message);

        return resultMap;
    }

    protected JoinErrorLogVO getMemberJoinFailReqVo(List<MemberJoinFailCause> causeList, MemberVO memberVO, HttpServletRequest request, Exception exception) {
        JoinErrorLogVO joinErrorLogVO = new JoinErrorLogVO();

        String errorLine = String.valueOf(exception.getStackTrace()[0].getLineNumber());
        ArrayList<String> errorCodeList = new ArrayList<>();

        joinErrorLogVO.setMembId(memberVO.getMembId());
        joinErrorLogVO.setMembNm(memberVO.getMembNm());
        joinErrorLogVO.setPwd(StringUtils.hasText(memberVO.getPwd()) ? "Y" : "N");
        joinErrorLogVO.setMbpno(memberVO.getMbpno());
        joinErrorLogVO.setMembEmail(memberVO.getEmail());
        joinErrorLogVO.setJoinChnl("C990");

        if(StringUtils.hasText(memberVO.getIpinInfo())) {
            joinErrorLogVO.setCertChnl("C001");
        } else if(StringUtils.hasText(memberVO.getPccV3Info())) {
            joinErrorLogVO.setCertChnl("C002");
        } else {
            joinErrorLogVO.setCertChnl(null);
        }

        joinErrorLogVO.setErrHapnRelocUrl(memberVO.getErrHapnRelocUrl());
        joinErrorLogVO.setErrHapnUrl(request.getRequestURI()); // request.getRequestURI()
        joinErrorLogVO.setCtnr("");
//        joinErrorLogVO.setCtnr(CommonPathInfo.CONTAINER);
        joinErrorLogVO.setRqstMthd(request.getMethod().toUpperCase());
        joinErrorLogVO.setMembAgt(request.getHeader("User-Agent"));

        // 오류 원인이 하나도 없는 경우, 기타 오류로 등록..
        if (CollectionUtils.isEmpty(causeList)) {
            causeList.add(MemberJoinFailCause.OTHERS);
        }
        causeList.forEach(cause -> errorCodeList.add(cause.getCode()));

        joinErrorLogVO.setErrLog(exception.toString());
        joinErrorLogVO.setErrCd(StringUtils.arrayToCommaDelimitedString(errorCodeList.toArray()));
        joinErrorLogVO.setErrLine(errorLine);
        joinErrorLogVO.setRgpsId(foAccountInfoUtil.getMembId());
        joinErrorLogVO.setMdpsId(foAccountInfoUtil.getMembId());

        return joinErrorLogVO;
    }

    private boolean sameStr(String userId, String pwd) {
        for (int i = 0; i < pwd.length() - 3; i++) {
            if (userId.contains((pwd.substring(i, i + 4)))) {
                return true;
            }
        }
        return false;
    }

    private boolean continuousPwd(String pwd) {
        char[] pwdArr = pwd.toCharArray();
        for (int i = 0; i < pwdArr.length - 3; i++) {
            if (pwdArr[i] == pwdArr[i + 1] && pwdArr[i] == pwdArr[i + 2] && pwdArr[i] == pwdArr[i + 3]) {
                return true;
            } else if (pwdArr[i] + 1 == pwdArr[i + 1] && pwdArr[i] + 2 == pwdArr[i + 2] && pwdArr[i] + 3 == pwdArr[i + 3]) {
                return true;
            }
        }
        return false;
    }

    /**
     * 회원알림로그 저장
     * @param memberAlarmVO
     */
    @Override
    public int insertMemberAlarmLog(MemberAlarmVO memberAlarmVO) {
        return memberMapper.insertMemberAlarmLog(memberAlarmVO);
    }
}
