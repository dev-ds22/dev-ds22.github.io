package kr.co.daiso.fo.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.fo.auth.model.AutoLoginToken;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import kr.co.daiso.fo.mb.service.LoginService;
import kr.co.daiso.fo.mb.service.MemberService;
import kr.co.daiso.fo.util.TokenUtil;
import kr.co.daiso.fo.util.XdbUtil;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;
import java.util.regex.Pattern;

/**
 * packageName    : kr.co.daiso.fo.auth
 * fileName       : FoAuthFilter
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    : FO 필터 클래스 (AccessToken & RefreshToken 체크등)
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26      Doo-Won Lee         최초생성
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class FoAuthFilter extends OncePerRequestFilter {

    @Autowired
    JwtTokenProvider loginTokenProvider;

    @Autowired
    CookieUtil cookieUtil;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    UserDetailService userDetailService;

    @Autowired
    LoginService loginService;

    @Autowired
    MemberService memberService;

    @Autowired
    TokenUtil tokenUtil;

    private static final String[] CORS_WHITE_LIST = {
            //로컬
            "dev.daiso.com:3013" //로컬 MG
            , "dev.daiso.com:3000" //로컬 모바일
            , "dev.daiso.com:3012"  //로컬 PC
            , "local.daisodev.com:3000" //Daiso Test Mo
            , "local.daisodev.com:3012" //Daiso Test PC

            //개발
            , "m.daisodev.com"       //aws 개발
            , "mapi.daisodev.com"   //aws 개발
            , "adm.daisodev.com"   //개발 MG
            , "www.daisodev.com"   //개발 PC
            , "company.daisodev.com"
            , "m-company.daisodev.com"

            //stg
            , "m-qa.daisodev.com"     //aws stg
            , "mapi-qa.daisodev.com"  //aws stg
            , "m-qa.daiso.com"     //aws stg
            , "mapi-qa.daiso.com"  //aws stg
            , "adm-qa.daisodev.com"   //stg MG
            , "qa.daisodev.com"       //stg PC
            , "qacompany.daisodev.com"
            , "m-qacompany.daisodev.com"

            //Test
            , "qa.daiso.com"         //성능 테스트 PC

            //prd
            , "m.daiso.com"           //aws prd
            , "mapi.daiso.com"     //aws prd
            , "adm.daiso.com"         //prd MG
            , "www.daiso.com"         //prd PC
            , "daiso.com"         //prd PC
            ,"company.daisodev.com"
            ,"m-company.daisodev.com"
            , "api.daiso.com"

            , "testpg.easypay.co.kr"
            , "testsp.easypay.co.kr"
            , "testgw.easypay.co.kr"
            , "testoffice.easypay.co.kr"
            ,"pg.easypay.co.kr"
            ,"sp.easypay.co.kr"
            ,"gw.easypay.co.kr"
    };

    private final String STR_ORIGIN = "Origin";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        String accessJwtToken = getAuthToken(request, CommonConstants.FO_ACCESS_TOKEN_NAME);
        String accessUserId = null;
        String refreshJwtToken = null;
        String refreshUserId = null;

        String token = null;
        AutoLoginToken autoLoginToken = null;

        boolean isPreflight = CorsUtils.isPreFlightRequest(request);
        if (request.getRequestURI().indexOf("cors") < 0) {
//            log.info("***********[Filter]***********************************");
//            String springVersion = org.springframework.core.SpringVersion.getVersion();
//            log.info("********** [Filter] Spring version :" + springVersion);
            log.info("********** [Filter]" + request.getRequestURI() + "");
//            log.info("********** [Filter]"+request.getRemoteHost() + "");
//            if (request.getRequestURI().indexOf("sub-code") > 0) {
//                StringBuffer params = new StringBuffer();
//                Enumeration names = request.getParameterNames();
//                while (names.hasMoreElements()) {
//                    String key = (String) names.nextElement();
//                    params = params.append(key)
//                            .append(":")
//                            .append(request.getParameter(key));
////            log.info(key + ": " + request.getParameter(key));
//
//                }
//                log.info("********** [Filter] SubCode Parma :" + params.toString());
//            }
            log.info("isPreflight :" + isPreflight);
            log.info("******************** [Filter] req Start time {},  {} ", request.getRequestURI(), new Date());
        }
//        if (checkWhiteServer(request)) { ucms등이나 redirect 등에서 접근할수 있어 제외
        if (accessJwtToken != null) {
//            log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ accese token :{}, {}", accessJwtToken, request.getRequestURI());
            try {
                accessUserId = loginTokenProvider.getUserId(accessJwtToken);
                if (null != accessUserId) {
                    UserDetails userDetails = userDetailService.loadUserByUsername(accessJwtToken);
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                }
            } catch (ExpiredJwtException e) {
                log.info(e.getMessage());
                accessJwtToken = null;
                // Access Token의 유효기간이 만료되면 Refresh Token의 값을 읽어온다.
                refreshJwtToken = getAuthToken(request, CommonConstants.FO_REFRESH_TOKEN_NAME);
            }
        } else {
            refreshJwtToken = getAuthToken(request, CommonConstants.FO_REFRESH_TOKEN_NAME);
        }
//        log.info("****************refreshJwtToken check******************************");
        if (refreshJwtToken != null) {
            try {
                String redisRefreshUserKey = loginTokenProvider.getUserId(refreshJwtToken);
                String redisRefreshToken = (String) redisUtil.getData(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + redisRefreshUserKey + ":" + refreshJwtToken);

                if(redisRefreshUserKey == null || !StringUtils.hasText(refreshJwtToken)) {
                    cookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, null, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
                    cookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, null, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
                } else if (redisRefreshUserKey != null && refreshJwtToken.equals(redisRefreshToken)) {
                    MemberVO memberVO = new MemberVO();
                    memberVO.setMembId(loginTokenProvider.getUserId(refreshJwtToken));
                    AccountInfo foAccountInfo = memberService.getMemberById(memberVO);
                    foAccountInfo.setPwd(null);

                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(foAccountInfo, null, foAccountInfo.getAuthorities());
                    usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

                    String newAccessToken = loginTokenProvider.createFoJwtToken(foAccountInfo, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
                    cookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, newAccessToken, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
                    String newRefreshToken = loginTokenProvider.createFoRefreshToken(foAccountInfo);
                    cookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, newRefreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
                    redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + redisRefreshUserKey + ":" + refreshJwtToken);
                    redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + foAccountInfo.getMembId() + ":" + newRefreshToken, newRefreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);

                    //                ResponseCookie newAccessTokenCookie = cookieUtil.createResponseCookie(CommonConstants.FO_ACCESS_TOKEN_NAME,newToken,CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
                    //                response.addHeader(HttpHeaders.SET_COOKIE, newAccessTokenCookie.toString());
                }
            } catch (ExpiredJwtException e) {
                log.info("refreshJwtToken Expired!!!!");

                autoLoginToken = Optional.ofNullable(CookieUtil.getCookie(request, "token"))
                        .map(Cookie::getValue)
                        .map(tokenValue -> {
                            AutoLoginToken searchToken = new AutoLoginToken();
                            try {
                                searchToken.setAutoLoginTknVal(URLDecoder.decode(tokenValue.replaceAll("\\+", "%2B"), "UTF-8"));
                            } catch (UnsupportedEncodingException uee) {
                                uee.printStackTrace();
                            }
                            return loginService.getAutoLoginToken(request, response, searchToken);
                        })
                        .orElse(null);
            }
        } else if (accessJwtToken == null) {
            autoLoginToken = Optional.ofNullable(CookieUtil.getCookie(request, "token"))
                    .map(Cookie::getValue)
                    .map(tokenValue -> {
                        AutoLoginToken searchToken = new AutoLoginToken();
                        try {
                            // + -> %2B
                            searchToken.setAutoLoginTknVal(URLDecoder.decode(tokenValue.replaceAll("\\+", "%2B"), "UTF-8"));
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        return loginService.getAutoLoginToken(request, response, searchToken);
                    })
                    .orElse(null);
        }
        if (autoLoginToken != null) {
            // accessToken, refreshToken 재발급
            MemberVO memberVO = new MemberVO();


            String decryptedTokenInfo = XdbUtil.getPosNormalDecrypt(autoLoginToken.getAutoLoginTknVal());
            String[] splitedTokenInfo = decryptedTokenInfo.split(Pattern.quote("."));

            if(splitedTokenInfo != null && splitedTokenInfo.length == 3) {

                String key = splitedTokenInfo[0];		// 인증키 값
                String memberId = splitedTokenInfo[1];	// 타겟 MemberId

                if(key.equals(CommonConstants.FO_AUTO_LOGIN_TOKEN_ENCRYPT_KEY)) {
                    memberVO.setMembId(autoLoginToken.getMembId());
                    AccountInfo foAccountInfo = memberService.getMemberById(memberVO);

                    if(foAccountInfo != null) {
                        final String accessToken = loginTokenProvider.createFoAccessToken(foAccountInfo);
                        final String refreshToken = loginTokenProvider.createFoRefreshToken(foAccountInfo);

                        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(foAccountInfo, null, foAccountInfo.getAuthorities());
                        usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

                        CookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, accessToken, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
                        CookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);

                        redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + foAccountInfo.getMembId() + ":" + refreshToken, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);

                        /* 자동로그인 방식 변경
                            // 자동로그인 토큰 연장
                            Date validDate = new Date();
                            //밑의 setDate, getDate Deplecate 되어 Calendar 로 변경 2022-03-07 Doo-won Lee
                            //validDate.setDate(validDate.getDate() + CommonConstants.FO_AUTO_LOGIN_TOKEN_EXPIRE_DATE);
                            Calendar calendar = Calendar.getInstance();
                            calendar.add(Calendar.DATE, CommonConstants.FO_AUTO_LOGIN_TOKEN_EXPIRE_DATE);
                            validDate = calendar.getTime();
                            autoLoginToken.setTknExpdt(validDate);
                            loginService.extendAutoLoginToken(autoLoginToken);
                        */

                        loginService.saveAutoLoginToken(request, response, autoLoginToken);
                    }
                }
            }
        }
//        log.info("************[Filter]******** from Authfilter to next  time -------------------------- {}, {} ", request.getRequestURI(), new Date());
        filterChain.doFilter(request, response);
        response.addHeader("Cache-Control", "no-cache");
        log.info("************[Filter]******** response to Authfilter  time --------------------------- {}, {} ", request.getRequestURI(), new Date());
//        }
//        else{
//            permissionFailProcess(request,response,"정상적인 접근이 아닙니다.");
//        }

//        log.info("**************[Filter]***** response to Authfilter out time {}, {} ", request.getRequestURI(), new Date());
    }

    private String getAuthToken(HttpServletRequest request, String tokenName) {
        final Cookie authTokenCookie = cookieUtil.getCookie(request, tokenName);
        //   return Optional.ofNullable(authTokenCookie.getValue()).orElse(null);
        return Optional.ofNullable(authTokenCookie)
                .map(Cookie::getValue)
                .orElse(null);
    }

//    private boolean checkWhiteServer(HttpServletRequest request){
//        log.info(request.getHeader(STR_ORIGIN));
//        return   Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> request.getHeader(STR_ORIGIN).indexOf(str)>-1);
//    }

    //허용되지 않는 서버에서 접근시
    private void permissionFailProcess(HttpServletRequest request, HttpServletResponse response, String message) throws IOException {
        log.info(request.getHeader(STR_ORIGIN));

        cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_ACCESS_TOKEN_NAME, null, 0);
        cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_REFRESH_TOKEN_NAME, null, 0);
        boolean isWhiteOrigin = Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> str.indexOf(request.getHeader(STR_ORIGIN)) > -1);
        if (isWhiteOrigin) {
            response.setHeader("Access-Control-Allow-Origin", request.getHeader(STR_ORIGIN));
        }
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setCharacterEncoding("UTF-8");
        response.setStatus(HttpStatus.OK.value());
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("permission", "N");
        ObjectMapper mapper = new ObjectMapper();
        CommonResponseModel responseModel = new CommonResponseModel(resultMap);
        responseModel.setSuccess(false);
        responseModel.setMessage(message);
        response.getWriter().write(mapper.writeValueAsString(responseModel));
        response.flushBuffer();
        //mapper.writeValue(response.getWriter(), new ResponseEntity<CommonResponseModel>(responseModel, HttpStatus.OK));
    }
}
