package kr.co.daiso.fo.auth.oauth;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthClientProperties
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : OAuth연동 Property 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23      Doo-Won Lee      최초생성
 */
@Component
@ConfigurationProperties(prefix = "oauth")
public class OAuthClientProperties {

    Map<String, OAuthRegistration> client = new HashMap<>();
    Map<String, OAuthProvider> provider = new HashMap<>();

    public Map<String, OAuthRegistration> getClient() {
        return client;
    }

    public Map<String, OAuthProvider> getProvider() {
        return provider;
    }
    
}