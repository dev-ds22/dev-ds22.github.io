package kr.co.daiso.fo.common.model;

import lombok.Data;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : MultiComminCodeManageVO
 * author         : chungwoo35
 * date           : 2022-07-19
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-07-19          chungwoo35         최초생성
 */
@Data
public class MultiCommonCodeManageVO{
    private String masterCd;
    private List<CommonCodeManageVO> subCodeList;
}
