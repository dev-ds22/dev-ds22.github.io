package kr.co.daiso.fo.config;

import kr.co.daiso.fo.auth.oauth.OAuthClientProperties;
import kr.co.daiso.fo.auth.oauth.OAuthClientRegistration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : OAuthConfigurer
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : OAuthConfiguration 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23    Doo-Won Lee       최초생성
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class OAuthConfigurer {

    private final OAuthClientProperties oAuthClientProperties;

    @Bean
    public Map<String, OAuthClientRegistration> clientRegistrationMap(){
        log.info("clientRegistrationList");
        
        List<OAuthClientRegistration> clientList =  oAuthClientProperties.getClient().keySet().stream()
                                                    .map(k -> getClientRegistration(k))
                                                    .filter(registration -> registration != null)
                                                    .collect(Collectors.toList());
        ConcurrentHashMap<String, OAuthClientRegistration> result = new ConcurrentHashMap<>();
        for (OAuthClientRegistration registration : clientList)
            result.put(registration.getClientType(), registration);
        return Collections.unmodifiableMap(result);
    }

    /**
     * methodName : getClientRegistration
     * author : Doo-Won Lee
     * description : OAuth 연동을 위한 정보를 각 OAuth 연동 Target별로 생성한다
     *
     * @param clientKey
     * @return OAuthClientRegistration 
     */
    private OAuthClientRegistration getClientRegistration(String clientKey){
//        log.info("getClientRegistration : "+clientKey);
        return OAuthClientRegistration.builder()
                                    .clientType(clientKey)
                                    .registration(oAuthClientProperties.getClient().get(clientKey))
                                    .providerDetails(oAuthClientProperties.getProvider().get(clientKey))
                                    .build();
    }
}
