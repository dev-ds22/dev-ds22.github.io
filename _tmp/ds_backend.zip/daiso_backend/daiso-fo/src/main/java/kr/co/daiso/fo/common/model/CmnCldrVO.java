package kr.co.daiso.fo.common.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : CmnCldrVO
 * author         : Doo-Won Lee
 * date           : 2022-01-27
 * description    : 달력관련 VO (기존 ClsCalVo 대체)
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-27       Doo-Won Lee     최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CmnCldrVO extends BaseModel {
    private String relvDate;       //해당일자
    private String isHldy;         //휴일여부
    private String isHldyType;     //휴일타입( 휴일 , 지점 휴점일 등등)
    private String desc;           //휴일설명
}
