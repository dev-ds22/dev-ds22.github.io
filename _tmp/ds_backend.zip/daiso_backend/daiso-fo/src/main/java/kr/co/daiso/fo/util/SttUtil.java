package kr.co.daiso.fo.util;

import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * packageName    : kr.co.daiso.fo.util
 * fileName       : SttUtil
 * author         : Doo-Won Lee
 * date           : 2022-03-31
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-31      Doo-Won Lee     최초생성
 */
@Slf4j
@Component
public class SttUtil {

    public String stt(MultipartFile file) throws Exception{

        String resultString = null;
        try {

            String clientId = "rqi60bwjgt";             // Application Client ID";
            String clientSecret = "PXlzko2NBmcyVKrRVy3A9dHDy604yy25BxKmEihi";     // Application Client Secret";

            String language = "Kor";        // 언어 코드 ( Kor, Jpn, Eng, Chn )
            String apiURL = "https://naveropenapi.apigw.ntruss.com/recog/v1/stt?lang=" + language;
            URL url = new URL(apiURL);


            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setRequestProperty("X-NCP-APIGW-API-KEY-ID", clientId);
            conn.setRequestProperty("X-NCP-APIGW-API-KEY", clientSecret);

            OutputStream outputStream = conn.getOutputStream();
            FileInputStream inputStream = (FileInputStream) file.getInputStream();
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            outputStream.flush();
            inputStream.close();
            BufferedReader br = null;
            int responseCode = conn.getResponseCode();
//            if(responseCode == 200) { // 정상 호출
//                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            } else {  // 오류 발생
//                log.info("error!!!!!!! responseCode= ", responseCode);
//                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            }
            br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;

//            if(br != null) {
                StringBuilder response = new StringBuilder();
//                StringBuffer response = new StringBuffer();
                while ((inputLine = br.readLine()) != null) {
                    response.append(inputLine);
                }
                br.close();
                log.info(response.toString());
                resultString = response.toString();
                JSONParser parser = new JSONParser();
                JSONObject jsonOb = (JSONObject) parser.parse(resultString);
//                log.info(jsonOb.get("text").toString());

                resultString = jsonOb.get("text").toString();

//            } else {
//                log.info("Clova STT 연동 error !!!");
//            }

        } catch (IOException e) {
//            e.printStackTrace();
            throw e;
        }
        return resultString;
    }
}
