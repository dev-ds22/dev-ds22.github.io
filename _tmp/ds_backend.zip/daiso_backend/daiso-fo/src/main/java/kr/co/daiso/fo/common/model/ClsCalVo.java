package kr.co.daiso.fo.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : ClsCalVo
 * author         : 이강욱
 * date           : 2022-05-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-06       이강욱            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCalVo {
    /** 년월일 */
	private String	vDate;
    /** 휴일, 지점 휴점일 등등 */
	private String	vWhat;

    /** 년 */
	private String	vYear;
    /** 월 */
	private String	vMonth;
    /** 일 */
	private String	vDay;

    /** datepicker.type */
	private String	vType;
    /** datepicker.title, 설명 */
	private String	vTitle;
}
