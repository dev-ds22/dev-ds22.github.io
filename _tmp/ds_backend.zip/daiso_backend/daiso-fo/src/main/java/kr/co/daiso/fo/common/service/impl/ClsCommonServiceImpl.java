package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.fo.common.model.ClsCommonReqVO;
import kr.co.daiso.fo.common.model.ClsCommonVo;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.service.ClsCommonService;
import kr.co.daiso.fo.message.model.SmsVO;
import kr.co.daiso.fo.message.service.SmsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : ClsCommonServiceImpl
 * author         : 이강욱
 * date           : 2022-04-18
 * description    : 공통작업 인터페이스 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18     이강욱             최초생성
 */
@Slf4j
@Service
@Transactional
public class ClsCommonServiceImpl implements ClsCommonService {
    @Autowired private SmsService smsService;

    /**
     * sms 전송 db에 등록
     * @param reqVo
     */
    @Override
    public void insertSms(ClsCommonReqVO reqVo) throws Exception {
        SmsVO smsVo = reqVo.toSmsVo();
        smsService.insertSms(smsVo);
    }

    /**
     * 첫번째 서브코드 정보 가져오기
     * @param reqVo - 검색조건 (i_sMstCode, i_sSubCode, ...)
     * @return 첫번째 서브코드 정보
     *
     * @deprecated {@link kr.co.daiso.fo.common.service.CommonCodeService#getFirstSubCode(CommonCodeSearchVO)}로 대체됨
     */
    @Override
    public ClsCommonVo getCmSubCodeListNoCache(ClsCommonReqVO reqVo) {
        return null;
    }

    /**
     * 서브코드 정보 목록 가져오기
     * @param reqVo - 검색조건 (i_sMstCode, i_sSubCode, ...)
     * @return 서브코드 정보 목록
     *
     * @deprecated {@link kr.co.daiso.fo.common.service.CommonCodeService#getSubCodeList(CommonCodeSearchVO)}}로 대체됨
     */
    @Override
    public List<ClsCommonVo> getCmSubCodeList(ClsCommonReqVO reqVo) {
        return null;
    }
}


