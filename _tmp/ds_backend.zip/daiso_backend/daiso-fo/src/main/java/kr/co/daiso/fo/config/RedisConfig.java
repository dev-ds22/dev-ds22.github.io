package kr.co.daiso.fo.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * packageName    : kr.co.daiso.fo.common.util
 * fileName       : RedisUtil
 * author         : Doo-Won Lee
 * date           : 2021-10-27
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-27      Doo-Won Lee       최초생성
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class RedisConfig {

    @Value("${spring.redis.host}")
    private String redisHost;

    @Value("${spring.redis.port}")
    private int redisPort;

    @Value("${spring.server_type}")
    private String serverType;
//    @Value("${spring.redis.password}")

    @Value("${spring.redis.sentinel.master}")
    private String sentinelMaster;

    @Value("${spring.redis.sentinel.nodes}")
    private String[] sentinelArray;

    private String redisPwd;

    @Bean
    public RedisConnectionFactory redisConnectionFactory() {

        switch(serverType){
            case "dev_cloud":
            case "stg_cloud":
            case "prd_cloud":
            case "stg":
            case "prd":
//            case "dev":
//            case "stg":
//            case "prd":
//            case "local":
//            default:
                RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
                redisStandaloneConfiguration.setHostName(redisHost);
                redisStandaloneConfiguration.setPort(redisPort);
//        redisStandaloneConfiguration.setPassword(redisPwd);
                return new LettuceConnectionFactory(redisStandaloneConfiguration);
            case "local":
            case "dev":
            default:
                RedisSentinelConfiguration redisSentinelConfiguration = new RedisSentinelConfiguration()
                        .master(sentinelMaster);
//                        .sentinel("192.168.210.31",5389)
//                        .sentinel("192.168.210.31",5399)
//                        .sentinel("192.168.210.31",5409);
                for(String sentinelAddr : sentinelArray){
                    String setinelHost = sentinelAddr.split(":")[0];
                    String setinelPort = sentinelAddr.split(":")[1];
                    redisSentinelConfiguration.sentinel(setinelHost,Integer.parseInt(setinelPort));
                }
                return new LettuceConnectionFactory(redisSentinelConfiguration);
        }
    }

    @Bean
    public RedisTemplate<String, String> redisTemplate() {
        RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory());
        redisTemplate.setKeySerializer(new StringRedisSerializer());
//		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        return redisTemplate;
    }
}
