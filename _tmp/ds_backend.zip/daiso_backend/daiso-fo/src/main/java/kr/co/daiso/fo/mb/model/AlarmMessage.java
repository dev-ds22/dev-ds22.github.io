package kr.co.daiso.fo.mb.model;

/**
 * packageName      : kr.co.daiso.fo.mb.model
 * fileName         : AlarmMessage
 * author           : kkh
 * date             : 2022-06-17
 * description      : 알림내용
 * ===========================================================
 * DATE                 AUTHOR              NOTE
 * -----------------------------------------------------------
 * 2022-06-17           kkh                최초 생성
 */

public enum AlarmMessage {
    WAIT_DEPOSIT("입금 대기중인 차량이 있습니다."),
    COUNSEL_APPLICATION("상담신청 중인 차량이 있습니다."),
    SETTLEMENT_COMPLETION("결제가 완료되었습니다."),
    NEED_GUARANTEE("보험증서를 올려야 하는 차량이 있습니다."),
    NEED_SIGNATURE("카카오페이 인증서 서명이 필요한 차량이 있습니다."),
    SET_ALARM_APPLICATION("동일모델 알림 신청 설정되었습니다."),
    IN_WAREHOUSE("판매준비 차량이 입고되었습니다.");

    private final String msg;

    public String getMsg() {
        return msg;
    }

    AlarmMessage(String msg) {
        this.msg = msg;
    }
}
