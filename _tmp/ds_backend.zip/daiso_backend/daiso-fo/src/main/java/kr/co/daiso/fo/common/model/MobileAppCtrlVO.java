package kr.co.daiso.fo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : MobileAppCtrlVO
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park     최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MobileAppCtrlVO {

    private String appCtrlCd;   //앱제어코드
    private String imgUrl;      //이미지URL
    private String linkUrl;     //링크URL
    private String useYn;       //사용여부
}
