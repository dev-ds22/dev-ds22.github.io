package kr.co.daiso.fo.common.mapper.oracle;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.mapper.oracle
 * fileName       : MataTagMapper
 * author         : Doo-Won Lee
 * date           : 2022-05-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-02      Doo-Won Lee       최초생성
 */
@Mapper
public interface MataTagMapper {

    //화면에 사용할 Meta정보를 조회한다.
    Map<String, String> getMetatagInfo(String pgid);
}
