package kr.co.daiso.fo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.model.MailVO;
import kr.co.daiso.common.util.MailUtil;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.util.FileUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.mg.common.controller
 * fileName       : CmnUtilController
 * author         : Doo-Won Lee
 * date           : 2022-03-22
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-22      Doo-Won Lee         최초생성
 */
@Slf4j
@RestController
@RequestMapping("/common")
public class CmnUtilController {

    @Autowired
    FileUtil fileUtil;

    @Autowired
    private Environment environment;

    @Autowired
    private MailUtil mailUtil;

    @ApiOperation("이미지 업로드")
    @RequestMapping("/img-file-upld")
    public ResponseEntity<CommonResponseModel> imgFileUpload(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{
        Map<String, String> resultMap = new HashMap<>();

//        boolean isNeedTransfer = Arrays.stream(environment.getActiveProfiles()).anyMatch(profileName -> profileName.equals("local") || profileName.equals("dev_cloud"));
        CommonResponseModel failModel = new CommonResponseModel();
        if (fileUtil.isAllowUpload(file, failModel, FileUtil.DaisoFileType.IMAGE)) {

            String datePath = req.getParameter("datePath");
            datePath = (datePath == null) ? "":datePath+"/";

            String newFileName = fileUtil.multipartFileUpload(file, CommonPathInfo.UPLOAD_IMAGE_PATH, null);  //파일만 업로드 처리
//            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+file.getOriginalFilename());

            String imagePath = CommonPathInfo.UPLOAD_IMAGE_PATH+datePath;
            switch(CommonPathInfo.SERVER_TYPE){
//                case "local":
//                case "dev":
//                case "dev_cloud":
//                    break;
                case "stg":
                case "stg_cloud":
                case "prd":
                case "prd_cloud":
                    imagePath = imagePath.replace("/BASE/daiso_nas","");
                    imagePath = imagePath.replace("/BASE/daiso","");
                    break;
                default:
                    break;
            }

            resultMap.put("filePath", imagePath + newFileName);
            resultMap.put("fileName", newFileName);
            resultMap.put("filePathOnly", imagePath);
        } else {
            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
        }

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("클라우드 파일 업로드-(MO)")
    @PostMapping("/cloud-file-upld")
    public ResponseEntity<CommonResponseModel> cloudFileUpload(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{

        return fileUtil.transferFileToIdc(file, req);
    }

    @ApiOperation("파일 업로드 - IDC에서 업로드시(PC)")
    @PostMapping("/file-upld")
    public ResponseEntity<CommonResponseModel> idcFileUpload(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{
        return fileUtil.fileUpload(file, req);
    }

    //AWS에서 메일 서버 포트 접근 안되어 추가
    @ApiOperation("메일전송 위임 - 모바일에서 메일 전송시 IDC쪽에 위임")
    @PostMapping("/idcMailSendAssign")
    public ResponseEntity<CommonResponseModel> idcMailSendAssign(HttpServletRequest req) throws  Exception{
        String fileName = req.getParameter("fileName");
        String[] fileNameArray = null;
        if (StringUtils.hasText(fileName)){
            fileNameArray = fileName.split(",");
        }

       MailVO returnMailVo = mailUtil.send(req.getParameter("fromName"),req.getParameter("fromEmail"),
                req.getParameter("to"),req.getParameter("cc"),
                req.getParameter("title"),req.getParameter("content"),
                fileNameArray
                     );
        CommonResponseModel<MailVO> returnResponseModel = new CommonResponseModel(returnMailVo);
        return new ResponseEntity<CommonResponseModel>(returnResponseModel, HttpStatus.OK);
    }

    //AWS에서 메일 서버 포트 접근 안되어 추가
    @ApiOperation("메일전송 위임 - 모바일에서 메일 전송시 IDC쪽에 위임")
    @PostMapping("/idcMailSendAssignWithFile")
    public ResponseEntity<CommonResponseModel> idcMailSendAssignWithFile(HttpServletRequest req) throws  Exception{

        String fileName = req.getParameter("fileName");
        String[] fileNameArray = null;
        if (StringUtils.hasText(fileName)){
            fileNameArray = fileName.split(",");
        }

        MailVO returnMailVo = mailUtil.send(req.getParameter("fromName"),req.getParameter("fromEmail"),
                req.getParameter("to"),req.getParameter("cc"),
                req.getParameter("title"),req.getParameter("content"),
                fileNameArray,req.getParameter("realFileName")
        );
        CommonResponseModel<MailVO> returnResponseModel = new CommonResponseModel(returnMailVo);
        return new ResponseEntity<CommonResponseModel>(returnResponseModel, HttpStatus.OK);
    }
}
