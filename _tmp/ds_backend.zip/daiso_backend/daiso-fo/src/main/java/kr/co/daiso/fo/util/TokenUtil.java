package kr.co.daiso.fo.util;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.fo.auth.JwtTokenProvider;
import kr.co.daiso.fo.auth.model.AutoLoginToken;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.security.SecureRandom;
import java.util.Date;

/**
 * packageName    : kr.co.daiso.fo.util
 * fileName       : TokenUtil
 * author         : kjm
 * date           : 2022-03-07
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-07       kjm            최초생성
 */
@Component
public class TokenUtil {

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    RedisUtil redisUtil;

    public void addLoginSuccessToken(AccountInfo foAccountInfo, HttpServletResponse response) {

        // Access Token, Refresh Token 생성
        final String accessToken = jwtTokenProvider.createFoAccessToken(foAccountInfo);
        final String refreshToken = jwtTokenProvider.createFoRefreshToken(foAccountInfo);

        CookieUtil.addResponseCookie(response, CommonConstants.FO_ACCESS_TOKEN_NAME, accessToken, CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
        CookieUtil.addResponseCookie(response, CommonConstants.FO_REFRESH_TOKEN_NAME, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);

        redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_FO_REFRESH + foAccountInfo.getMembId() + ":" + refreshToken, refreshToken, CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);

    }

    public AutoLoginToken makeAutoLoginToken(MemberVO memberVO) {

        SecureRandom sr = new SecureRandom();
        String randomTail = String.valueOf(sr.nextInt(5));

//        StringBuffer tokenBuffer = new StringBuffer(CommonConstants.FO_AUTO_LOGIN_TOKEN_ENCRYPT_KEY);
        StringBuilder tokenBuffer = new StringBuilder(CommonConstants.FO_AUTO_LOGIN_TOKEN_ENCRYPT_KEY);
        tokenBuffer.append(".");
        tokenBuffer.append(memberVO.getMembId());
        tokenBuffer.append(".");
        tokenBuffer.append(randomTail);

        String token = XdbUtil.getPosNormalEncrypt(tokenBuffer.toString());
//        token = UriEncoder.encode(token, Charset.forName("UTF-8"));

        Date validDate = new Date();
        validDate.setDate(validDate.getDate() + CommonConstants.FO_AUTO_LOGIN_TOKEN_EXPIRE_DATE);

        AutoLoginToken autoLoginToken = new AutoLoginToken();
        autoLoginToken.setMembId(memberVO.getMembId());
        autoLoginToken.setAutoLoginTknVal(token);
        autoLoginToken.setTknExpdt(validDate);

        return autoLoginToken;

    }
}
