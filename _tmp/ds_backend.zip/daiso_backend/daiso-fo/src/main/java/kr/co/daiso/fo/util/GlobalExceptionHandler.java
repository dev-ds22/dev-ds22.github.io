package kr.co.daiso.fo.util;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.exception.ErrorResponse;
import kr.co.daiso.common.model.CommonResponseModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * packageName    : kr.co.daiso.fo.util
 * fileName       : GlobalExceptionHandler
 * author         : leechangjoo
 * date           : 2021-11-09
 * description    : 전역 Exception
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-09          leechangjoo         최초생성
 **/
@Slf4j
//@RestControllerAdvice
//@RequiredArgsConstructor
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Autowired
    MessageSource messageSource;

    @ExceptionHandler(value = { Exception.class })
    protected ResponseEntity handleCommonException(Exception e) {

        if(e instanceof CommonException) {
            CommonException commonException = (CommonException) e;
            if (null!=commonException.getErrorCode()){
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode());
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getHttpStatus());
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getDetail());
                return ErrorResponse.toResponseEntity(commonException.getErrorCode().getHttpStatus(), commonException.getErrorCode().getDetail());
            }
            else{
                return ErrorResponse.toResponseEntity(commonException.getStatus(), commonException.getMessage());
            }
        }else if(e instanceof NullPointerException){
            log.error("handleException throw NullPointerException :", e);
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, e.getCause().toString());
        }else if(e instanceof NumberFormatException){
            log.error("handleException throw NumberFormatException :", e);
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof IOException){
            log.error("handleException throw IOException :", e);
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof ArithmeticException){
            log.error("handleException throw ArithmeticException :", e);
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        } else if(e instanceof IllegalStateException){
            log.error("handleException throw IllegalStateException :", e);
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }

        log.error(null, e);
        return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers
            , HttpStatus status, WebRequest request) {

//        log.error("what: {}",messageSource.getMessage("common.valid.lengthRange",new String[]{"Test","1","2"},Locale.KOREA));
        CommonResponseModel errorResponseModel = new CommonResponseModel();
        List<ObjectError> allErrors = ex.getBindingResult().getAllErrors();
        for (ObjectError error : allErrors) {
//            log.error("error: {}", error);
//            // 코드 정보를 확인할 수 있다.
//            log.error("error arguments: {}",  Arrays.toString(error.getArguments()));
//            log.error("error arguments size: {}",error.getArguments().length);
//            log.error("error: {}", Arrays.toString(error.getCodes()));

            String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
                    .map(c -> {
                        Object[] arguments = error.getArguments();
                        Locale locale = LocaleContextHolder.getLocale();
                        try {
//                            log.error("error arguments: {}", Arrays.toString(arguments));
//                            log.error("error e.getDefaultMessage(): {}", error.getDefaultMessage());
                            return messageSource.getMessage(error.getDefaultMessage(), arguments, locale);
                        } catch (NoSuchMessageException ne) {
//                            log.error("NoSuchMessageException: {}", ne);
                            return null;
                        }
                    }).filter(Objects::nonNull)
                    .findFirst()
                    // 코드를 찾지 못할 경우 기본 메시지 사용.
                    .orElse(error.getDefaultMessage());

            log.error("error message: {}", message);

            errorResponseModel.setData( ErrorResponse.toResponseEntity(HttpStatus.BAD_REQUEST,message));
            break;
        }
        return new ResponseEntity<Object>(errorResponseModel,HttpStatus.OK);

    }
}