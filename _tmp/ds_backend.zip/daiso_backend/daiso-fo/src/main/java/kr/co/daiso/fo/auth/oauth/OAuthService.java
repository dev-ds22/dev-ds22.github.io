package kr.co.daiso.fo.auth.oauth;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.util.DaisoRestTemplate;
import kr.co.daiso.fo.auth.oauth.apple.SigninWithAppleService;
import lombok.extern.slf4j.Slf4j;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthService
 * author         : Doo-Won Lee
 * date           : 2021-11-24
 * description    : OAuth 연동 처리 서비스 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-24     Doo-Won Lee        최초생성
 */
@Slf4j
public class OAuthService {

    SigninWithAppleService signinWithAppleService = new SigninWithAppleService();

    private DaisoRestTemplate restTemplate;

    Gson gson = new Gson();

    /**
     * methodName : requestAuthorize
     * author : Doo-Won Lee
     * description : SNS 인증을 위해 각 SNS인증서버로 로그인 요청
     *
     * @param clientRegistration
     * @param state
     * @param response
     * @throws IOException the io exception
     */
    public void requestAuthorize(OAuthClientRegistration clientRegistration, String state, HttpServletResponse response) throws IOException {

        String responseType = "code";
        if ("apple".equals(clientRegistration.getClientType())) responseType = "code id_token";

        String authorizationUri = UriComponentsBuilder.fromUriString(clientRegistration.getProviderDetails().getAuthUrl())
                .queryParam("client_id", clientRegistration.getRegistration().getClientId())
                .queryParam("response_type", responseType)
                .queryParam("access_type", "offline") //refresh token 을 받기 위한 옵션 : for google
                .queryParam("include_granted_scopes", true) // for google
                .queryParam("scope", clientRegistration.getRegistration().getScopes())
                .queryParam("state", state)
                .queryParam("redirect_uri", clientRegistration.getRegistration().getRedirectUrl())
                .queryParam("response_mode", "form_post")   //for apple
                .build().encode(StandardCharsets.UTF_8).toUriString();
        response.sendRedirect(authorizationUri);
    }


    /**
     * methodName : requestAuthorize
     * author : Doo-Won Lee
     * description : SNS의 OAuthToken을 요청한다.
     *
     * @param clientRegistration the client registration
     * @param code               the code
     * @param state              the state
     * @return the access token
     * @throws CommonException the common exception
     */
    public OAuthToken getAccessToken(OAuthClientRegistration clientRegistration, String code, String state) throws Exception  {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        if(clientRegistration.getClientType().equals("apple")) {
            params.add("client_id", clientRegistration.getRegistration().getClientId());
            params.add("client_secret", signinWithAppleService.getClientSecret());
            params.add("grant_type", "authorization_code");
            params.add("code", code);
            params.add("state", state);
            params.add("redirect_uri", clientRegistration.getRegistration().getRedirectUrl());
        } else {
            params.add("client_id", clientRegistration.getRegistration().getClientId());
            params.add("client_secret", clientRegistration.getRegistration().getClientSecret());
            params.add("grant_type", "authorization_code");
            params.add("code", code);
            params.add("state", state);
            params.add("redirect_uri", clientRegistration.getRegistration().getRedirectUrl());
        }

        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(params, headers);

        ResponseEntity<String> entity = null;
        try {
            restTemplate = new DaisoRestTemplate(clientRegistration.getProviderDetails().getTokenApiUrl());
            entity = restTemplate.exchage(params, headers,String.class);
        } catch (HttpStatusCodeException e) {
            int statusCode = e.getStatusCode().value();
            e.printStackTrace();
            throw new CommonException(String.format("%s 토큰 요청 실패 [응답코드 : %d].", clientRegistration.getClientType(), statusCode),e.getStatusCode());
        }
        log.info(entity.toString());

        JsonObject jsonObj = JsonParser.parseString(entity.getBody()).getAsJsonObject();
        String accessToken = jsonObj.get("access_token").getAsString();
        String refreshToken = jsonObj.get("refresh_token").getAsString();
        LocalDateTime expiredAt = LocalDateTime.now().plusSeconds(jsonObj.get("expires_in").getAsLong());

        return new OAuthToken(clientRegistration.getClientType(),accessToken, refreshToken, expiredAt);
    }

    /**
     * methodName : getUserInfo
     * author : Doo-Won Lee
     * description : SNS의 OAuthToken으로 me 정보를 요청한다.
     *
     * @param clientRegistration the clientRegistration
     * @param accessToken        the accessToken
     * @return the user info
     */
    public OAuthUserInfo getUserInfo(OAuthClientRegistration clientRegistration, String accessToken) throws ParseException, JsonProcessingException {
        HttpHeaders headers = new HttpHeaders();

        headers.add("Authorization", "Bearer " + accessToken);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

       // HttpEntity<?> httpEntity = new HttpEntity<>(headers);

        ResponseEntity<String> entity = null;
        try {
            entity = restTemplate.exchage(clientRegistration.getProviderDetails().getMeApiUrl(),HttpMethod.GET,null,headers,String.class);
        } catch (HttpStatusCodeException e) {
            int statusCode = e.getStatusCode().value();
            throw new CommonException(String.format("%s 유저 정보 요청 실패 [응답코드 : %d].", clientRegistration.getClientType().toUpperCase(), statusCode),e.getStatusCode());
        }

        log.info(entity.toString());

//        JsonObject jsonObj = JsonParser.parseString(entity.getBody()).getAsJsonObject();
//        if(clientRegistration.getClientType().equals("naver")) {
//            jsonObj = jsonObj.getAsJsonObject("response");
//        }
//        Map<String, Object> snsUserInfo = gson.fromJson(jsonObj, Map.class);

        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject) jsonParser.parse(entity.getBody());
        if(clientRegistration.getClientType().equals("naver")) {
            jsonObject = (JSONObject) jsonObject.get("response");
        }
        Map<String, Object> snsUserInfo = new ObjectMapper().readValue(jsonObject.toString(), Map.class);

        return new OAuthUserInfo(clientRegistration.getClientType(), snsUserInfo);
    }
}
