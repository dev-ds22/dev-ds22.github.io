package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * packageName    : kr.co.daiso.mg.login.model
 * fileName       : LoginReqVO
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class LoginReqVO extends BaseModel {

//    @NotNull(message = "common.valid.required")
//    @NotNull(message = "common.valid.required")
    private String membId;
    private String pwd;

    private boolean saveId;
    private boolean autoLogin;
}
