package kr.co.daiso.fo.auth;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.fo.mb.model.AccountInfo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

/**
 * packageName    : kr.co.daiso.fo.auth
 * fileName       : JwtTokenProvider
 * author         : Doo-Won Lee
 * date           : 2021-10-22
 * description    : JwtToken 생성 및 관련 기능처리 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-22       Doo-Won Lee       최초생성
 */
@Slf4j
@Component
public class JwtTokenProvider {

    /**
     * JWT Token을 위한 Secret Key. hmacShaKey는 256 byte 이상을 요구. 한글 11자, 영문 32자 이상으로 지정
     */
    private String secretKey = CommonConstants.JWT_SECRET_KEY_FO;


    /**
     * methodName : getJwtSigningKey
     * author : Doo-Won Lee
     * description : JWT 키 값을 구한다.
     *
     * @param secretKey
     * @return key
     */
    public Key getJwtSigningKey(String secretKey){
        byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes) ;
    }

    /**
     * methodName : createJwtToken
     * author : Doo-Won Lee
     * description : JWT Token을 생성한다.
     *
     * @param accountInfo
     * @param expireTime
     * @return string
     */
    public String createFoJwtToken(AccountInfo accountInfo, long expireTime){
        Claims claims = Jwts.claims();
        claims.put("id", accountInfo.getMembId());

        String pwd = accountInfo.getPwd();
        String ovlapKey = accountInfo.getOvlapKey();
        accountInfo.setPwd(null);
        accountInfo.setOvlapKey(null);

        if (CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND == expireTime) {
            claims.put("userInfo", accountInfo);
        }

        long now = System.currentTimeMillis();

        String jwtToken = Jwts.builder()
                .setClaims(claims)
                .setExpiration(new Date(now + expireTime))
                .setIssuedAt(new Date(now))
                .signWith(getJwtSigningKey(secretKey), SignatureAlgorithm.HS256)
                .compact();

        accountInfo.setPwd(pwd);
        accountInfo.setOvlapKey(ovlapKey);
        return jwtToken;
    }

    /**
     * methodName : createFoAccessToken
     * author : Doo-Won Lee
     * description : FoAccessToken을 생성한다.
     *
     * @param account
     * @return string
     */
    public String createFoAccessToken(AccountInfo account){
        return createFoJwtToken(account,CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
    }

    /**
     * methodName : createFoRefreshToken
     * author : Doo-Won Lee
     * description : FoRefreshToken을 생성한다.
     *
     * @param account
     * @return string
     */
    public String createFoRefreshToken(AccountInfo account){
        return createFoJwtToken(account,CommonConstants.FO_REFRESH_TOKEN_VALIDATION_SECOND);
    }

    /**
     * methodName : getClaimsInfo
     * author : Doo-Won Lee
     * description : JWT 토큰에 등록된 Claims를 얻는다.
     *
     * @param jwtToken
     * @return claims
     */
    public Claims getClaimsInfo(String jwtToken){
        return Jwts.parserBuilder()
                .setSigningKey(getJwtSigningKey(secretKey))
                .build()
                .parseClaimsJws(jwtToken)
                .getBody();
    }


    /**
     * methodName : getUserId
     * author : Doo-Won Lee
     * description : JWT 토큰에 등록된 id를 얻는다.
     *
     * @param jwtToken
     * @return string
     */
    public String getUserId(String jwtToken){
        return getClaimsInfo(jwtToken).get("id",String.class);
    }

    /**
     * methodName : isTokenExpired
     * author : Doo-Won Lee
     * description : JWT 토큰의 만료여부를 확인한다.
     *
     * @param jwtToken
     * @return string
     */
//    public boolean isTokenExpired(String jwtToken) {
//        final Date expiration = getClaimsInfo(jwtToken).getExpiration();
//        return expiration.before(new Date());
//    }

}
