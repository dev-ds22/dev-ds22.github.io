package kr.co.daiso.fo.util;

import kr.co.daiso.fo.common.model.CommonPathInfo;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.util
 * fileName       : CookieBox
 * author         : 이강욱
 * date           : 2022-04-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18       이강욱            최초생성
 */
@Slf4j
public class CookieBox {
	private CookieBox() {}
	// 1차원 쿠키

	public static Cookie createCookie(String name, String value) throws IOException {
		return new Cookie(name, URLEncoder.encode(value, "euc-kr"));
	}

	public static Cookie createCookie(String name, String value, String path) throws IOException {
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setPath(path);
		return cookie;
	}

	public static Cookie createCookie(String name, String value, String path, int maxAge) throws IOException {
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		return cookie;
	}

	public static Cookie createCookie(String name, String value, String domain, String path, int maxAge) throws IOException {
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setDomain(domain);
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		return cookie;
	}

	public static Cookie createCookie(String name, String value, String domain, String path) throws IOException {
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setDomain(domain);
		cookie.setPath(path);
		return cookie;
	}

	// 2차원 쿠키 전용

	public static Cookie createCookie(String name, Map<String, Object> cookieMap) throws IOException {
		String value = makeCookieString(cookieMap);
		return new Cookie(name, URLEncoder.encode(value, "euc-kr"));
	}

	public static Cookie createCookie(String name, Map<String, Object> cookieMap, String path) throws IOException {
		String value = makeCookieString(cookieMap);
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setPath(path);
		return cookie;
	}

	public static Cookie createCookie(String name, Map<String, Object> cookieMap, String path, int maxAge) throws IOException {
		String value = makeCookieString(cookieMap);
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		return cookie;
	}

	public static Cookie createCookie(String name, Map<String, Object> cookieMap, String domain, String path, int maxAge) throws IOException {
		String value = makeCookieString(cookieMap);
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setDomain(domain);
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		return cookie;
	}

	public static Cookie createCookie(String name, Map<String, Object> cookieMap, String domain, String path) throws IOException {
		String value = makeCookieString(cookieMap);
		Cookie cookie = new Cookie(name, URLEncoder.encode(value, "euc-kr"));
		cookie.setDomain(domain);
		cookie.setPath(path);
		return cookie;
	}

	public static Map<String, Cookie> parseCookiesString(String cookieString) throws IOException {
		return parseCookiesString(cookieString, true);
	}

	public static Map<String, Cookie> parseCookiesString(String cookieString, boolean decode) throws IOException {
		if (cookieString == null) {
			return null;
		}

		Map<String, Cookie> result = new LinkedHashMap<String, Cookie>();
		String[] cookiesRaw = cookieString.split("&");

		for (int i = 0; i < cookiesRaw.length; i++) {
			String[] parts = cookiesRaw[i].split("=", 2);
			String value = parts.length > 1 ? parts[1] : "";
			if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
				value = value.substring(1, value.length() - 1);
			}
			result.put(parts[0], new Cookie(parts[0], (decode) ? URLDecoder.decode(value, "euc-kr") : value));
		}

		return result;
	}


	public static String makeCookieString(Map<String, Object> cookieMap) throws IOException {
		return makeCookieString(cookieMap, true);
	}

	public static String makeCookieString(Map<String, Object> cookieMap, boolean encode) throws IOException {

		if (cookieMap == null) {
			return null;
		}

		String[] keys = (String[])cookieMap.keySet().toArray(new String[0]);
		int keyCount = keys.length;

		StringBuilder cookieString = new StringBuilder();

		for (int i = 0; i < keyCount; i++) {
			cookieString.append(keys[i]).append("=").append((encode) ? URLEncoder.encode((String)cookieMap.get(keys[i]), "euc-kr") : cookieMap.get(keys[i]));

			if (i != keyCount - 1) {
				cookieString.append("&");
			}
		}

		return cookieString.toString();
	}

	// cookie parse의 반환 값이 Map<String, String>
	public static Map<String, String> parseCookiesMapString(String cookieString) throws IOException {
		return parseCookiesMapString(cookieString, true);
	}

	// cookie parse의 반환 값이 Map<String, String>
	public static Map<String, String> parseCookiesMapString(String cookieString, boolean decode) throws IOException {
		if (cookieString == null) {
			return null;
		}

		Map<String, String> result = new LinkedHashMap<String, String>();
		String[] cookiesRaw = cookieString.split("&");

		for (int i = 0; i < cookiesRaw.length; i++) {
			String[] parts = cookiesRaw[i].split("=", 2);
			String value = parts.length > 1 ? parts[1] : "";
			if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
				value = value.substring(1, value.length() - 1);
			}
			result.put(parts[0], (decode) ? URLDecoder.decode(value, "euc-kr") : value);
		}

		return result;
	}

	// Map<String, String> 타입인 데이터를 queryString 형태의 쿠키 값으로 만들어주는 메소드.
	public static String makeCookieMapString(Map<String, String> cookieMap) throws IOException {
		return makeCookieMapString(cookieMap, true);
	}

	// Map<String, String> 타입인 데이터를 queryString 형태의 쿠키 값으로 만들어주는 메소드.
	public static String makeCookieMapString(Map<String, String> cookieMap, boolean encode) throws IOException {

		if (cookieMap == null) {
			return null;
		}

		String[] keys = (String[])cookieMap.keySet().toArray(new String[0]);
		int keyCount = keys.length;

		StringBuilder cookieString = new StringBuilder();

		for (int i = 0; i < keyCount; i++) {
			cookieString.append(keys[i]).append("=").append((encode) ? URLEncoder.encode((String)cookieMap.get(keys[i]), "euc-kr") : cookieMap.get(keys[i]));

			if (i != keyCount - 1) {
				cookieString.append("&");
			}
		}

		return cookieString.toString();
	}
	/////////////////////////////////////////////////////////////////////////////

	public static Cookie setCookie(String name, String value) throws IOException {
		return new Cookie(name, value);
	}

	public static Cookie setCookie(String name, String value, String path) throws IOException {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(path);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie setCookie(String name, String value, String path, int maxAge) throws IOException {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie setCookieForOneWeek(String name, String value, String path) throws IOException {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(path);
		cookie.setMaxAge(60 * 60 * 24 * 7);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie setCookie(String name, String value, String domain, String path, int maxAge) throws IOException {
		Cookie cookie = new Cookie(name, value);
		cookie.setDomain(domain);
		cookie.setPath(path);
		cookie.setMaxAge(maxAge);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie setCookie(String name, String value, String domain, String path) throws IOException {
		Cookie cookie = new Cookie(name, value);
		cookie.setDomain(domain);
		cookie.setPath(path);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie deleteCookie(String name){
		Cookie cookie = new Cookie(name, null);
		cookie.setMaxAge(0);
		if(CommonPathInfo.equalsServer("PRD")) // 운영계인 경우
			cookie.setSecure(true);
		return cookie;
	}

	public static Cookie getCookie(HttpServletRequest request, String name) {
		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null) {
			for (int inx = 0; inx < cookies.length; inx++) {
				if (name.equals(cookies[inx].getName())) {
					cookie = cookies[inx];
					break;
				}
			}
		}
		return cookie;
	}

	public static String getValue(HttpServletRequest request, String name){
		Cookie cookie = getCookie(request, name);

		if (cookie == null) {
			return null;
		}

		return cookie.getValue();
	}

	public static String getDecodeValue(HttpServletRequest request, String name){
		String value = getValue(request, name);

		try {
			if(value != null) {
				return URLDecoder.decode(value, CommonPathInfo.CHARSET);
			}
		} catch (Exception e) {
			log.error(null, e);
		}

		return value;
	}

	public static String getDomain(HttpServletRequest request) {

		String hostName = request.getServerName();
		/*int intLocation = hostName.toLowerCase().indexOf(".encardirect");
		if (intLocation > 0) {
			hostName = hostName.toLowerCase().substring(intLocation);
		}*/

		return hostName;
	}
}