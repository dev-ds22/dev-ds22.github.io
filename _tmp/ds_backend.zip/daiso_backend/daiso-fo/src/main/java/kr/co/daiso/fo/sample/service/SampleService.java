package kr.co.daiso.fo.sample.service;

import kr.co.daiso.fo.sample.model.SampleModel;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

public interface SampleService {
    //SampleCode를 가져온다
    public List<SampleModel> getSampleCode();
//
//    public ResponseEntity<CommonResponseModel> loginProcess(SampleLoginVO loginParams, HttpServletResponse response);
//
//    public ResponseEntity<CommonResponseModel> rgMember(AccountInfo aVo)throws Exception;
    //SampleCode를 가져온다
    public List<SampleModel> getSampleCode(Map<String, String> param);
    //SampleCode를 가져온다
    public void getSampleCode(HttpServletResponse response, Map<String, String> param);

    //Oracle 연동 테스트한다.
    public void testOracle();

    //PDF 파일을 생성하는 샘플
    public ByteArrayInputStream getPdf(List<SampleModel> sampleModelList);

    //샘플코드의 갯수를 구한다.
    public int getSampleCodeCount(SampleModel sampleModel);

    //샘플코드를 구한다.
    List<SampleModel> getSampleCode2(SampleModel sampleModel);

    //샘플코드를 구한다.
    SampleModel getSampleCode3(String mastCd);
}
