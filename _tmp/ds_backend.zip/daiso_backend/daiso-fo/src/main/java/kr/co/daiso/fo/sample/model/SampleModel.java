package kr.co.daiso.fo.sample.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper=false)
public class SampleModel extends CommonPagingVo implements Serializable  {
    String masterCd;
    String masterCdNm;
}
