package kr.co.daiso.fo.auth.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * packageName    : kr.co.daiso.fo.auth.model
 * fileName       : AutoLoginToken
 * author         : kjm
 * date           : 2022-03-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-03       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AutoLoginToken extends BaseModel {

    private String membId;
    private String autoLoginTknVal;
    private Date tknExpdt;

}
