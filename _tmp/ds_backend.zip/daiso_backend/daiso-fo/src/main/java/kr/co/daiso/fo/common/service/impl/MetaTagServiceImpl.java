package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.fo.common.mapper.oracle.MataTagMapper;
import kr.co.daiso.fo.common.service.MetaTagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : MetaTagServiceImple
 * author         : Doo-Won Lee
 * date           : 2022-05-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-02       Doo-Won Lee      최초생성
 */
@Service
public class MetaTagServiceImpl implements MetaTagService {

    @Autowired
    MataTagMapper mataTagMapper;

    /**
     * methodName : getMetaTagInfo
     * author : Doo-Won Lee
     * description : 화면에서 사용하는 MetaTag 정보를 조회한다.
     *
     * @param  pgId
     * @return Map
     */
    @Override
    public Map<String, String> getMetaTagInfo(String pgId) throws Exception {
        return mataTagMapper.getMetatagInfo(pgId);
    }
}
