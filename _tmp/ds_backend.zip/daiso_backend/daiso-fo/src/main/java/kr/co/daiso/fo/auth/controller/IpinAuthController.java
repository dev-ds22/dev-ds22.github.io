package kr.co.daiso.fo.auth.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.auth.service.IpinAuthService;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.service.MemberService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.mg.auth.controller
 * fileName       : IpinAuthController
 * author         : kjm
 * date           : 2022-01-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-24       kjm            최초생성
 */
@Slf4j
@RestController
@RequestMapping("/auth/ipin")
public class IpinAuthController {

    @Autowired
    private IpinAuthService ipinAuthService;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private MemberService memberService;

    @RequestMapping("/popup")
    public ResponseEntity ipinAuth(HttpServletRequest request, @RequestBody Map<String, Object> paramMap) {

        Device device = DeviceUtils.getCurrentDevice(request);
        String returnUrl = (String) paramMap.get("returnUrl");
        String srvNo = "";
        String reqNum = ipinAuthService.CreateKey();                // 암호화 키 생성
        String id = "NKR001";                                // IPIN 회원사 아이디
        String exVar = "0000000000000000";                    // 복호화용 임시필드
        String retUrl = null;

        Map<String, Object> resultMap = new HashMap<>();

        SecureRandom secureRandom = new SecureRandom();
        int redisKey = secureRandom.nextInt(1000000000);

        redisUtil.setDataExpire("fo:auth:ipinReqNum:" + redisKey, reqNum, 1000L * 60 * 20);

        if (device.isMobile()) {
            srvNo = CommonPathInfo.PCC_MOBILE_IPIN_SERVICE_NO; // IPIN 서비스번호

            if(request.getHeader("user-agent").contains("daisoIosApp")) {
                retUrl = "23" + CommonPathInfo.MOBILE_FULL_SSL2 + "mb/ipin/ipin-result" + "?returnUrl=" + returnUrl + "&redisKey=" + redisKey + "&type=ipin";       // 본인실명확인 결과수신 URL
            } else {
                if(returnUrl.indexOf("?") != -1) {
                    retUrl = "24" + CommonPathInfo.MOBILE_FULL_SSL2 + returnUrl + "&redisKey=" + redisKey + "&type=ipin";
                }
                else {
                    retUrl = "24" + CommonPathInfo.MOBILE_FULL_SSL2 + returnUrl + "?redisKey=" + redisKey + "&type=ipin";
                }
            }

            resultMap.put("device", "mobile");
        } else {
            srvNo = CommonPathInfo.PCC_IPIN_SERVICE_NO; // IPIN 서비스번호

            if(returnUrl.indexOf("?") != -1) {
                retUrl = "24" + CommonPathInfo.ROOT_FULL_SSL2 + returnUrl + "&redisKey=" + redisKey + "&type=ipin";
            }
            else {
                retUrl = "24" + CommonPathInfo.ROOT_FULL_SSL2 + returnUrl + "?redisKey=" + redisKey + "&type=ipin";
            }
            resultMap.put("device", "pc");
        }

        String reqInfo = reqNum + "/" + id + "/" + srvNo + "/" + exVar;
        reqInfo = ipinAuthService.IpinEncode(reqNum, reqInfo);        // 데이터 암호화

        resultMap.put("reqInfo", reqInfo);
        resultMap.put("retUrl", retUrl);

        return ResponseEntity.ok().body(resultMap);
    }

    /**
     * //     * I-PIN 인증 결과를 받는다.
     * //
     */
    @RequestMapping("/result")
    public ResponseEntity ipin_result(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramMap) {

        String redisKey = (String) paramMap.get("redisKey");
        String reqNum = redisUtil.getData("fo:auth:ipinReqNum:" + redisKey);
        String retInfo = (String) paramMap.get("retInfo");

        CommonResponseModel resultModel = new CommonResponseModel();
        Map<String, Object> resultMap = new HashMap<>();
        AccountInfo resultAccountInfo = new AccountInfo();

        if (reqNum == null) {
            log.info("reqNum not find...."); // "인증과정 중 오류가 발생하였습니다. 다시 시도하여 주세요."
            return ResponseEntity.badRequest().build();
        }

        try {
            String[] memberInfo = (String[]) ipinAuthService.IpinDecode(reqNum, retInfo); // 데이터 복호화
            if (memberInfo == null) {
                log.info("정상적인 접근이 아닙니다.");
                return ResponseEntity.badRequest().build();
            }

            resultMap.put("reqNum", memberInfo[0]);                // 요청번호
            resultMap.put("vDiscrNo", memberInfo[1]);                // 아이핀번호
            resultMap.put("name", URLDecoder.decode(memberInfo[2], "UTF-8"));
            resultMap.put("result", memberInfo[3]);                // 인증결과(1 : 성공)
            resultMap.put("age", memberInfo[4]);                    // 연령대구분값(0~8 : 1, 9~11 : 2, 12~13 : 3, 14 : 4, 15~17 : 5, 18 : 6, 19 : 7, 20이상 : 8)
            resultMap.put("sex", memberInfo[5]);                    // 성별 (M : 남성, F : 여성)
            resultMap.put("ip", memberInfo[6]);                    // 접속 IP
            /*
                발급수단정보( 0 : 본인 공인인증서, 1 : 본인 신용카드, 2 : 본인 핸드폰, 3 : 본인 대면확인, 4 : 신원보증인 아이핀,
                5 : 신원보증인 공인인증서 6 : 신원보증인 신용카드, 7 : 신원보증인 핸드폰, 8 : 신원보증인 대면확인, 9 : 본인 외국인등록번호, 10 : 본인 여권번호)
            */
            resultMap.put("authInfo", memberInfo[7]);
            resultMap.put("birth", memberInfo[8]); // 생년월일
            resultMap.put("fgn", memberInfo[9]);                    // 내, 외국인 구분 ( 0 : 내국인, 1 : 외국인)
            resultMap.put("discrHash", memberInfo[10]);            // 중복가입확인값
            resultMap.put("ciVersion", memberInfo[11]);            // CI 버전 정보
            resultMap.put("ciscrHash", memberInfo[12]);            // 연계정보 값(주민번호에 대한 연계정보)

            if(!StringUtils.hasText((String)resultMap.get("discrHash"))) {
                resultModel.setSuccess(false);
                resultModel.setMessage("003");
                return ResponseEntity.ok().body(resultModel);
            }

            AccountInfo searchAccountInfo = new AccountInfo();
            searchAccountInfo.setOvlapKey((String) resultMap.get("discrHash"));
            resultAccountInfo = memberService.getMemberByOverlapKey(searchAccountInfo);

            if (resultAccountInfo == null) {     // 오버랩키로 조회한 회원정보가 없을경우
                if(manAge(memberInfo[8]) >= 14) {
                    resultModel.setMessage("001");  // 회원정보가 테이블에 없는경우
                } else {
                    resultModel.setMessage("002");  // 회원정보가 테이블에 없고 만14세미만
                    memberService.insertMemberNonAge();
                }
                resultModel.setData(resultMap);
                resultModel.setSuccess(false);
            } else {  // 오버랩키로 조회한 회원정보가 있을경우
                resultModel.setData(resultAccountInfo);
                resultModel.setSuccess(true);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ResponseEntity.ok().body(resultModel);
    }

    private int manAge(String birYMD) {
        LocalDate now = LocalDate.now();
        LocalDate birthDate = LocalDate.parse(birYMD, DateTimeFormatter.ofPattern("yyyyMMdd"));
        int manAge = now.minusYears(birthDate.getYear()).getYear();
        if (birthDate.plusYears(manAge).isAfter(now)) {
            manAge = manAge -1;
        }
        return manAge;
    }
}
