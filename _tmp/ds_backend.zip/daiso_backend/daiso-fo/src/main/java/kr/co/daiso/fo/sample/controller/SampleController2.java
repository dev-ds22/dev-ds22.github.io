package kr.co.daiso.fo.sample.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * packageName    : kr.co.daiso.mg.sample.controller
 * fileName       : SampleController2
 * author         : chungwoo35
 * date           : 2022-03-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-24          chungwoo35         최초생성
 */
@Slf4j
@Controller
@RequestMapping("/jspinwar")
public class SampleController2 {

    @RequestMapping("/jspgoogle")
    public String testGoogleCrolling(HttpServletRequest request, HttpServletResponse response){
        return "google";
    }

    @RequestMapping("/googleMna")
    public ModelAndView testGoogleCrolling2(HttpServletRequest request, HttpServletResponse response){

        ModelAndView mv = new ModelAndView();
        mv.setViewName("/api/google");
        return mv;
    }
}
