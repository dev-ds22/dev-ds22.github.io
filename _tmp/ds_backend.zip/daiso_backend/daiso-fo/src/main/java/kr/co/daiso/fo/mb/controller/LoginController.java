package kr.co.daiso.fo.mb.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.common.util.SocialApiUtil;
import kr.co.daiso.fo.auth.oauth.*;
import kr.co.daiso.fo.auth.oauth.apple.SigninWithAppleService;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import kr.co.daiso.fo.mb.model.SnsMemberVO;
import kr.co.daiso.fo.mb.service.LoginService;
import kr.co.daiso.fo.mb.service.MemberService;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import kr.co.daiso.fo.util.XdbUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * packageName    : kr.co.daiso.fo.mb.controller
 * fileName       : LoginController
 * author         : kjm
 * date           : 2022-02-15
 * description    : 로그인 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
@Slf4j
@RestController
@RequestMapping("/mb")
@Api(tags = "로그인 컨트롤러")
public class LoginController {

    @Value("${domain}")
    private String domain;

    @Autowired
    private FoAccountInfoUtil foAccountInfoUtil;

    @Autowired
    private LoginService loginService;

    @Autowired
    private MemberService memberService;

    @Autowired
    private Map<String, OAuthClientRegistration> clientRegistrationMap;

    @Autowired
    private CookieUtil cookieUtil;

    @Autowired
    private SocialApiUtil socialApiUtil;

    SigninWithAppleService signinWithAppleService = new SigninWithAppleService();

    @ApiOperation("로그인 화면이동")
    @GetMapping("/login-page")
    public ResponseEntity loginPage(HttpServletRequest request, HttpServletResponse response) throws IOException {

        Map<String, Object> resultMap = new HashMap<>();
        if (CookieUtil.getCookie(request, "MemberId") != null) {
            String encMemberId = CookieUtil.getCookie(request, "MemberId").getValue();
            resultMap.put("membId", XdbUtil.getPosNormalDecrypt(encMemberId));
        }

        CommonResponseModel<Map<String, Object>> resultModel = new CommonResponseModel<>(resultMap);
        return ResponseEntity.ok().body(resultModel);
    }

    @ApiOperation("로그인")
    @PostMapping("/login")
    public ResponseEntity login(HttpServletRequest request, HttpServletResponse response, @RequestBody MemberVO memberVO) throws UnsupportedEncodingException {
        try {
            AccountInfo loginMember = loginService.login(request, response, memberVO);
            CommonResponseModel<AccountInfo> resultModel = new CommonResponseModel<>(loginMember);
            return ResponseEntity.ok().body(resultModel);
        } catch (IllegalArgumentException e) {
            CommonResponseModel resultModel = new CommonResponseModel<>();
            resultModel.setData("fail");
            resultModel.setMessage(e.getMessage());
            return ResponseEntity.ok().body(resultModel);
        } catch (IllegalStateException e) {
            CommonResponseModel resultModel = new CommonResponseModel<>();
            resultModel.setData("authentication");
            resultModel.setMessage(e.getMessage());
            Map<String, Object> extraData = new HashMap<>();
            extraData.put("membKnd", memberService.getMemberById(memberVO).getMembKnd());
            resultModel.setExtraData(extraData);
            return ResponseEntity.ok().body(resultModel);
        }
    }

    @ApiOperation("로그아웃")
    @GetMapping("/logout")
    public ResponseEntity logout(HttpServletRequest request, HttpServletResponse response) {
        CommonResponseModel resultModel = new CommonResponseModel();
        try {
            loginService.logout(request, response);
            resultModel.setMessage("로그아웃 성공");
            resultModel.setSuccess(true);
            return ResponseEntity.ok().body(resultModel);
        } catch (Exception e) {
            resultModel.setMessage("로그아웃 실패");
            resultModel.setSuccess(false);
            return ResponseEntity.badRequest().body(resultModel);
        }
    }

    @ApiOperation("SNS로그인 요청")
    @GetMapping("/sns/authorize/{provider}")
    public void snsLoginAuthRequest(@PathVariable String provider, String returnUrl, HttpServletRequest request, HttpServletResponse response) throws IOException {

        if (provider.equals("apple")) {
            response.addHeader(HttpHeaders.SET_COOKIE, ResponseCookie
                    .from("returnUrl", returnUrl)
                    .httpOnly(true)
                    .sameSite("None")
                    .secure(true)
                    .domain(domain)
                    .path("/")
                    .maxAge(Duration.ofMillis(1000 * 60))
                    .build().toString());
            response.addHeader(HttpHeaders.SET_COOKIE, ResponseCookie
                    .from("mid", foAccountInfoUtil.getMembId())
                    .httpOnly(true)
                    .sameSite("None")
                    .secure(true)
                    .domain(domain)
                    .path("/")
                    .maxAge(Duration.ofMillis(1000 * 60))
                    .build().toString());
        } else {
            CookieUtil.addResponseCookie(response, "returnUrl", returnUrl, 60 * 1000);
        }

        String state = CommonUtil.generateState();
        OAuthClientRegistration clientRegistration = clientRegistrationMap.get(provider);

        OAuthService oAuthService = OAuthServiceFactory.getOAuthService(provider);
        oAuthService.requestAuthorize(clientRegistration, state, response);
    }

    @ApiOperation("SNS로그인 리다이렉트")
    @RequestMapping("/sns/redirect/{provider}")
    public void returnSnsLoginAuth(@PathVariable String provider, String state, String code, String error
            , HttpServletRequest request, HttpServletResponse response, @AuthenticationPrincipal AccountInfo loginUser) throws IOException {


        log.info("DeviceUtils.getCurrentDevice(request): {}", DeviceUtils.getCurrentDevice(request));
        log.info("DeviceUtils.getCurrentDevice(request).getDevicePlatform(): {}", DeviceUtils.getCurrentDevice(request).getDevicePlatform());
        String webUrl = "";
        if (DeviceUtils.getCurrentDevice(request).isMobile()) {
            webUrl = CommonPathInfo.MOBILE_FULL_SSL2;
        } else {
            webUrl = CommonPathInfo.ROOT_FULL_SSL2;
        }
        try {
            String returnUrl = Optional.ofNullable(CookieUtil.getCookie(request, "returnUrl"))
                    .map(Cookie::getValue)
                    .orElse("");
            String membId = Optional.ofNullable(CookieUtil.getCookie(request, "mid"))
                    .map(Cookie::getValue)
                    .orElse("");
            CookieUtil.addResponseCookie(response, "returnUrl", null, 0);
            CookieUtil.addResponseCookie(response, "mid", null, 0);

            OAuthClientRegistration clientRegistration = clientRegistrationMap.get(StringUtils.substringBefore(provider, "_"));
            OAuthService oAuthService = OAuthServiceFactory.getOAuthService(StringUtils.substringBefore(provider, "_"));

            //SNS의 AccessToken & me 정보 get
            OAuthToken oAuthToken = oAuthService.getAccessToken(clientRegistration, code, state);

            Map<String, Object> paramMap = new HashMap<>();
            switch (provider.toLowerCase()) {
                case "apple":
                    String id_token = request.getParameter("id_token");
                    Map<String, Object> appleMap = signinWithAppleService.toKenDecrypt(id_token);
                    paramMap.put("snsId", (String) appleMap.get("sub"));
                    paramMap.put("membId", membId);
                    break;
                case "kakao":
                case "naver":
                    OAuthUserInfo oAuthUserInfo = oAuthService.getUserInfo(clientRegistration, oAuthToken.getToken());
                    paramMap.put("snsId", oAuthUserInfo.getSnsId());
                    paramMap.put("membId", foAccountInfoUtil.getMembId());
                    break;
                default:
                    break;
            }
            paramMap.put("knd", StringUtils.upperCase(provider));
            paramMap.put("returnUrl", returnUrl);

            if (returnUrl.toLowerCase().contains((webUrl + "mp/mysns").toLowerCase())) {
                SnsMemberVO snsMemberVO = new SnsMemberVO();
                snsMemberVO.setSnsId((String) paramMap.get("snsId"));
                snsMemberVO.setKnd((String) paramMap.get("knd"));
                snsMemberVO.setMembId((String) paramMap.get("membId"));
                memberService.updateSocialMember(snsMemberVO);
                response.sendRedirect(returnUrl);
            } else {
                loginService.snsLogin(request, response, paramMap);
            }

            // 회원의 경우 Jwt 토큰  (access & refresh Token) 발행하여 cookie 저장
            // 비회원의 경우 회원 가입 처리

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(webUrl);
        }
    }

    @ApiOperation("로그인여부 확인")
    @GetMapping("/login-check")
    public ResponseEntity loginCheck(HttpServletRequest request) {
        return foAccountInfoUtil.isLogined() ? ResponseEntity.ok().body(true) : ResponseEntity.ok().body(false);
    }

    @ApiOperation("로그인 유지용")
    @GetMapping("/token")
    public ResponseEntity token() throws IOException {
        return ResponseEntity.ok().build();
    }

    @ApiOperation("로그인 해제용")
    @GetMapping("/delete-token")
    public ResponseEntity deleteToken(HttpServletRequest request, HttpServletResponse response) {
        loginService.deleteToken(request, response);
        return ResponseEntity.ok().build();
    }
}
