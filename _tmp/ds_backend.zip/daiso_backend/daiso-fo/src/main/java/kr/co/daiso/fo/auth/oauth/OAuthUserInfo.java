package kr.co.daiso.fo.auth.oauth;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthUserInfo
 * author         : Doo-Won Lee
 * date           : 2021-11-25
 * description    : OAuth 연동후 받아오는 유저 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-25      Doo-Won Lee      최초생성
 */
public class OAuthUserInfo {

    String oAuthType;
    Map<String, Object> attributes;

    public OAuthUserInfo(String oAuthType,Map<String, Object> attributes) {
        this.oAuthType = oAuthType;
        this.attributes = attributes;
    }

    public String getSnsId(){
        return String.valueOf(this.attributes.get("id"));
//        return String.valueOf(new BigDecimal((Double) this.attributes.get("id")).longValue());
    }
}
