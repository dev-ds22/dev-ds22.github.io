package kr.co.daiso.fo.config;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : UrlDecodeFilter
 * author         : kjm
 * date           : 2022-05-10
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-10       kjm            최초생성
 */
@Component
public class UrlDecodeFilter extends OncePerRequestFilter {

    public class UrlDecodeWrapper extends HttpServletRequestWrapper {
        HttpServletRequest request;

        public UrlDecodeWrapper(HttpServletRequest request) {
            super(request);
            this.request = request;
        }

        public String[] getParameterValues(String name) {
            String[] result = null;
            try {
                result = Arrays.stream(request.getParameterValues(name))
                        .map(param -> decode(param, "UTF-8"))
                        .toArray(String[]::new);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        public String decode(String s, String enc) {
            try {
                return URLDecoder.decode(s, enc);
            } catch (UnsupportedEncodingException e) {
                return null;
            }
        }
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        UrlDecodeWrapper urlDecodeWrapper = new UrlDecodeWrapper((HttpServletRequest) request);
        filterChain.doFilter(urlDecodeWrapper, response);
    }

}
