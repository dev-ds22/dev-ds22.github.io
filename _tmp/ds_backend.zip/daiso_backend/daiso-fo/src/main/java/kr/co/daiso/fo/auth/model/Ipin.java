package kr.co.daiso.fo.auth.model;

import lombok.Data;

import java.net.URLDecoder;

/**
 * packageName    : kr.co.daiso.fo.auth.model
 * fileName       : Ipin
 * author         : kjm
 * date           : 2022-02-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18       kjm            최초생성
 */
@Data
public class Ipin {

    private String reqNum;      // 요청번호
    private String vDiscrNo;    // 아이핀번호
    private String name;
    private String result;      // 인증결과(1 : 성공)
    private String age;         // 연령대구분값(0~8 : 1, 9~11 : 2, 12~13 : 3, 14 : 4, 15~17 : 5, 18 : 6, 19 : 7, 20이상 : 8)
    private String sex;         // 성별 (M : 남성, F : 여성)

    /*
    발급수단정보( 0 : 본인 공인인증서, 1 : 본인 신용카드, 2 : 본인 핸드폰, 3 : 본인 대면확인, 4 : 신원보증인 아이핀,
    5 : 신원보증인 공인인증서 6 : 신원보증인 신용카드, 7 : 신원보증인 핸드폰, 8 : 신원보증인 대면확인, 9 : 본인 외국인등록번호, 10 : 본인 여권번호)
    */
    private String ip;          // 접속 IP

    private String authInfo;
    private String birth;       // 생년월일
    private String fgn;         // 내, 외국인 구분 ( 0 : 내국인, 1 : 외국인)
    private String discrHash;   // 중복가입확인값
    private String ciVersion;   // CI 버전 정보
    private String ciscrHash;   // 연계정보 값(주민번호에 대한 연계정보)
}
