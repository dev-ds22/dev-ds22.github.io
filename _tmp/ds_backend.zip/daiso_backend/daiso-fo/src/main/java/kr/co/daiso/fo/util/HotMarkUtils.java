package kr.co.daiso.fo.util;

import kr.co.daiso.common.util.StringUtil;
import kr.co.daiso.fo.common.model.CommonCodeManageVO;
import kr.co.daiso.fo.common.model.CommonCodeSearchVO;
import kr.co.daiso.fo.common.service.CommonCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : HotMarkUtils
 * author         : leechangjoo
 * date           : 2022-04-21
 * description    : hotmarkcd로 hotmarknm 생성
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       leechangjoo            최초생성
 */
@Component
public class HotMarkUtils {

    @Autowired
    CommonCodeService commonCodeService;

    public List<String> getHotMarkNames(String hotMarkCodes){
        List<String> hotMarkNameList = new ArrayList<String>();

        try{
            if (StringUtil.isNotEmpty(hotMarkCodes)) {
                CommonCodeSearchVO reqVo = new CommonCodeSearchVO();
                reqVo.setSMstCode("HOT_MARKCD");
                reqVo.setArrSubCd(hotMarkCodes.split(";"));

                List<CommonCodeManageVO> hotMarkVoList = commonCodeService.getSubCodeList(reqVo);
                for (CommonCodeManageVO vo : hotMarkVoList) {
                    hotMarkNameList.add(StringUtil.defaultString(vo.getSubCdNm()));
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return hotMarkNameList;
    }
}
