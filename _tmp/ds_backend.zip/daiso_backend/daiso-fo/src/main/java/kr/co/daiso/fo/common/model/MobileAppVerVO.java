package kr.co.daiso.fo.common.model;

import kr.co.daiso.common.model.BaseModel;
import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : MobileAppVerVO
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park     최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MobileAppVerVO {

    private String osDvsCd;     //OS구분코드
    private String appVer;      //앱버전
    private String coerYn;      //강제 여부
    private String storeLink;   //스토어 링크
}
