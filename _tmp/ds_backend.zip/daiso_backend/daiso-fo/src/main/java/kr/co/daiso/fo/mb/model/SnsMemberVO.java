package kr.co.daiso.fo.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.mb.model
 * fileName       : SnsMemberVO
 * author         : kjm
 * date           : 2022-03-30
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-30       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SnsMemberVO extends BaseModel {
    private String snsId;
    private String membId;
    private String knd;
}
