package kr.co.daiso.fo.common.service.impl;

import kr.co.daiso.fo.common.mapper.oracle.MobileAppCtrlMapper;
import kr.co.daiso.fo.common.mapper.oracle.MobileAppVerMapper;
import kr.co.daiso.fo.common.model.MobileAppCtrlVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;
import kr.co.daiso.fo.common.service.MobileAppCtrlService;
import kr.co.daiso.fo.common.service.MobileAppVerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service.impl
 * fileName       : MobileAppCtrlServiceImpl
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park   최초생성
 */
@Slf4j
@Service
public class MobileAppCtrlServiceImpl implements MobileAppCtrlService {

    @Autowired
    MobileAppCtrlMapper mobileAppCtrlMapper;

    /**
     * methodName : getMobileAppCtrl
     * author : Byung-chul Park
     * description : 모바일 APP제어정보를 조회한다.
     *
     * @param  mobileAppCtrlVO
     * @return MobileAppCtrlVO
     */


    @Override
    public List<MobileAppCtrlVO> getMobileAppCtrl(MobileAppCtrlVO mobileAppCtrlVO) {
        return mobileAppCtrlMapper.getMobileAppCtrl(mobileAppCtrlVO);
    }
}
