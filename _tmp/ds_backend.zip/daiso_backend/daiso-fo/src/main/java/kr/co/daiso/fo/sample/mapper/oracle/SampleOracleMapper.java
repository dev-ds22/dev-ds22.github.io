package kr.co.daiso.fo.sample.mapper.oracle;

import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.sample.model.SampleModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import java.util.List;

@Mapper
public interface SampleOracleMapper {

    List<SampleModel> getSampleCode();

    AccountInfo getAccount(String id);

    //Oracle 엳동 
    void testOracle();

    void rgMember(AccountInfo aVo);

    //샘플코드를 excelHandler를 통해 다운로드 처리한다.
    void getSampleCode(ResultHandler<SampleModel> excelHander);

    //샘플코드 갯수를 구한다.
    int getSampleCodeCount(SampleModel sampleModel);

    //샘플코드를 조회한다.
    List<SampleModel> getSampleCode2(SampleModel sampleModel);

    //샘플코드를 조회한다.
    SampleModel getSampleCode3(String mastCd);
}
