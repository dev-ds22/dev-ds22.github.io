package kr.co.daiso.fo.config;

import kr.co.daiso.fo.auth.FoAuthFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : SecurityConfig
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26       Doo-Won Lee         최초생성
 */
@RequiredArgsConstructor
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * 로그인이 필요한 URL 지정
     */
    private static final String[] LOGIN_LIST = {
            "/messageSample"
    };

    /**
     * Spring Security 처리예외 URL 지정
     */
    private static final String[] IGNORE_LIST = {
//            "/images/**",
//            "/css/**",
//            "/js/**",
//            "/swagger/**",
//            "/swagger-resources/**",
//            "/swagger-ui.html",
//            "/fo/sample/**",
            "/**"
    };

    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    /**
     * Spring Security 처리예외 설정
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers(IGNORE_LIST);
    }

    /**
     * Spring Security Configuration 설정. 로그인이 필요한 경우 JWT Token 체크를 위한 Filter를 거치도록 지정
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
            http.headers().frameOptions().sameOrigin().and()
                .httpBasic().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers("/**").permitAll()
                .and()
                .csrf().disable()
                .cors().disable()
                .addFilterBefore(new FoAuthFilter(), UsernamePasswordAuthenticationFilter.class)
//                .addFilterBefore(new FoAuthFilter(jwtTokenProvider,redisUtil,userDetailService), UsernamePasswordAuthenticationFilter.class)
              //  .addFilterBefore(new KCarCsrfFileter(),CsrfFilter.class)
                .exceptionHandling()
                .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
    }

}
