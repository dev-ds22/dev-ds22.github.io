package kr.co.daiso.fo.auth.oauth;

import lombok.extern.slf4j.Slf4j;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthServiceFactory
 * author         : Doo-Won Lee
 * date           : 2021-11-24
 * description    : OAuthService Factory 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-24      Doo-Won Lee      최초생성
 */
@Slf4j
public class OAuthServiceFactory {

    private OAuthServiceFactory() {
        log.info("OAuthServiceFactory");
    }

    public static OAuthService getOAuthService(String oAuthType){
        switch(oAuthType){
            case "naver":
            case "kakao":
            case "facebook":
            case "apple":
            case "google":
                return new OAuthService();
            default:
                break;
        }
        return null;
    }
}
