package kr.co.daiso.fo.mb.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.model.MemberVO;
import kr.co.daiso.fo.mb.service.MemberService;
import kr.co.daiso.fo.message.model.SmsVO;
import kr.co.daiso.fo.util.FoAccountInfoUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.mb.controller
 * fileName       : MemberController
 * author         : kjm
 * date           : 2022-03-08
 * description    : 회원 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-08       kjm            최초생성
 */
@Slf4j
@RestController
@RequestMapping("/mb")
@Api(tags = "회원 컨트롤러")
public class MemberController {

    @Autowired
    MemberService memberService;

    @Autowired
    FoAccountInfoUtil foAccountInfoUtil;

    @ApiOperation("회원조회")
    @GetMapping("/member")
    public ResponseEntity getMemberById(MemberVO memberVO) {
        AccountInfo accountInfo = memberService.getMemberById(memberVO);
        log.info("accountInfo: {}", accountInfo);
        CommonResponseModel resultModel = new CommonResponseModel();

        if (accountInfo == null) {
            resultModel.setMessage("일치 회원 없음");
            resultModel.setSuccess(false);
        } else {
            resultModel.setMessage("일치 회원 존재");
            resultModel.setSuccess(true);
            resultModel.setData(accountInfo);
        }

        return ResponseEntity.ok().body(resultModel);
    }

    @ApiOperation("비밀번호 변경")
    @PostMapping("/pwd")
    public ResponseEntity resetPassword(@Valid @RequestBody MemberVO memberVO) {
        CommonResponseModel resultModel = memberService.resetPassword(memberVO);
        return ResponseEntity.ok().body(resultModel);
    }

    @ApiOperation("회원 등록")
    @PostMapping("/member")
    public ResponseEntity insertMember(HttpServletRequest request, HttpServletResponse response, @Valid @RequestBody MemberVO memberVO) {
        log.info("memberVO: {}", memberVO);
        CommonResponseModel resultModel = memberService.insertMember(request, response, memberVO);
        return ResponseEntity.ok().body(resultModel);
    }

    @ApiOperation("휴대폰인증 sms전송")
    @PostMapping("/sms-key")
    public ResponseEntity sendAuthSms(@RequestBody SmsVO smsVO) {
        log.info("smsVO: {}", smsVO);
        return memberService.sendAuthSms(smsVO);
    }

    @ApiOperation("휴대폰인증 sms 인증번호 조회")
    @GetMapping("/sms-key")
    public ResponseEntity checkAuthSms(@RequestParam Map<String, Object> paramMap) {
        CommonResponseModel resultModel = new CommonResponseModel();

        if (memberService.checkAuthSms(paramMap)) {
            memberService.deleteJoinKey(paramMap);
            resultModel.setSuccess(true);
            resultModel.setMessage("인증되었습니다.");
        } else {
            resultModel.setSuccess(false);
            resultModel.setMessage("인증에 실패하였습니다.");
        }
        return ResponseEntity.ok().body(resultModel);
    }

    @ApiOperation("회원 기본정보 조회")
    @GetMapping("/login-member")
    public ResponseEntity loginMember() {

        CommonResponseModel resultModel = new CommonResponseModel();
        AccountInfo accountInfo = foAccountInfoUtil.getAccountInfo();

        try {
            if (accountInfo == null) {
                resultModel.setSuccess(false);
            } else {
                resultModel.setData(accountInfo);
                resultModel.setSuccess(true);
            }
            return ResponseEntity.ok(resultModel);
        } catch (Exception e) {
            e.printStackTrace();
            resultModel.setSuccess(false);
            return ResponseEntity.ok(resultModel);
        }
    }

    @ApiOperation("비밀번호 오류 횟수 초기화")
    @PostMapping("/pwd-error")
    public ResponseEntity resetPwdErrorCount(@RequestBody AccountInfo accountInfo) {
        memberService.resetPwdErrorCount(accountInfo);
        return ResponseEntity.ok().build();
    }
}
