package kr.co.daiso.fo.auth.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.fo.auth.model
 * fileName       : Pccv3
 * author         : kjm
 * date           : 2022-02-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18       kjm            최초생성
 */
@Data
public class Pccv3 {
    private String name;        // 이름
    private String birYMD;      // 생년월일(YYYYMMDD)
    private String sex;         // 성별 ( M : 남 , F : 여)
    private String fgnGbn;      // 내외국인 구분(1 : 내국인, 2 : 외국인)
    private String di;          // 중복가입정보
    private String ci1;         // 연계정보 1
    private String ci2;         // 연계정보 2
    private String civersion;   // 연계정보버전
    private String reqNum;      // 요청번호
    private String result;      // 인증성공여부( Y : 성공, N : 실패,  F : 3회 오류)
    private String certGb;      // 인증수단( H : 휴대폰)
    private String cellNo;      // 핸드폰번호
    private String cellCorp;    // 이동통신사
    private String certDate;    // 요청시간
    private String moveUrl;     // 이동할 페이지 정보(retUrl)
}
