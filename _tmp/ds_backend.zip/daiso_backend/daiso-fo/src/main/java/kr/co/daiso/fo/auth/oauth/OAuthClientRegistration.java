package kr.co.daiso.fo.auth.oauth;

import lombok.Builder;
import lombok.Data;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthClientRegistration
 * author         : Doo-Won Lee
 * date           : 2021-11-23
 * description    : OAuth 연동 정보 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-23       Doo-Won Lee     최초생성
 */
@Data
public final class OAuthClientRegistration {
    private String clientType;
    private OAuthRegistration registration = new OAuthRegistration();
    private OAuthProvider providerDetails = new OAuthProvider();

    @Builder
    public OAuthClientRegistration(String clientType, OAuthRegistration registration, OAuthProvider providerDetails){
        this.clientType = clientType;
        this.registration = registration;
        this.providerDetails = providerDetails;
    }
}
