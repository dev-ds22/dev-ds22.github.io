package kr.co.daiso.fo.sample.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * packageName    : kr.co.daiso.fo.sample.model
 * fileName       : SampleLoginVO
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26       Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SampleLoginVO extends BaseModel {
    @NotNull
    private String id;
    private String password;

//    private String name; /* 이름 */
//    private String dept; /* 부서코드 */
//    private String jikgub; /* 직급코드 */
//    private String sDate; /* 입사일 */
//    private String chiefYn; /* 부서장여부 */
//    private String retire; /* 퇴직여부 */
//    private String retireDt; /* 퇴직일자 */
//    private String email; /* 이메일 */
//    private String deptNm; /* 부서명 */
//    private String jikgubNm; /* 직급명 */
}
