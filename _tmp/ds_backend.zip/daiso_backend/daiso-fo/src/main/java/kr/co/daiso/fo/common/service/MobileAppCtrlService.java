package kr.co.daiso.fo.common.service;

import kr.co.daiso.fo.common.model.MobileAppCtrlVO;
import kr.co.daiso.fo.common.model.MobileAppVerVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.fo.common.service
 * fileName       : MobileAppCtrlService
 * author         : Byung-Chul Park
 * date           : 2022-04-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-29     Byung-Chul Park   최초생성
 */
public interface MobileAppCtrlService {

    //모바일 APP제어정보를 조회한다.
    public List<MobileAppCtrlVO> getMobileAppCtrl(MobileAppCtrlVO mobileAppCtrlVO);
}
