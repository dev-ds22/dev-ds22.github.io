package kr.co.daiso.fo.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.fo.common.model
 * fileName       : ClsCarInfoReqVo
 * author         : 이강욱
 * date           : 2022-04-18
 * description    : 온라인 구매 장바구니 응답 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18       이강욱            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCarInfoReqVo extends ClsCommonReqVO {
	private static final long serialVersionUID = 1L;

//	private String	i_sGetDtm;
//	private String	i_sGetFlagImg;
	private String	i_sCarCd;
//	private String	i_sEncarCd;
//	private String	i_sSellerCd;
	/** 상태값 */
	private String	i_sStatus;
//	private String	i_sType;
//	private String	i_sMakeCd;
//	private String	i_sMakeNm;
//	private String	i_sMakeEngNm;
//	private String	i_sMakeType;
//	private String	i_sModelCd;
//	private String	i_sModelNm;
//	private String	i_sModelEngNm;
//	private String	i_sModelYear;
//	private String	i_sCategoryCd;
//	private String	i_sCategoryNm;
//	private String	i_sClassEngNm;
//	private String	i_sClassHeadCd;
//	private String	i_sClassHeadCd2;
//	private String	i_sClassHeadNm;
//	private String	i_sClassHeadNm2;
//	private String	i_sClassHeadEngNm;
//	private String	i_sClassDetailCd;
//	private String	i_sClassDetailCd2;
//	private String	i_sClassDetailNm;
//	private String	i_sClassDetailNm2;
//	private String	i_sClassDetailEngNm;
//	private String	i_sMfrDate;
//	private String	i_sMfrDateFrom;
//	private String	i_sMfrDateTo;
//	private String	i_sVinNum;
//	private int		i_iMileage;
//	private int		i_iMileageFrom;
//	private int		i_iMileageTo;
//	private int		i_iEngineVolume;
//	private int		i_iPrice;
//	private int		i_iPriceFrom;
//	private int		i_iPriceTo;
//	private String	i_sTransmissionCd;			// 변속기 코드
//	private String	i_sTransmissionNm;			// 변속기 코드
//	private String	i_sFuelTypeCd;
//	private String	i_sFuelTypeNm;
//	private String	i_sDoorCd;
//	private String	i_sExteriorColorCd;
//	private String	i_sExteriorColorNm;
//	private int		i_iViewCnt;
//	private String	i_sFlagDel;
//	private String	i_sStatusDtm;
//	private String	i_sInspDate;
//	private String	i_sOptionCd;
//	private String	i_sYoutubeId;
//	private String	i_sCarNumber;
//	private String	i_sCarDetail;
//	private String	i_sCarDetail2;
//	private String	i_sIsValId;
//	private String	i_sPriceFrom;
//	private String	i_sPriceTo;
//	private String	i_sImgSwidth;
//	private String	i_sImgMwidth;
//	private String	i_sImgBwidth;
//	private String	i_sViewType;
//	private String	i_sRegIp;
//	private String	i_sSimpleComment;
//	private String	i_sWarrantyYn;
//	private String	i_sEngineType;
//	private String	i_sNspDtm;
//	private int		i_iNspNumber;
//	private String	i_sHotMarkCd;
//	private String	i_sSoldDtm;
//	private int		i_iSoldPrice;
//	private String	i_sDelDtm;
//	private String	i_sDelComment;
//	private int		i_iTransNo;
//	private String	i_sRecYn;
//	private String	i_sRecDtm;
//	private String	i_sCheckUserCd;
//	private String	i_sSubCheckUserCd;
//	private String	i_sResultType;
//	private String	i_sResultCd1;
//	private String	i_sResultCd2;
//	private String	i_sRegDtm;
//	private String	i_sUpdateDtm;
//	private String	i_sRecComment;
//	private String	i_sThumbnailId;
//	private String	i_sFlag;
//	private String	i_sFlagSame;
//	private String	i_sThumbnailPath;
//	private String	i_sThumbnailWebPath;
//	private String	i_sThumbnailExt;
//	private int		i_iThumbnailWidth;
//	private String	i_sFlagOrignal;
//	private String	i_sThumbnailNm;
//	private String	i_sSearchCategoryCd;
//	private String	i_sSearchStartDt;
//	private String	i_sSearchEndDt;
//	private String[] i_arrSearchYear;
//	private String	i_sMinSearchYear;
//	private String	i_sMinSearchMonth;
//	private String	i_sSearchStartYear;
//	private String	i_sSearchStartMonth;
//	private String	i_sSearchEndYear;
//	private String	i_sSearchEndMonth;
	private String	i_sSearchType; // ClsCarInfoMapper.getCarInfo 쿼리에서 사용
//	private String	i_sSearchType2;
//	private String	i_sListType;
//	private String	i_sMessage;
//	private String	i_sFromEmail;
//	private String	i_sToEmail;
//	private String	i_sFromName;
//	private String	i_sToName;
//	private String	i_sCarDetailPath;
//	private String	i_sDeclearNumber;
//	private String	i_sDateFrom;
//	private String	i_sDateTo;
//	private String	i_sDetailPagUrl;
//	private int		i_iThemeNo;
//	private int		i_iEventNo;
//	private	String	i_sCenterRegion;
//	private	String	i_sBeginYear;
//	private	String	i_sWheel;
//	private	String	i_sGuaranty;
//	private int		i_iSeq;
//	private String	i_sLeaseBuybakType; // 리스, 바이백 차량조건
//	private String  i_sOrgMfr;
//	/* 브랜드인증몰 - 20200731 Start */
//	private String 	i_sCarTcd;
//	private String 	i_sLeseEndDt;
//	private String 	i_sShowRoomCd;
//	private String  i_sPfmncCkqtRegWayCd;
//	/* 브랜드인증몰 - 20200731 End */
//
//	private String		i_sMileageFrom;
//	private String		i_sMileageTo;
	private String[]	i_arrCarCd; // ClsCarInfoMapper.getCarInfo 쿼리에서 사용
//	private String[]	i_arrFuelCd;
//	private String[]	i_arrTransCd;
//	private String[]	i_arrOptionCd;
//	private String[]	i_arrTrustOptionCd;
//	private String[]	i_arrExteriorColorCd;
//	private String[]	i_arrFlag;
//	private String[]	i_arrStatus;
//	private int[]		i_arrThumbWidth;
//
//	private String[]	i_arrMakeCd;
//	private String[]	i_arrModelCd;
//	private String[]	i_arrClassHeadCd;
//	private String[]	i_arrClassDetailCd;
//	private String[]	i_arrColorCd;
//	private String[]	i_arrTrustFlag;
//	private String[]	i_arrLeaseBuybakType; // 리스, 바이백 차량조건
//
//	private List<ClsCarMakeReqVo>	subList;
//	private List<String>		i_notInListCarCd;
//
//	private String		i_sSellerName;
//	private String		i_sSellerAddr;
//	private String		i_sSellerPhone;
//	private String		i_sSellerMobile;
//	private String		i_sSellerEmail;
//	private String		i_sOfficeName;
//	private String		i_sOfficePost;
//	private String		i_sOfficeAddr;
//	private String		i_sOfficePhone;
//	private String		i_sAssoName;
//	private String		i_sAssoPhone;
//
//	// 판매사원 검색엔진 파라미터
//	private String 		wr_eq_v_usernm;
//	private String		wr_eq_v_user_nm;
//
//	private String      wr_like_v_car_number;
//
//    // 핫마크 검색엔진 파라미터
//	private String 		wr_in_v_hot_markcd;
//
//	// 배치작업 관련 기록
//	private int			i_iBatchSeqNo;
//	private long		i_iBatchXmlTime;
//	private long		i_iBatchCarTime;
//	private long		i_iBatchCodeTime;
//	private String		i_sBatchMakeYn;
//	private String		i_sBatchModelYn;
//	private String		i_sBatchClassHeadYn;
//	private String		i_sBatchClassDetailYn;
//	private int			i_iBatchTotalCnt;
//	private int			i_iBatchRegCnt;
//	private int			i_iBatchUpdateCnt;
//	private int			i_iBatchDelCnt;
//
//	private	String		i_sEmail;
//	private String		i_sSlider1;
//	private String		i_sSlider2;
//	private String		i_sSlider3;
//	private String		i_sSlider4;
//	private String		i_sUserCd;
//	// TODO 판매사원 이름 가져오기
//	private	String		i_sCenterType;
//
//	private	String		i_sGoPageUrl;
//
//	//중고차시세 배치 관련
//	private	String		i_sYear;
//	private	String		i_sWeekOfYear;
//	private	String		i_sClassOldNm;
//	private	String		i_sYr;
//	private	String		i_sCntud;
//	private	String		i_sAvgud;
//	private	String		i_sClassOldCd;
//	private int			i_iAvg;
//	private int			i_iCnt;
//	private int			i_iDepreciationTop;
//	private int			i_iDepreciationMedium;
//	private int			i_iDepreciationLow;
//	private int			i_iControlPrice;
//	private int			i_iViewPrice;
//	private	String		i_sMonth;
//	private	String		i_sWeek;
//	private	String		i_sPriceWeek;
//	private	String		i_sDirectYn;
//
//	//중고차시세
//	private	String		i_sContent;
//	private	String		i_sFile;
//	private	int			i_nOrder;
//	private	int			i_nPrice;
//
//	private	String		i_sTitle;
//
//	//진단결과
//	private	String	i_sNspdt;
//	private	String	i_sNspknb;
//	private	String	i_sEmpid;
//	private	String	i_sRealdt;
//	private	String	i_sEffectdt;
//	private	String	i_sChecker;
//	private	int		i_iInspfee;
//	private	int		i_iTrnsno;
//	private	String	i_sCheckerid;
//	private	String	i_sResutype;
//
//	private	String	i_sResu;
//	private	String	i_sRef;
//	private	String	i_sDtlcheck;
//	private	String	i_sDtlcheckTxt;
//	private	String	i_sDtlcheckTxt2;
//	private	String	i_sMemo;
//
//	private	String	i_sPureYn;
//
//	// 시세표
//	private	String	i_sCreate_dt;			// 차량 등록일
//	private	int		i_iBuy_price;			// 매입가
//	private	String	i_sPriceUpdateYn;		// 광고가 여부
//	private	String	i_sClassHeadCd_temp;
//	private	String	i_sCarCdList;
//	private	String	i_sVisitM;
//	private	String	i_sVisitD;
//	private	String	i_sVisitT;
//	private	String	i_sPresent;
//	private	String	i_sMobile;
//
//	private	String	rgsid;
//	private	String	i_sElanPath;
//	private	String	i_sResult;
//
//	// RSM이벤트용
//	private	String	i_sMakeModelClassCd;
//
//	// 다이렉트센터
//	private	String	i_sOrderBy_temp;
//	private	int		i_iPageSize_temp;
//
//	private String	i_sThemeCd;
//
//	private String	i_sCarOption;
//	private String	i_sInstallmentCd;
//	private String	i_sLifeTheme;
//	private String	i_sCoverCarPrice;
//	private String	i_sMakerFlag;
//
//	private String	i_sHelpCd;
//	private String	i_sMemberId;
//	private String	i_sPremiumFlag;
//	private String	i_sExteriorColorCd2;
//	private String	i_sSettleyn;
//	private String	i_sTrustFlag;
//	private String	i_sFuelCd;
//	private String	i_sTransCd;
//	private String	i_sArrCarCd;
//	private String	i_sMemberCd;
//	private String	i_sSearchCd;
//
//	//차량검색 변경
//	private String	i_sArrCategoryCd;
//	private String[] i_arrCategoryCd;
//	private String	i_sMakeModelCd;
//	private String	i_sEventFlag;
//	private int		i_iOptionCnt;
//	private String[] i_arrMakeModelCd;
//
//	// 라이프앱
//	private String	i_sPrice;
//	private String	i_sPriceImport;
//	private String	i_sUse;
//	private String	i_sSex;
//	private String	i_sAge;
//	private String	i_sRegion;
//
//	private String	i_sMyLifeStyleMemberId;
//	private String	i_sMyCarMemberId;
//	private String	i_sMyLifePrice;
//	private String	i_sSellerId;
//
//	private String	i_sPush;
//	private String	i_sNews;
//	private String	i_sLocation;
//	private String	i_sTheme;
//	private String	i_sTodayCar;
//	private String	i_sYearTo;
//	private String	i_sYearFrom;
//
//	// 금융 월 할부
//	private int     i_iInstMonth = 36;	// 할부개월
//	private double  i_iInstRate  = 7.0;	// 금리
//
//	// 리스승계
//	private String	i_sRgsid;
//	private int		i_iBuyOut;
//	private int		i_iMonthLease;
//	private int		i_iDeposit;
//	private int		i_iResidualValue;
//	private int		i_iRestMonth;
//	private int		i_iTotalMonth;
//	private int		i_iPrincipal;
//	private String	i_sStartDt;
//	private String	i_sEndDt;
//	private String	i_sBuyType;
//	private String	i_sLeasePriceTo;
//	private String	i_sLeasePriceFrom;
//	private String	i_sLeaseSearchType;
//	private String	i_sLeasegbn;
//	private String	i_sSearchStartBuyOut;
//	private String	i_sSearchEndBuyOut;
//	private String	i_sSearchStartMonthLease;
//	private String	i_sSearchEndMonthLease;
//	private String[]	i_arrLeasegbn; 	// 운용,금융리스 구분
//	private String	i_sMemberToken;
//	private String	i_sSearchCarOptionCd;
//	private String	i_sSellEmpId;
//	private String	i_sLeasePeriod;
//	private String	i_sDepositRate;
//	private String	i_sMemberNm;
//	private String	i_sFax;
//	private String	i_sTruckFlag;
//	private String	i_sAlsunSearchCd;
//	private String	i_sBestSellerCar;
//	private String  i_sLeaseDiv;
//
//	// 알선
//	private String i_sSupplyDt;
//	private String i_sTrustBuyDt;
//	private String i_sCarPrice;
//	private String i_sHopeCarPrc;
//	private	String i_sTrustFee;
//	private String i_sTrustFeeFg;
//	private String i_sActHolder;
//	private String i_sBankCd;
//	private String i_sActNo;
//	private String i_sSecuFg;
//	private String i_sTaxIssue;
//	private	String i_sContractorKind;
//	private	String i_sEmpId;
//	private	String i_sBankNm;
//	private String i_sTmanageNo;
//	private String i_sRgsId;
//	private String i_sElanRgsId;
//	private String i_sCrrgsnb;
//	private String i_sCarBodyNb;
//	private String i_sMnfccd;
//	private String i_sMdlcd;
//	private String i_sClsheadcd;
//	private String i_sClsdetailcd;
//	private String i_sBeginYr;
//	private String i_sMlg;
//	private String i_sTrns;
//	private String i_sDsp;
//	private String i_sClr;
//	private String i_sOutday;
//	private String i_sAccFg;
//	private String i_sAccDesc;
//	private String i_sCorpCd;
//	private String i_sDealCd;
//	private String i_sSupplyNo;
//	private String i_sEffectDt;
//	private String i_sSeizingCnt;
//	private String i_sPledgeCnt;
//	private String i_sFlagNoSmoking;
//	private String i_sFlagSolo;
//	private String i_sFlagCompromise;
//	private String i_sFlagMonthly;
//	private String i_sFlagMnfcAs;
//	private String i_sFlagLpg;
//	private String i_sRecoUseType;
//	private String i_sBuyerComment;
//	private String i_sSubCd;
//	private String i_sOption;
//	private String i_sSclId;
//	private String i_sSd;
//	private String i_sSgng;
//	private String i_sManageNo;
//	private String i_sUpmyndng;
//	private String i_sPhn;
//	private String i_sMphn;
//	private String i_sPostNo;
//	private String i_sName;
//	private String i_sRstAddr;
//	private String i_sId;
//	private String i_sPesonalFg;
//	private String i_sSeq;
//	private String i_sBizRegNum;
//	private String i_sBizName;
//	private String i_sBizBranch;
//	private String i_sCenterCd;
//	private String i_sNowCrNo;
//	private String i_sControlNum;
//	private String[] i_arrSubCd;
//	private String[] i_arrOption;
//	private String[]	i_arrSellerType;		// 구분
//	private String[]	i_arrSellerName;		// 명의자 이름
//	private String[]	i_arrSellerId;			// 명의자 ID
//	private String[]	i_arrSellerLoc;			// 명의자 센터정보
//	private String[]	i_arrSellerCenterCd;	// 명의자 센터정보
//	private String[]	i_arrSellerEmpId;		// 명의자 센터정보
//	private String[]	i_arrPid;				// 명의자 주민등록번호		패턴암호화 후 저장
//	private String[]	i_arrPid1;				// 명의자 주민등록번호
//	private String[]	i_arrPid2;				// 명의자 주민등록번호
//	private String[]	i_arrBizNm;				// 사업장명
//	private String[]	i_arrBizNo;				// 사업자등록번호
//	private String[]	i_arrBizNo1;			// 사업자등록번호
//	private String[]	i_arrBizNo2;			// 사업자등록번호
//	private String[]	i_arrBizNo3;			// 사업자등록번호
//	private String[]	i_arrMphn;				// 휴대전화
//	private String[]	i_arrMphn1;				// 휴대전화
//	private String[]	i_arrMphn2;				// 휴대전화
//	private String[]	i_arrMphn3;				// 휴대전화
//	private String[]	i_arrPhn; 				// 전화번호
//	private String[]	i_arrPhn1; 				// 전화번호
//	private String[]	i_arrPhn2; 				// 전화번호
//	private String[]	i_arrPhn3; 				// 전화번호
//
//	private String[]	i_arrAddr;			// 주소
//	private String[]	i_arrSellerAddr1;	// 주소 시도+구군+을면동
//	private String[]	i_arrSellerAddr2;	// 주소 나머지
//	private String[]	i_arrAddrSd; 		// 주소	(시,도)
//	private String[]	i_arrAddrSgng;		//		(구,군)
//	private String[]	i_arrAddrUpmyndng;	//		(을,면,동)
//	private String[]	i_arrAddrRst;		//		(나머지)
//	private String[]	i_arrPostNo;		//		(우편번호)
//	private String[]	i_arrSellEmpId;		// 명의자 센터 사원
//	private String[]	i_arrBranch;		// 명의자 영업소직영점명
//	private String	i_sPure;
//	private String	i_sCsCd;
//	private String	i_sMasterComment;
//	private String	i_sPledgeCompanyEtc;
//	private String[]	i_arrName;
//	private String[]	i_arrSclId;
//	private String[]	i_arrSd;
//	private String[]	i_arrSgng;
//	private String[]	i_arrUpmyndng;
//	private String[]	i_arrRstAddr;
//	private String[]	i_arrBizName;
//
//	// 알선 성능점검
//	private	String	recordno;				//	점검기록부 번호
//	private	String	mileage;				//	주행거리
//	private	String	boardstate;				//	계기상태
//	private	String	validity1;				//	유효기간 시작일
//	private	String	validity2;				//	유효기간 종료일
//	private	String	firstregdt;				//	최초등록일
//	private	String	transmission;			//	변속기
//	private	String	motortype;				//	원동기형식
//	private	String	carregistration;		//	차대번호
//	private	String	carstate;				//	동일성확인
//	private	String	tuningyn;				//	불법구조변경
//	private	String	accyn;					//	사고유무
//	private	String	enginecheck;			//	엔진상태
//	private	String	trnscheck;				//	변속기상태
//	private	String	coout;					//	배출가스(CO)
//	private	String	hcout;					//	배출가스(HC)
//	private	String	smout;					//	배출가스(매연)
//	private	String	comments;				//	특이사항
//	private	String	issuedt;				//	점검 확인일자
//	private	String	rgsdt;					//	등록일자
//	private	String	insp_nm;				//	상태점검자
//	private	String	notice_nm;				//	상태고지자
//	private	String	yr;						//	성능점검표상 연식
//	private	String	guarantytype;			//	보증유형
//	private	String	trnsetc;				//	변속기 기타
//	private	String	mncd;		//	Main Code
//	private	String	sbcd;		//	Sub Code
//	private	String	resu;		//	성능점검 결과
//	private	String	mjrcd;		//	결과 수치(?) - 기준 연월일에 따른 구분 코드
//	private	String	sumcd;		//	Sub Code
//	private	String	result;		//	성능점검 결과
//	private	String	seq;			//	히스토리 시퀀스
//	private	String	updt;			//	변경일자
//	private	String	available;		//	변경가능여부
//	private	String	memo;			//	변경사유
//	private	String	admnm;			//	변경처리자
//	private String	i_sMnfcCd;			// 제조사 코드
//	private	String	i_sMnfcNm;			// 모델명
//	private	String	i_sMdlCd;			// 모델명 코드
//	private	String	i_sMdlNm;			// 모델명
//	private	String	i_sClsCd;			// 등급 코드
//	private	String	i_sClsNm;			// 등급명
//	private String	i_sCtgrNm;			// 차종
//	private int		i_iDmndPrc;			// 광고가
//	private String	i_sDmndDtt;			// 희망매도일2
//	private String	i_sCrrgsNb;			// 차량번호
//	private String	i_sDr;				// 도어
//	private String	i_sCarbodyNb; 		// 차대번호
//	private String	i_sWrntnb;			// 보증여부
//	private String	i_sDohc;			// 엔진
//	private String	i_sNspDt;			// 진단일자
//	private String	i_sHorMark;			// 핫마크 코드
//	private String	i_sVacctYn;			// 무통장입금 예약
//	private String	i_sNspkNb;			// 진단번호
//	private String	i_sPowerPack;		// 파워팩 문구
//	private String	i_sSlDt;			// 판매 일자
//	private String	i_sSlPrc;			// 판매 가격
//	private String	i_sCrMm;			// 차량 설명
//	private String	i_sStsf;			// 만족도
//	private String	i_sDlstDt;			// 삭제 일자
//	private String	i_sDlstRsn;			// 삭제 이유
//	private String	i_sMdfDt;			// 수정 일자
//	private String	i_sFrstRgsDt;		// 최초등록일
//	private String	i_sTrnsNo;			// 거래번호
//	private String	i_sSettleYn;		// 결제여부
//	private String	i_sWhatFuel;		// 연료명
//	private String	i_sIsValid;			// 차량상태
//	private String	i_sMnfcNmEn;		// 제조사 영문 이름
//	private String	i_sMdlNmEn;			// 모델 영문 이름
//	private String	i_sClsNmEn;			// 등급 영문 이름
//	private String	i_sLease;			// 리스가능여부
//	private String	i_sRgsDt;			// 최초등록일(입력일)
//	private String	i_sClsHeadCd;		// 등급 코드
//	private String	i_sClsHeadNm;		// 등급명
//	private String	i_sClsDetailCd;		// 세부등급 코드
//	private String	i_sClsDetailNm;		// 세부등급 명
//	private String	i_sProHrep;			// 차량번호 중복체크
//	private String	i_sInspYn;			// 성능점검표 입력 여부
//	private String	i_sImportYn;		// 임판/직수입차량
//	private String	i_sAdvWords;		// 우대등록 한줄광고 문구
//	private String	i_sPopMdfDt;		// 인기차량 자유광고 수정일
//	private String	i_sSpecMdfDt;		// 우대등록 자유광고 수정일
//	private String	i_sHotMdfDt;		// 핫마크 자유광고 수정일
//	private String	i_sPowMdfDt;		// 파워팩 자유광고 수정일
//	private String	i_sRecMdfDt;		// 몰등록 시간
//	private String	i_sMdfFg;			// 48시간 옵션 변경
//	private String	i_sMallYn;			// 몰등록 여부(Y: 몰등록, C: K Car 등록, N: 등록안함)
//	private String	i_sNspkYn;			// 진단여부
//	private	String	i_sAuctionFg;		// 법인- 경매영업배분
//
//	private	String	i_sRecordNo;						//	성능점검표 일련번호
//	private	String	i_sBoardState;						//	계기상태
//	private	String	i_sEffectFromDt;					//	검사유효기간 시작날짜
//	private	String	i_sEffectToDt;						//	검사유효기간 마지막날짜
//	private	String	i_sFirstRegDt;						//	최초등록일
//	private	String	i_sMotorType;						//	원동기형식
//	private	String	i_sTransMission;					//	변속기
//	private	String	i_sTrnsEtc;							//	변속기 기타
//	private	String	i_sCarRegistration;					//	차대번호
//	private	String	i_sGuarantyType;					//	보증유형
//	private	String	i_sCarState;						//	동일성 확인
//	private	String	i_sTuningYn;						//	불법구조변경
//	private	String	i_sAccYn;							//	사고/침수유무
//	private	String	i_sEngineCheck;						//	자기진단사항 - 원동기
//	private	String	i_sTrnsCheck;						//	자기진단사항 - 변속기
//	private	String	i_sCoOut;							//	배출가스 - 일산화탄소(CO)
//	private	String	i_sHcOut;							//	배출가스 - 탄화수소(HC)
//	private	String	i_sSmOut;							//	배출가스 - 매연
//	private	String	i_sParts_1_001001;					//	주요장치 - 원동기 : 작동상태(공회전)
//	private	String	i_sParts_2_001002;					//	주요장치 - 원동기 : 압축상태(공회전)
//	private	String	i_sParts_3_001003001;					//	주요장치 - 원동기 : 오일누유 - 실린더헤드
//	private	String	i_sParts_4_001003002;					//	주요장치 - 원동기 : 오일누유 - 실린더블럭
//	private	String	i_sParts_5_001004;					//	주요장치 - 원동기 : 오일유량 및 오염
//	private	String	i_sParts_6_001005001;					//	주요장치 - 원동기 : 냉각수누수 - 실린더블럭
//	private	String	i_sParts_7_001005002;					//	주요장치 - 원동기 : 냉각수누수 - 실린더헤드/가스켓
//	private	String	i_sParts_8_001005003;					//	주요장치 - 원동기 : 냉각수누수 - 워터펌프
//	private	String	i_sParts_9_001005004;					//	주요장치 - 원동기 : 냉각수누수 - 냉각쿨러(라디에이터)
//	private	String	i_sParts_10_001005005;					//	주요장치 - 원동기 : 냉각수누수 - 냉각수량 및	오염
//	private	String	i_sParts_11_001006;					//	주요장치 - 원동기 : 고압펌프(커먼레일)
//	private	String	i_sParts_12_002001001;					//	주요장치 - 변속기 : 자동변속기(A/T) - 오일누유
//	private	String	i_sParts_13_002001002;					//	주요장치 - 변속기 : 자동변속기(A/T) - 오일유량 및 상태
//	private	String	i_sParts_14_002001003;					//	주요장치 - 변속기 : 자동변속기(A/T) - 스톨시험(전진)
//	private	String	i_sParts_15_002001004;					//	주요장치 - 변속기 : 자동변속기(A/T) - 스톨시험(후진)
//	private	String	i_sParts_16_002001005;					//	주요장치 - 변속기 : 자동변속기(A/T) - 작동상태(공회전)
//	private	String	i_sParts_17_002002001;					//	주요장치 - 변속기 : 수동변속기(M/T) - 오일누유
//	private	String	i_sParts_18_002002002;					//	주요장치 - 변속기 : 수동변속기(M/T) - 기어변속장치
//	private	String	i_sParts_19_002002003;					//	주요장치 - 변속기 : 수동변속기(M/T) - 오일유량 및 상태
//	private	String	i_sParts_20_002002004;					//	주요장치 - 변속기 : 수동변속기(M/T) - 작동상태(공회전)
//	private	String	i_sParts_21_003001;					//	주요장치 - 동력전달 : 클러치 어셈블리
//	private	String	i_sParts_22_003002;					//	주요장치 - 동력전달 : 등속죠인트
//	private	String	i_sParts_23_003003;					//	주요장치 - 동력전달 : 추진축 및 베어링
//	private	String	i_sParts_24_004001;					//	주요장치 - 조향 : 동력조향작동 오일누유
//	private	String	i_sParts_25_004002001;					//	주요장치 - 조향 : 작동상태 - 스티어링기어
//	private	String	i_sParts_26_004002002;					//	주요장치 - 조향 : 작동상태 - 스티어링펌프
//	private	String	i_sParts_27_004002003;					//	주요장치 - 조향 : 작동상태 - 타이로드엔드 및 볼 죠인트
//	private	String	i_sParts_28_005001;					//	주요장치 - 제동 : 브레이크오일 유량상태
//	private	String	i_sParts_29_005002;					//	주요장치 - 제동 : 브레이크오일누유
//	private	String	i_sParts_30_005003;					//	주요장치 - 제동 : 배력장치상태
//	private	String	i_sParts_31_006001;					//	주요장치 - 전기 : 발전기출력
//	private	String	i_sParts_32_006002;					//	주요장치 - 전기 : 와이퍼모터기능
//	private	String	i_sParts_33_006003;					//	주요장치 - 전기 : 실내송품모터
//	private	String	i_sParts_34_006004;					//	주요장치 - 전기 : 라디에이터 팬 모터
//	private	String	i_sParts_35_007001;					//	주요장치 - 기타 : 연료누출(LP가스포함)
//	private	String	i_sParts_36_007002;					//	주요장치 - 기타 : 윈도우 모터 작동
//	private	String	i_sDtl1_002;						//	외관 - A 후드 : 교환(교체)
//	private	String	i_sDtl2_002;						//	외관 - A 후드 : 판금(용접)
//	private	String	i_sDtl1_003;						//	외관 - B 운전석 프론트휀더 : 교환(교체)
//	private	String	i_sDtl2_003;						//	외관 - B 운전석 프론트휀더 : 판금(용접)
//	private	String	i_sDtl1_004;						//	외관 - C 조수석 프론트휀더 : 교환(교체)
//	private	String	i_sDtl2_004;						//	외관 - C 조수석 프론트휀더 : 판금(용접)
//	private	String	i_sDtl1_005;						//	외관 - D 운전석 프론트도어 : 교환(교체)
//	private	String	i_sDtl2_005;						//	외관 - D 운전석 프론트도어 : 판금(용접)
//	private	String	i_sDtl1_006;						//	외관 - E 운전석 리어도어 : 교환(교체)
//	private	String	i_sDtl2_006;						//	외관 - E 운전석 리어도어 : 판금(용접)
//	private	String	i_sDtl1_007;						//	외관 - F 조수석 프론트도어 : 교환(교체)
//	private	String	i_sDtl2_007;						//	외관 - F 조수석 프론트도어 : 판금(용접)
//	private	String	i_sDtl1_008;						//	외관 - G 조수석 리어도어 : 교환(교체)
//	private	String	i_sDtl2_008;						//	외관 - G 조수석 리어도어 : 판금(용접)
//	private	String	i_sDtl1_009;						//	외관 - H 트렁크리드 : 교환(교체)
//	private	String	i_sDtl2_009;						//	외관 - H 트렁크리드 : 판금(용접)
//	private	String	i_sDtl1_011;						//	주요골격 - A 프론트패널 : 교환(교체)
//	private	String	i_sDtl2_011;						//	주요골격 - A 프론트패널 : 판금(용접)
//	private	String	i_sDtl1_012;						//	주요골격 - B 운전석 인사이드패널 : 교환(교체)
//	private	String	i_sDtl2_012;						//	주요골격 - B 운전석 인사이드패널 : 판금(용접)
//	private	String	i_sDtl1_013;						//	주요골격 - C 조수석 인사이드패널 : 교환(교체)
//	private	String	i_sDtl2_013;						//	주요골격 - C 조수석 인사이드패널 : 판금(용접)
//	private	String	i_sDtl1_014;						//	주요골격 - D 운전석 프론트 휠하우스 : 교환(교체)
//	private	String	i_sDtl2_014;						//	주요골격 - D 운전석 프론트 휠하우스 : 판금(용접)
//	private	String	i_sDtl1_015;						//	주요골격 - E 조수석 프론트 휠하우스 : 교환(교체)
//	private	String	i_sDtl2_015;						//	주요골격 - E 조수석 프론트 휠하우스 : 판금(용접)
//	private	String	i_sDtl1_016;						//	주요골격 - F 프론트 그로스멤버 : 교환(교체)
//	private	String	i_sDtl2_016;						//	주요골격 - F 프론트 그로스멤버 : 판금(용접)
//	private	String	i_sDtl1_017;						//	주요골격 - G 프론트 대쉬패널 : 교환(교체)
//	private	String	i_sDtl2_017;						//	주요골격 - G 프론트 대쉬패널 : 판금(용접)
//	private	String	i_sDtl1_018;						//	주요골격 - H 루프패널(지붕) : 교환(교체)
//	private	String	i_sDtl2_018;						//	주요골격 - H 루프패널(지붕) : 판금(용접)
//	private	String	i_sDtl1_019;						//	주요골격 - I 플러어패널(바닥) : 교환(교체)
//	private	String	i_sDtl2_019;						//	주요골격 - I 플러어패널(바닥) : 판금(용접)
//	private	String	i_sDtl1_020;						//	주요골격 - J 리어 대쉬패널 : 교환(교체)
//	private	String	i_sDtl2_020;						//	주요골격 - J 리어 대쉬패널 : 판금(용접)
//	private	String	i_sDtl1_021;						//	주요골격 - K 운전석 리어 휠하우스 : 교환(교체)
//	private	String	i_sDtl2_021;						//	주요골격 - K 운전석 리어 휠하우스 : 판금(용접)
//	private	String	i_sDtl1_022;						//	주요골격 - L 조수석 리어 휠하우스 : 교환(교체)
//	private	String	i_sDtl2_022;						//	주요골격 - L 조수석 리어 휠하우스 : 판금(용접)
//	private	String	i_sDtl1_023;						//	주요골격 - M 트렁크플로어 : 교환(교체)
//	private	String	i_sDtl2_023;						//	주요골격 - M 트렁크플로어 : 판금(용접)
//	private	String	i_sDtl1_024;						//	주요골격 - N 리어앤드패널 : 교환(교체)
//	private	String	i_sDtl2_024;						//	주요골격 - N 리어앤드패널 : 판금(용접)
//	private	String	i_sDtl1_025;						//	주요골격 - O 운전석 쿼터패널 : 교환(교체)
//	private	String	i_sDtl2_025;						//	주요골격 - O 운전석 쿼터패널 : 판금(용접)
//	private	String	i_sDtl1_026;						//	주요골격 - P 조수석 쿼터패널 : 교환(교체)
//	private	String	i_sDtl2_026;						//	주요골격 - P 조수석 쿼터패널 : 판금(용접)
//	private	String	i_sDtl1_027;						//	주요골격 - Q 운전석 사이드실패널 : 교환(교체)
//	private	String	i_sDtl2_027;						//	주요골격 - Q 운전석 사이드실패널 : 판금(용접)
//	private	String	i_sDtl1_028;						//	주요골격 - R 조수석 사이드실패널 : 교환(교체)
//	private	String	i_sDtl2_028;						//	주요골격 - R 조수석 사이드실패널 : 판금(용접)
//	private	String	i_sDtl1_029;						//	주요골격 - S 운전석 A 필러패널 : 교환(교체)
//	private	String	i_sDtl2_029;						//	주요골격 - S 운전석 A 필러패널 : 판금(용접)
//	private	String	i_sDtl1_030;						//	주요골격 - T 운전석 B 필러패널 : 교환(교체)
//	private	String	i_sDtl2_030;						//	주요골격 - T 운전석 B 필러패널 : 판금(용접)
//	private	String	i_sDtl1_031;						//	주요골격 - U 운전석 C 필러패널 : 교환(교체)
//	private	String	i_sDtl2_031;						//	주요골격 - U 운전석 C 필러패널 : 판금(용접)
//	private	String	i_sDtl1_032;						//	주요골격 - V 조수석 A 필러패널 : 교환(교체)
//	private	String	i_sDtl2_032;						//	주요골격 - V 조수석 A 필러패널 : 판금(용접)
//	private	String	i_sDtl1_033;						//	주요골격 - W 조수석 B 필러패널 : 교환(교체)
//	private	String	i_sDtl2_033;						//	주요골격 - W 조수석 B 필러패널 : 판금(용접)
//	private	String	i_sDtl1_034;						//	주요골격 - X 조수석 C 필러패널 : 교환(교체)
//	private	String	i_sDtl2_034;						//	주요골격 - X 조수석 C 필러패널 : 판금(용접)
//	private	String	i_sDtl1_035;						//	주요골격 - Y 리어 사이드멤버 : 교환(교체)
//	private	String	i_sDtl2_035;						//	주요골격 - Y 리어 사이드멤버 : 판금(용접)
//	private	String	i_sDtl1_036;						//	주요골격 - Z 프론트 사이드멤버 : 교환(교체)
//	private	String	i_sDtl2_036;						//	주요골격 - Z 프론트 사이드멤버 : 판금(용접)
//	private	String	i_sDtl1_037;						//	주요골격 - Z1 라디에이터 서포트(볼트체결부품) : 교환(교체)
//	private	String	i_sDtl2_037;						//	주요골격 - Z1 라디에이터 서포트(볼트체결부품) : 판금(용접)
//	private	String	i_sChk1_001;						//	외판부위의 판금, 용접수리 및 교환 - 후드
//	private	String	i_sChk1_002;						//	외판부위의 판금, 용접수리 및 교환 - 프론트휀더
//	private	String	i_sChk1_003;						//	외판부위의 판금, 용접수리 및 교환 - 도어
//	private	String	i_sChk1_004;						//	외판부위의 판금, 용접수리 및 교환 - 트렁크리드
//	private	String	i_sChk1_005;						//	외판부위의 판금, 용접수리 및 교환 - 사이드실 패널
//	private	String	i_sChk1_006;						//	외판부위의 판금, 용접수리 및 교환 - 루푸패널
//	private	String	i_sChk1_007;						//	외판부위의 판금, 용접수리 및 교환 - 쿼터패널
//	private	String	i_sChk1_008;						//	외판부위의 판금, 용접수리 및 교환 - 라디에이터 서포트(볼트체결부품)
//	private	String	i_sChk2_001;						//	주요골격부위의 판금, 용접수리 및 교환 - 프론트패널
//	private	String	i_sChk2_002;						//	주요골격부위의 판금, 용접수리 및 교환 - 크로스 멤버
//	private	String	i_sChk2_003;						//	주요골격부위의 판금, 용접수리 및 교환 - 인사이드패널
//	private	String	i_sChk2_004;						//	주요골격부위의 판금, 용접수리 및 교환 - 사이드멤버
//	private	String	i_sChk2_005;						//	주요골격부위의 판금, 용접수리 및 교환 - 휠하우스
//	private	String	i_sChk2_006;						//	주요골격부위의 판금, 용접수리 및 교환 - 대쉬패널
//	private	String	i_sChk2_007;						//	주요골격부위의 판금, 용접수리 및 교환 - 루프패널
//	private	String	i_sChk2_008;						//	주요골격부위의 판금, 용접수리 및 교환 - 필러패널
//	private	String	i_sChk2_009;						//	주요골격부위의 판금, 용접수리 및 교환 - 쿼터패널
//	private	String	i_sChk2_010;						//	주요골격부위의 판금, 용접수리 및 교환 - 사이드실패널
//	private	String	i_sChk2_011;						//	주요골격부위의 판금, 용접수리 및 교환 - 플로어패널
//	private	String	i_sChk2_012;						//	주요골격부위의 판금, 용접수리 및 교환 - 트렁크플로어
//	private	String	i_sChk2_013;						//	주요골격부위의 판금, 용접수리 및 교환 - 리어패널
//	private	String	i_sComments;						//	특기사항 및 점검자의 의견
//	private	String	i_sIssuedt;							//	성능점검 날짜
//	private	String	i_sInspNm;							//	중고자동차 성능 상태 점검자
//	private	String	i_sNoticeNm;						//	중고자동차 성능 상태 고지자
//	private	String	i_sPageType;						//	PageType(insert/update)
//	private String	i_sSubNmEng;
//	private String	i_sReturnParam;
//	private String	i_sSettleKind;
//	private String	i_sReqContent;
//	private String	i_sRecoState;
//	private String[]	i_arrRecoState;
//	private String	i_sRecoState2;
//	private int		i_iReqPrc;
//	private String	i_sSaveFlag;
//	private String  i_sNextDay;
//	private String  i_sGroup;
//	private String  i_sRecoStateNm;
//	private String  i_sDivCnt;
//
//	//장기재고 차량
//	private String	i_sDiscountCd;
//	private String	i_sStepCd;
//	private String	i_sCaldateDtm;
//	private String	i_sArrDiscountCd;
//	private String	i_sStartDtTmp;
//	private String	i_sEndDtTmp;
//	private String	i_sSearchStatus;
//
//	// LIG ew
//	private String	i_sWarrantyNb;
//	private String	i_sAcceptCd;
//	private String	i_sProgressContent;
//	private String	i_sHeadType;
//	private String	i_sDetailType;
//	private String	i_sReward;
//	private String	i_sFlagSms;
//	private String	i_sFlagFinish;
//	private String	i_sDetailEtc;

//	private String	i_sCarCd2; // TODO 이강욱 CAR_ID로 대체 가능한 것으로 판단
//	private	String	i_rgsid2;
//	private	String	i_sMstCd2;
//	private	String	i_sBuffer2;
//	private	String	i_sSubNmEng2;
//	private	String	mjrcd2;
//	private	String	i_sSiteType;
//	private	String	i_sPastState;
//	private	String  i_sEventStatus;
//	private	String  i_sMobile1;
//	private	String  i_sMobile2;
//	private	String  i_sMobile3;
//	private	String  i_sSaleCd;
//	private	String  i_sCoupon;
//
//	private	String	i_sNewYn;
//	private	String	i_sSupGrpCd;
//
//	//mobile lease data flag
//	private	String  i_sMobileLease;
//
//	// 간편검색/상세검색 구분
//	private	String i_sTabFlag;
//	private	String carcds = "";
//
//	// K Car직영리스 페이지 여부
//	private String encarLeasePageYn;
//
//	// 모바일검색 조건
//	private String i_sMobileKeyWord;
//
//	//start weeklist value
//	private String i_sWeekListMin;
//
//	//홈서비스 상담방법
//	private String i_sCounselCd;
//	private String i_sPrivacyCd;
//
//	// cdn 서비스
//	private String i_sIfImgUrl;
//
//	//검색 조건 pass 여부 (차량상세정보)
//	private	String i_sPassYn;
//
//	//성능상태점검기록부 신규버전 페이지 사용변수
//	private String i_sInspScreenGb;
//
//	//리스승계 관련
//	private String i_sAdDtm;
//	private String i_sLeaseCompany;
//	private String i_sAdDtmTmp;
//	private String i_sFstConPer;
//	private String i_sRemanPer;
//	private int i_iMonthPrice;
//	private int i_iMonthPrice1;
//	private int i_iMonthPrice2;
//	private String i_sResidual;
//	private int i_iSupportFund;
//	private int i_iFstBuyPrice;
//	private String i_sMakerWarranty;
//	private String i_sNowUser;
//	private int i_iLeasePer1;
//	private int i_iLeasePer2;
//	private String i_sComment;
//	private String i_sBeginMonth;
//	private String i_sSellerPost;
//	private String i_sSellerAddr1;
//	private String i_sSellerAddr2;
//	private String i_sBuyerName;
//	private String i_sBuyerPost;
//	private String i_sBuyerAddr1;
//	private String i_sBuyerAddr2;
//	private String i_sBuyerPhone;
//	private String i_sSearchBuyerName;
//	private String i_sSearchBuyerPhone;
//	private int i_iCashPrice;
//	private String i_sLeaseStartDtmTmp;
//	private String i_sLeaseStartDtm;
//	private String i_sCounselContents;
//	private String[] i_sArrCounselContents;
//	private String i_sLeaseSuccStatus;
//	private String i_sCallNumber;
//	private String i_sEtc;
//	private String i_sCarLocBranch;
//	//if 키
//	private String i_sIfKey;
//	private String i_sIfStatus;
//	private String i_sIfTable;
//	private String i_sProcStatus;
//	private String i_sErrMsg;
//	private String i_sSellFg;
//
//	private String i_s3dViewFlag;
//	private String wr_eq_v_3dview_flag;
//
//
//	private String[] i_arrMonthPrice;
//
//	//최근본차량 정렬
//	private String i_sMyParkingCar;
//
//	//비교하기차량 정렬
//	private String i_sMyComparingCar;
//
//	private String i_sReffer;
//
//	//ew지원차량
//	private String i_sEwSupport;
//	private String[] i_arrEwPrice;
//
//	private String[]	i_arrMakeType; // 국산/수입구분
//
//	private String i_sModelGrpCd; // 모델그룹
//
//	private String i_sOptionFlag; // 검색시 옵션창 펼침/닫기 구분
//	private String i_sOptionNmFlag; // 옵션목록 가로나열(OPTION_HORIZONTAL) 구분
//
//	/* 차량 랜덤정렬 */
//	private String i_sOrderByRandomFlag; // 차량 랜덤정렬 구분
//	private String i_sOrderByRandomStartNum; // 정렬 우선 숫자
//	private String i_sOrderByRandomAscFlag; // 오름차순/내림차순
//	private String[] i_arrMyParkingCar; // 최근본차량 목록
//
//	private String i_sCenterSort;
//
//	private String[]	i_arrCenterRegion;
//	private String[]	i_arrCenterCode;
//
//	private int		i_iMaxCnt;
//
//	private String datakey;
//
//	private String[] i_arrRecComment; // 사고유무 코드 배열
//	private String[] i_arrPassCnt; // 승차 인원 배열
//	private int   	 i_iStartPassCnt; // 승차 시작인원
//	private int    	 i_iEndPassCnt; // 승차 종료인원
//	private String   i_sStartMfrDate;  // 주행연식 시작
//	private String   i_sEndMfrDate;    // 주행연식 종료
//	private int      i_iStartMileage; // 주행거리 시작
//	private int      i_iEndMileage;   // 주행거리 종료
//	private int      i_iStartPrice;   // 자동차 시작가격
//	private int      i_iEndPrice;     // 자동차 종료가격
//	private int      i_iStartMonthPrice;   // 자동차 할부 시작가격
//	private int      i_iEndMonthPrice;     // 자동차 할부 종료가격
//	private String   i_sOrder;		  //  기본정렬
//	private String[] i_arrSearchCategoryCd; // 카테고리 검색 조건
//	private String   i_sSearchMakeType; // 국산차/수입차 검색 조건
//	private String   i_sSearchMakeCd; // 제조사 검색 조건
//	private String   i_sSearchModelGrpCd; // 모델그룹 검색 조건
//	private String   i_sSearchModelCd; // 모델 상세 검색 조건
//	private String[] i_arrModelGrpCd; // 모델 그룹 배열
//
//	private String   i_sSearchMfrDateFrom; // 주행연식 시작 검색
//	private String   i_sSearchMfrDateTo;   // 주행연식 종료 검색
//	private int      i_iSearchMileageFrom; // 마일리지 시작 검색
//    private int      i_iSearchMileageTo;   // 마일리지 종료 검색
//    private int      i_iSearchPriceFrom;   // 가격 시작 검색
//    private int      i_iSearchPriceTo;     // 가격 종료 검색
//    private String[] i_arrSearchOptionCd;  // 옵션 코드 배열
//	private String   i_sFromYear;
//	private String   i_sToYear;
//
//	//2020.01.07 : 10분마다 납부관리 배치 검사 - 상태 변경
	private String i_sReq_seq_no;
//	private String i_sReq_sts_cd;
//    private String i_sReq_sts_cd_web;
//	private String i_sPymt_type_cd;
//
//    private String i_sLeaseType; // 리스 차량 유무
//    private String i_sRentStatus; // 렌트 차량 유무
//
//    private String i_sCancelFlag; // 취소신청사유코드
//    private String i_sCancelDttm; // 취소완료일시
//
//    private String iframeYn; // 아이프레임여부
//
//    private String[] i_arrHotMarkCd; //핫마크 배열
//
//    private String i_sStockFlag; // 구글동적리마케팅 재고여부
//    private String i_sErrCode;
//    private String i_sReqBody;
//    private String i_sResBody;
}
