package kr.co.daiso.fo.auth.oauth;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * packageName    : kr.co.daiso.fo.auth.oauth
 * fileName       : OAuthToken
 * author         : Doo-Won Lee
 * date           : 2021-11-24
 * description    : OAuthToken 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-24      Doo-Won Lee        최초생성
 */
@Data
public class OAuthToken {
    private String token;
    private String refreshToken;
    private LocalDateTime expiredAt;
    private String oAuthType;

    public OAuthToken() {
    }

    public OAuthToken(String oAuthType,String token, String refreshToken, LocalDateTime expiredAt) {
        this.oAuthType = oAuthType;
        this.token = token;
        this.refreshToken = refreshToken;
        this.expiredAt = expiredAt;
    }
}
