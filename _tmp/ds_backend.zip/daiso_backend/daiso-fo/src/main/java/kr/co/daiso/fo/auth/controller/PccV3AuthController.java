package kr.co.daiso.fo.auth.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.StringUtil;
import kr.co.daiso.fo.auth.service.PccV3AuthService;
import kr.co.daiso.fo.common.model.CommonPathInfo;
import kr.co.daiso.fo.common.util.RedisUtil;
import kr.co.daiso.fo.mb.model.AccountInfo;
import kr.co.daiso.fo.mb.service.MemberService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.fo.auth.controller
 * fileName       : PccV3AuthController
 * author         : kjm
 * date           : 2022-01-27
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-27       kjm            최초생성
 */

@Slf4j
@RestController
@RequestMapping("/auth/pccV3")
public class PccV3AuthController {

    @Autowired
    private PccV3AuthService pccV3AuthService;

    @Autowired
    private MemberService memberService;

    @Autowired
    private RedisUtil redisUtil;

    @PostMapping("/popup")
    public ResponseEntity pccV3_auth(HttpServletRequest request, @RequestBody Map<String, Object> paramMap) {

        String returnUrl = (String) paramMap.get("returnUrl");

        Device device = DeviceUtils.getCurrentDevice(request);

        String id = "SNKR001";                                // 본인실명확인 회원사 아이디
        String srvNo = "";
        String reqNum = getKey();         // 암호화 키 생성  본인실명확인 요청번호
        String exVar = "0000000000000000";                        // 복호화용 임시필드
        String retUrl = null;

        SecureRandom secureRandom = new SecureRandom();
        int redisKey = secureRandom.nextInt(1000000000);

        redisUtil.setDataExpire("fo:auth:pccReqNum:" + redisKey, reqNum, 1000L * 60 * 20);

        Map<String, Object> resultMap = new HashMap<>();
        if (device.isMobile() || StringUtil.defaultString(paramMap.get("device")).equals("mobile")) {
            log.info("MOBILE ::::::");
            srvNo = CommonPathInfo.PCC_MOBILE_SERVICE_NO;

//            if(returnUrl.indexOf("?") != -1) {
//                retUrl = "31" + CommonPathInfo.MOBILE_FULL_SSL2 + returnUrl + "&redisKey=" + redisKey + "&type=pccv3";       // 본인실명확인 결과수신 URL
//            }
//            else {
//                retUrl = "31" + CommonPathInfo.MOBILE_FULL_SSL2 + returnUrl + "?redisKey=" + redisKey + "&type=pccv3";
//            }
            if(request.getHeader("user-agent").contains("daisoIosApp") || request.getHeader("user-agent").contains("daisoAndroid")) {
                retUrl = "32" + CommonPathInfo.MOBILE_FULL_SSL2 + "mb/pccv3/pccv3-result" + "?returnUrl=" + returnUrl + "&redisKey=" + redisKey + "&type=pccv3";       // 본인실명확인 결과수신 URL
            } else {
                if(returnUrl.indexOf("?") != -1) {
                    retUrl = "31" + CommonPathInfo.MOBILE_FULL_SSL2 + returnUrl + "&redisKey=" + redisKey + "&type=pccv3";       // 본인실명확인 결과수신 URL
                }
                else {
                    retUrl = "31" + CommonPathInfo.MOBILE_FULL_SSL2  + returnUrl + "?redisKey=" + redisKey + "&type=pccv3";       // 본인실명확인 결과수신 URL
                }
            }
            resultMap.put("device", "mobile");
        } else {
            log.info("PC ::::::");
            srvNo = CommonPathInfo.PCC_SERVICE_NO;
            if(returnUrl.indexOf("?") != -1) {
                retUrl = "31" + CommonPathInfo.ROOT_FULL_SSL2 + returnUrl + "&redisKey=" + redisKey + "&type=pccv3";       // 본인실명확인 결과수신 URL
            } else {
                retUrl = "31" + CommonPathInfo.ROOT_FULL_SSL2 + returnUrl + "?redisKey=" + redisKey + "&type=pccv3";
            }
            resultMap.put("device", "pc");
        }

        Calendar today = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String day = sdf.format(today.getTime());
        String certDate = day;                                            // 본인실명확인 요청시간
        String certGb = "H";                                            // 본인실명확인 본인확인 인증수단
        String addVar = "";
        String reqInfo = id + "^" + srvNo + "^" + reqNum + "^" + certDate + "^" + certGb + "^" + addVar + "^" + exVar;  // 데이터 암호화
        reqInfo = pccV3AuthService.PccV3Encode(reqNum, reqInfo);

        resultMap.put("reqInfo", reqInfo);
        resultMap.put("retUrl", retUrl);

        return ResponseEntity.ok().body(resultMap);
    }

    @RequestMapping("/result")
    public ResponseEntity pccV3_result(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramMap) {

        String redisKey = (String) paramMap.get("redisKey");
        String reqNum = redisUtil.getData("fo:auth:pccReqNum:" + redisKey);
//        redisUtil.deleteData("fo:auth:pccReqNum:" + redisKey);
        String retInfo = (String) paramMap.get("retInfo");

        CommonResponseModel resultModel = new CommonResponseModel();
        Map<String, Object> resultMap = new HashMap<>();
        AccountInfo resultAccountInfo = new AccountInfo();

        if (reqNum == null) {
            log.info("reqNum not find...."); // "인증과정 중 오류가 발생하였습니다. 다시 시도하여 주세요."
            return ResponseEntity.badRequest().build();
        }

        try {
            String[] memberInfo = (String[]) pccV3AuthService.PccV3Decode(reqNum, retInfo);
            if (memberInfo == null) {
                log.info("정상적인 접근이 아닙니다.");
                return ResponseEntity.badRequest().build();
            }

            String names = memberInfo[0];
            String name = URLDecoder.decode(names, CommonPathInfo.CHARSET);
            resultMap.put("name", name);
            resultMap.put("birYMD", memberInfo[1]);     // 생년월일(YYYYMMDD)
            resultMap.put("sex", memberInfo[2]);        // 성별 ( M : 남 , F : 여)
            resultMap.put("fgnGbn", memberInfo[3]);     // 내외국인 구분(1 : 내국인, 2 : 외국인)
            resultMap.put("di", memberInfo[4]);         // 중복가입정보
            resultMap.put("ci1", memberInfo[5]);        // 연계정보 1
            resultMap.put("ci2", memberInfo[6]);        // 연계정보 2
            resultMap.put("civersion", memberInfo[7]);  // 연계정보버전
            resultMap.put("reqNum", memberInfo[8]);     // 요청번호
            resultMap.put("result", memberInfo[9]);     // 인증성공여부( Y : 성공, N : 실패,  F : 3회 오류)
            resultMap.put("certGb", memberInfo[10]);    // 인증수단( H : 휴대폰)
            resultMap.put("cellNo", memberInfo[11]);    // 핸드폰번호
            resultMap.put("cellCorp", memberInfo[12]);  // 이동통신사
            resultMap.put("certDate", memberInfo[13]);  // 요청시간
            resultMap.put("moveUrl", memberInfo[14]);   // 이동할 페이지 정보(retUrl)

//            resultMap.put("authInfo", request.getParameter("retInfo").trim());

            if(!StringUtils.hasText((String)resultMap.get("di"))) {
                resultModel.setSuccess(false);
                resultModel.setMessage("003");
                return ResponseEntity.ok().body(resultModel);
            }

            Device device = DeviceUtils.getCurrentDevice(request);
            if (device != null && device.isNormal()) {
                resultMap.put("moveReturnUrl", "/user/user_myCheck.do");
            } else {
                resultMap.put("moveReturnUrl", "/mobile/user/user_myCheck.do");
            }

            AccountInfo searchAccountInfo = new AccountInfo();
            searchAccountInfo.setOvlapKey((String) resultMap.get("di"));
            resultAccountInfo = memberService.getMemberByOverlapKey(searchAccountInfo);


            if (resultAccountInfo == null) {     // 오버랩키로 조회한 회원정보가 없을경우
                if(manAge(memberInfo[1]) >= 14) {
                    resultModel.setMessage("001");  // 회원정보가 테이블에 없는경우
                } else {
                    resultModel.setMessage("002");  // 회원정보가 테이블에 없고 만14세 미만
                    memberService.insertMemberNonAge();
                }
                resultModel.setData(resultMap);
                resultModel.setSuccess(false);
            } else {  // 오버랩키로 조회한 회원정보가 있을경우
                resultModel.setData(resultAccountInfo);
                resultModel.setSuccess(true);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
//        return ResponseEntity.ok().body(resultMap);
        return ResponseEntity.ok().body(resultModel);
    }

    // 비회원 휴대폰 인증용
    @RequestMapping("/guest")
    public ResponseEntity pccV3_guest(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> paramMap) {

        String redisKey = (String) paramMap.get("redisKey");
        String reqNum = redisUtil.getData("fo:auth:pccReqNum:" + redisKey);
        String retInfo = (String) paramMap.get("retInfo");

        CommonResponseModel resultModel = new CommonResponseModel();
        Map<String, Object> resultMap = new HashMap<>();

        if (reqNum == null) {
            log.info("reqNum not find...."); // "인증과정 중 오류가 발생하였습니다. 다시 시도하여 주세요."
            return ResponseEntity.badRequest().build();
        }

        try {
            String[] memberInfo = (String[]) pccV3AuthService.PccV3Decode(reqNum, retInfo);
            if (memberInfo == null) {
                log.info("정상적인 접근이 아닙니다.");
                return ResponseEntity.badRequest().build();
            }

            String names = memberInfo[0];
            String name = URLDecoder.decode(names, CommonPathInfo.CHARSET);
            resultMap.put("name", name);
            resultMap.put("birYMD", memberInfo[1]);     // 생년월일(YYYYMMDD)
            resultMap.put("sex", memberInfo[2]);        // 성별 ( M : 남 , F : 여)
            resultMap.put("fgnGbn", memberInfo[3]);     // 내외국인 구분(1 : 내국인, 2 : 외국인)
            resultMap.put("di", memberInfo[4]);         // 중복가입정보
            resultMap.put("ci1", memberInfo[5]);        // 연계정보 1
            resultMap.put("ci2", memberInfo[6]);        // 연계정보 2
            resultMap.put("civersion", memberInfo[7]);  // 연계정보버전
            resultMap.put("reqNum", memberInfo[8]);     // 요청번호
            resultMap.put("result", memberInfo[9]);     // 인증성공여부( Y : 성공, N : 실패,  F : 3회 오류)
            resultMap.put("certGb", memberInfo[10]);    // 인증수단( H : 휴대폰)
            resultMap.put("cellNo", memberInfo[11]);    // 핸드폰번호
            resultMap.put("cellCorp", memberInfo[12]);  // 이동통신사
            resultMap.put("certDate", memberInfo[13]);  // 요청시간
            resultMap.put("moveUrl", memberInfo[14]);   // 이동할 페이지 정보(retUrl)
            resultMap.put("guestId", getGuestId(memberInfo[11], memberInfo[1]));

            resultModel.setData(resultMap);
//            resultMap.put("authInfo", request.getParameter("retInfo").trim());

            // 인증 정보가 없는 경우
            if(!StringUtils.hasText((String)resultMap.get("di"))) {
                resultModel.setSuccess(false);
                return ResponseEntity.ok().body(resultModel);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok().body(resultModel);
    }

    private String getGuestId(String phoneNo, String birYmd) throws Exception {
        String keyStr = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder id = new StringBuilder("@");
        String phoneNo1 = phoneNo.substring(0, 3);
        if(phoneNo1.equals("010")) {
            id.append('z');
        }

        int keyIndex = 0;
        for(int i = 3; i < phoneNo.length(); i++) {
            int num = Integer.parseInt(phoneNo.charAt(i) + "");
            keyIndex = (keyIndex + num) % 26;
            id.append(keyStr.charAt(keyIndex));
        }

        for(int i = 2; i < birYmd.length(); i++) {
            int num = Integer.parseInt(birYmd.charAt(i) + "");
            keyIndex = (keyIndex + num) % 26;
            id.append(keyStr.charAt(keyIndex));
        }

        return id.toString();
    }

    public String getKey() {
        //날짜 생성
        Calendar today = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String day = sdf.format(today.getTime());
        return pccV3AuthService.PccV3CreateKey(day);
    }

    private int manAge(String birYMD) {
        LocalDate now = LocalDate.now();
        LocalDate birthDate = LocalDate.parse(birYMD, DateTimeFormatter.ofPattern("yyyyMMdd"));
        int manAge = now.minusYears(birthDate.getYear()).getYear();
        if (birthDate.plusYears(manAge).isAfter(now)) {
            manAge = manAge -1;
        }
        return manAge;
    }
}
