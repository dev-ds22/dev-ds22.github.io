package kr.co.daiso.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaisoCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
