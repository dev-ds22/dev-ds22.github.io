package kr.co.daiso.common.model;

import lombok.Data;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : CommonResponseModel
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    : Api 연동시 기초 모델
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26     Doo-Won Lee         최초생성
 */
@Data
@ToString
public class CommonResponseModel<T>  { //implements Serializable

    private boolean isSuccess;
    private String message;

    private T data;

    private Map<String, Object> extraData;
    private String extraString;
    private String returnCode;

    public CommonResponseModel() {
        this.isSuccess = true;
        this.message = null;
        this.data = null;
        this.extraData = new HashMap<>();
    }

    public CommonResponseModel(T data) {
        this.data = data;
        this.isSuccess = true;
        this.message = null;
        this.extraData = new HashMap<>();
    }

    public CommonResponseModel(String msg) {
        this.isSuccess = true;
        this.message = msg;
        this.data = null;
        this.extraData = new HashMap<>();
    }


    public void put(String key, Object value) {
        extraData.put(key, value);
    }

    public Object get(String key) {
        return extraData.get(key);
    }
}