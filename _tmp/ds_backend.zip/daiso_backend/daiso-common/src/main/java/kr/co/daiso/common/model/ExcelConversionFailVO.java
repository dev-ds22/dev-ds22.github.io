package kr.co.daiso.common.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : ExcelConversionFailVO
 * author         : Doo-Won Lee
 * date           : 2022-01-21
 * description    : Excel 내용을 VO로 변환시 실패 목록 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-21     Doo-Won Lee        최초생성
 */
@Data
public class ExcelConversionFailVO {
    private int rowIdx;             //변환 실패한 rowIndex
    private String exceptionMsg;    //변환 실패 Exception Msg
}
