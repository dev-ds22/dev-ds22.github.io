package kr.co.daiso.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : CommonPagingVo
 * author         : leechangjoo
 * date           : 2021-11-09
 * description    : 공통 페이징 Vo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-09          leechangjoo         최초생성
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonPagingVo extends BaseModel implements Serializable {

    private static final long serialVersionUID = 3826650157441723066L;

    // [s] paging
    private int			i_iGroupSize;
    private int			i_iTotalPageCnt;
    private int			i_iRecordCnt;
    private int			i_iPageSize;
    private int			i_iNowPageNo;   // 현재페이지 번호
    private int			i_iSkipCnt;
    private	String		i_sSortCol;     // sort col
    private	String		i_sSortDir;     // sort dir
    private int			i_iNowPageNo2;
    private int			i_iStartRownum;
    private int			i_iEndRownum;

    private	String	i_sUserCd;
    // [e] paging

    private int total;              // 전체 수
    private int currentPage =1;        // 현재 페이지 번호
    private int pageSize = 15;      // 한페이지에 보여줄 개수
    private int pagerCount = 11;    // 한번에 보여줄 페이지버튼 개수
    private int firstIndex;         // 리스트 첫번째 인덱스
    private int lastIndex;          // 리스트 마지막 인덱스

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
        if(this.currentPage != 0) {
            this.firstIndex = this.pageSize * (this.currentPage-1) + 1;
            this.lastIndex = this.pageSize * this.currentPage;
        }
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = (currentPage > 0) ? currentPage : 1;
    }

    public int getFirstIndex(){
        if(this.currentPage != 0) {
            if(this.firstIndex != 0) {
                return this.firstIndex;
            }
            this.firstIndex = this.pageSize * (this.currentPage-1) + 1;
            return this.firstIndex;
        }
        return 1;
    }

    public int getLastIndex(){
        if(this.currentPage != 0) {
            if(this.lastIndex != 0) {
                return this.lastIndex;
            }
            this.lastIndex = this.pageSize * this.currentPage;
            return this.lastIndex;
        }
        return 10;
    }
}
