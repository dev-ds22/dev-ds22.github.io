package kr.co.daiso.common.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.StringWriter;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : StringUtil
 * author         : 이강욱
 * date           : 2022-04-08
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-08       이강욱         최초생성
 */
public class StringUtil extends StringUtils {
    public static String LINE_SEPAR = System.getProperty("line.separator");

    private StringUtil() {}

    public static String defaultString(Object obj) {
        return (obj == null) ? "" : obj.toString();
    }

    /**
     * 주어진 두 문자열값이 다른지 여부를 알아낸다.
     *
     * @param str1 첫째 문자열
     * @param str2 둘째 문자열
     * @return 다르면 true, 같으면 false
     */
    public static boolean notEquals(String str1, String str2) {
        return equals(str1, str2) ? false : true;
    }

    /**
     * 유니코드 unescape
     * - AsIs ClsOrderServiceImpl.unescape(String inp) 메소드를 옮겨 놓음
     *
     * @param str
     * @return
     */
    public static String unescapeUnicode(String str) {
        StringBuilder rtnStr = new StringBuilder();
        char [] arrInp = str.toCharArray();
        int i;
        for(i=0;i<arrInp.length;i++) {
            if(arrInp[i] == '%') {
                String hex;
                if(arrInp[i+1] == 'u') {    //유니코드.
                    hex = str.substring(i+2, i+6);
                    i += 5;
                } else {    //ascii
                    hex = str.substring(i+1, i+3);
                    i += 2;
                }
                try{
                    rtnStr.append(new String(Character.toChars(Integer.parseInt(hex, 16))));
                } catch(NumberFormatException e) {
                    rtnStr.append("%");
                    i -= (hex.length()>2 ? 5 : 2);
                }
            } else {
                rtnStr.append(arrInp[i]);
            }
        }
        return rtnStr.toString();
    }

    public static String toString(Object object) {
        return (object == null) ? null : object.toString();
    }


    /**
     * 주어진 객체를 Json 문자열로 변환한다.
     * @param obj 객체
     * @param prettyPrint formatting 유무. true이면 들여쓰기가 적용된 Json 문자열 반환.
     * @return Json 문자열. 변환할 데이터가 없거나 실패시 "{}" 문자열 반환.
     * @throws Exception 변환실패시
     */
    public static String toJson(Object obj, boolean prettyPrint) throws Exception {
        StringWriter out = new StringWriter();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonGenerator jsonGenerator = objectMapper.getJsonFactory().createJsonGenerator(out);

            if(prettyPrint) {
                jsonGenerator.useDefaultPrettyPrinter();
            }

            objectMapper.writeValue(jsonGenerator, obj);
            String json = out.toString();
            return (json == null || "null".equals(json)) ? "{}" : json;

        } catch(Exception e) {
            throw e;
        } finally {
            IOUtils .closeQuietly(out);
        }
    }

    /**
     * 주어진 json 문자열을 지정된 클래스의 객체로 변환한다.
     *
     * @param json json 문자열
     * @param clazz 변환될 클래스
     * @return 클래스 객체
     * @throws Exception 변환실패시
     */
    public static <T> T toObject(String json, Class<T> clazz) throws Exception {
        try {
            if(json == null) {
                throw new Exception("Invalid json format. json string is null.");
            }

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return objectMapper.readValue(json, clazz);
        } catch(Exception e) {
            throw e;
        }
    }
}
