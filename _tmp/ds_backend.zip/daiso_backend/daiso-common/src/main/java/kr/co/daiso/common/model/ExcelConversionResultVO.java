package kr.co.daiso.common.model;

import lombok.Data;

import java.util.List;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : ExcelConversionResultVO
 * author         : Doo-Won Lee
 * date           : 2022-01-21
 * description    : Excel을 VO 변환결과 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-21     Doo-Won Lee      최초생성
 */
@Data
public class ExcelConversionResultVO<T> {

    private List<T> successList;
    private List<ExcelConversionFailVO> failList;

}
