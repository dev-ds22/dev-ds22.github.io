package kr.co.daiso.common.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * packageName    : kr.co.daiso.common.exception
 * fileName       : CommonException
 * author         : leechangjoo
 * date           : 2021-11-10
 * description    : 공통 Exception class
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-10          leechangjoo         최초생성
 **/

@Getter
public class CommonException extends RuntimeException{
    private ErrorCode errorCode;
    private HttpStatus status;
    private String message;
    public CommonException(String message, HttpStatus status) {
        super(message);
        this.status = status;
        this.message = message;
    }
    public CommonException(ErrorCode errorCode){
        this.errorCode = errorCode;
    }
}
