package kr.co.daiso.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.mg.util
 * fileName       : SocialApiUtil
 * author         : 82108
 * date           : 2022-02-09
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-09          82108         최초생성
 */
@Slf4j
@Component
public class SocialApiUtil {

    @Value("${oauth.provider.kakao.map_api_url}")
    private String kakaoMapUrl; // = "http://dapi.kakao.com/v2/local/search/address.json";

    @Value("${oauth.client.kakao.client_id}")
    private String kakaoClientId; // = "6f6d2287430e9b93ace3fdf0026031e1";

    public Map<String,String> getKaKaoMapAddrToGeocode(String address) throws Exception {

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("address",address);

        DaisoRestTemplate kCarRestTemplate = new DaisoRestTemplate(kakaoMapUrl+"?analyze_type=exact&page=1&size=10&query=" + address);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization","KakaoAK " + kakaoClientId);
        ResponseEntity entity = kCarRestTemplate.exchage(HttpMethod.GET,null, headers,JSONObject.class);
        JSONObject obj = (JSONObject)entity.getBody();
        log.info(obj.get("documents").toString());
        ArrayList<LinkedHashMap<String,Object>> documentObj = (ArrayList<LinkedHashMap<String, Object>>) obj.get("documents");
        if (documentObj.size()>0){
            resultMap.put("x",documentObj.get(0).get("x").toString());
            resultMap.put("y",documentObj.get(0).get("y").toString());
        }
        else{
            resultMap.put("x", StringUtils.EMPTY);
            resultMap.put("y",StringUtils.EMPTY);
        }

        return resultMap;


//        return getURLResult(kakaoMapUrl+"?analyze_type=exact&page=1&size=10&query=" + address, "KakaoAK " + kakaoClientId, "GET");
//        address = URLEncoder.encode((String)address, "UTF-8");
//        return getExampleHttp(kakaoMapUrl+"?analyze_type=exact&page=1&size=10&query=" + address, "KakaoAK " + kakaoClientId, "GET", "KAKAO");
//        return null;
    }

    public JSONObject getURLResult(String URL, String header) {
        DaisoRestTemplate kCarRestTemplate = new DaisoRestTemplate(URL);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization",header);
        ResponseEntity entity = kCarRestTemplate.exchage(URL, HttpMethod.GET,null, headers,JSONObject.class);
        JSONObject obj = null;
        return obj;
    }

}
