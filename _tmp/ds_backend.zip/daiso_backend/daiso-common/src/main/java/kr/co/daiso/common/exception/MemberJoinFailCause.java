package kr.co.daiso.common.exception;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * packageName    : kr.co.daiso.common.exception
 * fileName       : MemberJoinFailCause
 * author         : kjm
 * date           :
 * description    : 회원가입 실패 원인 Enum Class
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 *      			kjm
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum MemberJoinFailCause {

	NON_INPUT_ID("001", "아이디가 입력되지 않았습니다."),
	
	NON_INPUT_MOBILE("002", "휴대전화번호가 입력되지 않았습니다."),
	
	NON_INPUT_PASSWORD("003", "비밀번호가 입력되지 않았습니다."),
	
	NON_INPUT_EMAIL("004", "이메일 주소가 입력되지 않았습니다."),
	
	INVALILD_ACCESS("005", "잘못된 접근입니다."),
	
	INVALID_PASSWORD_FORMAT("006", "비밀번호 형식이 맞지 않습니다.\\n영문 대/소문자, 숫자, 특수문자(`~!@#$%^*+=-_만 허용)를 조합하여 8~20자로 입력해 주세요."),
	
	ALREADY_JOINED_ID("007", "이미 가입된 아이디 입니다."),
	
	ALREADY_JOINED_MOBILE("008", "이미 가입된 휴대전화번호 입니다."),
	
	INVALID_AUTH_ACCESS("009", "정상적인 접근이 아닙니다."),
	
	LEFT_MEMBER("010", "탈퇴한 회원입니다. 탈퇴 후 1주일동안 재가입이 불가능합니다."),
	
	ALREADY_EXISTS_JOINED_INFO("011", "이미 가입된 정보가 있습니다."),
	
	OTHERS("999", "회원가입 중 오류가 발생하였습니다. 잠시 후 다시 시도 해주세요.");
	
	// 실패 코드
	private String code;
	// 실패 사유
	private String message;
	
	MemberJoinFailCause(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}
	
}
