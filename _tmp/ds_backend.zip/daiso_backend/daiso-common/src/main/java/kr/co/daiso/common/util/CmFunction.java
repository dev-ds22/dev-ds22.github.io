package kr.co.daiso.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.net.ssl.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * packageName    : kr.co.daiso.batch.util
 * fileName       : CmFunction
 * author         :
 * date           :
 * description    : AsIs kr.co.daiso.common.utils.CmFunction 클래스를 옮겨놓음. ToBe에 필요한 소스만 주석해제하여 사용하세요.
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 */
@Slf4j
@Component
public class CmFunction {
    private static String UTF_8 = "UTF-8";
    private static final String RNO_PATTERN = "(.{6}$)";

    private CmFunction() {}

    public static String getPointDate(String i_sSource, String sDelimeter) {
        if (StringUtil.defaultString(i_sSource).length() < "YYYYMMDD".length()) {
            return i_sSource;
        }

        sDelimeter= StringUtil.defaultString(sDelimeter);

        return i_sSource.substring(0, 4)
                + sDelimeter + i_sSource.substring(4, 6)
                + sDelimeter + i_sSource.substring(6, 8);
    }

    // 시분초 [HHMMSS -> HH:MM:SS]
    public static String getPointTime(String i_sSource) {
        if (StringUtil.defaultString(i_sSource).length() < "HHMMSS".length()) {
            return i_sSource;
        }

        return i_sSource.substring(0, 2) + ":" + i_sSource.substring(2, 4) + ":" + i_sSource.substring(4, 6);
    }

    /**
     * @deprecated {@link kr.co.daiso.common.util.StringUtil#defaultString(Object obj)}로 대체됨
     */
    @Deprecated
    public static String getStringValue(Object i_oSource) {
        return StringUtil.defaultString(i_oSource);
    }

    // LPAD, RPAD
    /**
     * @deprecated {@link kr.co.daiso.common.util.StringUtil#leftPad(String, int, char)} 또는 {@link kr.co.daiso.common.util.StringUtil#rightPad(String, int, char)}로 대체됨
     */
    @Deprecated
    public static String getStringPad(String type, String str, int len, char spaceChr) {
        String	sResult		= "";
        int		strLen		= 0;

        if (str == null)	str		= "";

        strLen	= str.length();

        if (strLen < len)
        {
            for (int i = 0; i < len - strLen ; i++)
            {
                sResult	+= spaceChr;
            }

            if ("LPAD".equals(type.toUpperCase()) )
            {
                sResult	+= str;
            }
            else if ("RPAD".equals(type.toUpperCase()) )
            {
                sResult	=  str + sResult;
            }
        }
        else
        {
            sResult		= str;
        }

        return sResult;
    }

    @SuppressWarnings({ "unchecked", "unused" })
    public static Map<String, Object> convertListObjectToMap(Object obj){
        try {
            Class clazz = obj.getClass();
            Field[] fields = clazz.getDeclaredFields();
            Field[] allFields = (Field[]) ArrayUtils.addAll(fields, clazz.getSuperclass().getDeclaredFields());

            Map<String, Object> resultMap = new HashMap<>();
            for(int i=0; i<=allFields.length-1;i++){
                allFields[i].setAccessible(true);
                String filedName = allFields[i].getName();

                Object value = allFields[i].get(obj);

                // 실제로 유효한 형태의 파라미터만 추출토록 한다.
                if (null != value) {
                    if(value instanceof Integer) {
                        if(Integer.parseInt(value.toString()) > 0) {
                            resultMap.put(filedName, value);
                        }
                    }else if(value instanceof String) {
                        if(!value.toString().isEmpty()) {
                            resultMap.put(filedName, value);
                        }
                    }
                }
            }
            return resultMap;
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 랜덤 영문 숫자 조합 ( 영문보다 숫자가 나올 확률이 2배 높다. )
    /*
    public static String getRandomString(int strLength) {

        String 		returnStr	= "";
        String[] 	strArr		= new String[]{"0123456789", "0123456789", "abcdefghijklmnopqrstuvwxyz"};
        int			len			= strArr.length;
        Random random		= new Random();

        for (int i = 0; i < strLength; i++)
        {
            int iRan1 	= random.nextInt(len);
            int iRan2	= random.nextInt(strArr[iRan1].length());

            returnStr	+= strArr[iRan1].substring(iRan2, iRan2+1);
        }

        return returnStr;
    }*/

    /**
     * @deprecated {@link kr.co.daiso.common.util.StringUtil#isNotEmpty(CharSequence)}로 대체됨
     */
    @Deprecated
    public static boolean isNotEmpty (String str) {
        if (str != null && !str.equals(""))
            return true;
        else
            return false;
    }

    /**
     * 오늘날짜 가져오기
     * @deprecated {@link kr.co.daiso.common.util.DateUtil#getNowString(String)}}로 대체됨
     */
    @Deprecated
    public static String getTodayString(String format) {
        return getDateToString(new Date(), format);
    }

    /**
     * Date => String
     * @deprecated {@link kr.co.daiso.common.util.DateUtil#format(Date, String)}}로 대체됨
     */
    @Deprecated
    public static String getDateToString(Date date, String format) {
        SimpleDateFormat sdf;

        if (format == null || format.equals(""))
            format = "yyyyMMdd";

        try {
            sdf = new SimpleDateFormat(format);
        } catch (Exception e) {
            sdf = new SimpleDateFormat("yyyyMMdd");
        }
        return sdf.format(date);
    }
    /**
     * POST URL 연결
     * @param strUrl
     * @param params
     * @return
     * @throws Exception
     */
    public static JSONObject httpPostConnect(RestTemplate restTemplate, String strUrl, Map<String, Object> params) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(new MediaType("application", "json", Charset. forName(UTF_8)));
        HttpEntity<Object> entity = new HttpEntity<Object>(mapper.writeValueAsString(params), headers);

        ResponseEntity< String > responseEntity = restTemplate.exchange(strUrl, HttpMethod.POST, entity, String.class);

        String result = responseEntity.getBody();
        JSONParser parser = new JSONParser();
        Object obj = parser.parse(result);
        JSONObject jsonObject = (JSONObject) obj;

        return jsonObject;
    }

    // 년월일 [YYYYMMDD -> YYYY.MM.DD]
    public static String getPointDate(String i_sSource) {
        if (StringUtil.defaultString(i_sSource).length() < "YYYYMMDD".length()) {
            return i_sSource;
        }

        return i_sSource.substring(0, 4)
                + "." + i_sSource.substring(4, 6)
                + "." + i_sSource.substring(6, 8);
    }

    /**
     * HTTPS POST URL 연결
     * @param strUrl
     * @param urlParameters
     * @return
     * @throws Exception
     */
    public static String httpsPostConnect(String strUrl, String urlParameters) throws Exception {
        String rsjson = "";
        URL obj = new URL(strUrl);
        HttpsURLConnection con = null;
        String USER_AGENT = "Mozilla/5.0";
        Charset charset = Charset.forName(UTF_8);
        BufferedReader in = null;
        DataOutputStream wr = null;

        try {
            con = (HttpsURLConnection) obj.openConnection();

            //add reuqest header
            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Charset", UTF_8);
            con.setConnectTimeout(10000);       //컨텍션타임아웃 10초
            con.setReadTimeout(5000);           //컨텐츠조회 타임아웃 5총

            // Send post request
            con.setDoOutput(true);              //항상 갱신된내용을 가져옴.

            wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();

            int responseCode = con.getResponseCode();
//            log.debug("Sending 'POST' request to URL : " + strUrl);
//            log.debug("Post parameters : " + urlParameters);
//            log.debug("Response Code : " + responseCode);

            String inputLine;
            StringBuilder response = new StringBuilder();

            in = new BufferedReader(new InputStreamReader(con.getInputStream(),charset));
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            rsjson = response.toString();

//            log.debug("Response data : " + response.toString());
        } catch (Exception e) {
            log.error(null, e);

            throw new Exception(e);
        }finally{
            if(in != null){ in.close(); }
            if(wr != null){ wr.close(); }
            if(con != null){ con.disconnect(); }
        }

        return rsjson;
    }

    /**
     * @deprecated {@link kr.co.daiso.common.util.StringUtil#isEmpty(CharSequence)}로 대체됨
     */
    @Deprecated
    public static boolean isEmpty(String str) {
        if (str != null && !str.equals(""))
            return false;
        else
            return true;
    }

    public static String nvl(String val, String replace) {
        String retValue = null;
        if (val == null || "".equals(val.trim()) || "null".equals(val.trim().toLowerCase())) {
            retValue = replace;
        } else {
            retValue = val;
        }
        return retValue;
    }

    // cookie
    public static String getCookie(String cookieName, HttpServletRequest request) {
        String 		resultStr	= "";
        Cookie[] 	cookies 	= request.getCookies();

        if(cookies != null){
            for( int i = 0; i < cookies.length; i++ ) {
                Cookie thisCookie =  cookies[i];

                if ( thisCookie.getName().equals(cookieName) ) {
                    resultStr   = thisCookie.getValue();
                    break;
                }
            }
        }

        return resultStr;
    }

    /**
     * @deprecated kr.co.daiso.fo.common.util.HttpUtil#getDevicePlatform(HttpServletRequest) 로 대체됨
     */
    public static String getDevicePlatformFromUserAgentEx(HttpServletRequest request) {
        String userAgent = request.getHeader("User-Agent").toLowerCase();
        if (StringUtil.isNotEmpty(userAgent)) {
            if (userAgent.toLowerCase().indexOf("daisoandroid") > -1) {
                return "ANDROID";
            }else if (userAgent.toLowerCase().indexOf("daisoios") > -1) {
                return "IOS";
            }
        }
        return "WEB";
    }

    /**
     * Map Parameter 처리위해..RequestValueInterceptor 내용 복사
     * @param request
     * @return
     * @throws UnsupportedEncodingException
     */
    @SuppressWarnings("unchecked")
    public static Map<Object, Object> getMapParameters(HttpServletRequest request) throws UnsupportedEncodingException{
        Map<Object, Object>	reqMap		= new HashMap<>();
        Map<Object, Object>	reloadMap	= new HashMap<>();

        Enumeration<String>  enumeration	= request.getParameterNames();
        StringBuilder 	param = new StringBuilder();
        String[] 		values;
        String 			reqUrl			= request.getRequestURI();
        String 			name;
        boolean 		isTemp;
        int				len;

        while (enumeration.hasMoreElements()) {
            name		= enumeration.nextElement();
            values		= request.getParameterValues(name);
            isTemp		= name.indexOf("_temp") > -1 && name.indexOf("_temp") == name.length() - 5;

            if (name.indexOf("[") > -1 && name.indexOf("[]") == name.length() - 2) {
                name = name.substring(0, name.length() - 2);
            }

            if (values != null) {
                if (!isTemp) {
                    for (int i = 0; i < values.length; i++) {
                        //XSS 공격을 막기위해서 블랙리스트 단어앞에 x-를 붙여줌
                        values[i] = CmFunction.replaceAlltoXSS(values[i]);
                    }
                }

                // 현재 페이지 요청 정보 가져옴
                if (!isTemp) {
                    // key 값이 i_i로 시작하고 값이 없으면 0처리
                    //reqMap.put(name, name.indexOf("i_i") == 0 || values == null ? 0 : reqMap.get(name));
                    // key 값이 i_arr 로 시작하면 1개라도 무조건 배열로 처리
                    reqMap.put(name, name.indexOf("i_arr") == 0 || values.length > 1 ? values : values[0]);
                    reloadMap.put(name, values);

                    if ( !name.equals("i_sReturnUrl") && !name.equals("i_sReturnParam") ) {
                        len = values.length;

                        if (len > 1) {
                            for (int i = 0; i < len; i++) {
                                param.append(name).append("=").append(URLEncoder.encode(values[i], UTF_8)).append("&");
                            }
                        }
                        else {
                            param.append(name).append("=").append(URLEncoder.encode(values[0], UTF_8)).append("&");
                        }
                    }
                }
            }
        }

        reqMap.put("i_iRecordCnt", reqMap.get("i_iRecordCnt") == null ? 0 : reqMap.get("i_iRecordCnt"));
        reqMap.put("i_iTotalPageCnt", reqMap.get("i_iTotalPageCnt") == null ? 0 : reqMap.get("i_iTotalPageCnt"));
        reqMap.put("pageUrl", reqUrl);
        reqMap.put("pageParam", param.toString());

        if (request instanceof MultipartHttpServletRequest) {
            MultipartHttpServletRequest multi	= (MultipartHttpServletRequest) request;

            Map<String, MultipartFile> files	= multi.getFileMap();

            Iterator<Map.Entry<String, MultipartFile>> iterator	= files.entrySet().iterator();

            while(iterator.hasNext()) {
                Map.Entry<String, MultipartFile> entry	= iterator.next();
                String key = entry.getKey();
                MultipartFile value = entry.getValue();
                if (!value.isEmpty())
                    reqMap.put(key, value);
            }
        }

        // [s] view, reg 페이지일 경우 i_sReturnUrl 셋팅
        /**
         * tobe Uri에 ".do" 없어서 수정
          */
        String urlPatten	= reqUrl.substring(reqUrl.lastIndexOf("_") + 1);

        if (urlPatten.equals("view") || urlPatten.equals("reg")) {

            String i_sReturnUrl		= StringUtil.trimToEmpty((String) reqMap.get("i_sReturnUrl"));

            if (i_sReturnUrl.equals("")) {
                i_sReturnUrl			= reqUrl.substring(0, reqUrl.lastIndexOf("_")) + "_list";
                reqMap.put("i_sReturnUrl", i_sReturnUrl);
                reqMap.put("i_sReturnParam", null);
            }
        }
        // [e] view, reg 페이지일 경우 i_sReturnUrl 셋팅

        // 페이지 리로드를 위한 셋팅
        request.setAttribute("requestUri", reqUrl);
        request.setAttribute("reloadInfoMap", reloadMap);

        // session
        CmFunction.setSessionValue(request, reqMap);
        // ------------

        return reqMap;
    }

    /**
     * XSS 공격 대비 스트립트를 변경하는 함수
     * @param str
     * @return
     */
    public static String replaceAlltoXSS(String str){
        str = str.replace("javascript",	"x-javascript");
        str = str.replace("script",		"x-script");
        str = str.replace("iframe",		"x-iframe");
        str = str.replace("document",	"x-document");
        str = str.replace("vbscript",	"x-vbscript");
        str = str.replace("applet",		"x-applet");
        str = str.replace("embed",		"x-embed");
        str = str.replace("object",		"x-object");
        str = str.replace("frame",		"x-frame");
        str = str.replace("grameset",	"x-grameset");
        str = str.replace("layer",		"x-layer");
        str = str.replace("bgsound",		"x-bgsound");
        str = str.replace("alert",		"x-alert");
        str = str.replace("onblur",		"x-onblur");
        str = str.replace("onchange",	"x-onchange");
        str = str.replace("onclick",		"x-onclick");
        str = str.replace("ondblclick",	"x-ondblclick");
        str = str.replace("enerror",		"x-enerror");
        str = str.replace("onfocus",		"x-onfocus");
        str = str.replace("onload",		"x-onload");
        str = str.replace("onmouse",		"x-onmouse");
        str = str.replace("onscroll",	"x-onscroll");
        str = str.replace("onsubmit",	"x-onsubmit");
        str = str.replace("onunload",	"x-onunload");
        return str;
    }

    public static void setSessionValue(HttpServletRequest request, Map<Object, Object> dataMap ) {
        if (dataMap == null)
            dataMap		= new HashMap<>();

        HttpSession		session		= request.getSession();

        dataMap.put("s_empid",			session.getAttribute("S_USER_ID"));
        dataMap.put("s_empnm",			session.getAttribute("S_USER_NAME"));
        dataMap.put("s_centercd",		session.getAttribute("S_CENTER_CODE"));
        dataMap.put("s_centernm",		session.getAttribute("S_CENTER_NAME"));
    }

    /**
     * @deprecated {@link kr.co.daiso.common.util.StringUtil#trimToEmpty(String)}로 대체됨
     */
    @Deprecated
    public static String getStrVal(String str) {
        if (str == null || "".equals(str))
            return "";
        return str.trim();
    }

    @SuppressWarnings({ "unchecked", "unused" })
    public static Map<String, Object> convertListObjectToCmMap(Object obj){
        try {
            Class clazz = obj.getClass();
            Field[] fields = clazz.getDeclaredFields();
            Field[] allFields = (Field[]) ArrayUtils.addAll(fields, clazz.getSuperclass().getDeclaredFields());

            Map<String, Object> resultMap = new HashMap<>();
            for(int i=0; i<=allFields.length-1;i++){
                allFields[i].setAccessible(true);
                String filedName = allFields[i].getName();

                Object value = allFields[i].get(obj);

                // 실제로 유효한 형태의 파라미터만 추출토록 한다.
                if (null != value) {
                    if(value instanceof Integer) {
                        if(Integer.parseInt(value.toString()) > 0) {
                            resultMap.put(filedName, value);
                        }
                    }else if(value instanceof String) {
                        if(StringUtil.isNotEmpty(value.toString())) {
                            resultMap.put(filedName, value);
                        }
                    }
                }
            }
            return resultMap;
        } catch (Exception e) {
            log.error(null, e);
        }
        return null;
    }
    /**
     * 해당 url의 html을 가져온다.
     * @param i_sUrl
     * @return
     */
    public static String urlToString(String i_sUrl) {
        String	sReturn			= "";

        try {
            URL					url			= new URL(i_sUrl);
            HttpURLConnection conn		= (HttpURLConnection) url.openConnection();
            byte[]				bTmp		= null;
            InputStream in			= null;

            conn.connect();

            in 			= conn.getInputStream();
            bTmp		= CmFunction.fileToByte(in);				// file => byte
            sReturn		= new String(bTmp, UTF_8);

        } catch (Exception e) {
            log.error(null, e);
        }

        return sReturn;
    }

    // file => Byte 로
    public static byte[] fileToByte (InputStream in) throws IOException {

        byte[] 					bResult		= null;
        byte[] 					bTmp		= new byte[1024];
        ByteArrayOutputStream 	baos		= new ByteArrayOutputStream();

        try
        {
            int		j;
            while (( j = in.read(bTmp)) != -1)
            {
                baos.write(bTmp, 0, j);
            }

            bResult	= baos.toByteArray();
        }
        finally
        {
            if(baos != null) {
                try{ baos.close(); }catch(IOException e){ log.error(null, e); }
            }

            if (in != null) {
                try{ in.close(); }catch (IOException e){ log.error(null, e); }
            }
        }

        return bResult;
    }

    // 문자열에서 모든 HTML 태그 삭제 하고  \n을  --> <br> 로 변경
    public static String removeHTMLChangeBr(String i_sHTML) {
        String	result	= "";

        if ((null == i_sHTML) || "".equals(i_sHTML)) {
            return "";
        }

        result	= i_sHTML.replace("<.+?>", "").replace("\n", "<br/>");

        return result;
    }

    /**
     * 년월식 표시
     * @param i_sSource
     * @return
     */
    public static String getMfrDate2(String i_sSource) {

        StringBuilder	sb			= new StringBuilder();

        sb.append("");

        if (i_sSource != null && i_sSource.length() >= "YYYYMM".length())
        {
            sb.append(i_sSource.substring(0, 4));
            sb.append("년 ");
            sb.append(i_sSource.substring(4, 6));
            sb.append("월");
        }

        return sb.toString();
    }


    /**
     * 오늘 날짜 기준 [년|월|일|시|분|초] 차이를 구한다.
     *
     * @deprecated {@link DateUtil#addYears(int, String)}, {@link DateUtil#addMonths(int, String)},
     *             {@link DateUtil#addDays(int, String)}, {@link DateUtil#addHours(int, String)},
     *             {@link DateUtil#addMinutes(int, String)}, {@link DateUtil#addSeconds(int, String)}} 로 대체됨
     */
    public static String getTodayGapToString(int paramInt, int gapInt, String format) {
        GregorianCalendar	calendar	= new GregorianCalendar();
        switch (paramInt) {
            case Calendar.YEAR : // 1 사용
                calendar.add(Calendar.YEAR, gapInt);
                break;
            case Calendar.MONTH : // 2
                calendar.add(Calendar.MONTH, gapInt);
                break;
            case Calendar.DATE : // 5 사용
                calendar.add(Calendar.DATE, gapInt);
                break;
            case Calendar.HOUR : // 10
                calendar.add(Calendar.HOUR, gapInt);
                break;
            case Calendar.MINUTE : // 12
                calendar.add(Calendar.MINUTE, gapInt);
                break;
            case Calendar.SECOND : // 13
                calendar.add(Calendar.SECOND, gapInt);
                break;

            default:
                break;
        }
        return getDateToString(calendar.getTime(), format);
    }

    /**
     * 폰번호 마스킹
     * @param str
     * @return
     */
	public static String getPhoneNumberMasking2(String str) {
		String returnStr = str;

		if(str != null){
			int count = str.length();
			if(count == 11){
				returnStr = str.substring(0,3) + "****" + str.substring(7,11) ;
			}else if(count == 10){
				returnStr = str.substring(0,3) + "***" + str.substring(6,10) ;
			}else if(count == 13){
				returnStr = str.substring(0,3) + "-****-" + str.substring(9,13);
			}else if(count == 12){
				returnStr = str.substring(0,3) + "-***-" + str.substring(8,12);
			}else{
				returnStr = str;
			}
		}else{
			returnStr = "";
		}

		return returnStr;
	}

    /**
     * 주민번호 마스킹
     * @param str
     * @return
     */
	public static String getRNOMasking(String str) {
		String returnStr = str;

		if (str == null || "".equals(str) || str.length()<6)
			return str;
		returnStr = str.replaceAll(RNO_PATTERN, "******");

		return returnStr;
	}

    public static String getParameter(HttpServletRequest request, char opt, String param) {
        String ret;
        if('S'==opt){ /// 태그제거
            ret = removeAllHTML2(request.getParameter(param));
        }else if('F'==opt){ /// 파일관련
            ret = removeFile(request.getParameter(param));
        }else{
            ret = request.getParameter(param);
        }
        return ret;
    }

    // 문자열에서 모든 HTML 태그 삭제
    /***
     * jsp 용으로 별도 생성
     * @param i_sHTML
     * @return
     */
    public static String removeAllHTML2(String i_sHTML) {
        String	result	= "";

        if ((null == i_sHTML) || "".equals(i_sHTML)) {
            return "";
        }

        result	= i_sHTML.replace("<.+?>", "");
        result	= result.replace("&nbsp;", "");
        result	= result.replace("\\n", "");
        result	= result.replace("\\r", "");
        return result;
    }

    public static String removeFile(String i_sHTML) {
        String	result	= removeAllHTML2(i_sHTML);

        result	= result.replace("/", "")
                .replace("\\.", "")
                .replace("&", "")
                .replace("\\\\", "");
        return result;
    }

    // 문자열을 Byte 수 만큼 자르고  문자열임을 표시
    public static String getByteString2(String i_sSource, int i_iLength) {
        String	result	= "";

        if ((null == i_sSource) || "".equals(i_sSource)) {
            return result;
        }

        if (i_iLength <= 0) {
            return i_sSource;
        }

        try {

            char 	cTmp;
            byte[]	bTmp;
            int		nowLength	= 0;
            int		strLemgth	= 0;

            for (int i = 0 ; i < i_sSource.length(); i++ )
            {
                cTmp	= i_sSource.charAt(i);

                bTmp		= ("" + cTmp).getBytes("UTF-8");
                strLemgth	= bTmp.length;

                if (strLemgth == 3)
                    nowLength += 2;
                else
                    nowLength += strLemgth;

                if (nowLength <= i_iLength)
                {
                    result	+= cTmp;
                }
                else
                {
                    break;
                }
            }

            if (i_sSource.length() > result.length())
                result += "";

        } catch (Exception e) {
            result	= i_sSource;
        }

        return result;
    }

    /**
     * HTTPS URL 연결
     * @param strUrl
     * @return
     * @throws Exception
     */
    public static StringBuilder httpsConnect(String strUrl) throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
                //
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
                //
            }
        } };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

//        // Create all-trusting host name verifier
//        HostnameVerifier allHostsValid = new HostnameVerifier() {
//            public boolean verify(String hostname, SSLSession session) {
//                return true;
//            }
//        };
//        // Install the all-trusting host verifier
//        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        /*
         * end of the fix
         */

        URL url = new URL(strUrl);
        URLConnection con = url.openConnection();

//        BufferedReader postRes = null;

        String buf = "";
        StringBuilder resultBuffer = new StringBuilder();

        try {
            InputStreamReader isr = new InputStreamReader(con.getInputStream(), "UTF-8");
            BufferedReader postRes = new BufferedReader(isr);

            while ((buf = postRes.readLine()) != null) { // -1이 아니고 null
                resultBuffer.append(buf);
            }
        } catch (Exception e) {
            throw new Exception(e);
        }
//        finally {
//            if(postRes != null) {
//                try{ postRes.close(); }catch(IOException ioe){ ioe.printStackTrace(); }
//            }
//        }

        return resultBuffer;
    }
}
