package kr.co.daiso.common.model;

import lombok.Data;

import java.io.Serializable;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : BaseModel
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    : 기본 모델
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26       Doo-Won Lee         최초생성
 */
@Data
public class BaseModel implements Serializable {

    private static final long serialVersionUID = -5767508192561569865L;

//    @MaskingField(MaskingField.MaskingType.NAME)
    private String rgpsId;
    private String regDttm;

//    @MaskingField(MaskingField.MaskingType.NAME)
    private String mdpsId;
    private String modDttm;

}
