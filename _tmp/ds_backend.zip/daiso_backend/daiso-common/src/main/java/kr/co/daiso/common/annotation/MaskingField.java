package kr.co.daiso.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * packageName    : kr.co.daiso.common.annotation
 * fileName       : MaskingField
 * author         : Doo-Won Lee
 * date           : 2022-01-13
 * description    : Masking 처리 필요한 Field Annotation
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13      Doo-Won Lee         최초생성
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MaskingField {
    public MaskingType value() default MaskingType.NONE;

    enum MaskingType{
        NAME,
        EMAIL,
        PHONE_NUM,
        IP,
        NONE;
    }

}
