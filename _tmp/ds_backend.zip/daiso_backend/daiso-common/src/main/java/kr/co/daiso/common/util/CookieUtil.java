package kr.co.daiso.common.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;

/**
 * packageName    : kr.co.daiso.fo.common
 * fileName       : CookieUtil
 * author         : Doo-Won Lee
 * date           : 2021-10-27
 * description    : Cookie 사용 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-27      Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public final class CookieUtil {

    public static String DOMAIN;
    @Value("${domain}")
    public void setDevDomain(String domain) { DOMAIN = domain; }

    public static String SERVERTYPE;

    @Value("${spring.server_type}")
    public void setServerType(String serverType) { SERVERTYPE = serverType; }

    /**
     * methodName : createResponseCookie
     * author : Doo-Won Lee
     * description : Response Cookie를 생성한다.
     *
     * @param cookieName
     * @param value
     * @param expireTime
     * @return response cookie
     */
    public static ResponseCookie createResponseCookie(String cookieName, String value, long expireTime){
        return ResponseCookie
                .from(cookieName, value)
                .httpOnly(true)
                .sameSite("Lax")
//                .secure(true)
                .domain(DOMAIN)
                .path("/")
                .maxAge(Duration.ofMillis(expireTime))
                .build();
    }

    public static void addResponseCookie(HttpServletResponse response, String cookieName, String value, long expireTime){

        if ("local".equals(SERVERTYPE)){
            response.addHeader(HttpHeaders.SET_COOKIE,ResponseCookie
                    .from(cookieName, value)
                    .httpOnly(true)
                    .sameSite("Lax")
//                .secure(true)
                    .domain(DOMAIN)
                    .path("/")
                    .maxAge(Duration.ofMillis(expireTime))
                    .build().toString());
        }
        else{
            response.addHeader(HttpHeaders.SET_COOKIE,ResponseCookie
                    .from(cookieName, value)
                    .httpOnly(true)
                    .sameSite("Lax")
                    .secure(true)
                    .domain(DOMAIN)
                    .path("/")
                    .maxAge(Duration.ofMillis(expireTime))
                    .build().toString());
        }
    }

    /**
     * methodName : getCookie
     * author : Doo-Won Lee
     * description : CookieName에 해당하는 Cookie를 구한다.
     *
     * @param request
     * @param cookieName
     * @return cookie
     */
    public static Cookie getCookie(HttpServletRequest request, final String cookieName){
        final Cookie[] cookies = request.getCookies();
        if (null==cookies) return null;
//        for(Cookie cookie : cookies){
//            log.info(cookie.getName() + " : " + cookie.getValue());
//        }

        return  Arrays.stream(cookies)
                .filter(cookie -> cookie.getName().equals(cookieName))
                .findFirst()
                .orElse(null);
    }

    public static Optional<Cookie> getOptCookie(HttpServletRequest request, String name) {
        final Cookie[] cookies = request.getCookies();
        if (cookies != null && cookies.length > 0) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return Optional.of(cookie);
                }
            }
        }
        return Optional.empty();
    }
}
