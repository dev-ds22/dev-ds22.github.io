package kr.co.daiso.common.util;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Map;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : CollectUtil
 * author         : 이강욱
 * date           : 2022-05-06
 * description    : Collection 유틸리티 클래스 - org.apache.commons.collections4.CollectionUtils 상속이 안되어 자체 구현
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-06       이강욱         최초생성
 */
@Slf4j
public class CollectUtil {
    private CollectUtil() {}

    public static int size(Object object) {
        return CollectionUtils.size(object);
    }

    public static boolean equals(Map<String, Object> map, String key, String searchString) {
        if (map == null || key == null || searchString == null) {
            return false;
        }

        try {
            Object value = map.get(key);
            return (value == null) ? false : StringUtil.equals(String.valueOf(value), searchString);
        } catch (Exception e) {
        }

        return false;
    }

    public static boolean getBoolean(Map<String, Object> map, String key) {
        if (map == null || key == null) {
            return false;
        }

        try {
            Object value = map.get(key);
            return (value == null) ? false : Boolean.valueOf(String.valueOf(value));
        } catch (Exception e) {
        }

        return false;
    }

    public static String getStringToEmpty(Map<String, Object> map, String key) {
        try {
            Object value = map.get(key);
            return (value == null) ? "" : String.valueOf(value);
        } catch (Exception e) {
            return "";
        }
    }

    public static int getIntToZero(Map<String, Object> map, String key) {
        try {
            return Integer.parseInt(String.valueOf(map.get(key)));
        } catch (Exception e) {
            return 0;
        }
    }

    public static String[] getStringArray(Map<Object, Object> map, String key) {
        try {
            if (!map.get(key).getClass().isArray()) {
                return new String[] { (String)map.get(key) };
            }

            return (String[])map.get(key);
        } catch (Exception e) {
            return null;
        }
    }

    public static String getStringByPathKey(Map<String, Object> map, String pathKey) {
        Object valueObj = null;

        try {
            String[] keyArray = pathKey.split("/");
            int pathSize = (keyArray == null) ? 0 : keyArray.length;

            if(pathSize == 0) {
                return null;
            } else if(pathSize == 1) {
                valueObj = map.get(keyArray[0]);
            } else {
                Map<String, Object> inMap = map;
                for(int i = 0; i < keyArray.length; i++) {
                    valueObj = inMap.get(keyArray[i]);

                    if(i != keyArray.length - 1) {
                        inMap = (Map<String, Object>) valueObj;
                    }
                }
            }
        } catch (Exception e) {
            log.error(null, e);
        }

        return (valueObj == null) ? null : String.valueOf(valueObj);
    }
}
