package kr.co.daiso.common.util;

import kr.co.daiso.common.annotation.MaskingField;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : MaskingUtil
 * author         : Doo-Won Lee
 * date           : 2022-01-13
 * description    : Masking 처리 Util - 기존 소스와 동일처리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13      Doo-Won Lee     최초생성
 */
@Slf4j
@Component
public class MaskingUtil {

    private MaskingUtil(){
        log.debug("MaskingUtil");
    }
    /**
     * methodName : maskingFieldProcess
     * author : Doo-Won Lee
     * description : Interceptor를 통해 Target Field를 전달 받아 Field 타입에 따라 Masking 처리한다.
     *
     * @param paramsObject
     */
    public  static <T>T maskingFieldProcess(T paramsObject) throws IllegalAccessException {
        Class resultClass = paramsObject.getClass();
//        Field[] declaredFields = resultClass.getDeclaredFields();
        List<Field> declaredFieldList = FieldUtils.getAllFieldsList(resultClass);
        for (Field field : declaredFieldList) {
            MaskingField maskField = field.getAnnotation(MaskingField.class);
            if (!Objects.isNull(maskField)) {
                field.setAccessible(true);
                Object object = field.get(paramsObject);
                if (object instanceof String) {
                    String value = (String) object;
                    switch (field.getAnnotation(MaskingField.class).value()) {
                        case NAME:
                            field.set(paramsObject, getNameMasking(value));
                            break;
                        case EMAIL:
                            field.set(paramsObject, getEmailMasking(value));
                            break;
                        case PHONE_NUM:
                            field.set(paramsObject, getPhoneNumberMasking(value));
                            break;
                        case IP:
                            log.info(value);
                            field.set(paramsObject, getIpNumberMasking(value));
                            break;
                        default:
                            break;
                    }

                }
            }
        }
        return paramsObject;
    }


    /**
     * methodName : getNameMasking
     * author : Doo-Won Lee
     * description : 이름을 Masking 처리한다.
     *
     * @param source
     */
    public static String getNameMasking(String source) {
        String sResult	= "";

        if (source != null) {
            int sNameLength = source.length();
            for(int i=0; i<sNameLength; i++){
                if(i==1){
                    sResult = sResult + "*";
                }else{
                    sResult = sResult + source.charAt(i);
                }
            }
        }
        return sResult;
    }

    /**
     * methodName : getEmailMasking
     * author : Doo-Won Lee
     * description : Email을 Masking 처리한다.
     *
     * @param source
     */
    public static String getEmailMasking(String source) {
        String sResult	= "";

        if (source != null) {
            String[] ArrN_PRICE = null;

            ArrN_PRICE =  source.split("@");

            int count = ArrN_PRICE.length;
            if(count==2){
                String sFront = ArrN_PRICE[0];
                int sFrongLength = sFront.length();
				/*
				int mskingLength = 0;
				if(sFrongLength <= 3){
					mskingLength = sFrongLength - 2;
				}else{
					mskingLength = sFrongLength - 4;
				}*/
                for(int i=0; i<sFrongLength; i++){
                    if(i<=1){
                        sResult = sResult + sFront.charAt(i);
                    }else{
                        sResult = sResult + "*";
                    }
                }
                sResult = sResult + "@" + ArrN_PRICE[1];
            }

        }
        return sResult;
    }

    /**
     * methodName : getPhoneNumberMasking
     * author : Doo-Won Lee
     * description : 전화번호를 Masking 처리한다.
     *
     * @param str
     */
    public static String getPhoneNumberMasking(String str) {
        String returnStr = null;

        if(str != null){
            int count = str.length();
            if(count == 11){
                returnStr = str.substring(0,3) + "****" + str.substring(7,11);
            }else if(count == 10){
                returnStr = str.substring(0,3) + "***" + str.substring(6,10);
            }else if(count == 13){
                returnStr = str.substring(0,3) + "-****-" + str.substring(9,13);
            }else if(count == 12){
                returnStr = str.substring(0,3) + "-***-" + str.substring(8,12);
            }else{
                returnStr = str;
            }
        }else{
            returnStr = "";
        }

        return returnStr;
    }

    /**
     * methodName : getIpNumberMasking
     * author : Byung-Chul Park
     * description : IP를 Masking 처리한다.
     *
     * @param ip
     */
    public static String getIpNumberMasking(String ip){
        String returnIp = ip;

        if(ip != null && ip.contains(".")){
            String[] temp = ip.split("\\.");
            if (temp.length>1){
                temp[1] =  temp[1].replaceAll("[0-9]","*"); //정규식으로 전체를 * 로 변환
            }
             returnIp = String.join(".",temp);
        }
        else {
            returnIp = "";
        }

        return returnIp;
    }

}
