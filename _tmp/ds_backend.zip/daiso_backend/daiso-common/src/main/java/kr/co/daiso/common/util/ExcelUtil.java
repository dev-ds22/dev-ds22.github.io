package kr.co.daiso.common.util;

import com.google.common.base.CaseFormat;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.ExcelConversionFailVO;
import kr.co.daiso.common.model.ExcelConversionResultVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

/**
 * packageName    : kr.co.daiso.fo.common.util
 * fileName       : ExcelUtil
 * author         : Doo-Won Lee
 * date           : 2021-11-08
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-08      Doo-Won Lee     최초생성
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ExcelUtil {

    /**
     * The Executor.
     */
// Executor executor;
    ExecutorService executor = Executors.newSingleThreadExecutor();
    /**
     * The Wb.
     */
    SXSSFWorkbook wb = new SXSSFWorkbook();
    SXSSFSheet sheet = wb.createSheet();
    int rowIdx = 0;
    int cellIdx = 0;
    HttpServletResponse response;
    File excelFile;
    String excelFileName;
    CellStyle headerStyle;
    CellStyle bodyStyle;

    /**
     * methodName : makeExcelFileToResponse
     * author : Doo-Won Lee
     * description : Response에 엑셀 파일을 생성한다
     *
     * @param <R>         the type parameter
     * @param <T>         the type parameter
     * @param fileName    the file name
     * @param headerNames the headre names
     * @param columnNames the column names
     * @param function    the function
     * @param response    the response
     * @param params      the params
     */
    public <R, T> void makeExcelFileToResponse(String fileName, List<String> headerNames, List<String> columnNames
                                    , Function<T, List<R>> function, HttpServletResponse response, T params){

        wb = new SXSSFWorkbook();
        sheet = wb.createSheet();
        rowIdx = 0;
        cellIdx = 0;

        String extension = FilenameUtils.getExtension(fileName);
        String newFileName = StringUtils.hasText(extension) ? fileName : fileName + CommonConstants.EXCEL_EXTENTION;
        this.response = response;
        this.response.setContentType("ms-vnd/excel");
        this.response.setHeader("Content-Disposition", "attachment;filename="+newFileName);

        this.excelFileName =newFileName;

        setStyle();
        makeHeaders(headerNames);
        writeData(columnNames, function.apply(params));

    }
    /**
     * methodName : makeExcelFileHeader
     * author : khpark
     * description : 엑셀 파일 헤더정보만 생성한다
     *
     * @param fileName    the file name
     * @param headerNames the headre names
     * @param response    the response
     */
    public void makeExcelFileHeader(String fileName, List<String> headerNames, HttpServletResponse response){

        wb = new SXSSFWorkbook();
        sheet = wb.createSheet();
        rowIdx = 0;
        cellIdx = 0;

        String extension = FilenameUtils.getExtension(fileName);
        String newFileName = StringUtils.hasText(extension) ? fileName : fileName + CommonConstants.EXCEL_EXTENTION;
        this.response = response;
        this.response.setContentType("ms-vnd/excel");
        this.response.setHeader("Content-Disposition", "attachment;filename="+newFileName);

        this.excelFileName =newFileName;

        setStyle();
        makeHeaders(headerNames);

        try {
            if (null != this.response) {
                wb.write(this.response.getOutputStream());
                wb.dispose();
                wb.close();
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

//    public <R, T> String makeExcelFileToFile(String fileName, List<String> headreNames, List<String> columnNames
//            , Function<T, List<R>> function, HttpServletResponse response, T params){
//        String extension = FilenameUtils.getExtension(fileName);
//        String newFileName = StringUtils.hasText(extension) ? fileName : fileName + CommonConstants.EXCEL_EXTENTION;
//
//        this.excelFileName =newFileName;
//
//        executor.execute(() -> {
//            //sheet.setRandomAccessWindowSize(1000);  //메모리 size
//            makeHeaders(headreNames);
//            writeData(columnNames, function.apply(params));
//        });
//
//        return excelFile.getAbsolutePath();
//    }

    /**
     * methodName : makeHeaders
     * author : Doo-Won Lee
     * description : WorkSheet에 헤더를 생성한다.
     *
     * @param headerNames
     */
    private void makeHeaders(List<String> headerNames) {
        Row row = sheet.createRow(rowIdx++);
        Cell cell;

        for (String header : headerNames){
            cell = row.createCell(cellIdx++);
            cell.setCellStyle(headerStyle);
            cell.setCellValue(header);
        }
    }

    /**
     * methodName : writeData
     * author : Doo-Won Lee
     * description : response애 Data를 작성한다.
     *
     * @param columnNames, dataList
     */
    private <T> void writeData(List<String> columnNames, List<T> dataList){
        for (T t : dataList) {
            this.writeToRow(columnNames, t);
        }
        try {
            if (null != this.response) {
                wb.write(this.response.getOutputStream());
                wb.dispose();
                wb.close();
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * methodName : writeToRow
     * author : Doo-Won Lee
     * description : 각 row에 Data를 작성한다.
     *
     * @param columnNames, data
     */
    private <T> void writeToRow(List<String> columnNames, T data){
        try {
            Row row = sheet.createRow(rowIdx++);
            Class dataClass = data.getClass();
            String getMethodName;
            Object dataValue;
            cellIdx = 0;
            Cell cell;
            for (String colName : columnNames) {
                getMethodName = "get" + CaseFormat.LOWER_CAMEL.to(CaseFormat.UPPER_CAMEL, colName);
                Method method = dataClass.getMethod(getMethodName);
                dataValue = method.invoke(data);

                if (dataValue == null) {
                    dataValue = "";
                }

                cell = row.createCell(cellIdx++);
                writeToCell(cell,dataValue, bodyStyle);
            }
        }catch (Exception ex){
            ex.printStackTrace();
            log.error("Excel Data To Workbook write Exception : " + ex.getMessage());
        }
    }

    /**
     * methodName : writeToCell
     * author : Doo-Won Lee
     * description : 각 Cell에 Data를 작성한다.
     *
     * @param dataValue, style
     */
    private void writeToCell(Cell cell, Object dataValue, CellStyle style){
        if(style != null) {
            cell.setCellStyle(style);
        }
        if (dataValue instanceof String) {
            cell.setCellValue((String) dataValue);
        } else if (dataValue instanceof Short) {
            cell.setCellValue((Short) dataValue);
        } else if (dataValue instanceof Integer) {
            cell.setCellValue((Integer) dataValue);
        } else if (dataValue instanceof Long) {
            cell.setCellValue((Long) dataValue);
        } else if (dataValue instanceof Float) {
            cell.setCellValue((Float) dataValue);
        } else if (dataValue instanceof Double) {
            cell.setCellValue((Double) dataValue);
        } else if (dataValue instanceof BigDecimal) {
            if ("".equals(dataValue)) {
                cell.setCellValue(new BigDecimal(0).doubleValue());
            } else {
                cell.setCellValue(((BigDecimal) dataValue).doubleValue());
            }
        } else if (dataValue instanceof Date) {
            cell.setCellValue((Date) dataValue);
        } else if (dataValue instanceof Calendar) {
            cell.setCellValue((Calendar) dataValue);
        } else if (dataValue instanceof Boolean) {
            cell.setCellValue((Boolean) dataValue);
        } else {
            cell.setCellValue((String) dataValue);
        }
    }

    /**
     * methodName : setStyle
     * author : Doo-Won Lee
     * description : WorkSheet 스타일을 설정한다.
     *
     */
    private void setStyle(){
        Font headerFont = wb.createFont();
        headerFont.setFontName("맑은 고딕");
        headerFont.setBold(true);
        headerStyle = wb.createCellStyle();
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setFont(headerFont);

        Font bodyFont = wb.createFont();
        bodyFont.setFontName("맑은 고딕");
        bodyStyle= wb.createCellStyle();
        bodyStyle.setBorderTop(BorderStyle.THIN);
        bodyStyle.setBorderBottom(BorderStyle.THIN);
        bodyStyle.setBorderLeft(BorderStyle.THIN);
        bodyStyle.setBorderRight(BorderStyle.THIN);
        bodyStyle.setAlignment(HorizontalAlignment.LEFT);
        bodyStyle.setFont(bodyFont);
    }

    /***************************************************
     *
     *  Excel Upload
     *
     ****************************************************/

    /**
     * methodName : makeDataFromExcelFile
     * author : Doo-Won Lee
     * description : 엑셀파일을 서버에 저장하고 파일을 읽어 리스트 형태로 반환한다.
     */
    public <T> List<T> makeDataFromExcelFile(MultipartFile file, HttpServletRequest req, Class clazz, int dataStatRowIdx, String path) throws IOException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {

        //확장자 Check
        if (isExcelXls(file.getOriginalFilename()) || isExcelXlsx(file.getOriginalFilename())){
            OPCPackage pkg = null;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            String format = sdf.format(System.currentTimeMillis());
            String realPath = req.getServletContext().getRealPath("/upload/") + format+file.getOriginalFilename();
            if (null!=path){
                realPath = path + format+file.getOriginalFilename();
            }
            File folder = new File(realPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            log.debug(realPath);
            log.debug(file.getOriginalFilename());

            //file.transferTo(new File(folder.getAbsolutePath(), file.getOriginalFilename()));
            //File uploadedFile = new File(folder.getAbsolutePath(), file.getOriginalFilename());
            File newFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());
            FileOutputStream fos = new FileOutputStream(newFile);
            fos.write(file.getBytes());
            fos.close();

//            file.transferTo(new File(folder.getAbsolutePath()+"/"+ file.getOriginalFilename()));
            File uploadedFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());

            try {
                pkg = OPCPackage.open(uploadedFile);
            } catch (InvalidFormatException e) {
                e.printStackTrace();
            } catch (Exception e){
                e.printStackTrace();
            }
            Workbook uploadWorkbook = multipartFileToWorkbook(file,pkg);
            Sheet localSheet = uploadWorkbook.getSheetAt(0);

            Row namesRow = localSheet.getRow(0);
            Map<Integer, Method> methodMap = new HashMap<>();
            for(int i=0;i<namesRow.getPhysicalNumberOfCells();i++){
                String methodName = "set"+namesRow.getCell(i).getStringCellValue();
                for (Method method:clazz.getDeclaredMethods()){
                    if (method.getName().equalsIgnoreCase(methodName.toUpperCase())){
                        methodMap.put(i,method);
                    }
                }
            }

            int rowCount = localSheet.getPhysicalNumberOfRows();
            List<T> resultList = new ArrayList<>();
            for(int idx=dataStatRowIdx;idx<rowCount;idx++){
                try {
                    T t = (T)clazz.getDeclaredConstructor().newInstance();
                    for(Map.Entry<Integer,Method> entry : methodMap.entrySet()){
                        switch(localSheet.getRow(idx).getCell(entry.getKey()).getCellType()){
                            case NUMERIC:
                                entry.getValue().invoke(t, localSheet.getRow(idx).getCell(entry.getKey()).getNumericCellValue());
                                break;
//                            case STRING:
//                                entry.getValue().invoke(t,localSheet.getRow(idx).getCell(entry.getKey()).getStringCellValue());
//                                break;
                            case BOOLEAN:
                                entry.getValue().invoke(t,localSheet.getRow(idx).getCell(entry.getKey()).getBooleanCellValue());
                                break;
                            case FORMULA:
                                entry.getValue().invoke(t,localSheet.getRow(idx).getCell(entry.getKey()).getCellFormula());
                                break;
                            default:
                                switch(entry.getValue().getParameterTypes()[0].getSimpleName()){
                                    case "double":
                                    case "Double":
                                    case "int":
                                    case "Integer":
                                        entry.getValue().invoke(t,0);
                                        break;
                                    default:
                                        Cell cell = localSheet.getRow(idx).getCell(entry.getKey());
                                        if (cell == null || cell.getCellType() == CellType.BLANK) {
                                            entry.getValue().invoke(t,"");
                                        }
                                        else {
                                            entry.getValue().invoke(t, localSheet.getRow(idx).getCell(entry.getKey()).getStringCellValue());
                                        }
                                        break;
                                }
                                break;
                        }
                    }
                    resultList.add(t);
                } catch (InstantiationException  | IllegalAccessException  |InvocationTargetException | NoSuchMethodException e ) {
                    throw e;
                }
            }
            assert pkg != null;
            pkg.close();
            uploadedFile.delete();
            folder.delete()    ;
            return resultList;
        }
        else{
            //Excel 파일 아님 Exception
            throw new CommonException("xls, xlsx 파일만 등록 가능합니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /***************************************************
     *
     *  Excel Upload
     *
     ****************************************************/

    /**
     * methodName : makeKorHeaderDataFromExcelFile
     * author : khpark
     * description : 엑셀파일(한글해더)을 서버에 저장하고 파일을 읽어 리스트 형태로 반환한다.
     */
    public <T> List<T> makeKorHeaderDataFromExcelFile(MultipartFile file, HttpServletRequest req, Class clazz, int dataStatRowIdx, String path, HashMap<String, String> headerMap) throws IOException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {

        //확장자 Check
        if (isExcelXls(file.getOriginalFilename()) || isExcelXlsx(file.getOriginalFilename())){
            OPCPackage pkg = null;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            String format = sdf.format(System.currentTimeMillis());
            String realPath = req.getServletContext().getRealPath("/upload/") + format+file.getOriginalFilename();
            if (null!=path){
                realPath = path + format+file.getOriginalFilename();
            }
            File folder = new File(realPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            log.info("realPath", realPath);
            log.info("file.getOriginalFilename()",file.getOriginalFilename());

            //file.transferTo(new File(folder.getAbsolutePath(), file.getOriginalFilename()));
            //File uploadedFile = new File(folder.getAbsolutePath(), file.getOriginalFilename());

            File newFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());
            FileOutputStream fos = new FileOutputStream(newFile);
            fos.write(file.getBytes());
            fos.close();

//            file.transferTo(new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename()));
            File uploadedFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());

            try {
                pkg = OPCPackage.open(uploadedFile);
            } catch (InvalidFormatException e) {
                e.printStackTrace();
            } catch (Exception e){
                e.printStackTrace();
            }
            Workbook uploadWorkbook = multipartFileToWorkbook(file,pkg);
            Sheet localSheet = uploadWorkbook.getSheetAt(0);

            Row namesRow = localSheet.getRow(0);
            Map<Integer, Method> methodMap = new HashMap<>();
            for (int i = 0; i < namesRow.getPhysicalNumberOfCells(); i++) {
                    String sellValue = namesRow.getCell(i).getStringCellValue();
                    if (headerMap.containsKey(sellValue)) {
                        String methodName = "set" + headerMap.get(sellValue);
                        for (Method method : clazz.getDeclaredMethods()) {
                            if (method.getName().equalsIgnoreCase(methodName.toUpperCase())) {
                                methodMap.put(i, method);
                            }
                        }
                    }
                }

            int rowCount = localSheet.getPhysicalNumberOfRows();
            List<T> resultList = new ArrayList<>();
            DataFormatter dataFormatter = new DataFormatter();
            for(int idx=dataStatRowIdx;idx<rowCount;idx++){
                try {
                    T t = (T)clazz.getDeclaredConstructor().newInstance();
                    for(Map.Entry<Integer,Method> entry : methodMap.entrySet()){
                        switch(entry.getValue().getParameterTypes()[0].getSimpleName()){
                            case "double":
                            case "Double":
                            case "int":
                            case "Integer":
                                entry.getValue().invoke(t,0);
                                break;
                            default:
                                Cell cell = localSheet.getRow(idx).getCell(entry.getKey());
                                if (cell == null || cell.getCellType() == CellType.BLANK) {
                                    entry.getValue().invoke(t,"");
                                }
                                else {
                                    String value = dataFormatter.formatCellValue(cell);
                                    entry.getValue().invoke(t, value);
                                }
                                break;
                        }
                    }
                    resultList.add(t);
                } catch (InstantiationException  | IllegalAccessException  |InvocationTargetException | NoSuchMethodException e ) {
                    throw e;
                }
            }
            pkg.close();
            uploadedFile.delete();
            folder.delete();
            return resultList;
        }
        else{
            //Excel 파일 아님 Exception
            throw new CommonException("xls, xlsx 파일만 등록 가능합니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * methodName : makeResultDataFromExcelFile
     * author : Doo-Won Lee
     * description : 엑셀파일을 서버에 저장하고 파일을 읽어 리스트 형태로 반환한다.
     */
    public  <T> ExcelConversionResultVO<T> makeResultDataFromExcelFile(MultipartFile file, HttpServletRequest req, Class clazz, int dataStatRowIdx, String path) throws IOException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {

        //확장자 Check
        if (isExcelXls(file.getOriginalFilename()) || isExcelXlsx(file.getOriginalFilename())){

            ExcelConversionResultVO<T> resultVO = new ExcelConversionResultVO<>();

            OPCPackage pkg = null;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            String format = sdf.format(System.currentTimeMillis());
            String realPath = req.getServletContext().getRealPath("/upload/") + format+file.getOriginalFilename();
            if (null!=path){
                realPath = path + format+file.getOriginalFilename();
            }
            File folder = new File(realPath);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            log.info("realPath", realPath);
            log.info("file.getOriginalFilename()", file.getOriginalFilename());

//            file.transferTo(new File(folder.getAbsolutePath(), file.getOriginalFilename()));
//            File uploadedFile = new File(folder.getAbsolutePath(), file.getOriginalFilename());

            File newFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());
            FileOutputStream fos = new FileOutputStream(newFile);
            fos.write(file.getBytes());
            fos.close();

//            file.transferTo(new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename()));
            File uploadedFile = new File(folder.getAbsolutePath()+"/"+file.getOriginalFilename());

            try {
                pkg = OPCPackage.open(uploadedFile);
            } catch (InvalidFormatException e) {
                e.printStackTrace();
            } catch (Exception e){
                e.printStackTrace();
            }
            Workbook uploadWorkbook = multipartFileToWorkbook(file,pkg);
            Sheet localSheet = uploadWorkbook.getSheetAt(0);

            Row namesRow = localSheet.getRow(0);
            Map<Integer, Method> methodMap = new HashMap<>();
            for(int i=0;i<namesRow.getPhysicalNumberOfCells();i++){
                String methodName = "set"+namesRow.getCell(i).getStringCellValue();
                for (Method method:clazz.getDeclaredMethods()){
                    if (method.getName().equalsIgnoreCase(methodName.toUpperCase())){
                        methodMap.put(i,method);
                    }
                }
            }

            int rowCount = localSheet.getPhysicalNumberOfRows();
            List<T> successList = new ArrayList<>();
            List<ExcelConversionFailVO> failList = new ArrayList<>();
            for(int idx=dataStatRowIdx;idx<rowCount;idx++){
                try {
                    T t = (T)clazz.getDeclaredConstructor().newInstance();
                    for(Map.Entry<Integer,Method> entry : methodMap.entrySet()){
                        switch(localSheet.getRow(idx).getCell(entry.getKey()).getCellType()){
                            case NUMERIC:
                                entry.getValue().invoke(t, localSheet.getRow(idx).getCell(entry.getKey()).getNumericCellValue());
                                break;
                            case BOOLEAN:
                                entry.getValue().invoke(t,localSheet.getRow(idx).getCell(entry.getKey()).getBooleanCellValue());
                                break;
                            case FORMULA:
                                entry.getValue().invoke(t,localSheet.getRow(idx).getCell(entry.getKey()).getCellFormula());
                                break;
                            default:
                                switch(entry.getValue().getParameterTypes()[0].getSimpleName()){
                                    case "double":
                                    case "Double":
                                    case "int":
                                    case "Integer":
                                        Cell cell = localSheet.getRow(idx).getCell(entry.getKey());
                                        if (cell == null || cell.getCellType() == CellType.BLANK) {
                                            entry.getValue().invoke(t, 0);
                                        }
                                        else{
                                            throw new CommonException("invalid value for cell : " + localSheet.getRow(0).getCell(entry.getKey()).getStringCellValue()
                                                                ,HttpStatus.INTERNAL_SERVER_ERROR);
//                                            entry.getValue().invoke(t, sheet.getRow(idx).getCell(entry.getKey()).getStringCellValue());
                                        }
                                        break;
                                    default:
                                        Cell scell = localSheet.getRow(idx).getCell(entry.getKey());
                                        if (scell == null || scell.getCellType() == CellType.BLANK) {
                                            entry.getValue().invoke(t,"");
                                        }
                                        else {
                                            entry.getValue().invoke(t, localSheet.getRow(idx).getCell(entry.getKey()).getStringCellValue());
                                        }
                                        break;
                                }
                                break;
                        }
                    }
                    successList.add(t);
                } catch (CommonException e) {
//                    e.printStackTrace();
//                    System.out.println(e.getCause());
                    ExcelConversionFailVO failVO = new ExcelConversionFailVO();
                    failVO.setRowIdx(idx);
                    failVO.setExceptionMsg(e.getMessage());
                    failList.add(failVO);
                } catch (InstantiationException  | IllegalAccessException  |InvocationTargetException | NoSuchMethodException e ) {
                    throw e;
                }
            }
            pkg.close();
            uploadedFile.delete();
            folder.delete();
            resultVO.setSuccessList(successList);
            resultVO.setFailList(failList);
            return resultVO;
        }
        else{
            //Excel 파일 아님 Exception
            throw new CommonException("xls, xlsx 파일만 등록 가능합니다.", HttpStatus.BAD_REQUEST);
        }
    }


    private boolean isExcelXls(String fileName) {
        return fileName.endsWith(CommonConstants.EXCEL_XLS_EXTENTION);
    }

    private boolean isExcelXlsx(String fileName) {
        return fileName.endsWith(CommonConstants.EXCEL_XLSX_EXTENTION);
    }

    private Workbook multipartFileToWorkbook(MultipartFile file,OPCPackage pkg)
            throws IOException {
        if (isExcelXls(file.getOriginalFilename())) {
            return new HSSFWorkbook(file.getInputStream());
        } else {
            return new XSSFWorkbook(pkg);
        }
    }
}
