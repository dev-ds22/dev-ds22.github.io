package kr.co.daiso.common.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Objects;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : CommonUtil
 * author         : Doo-Won Lee
 * date           : 2021-11-24
 * description    : 공통 유틸 Class
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-24       Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public class CommonUtil {

    private CommonUtil(){
      log.debug("CommonUtil");
    }

    //Request 내에 IP 정보 헤더들
    private static final String[] IP_HEADER_LIST = {
            "X-Real-IP",
            "X-Forwarded-For",
            "Proxy-Client-IP",
            "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR",
            "HTTP_X_FORWARDED",
            "HTTP_X_CLUSTER_CLIENT_IP",
            "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR",
            "HTTP_FORWARDED",
            "HTTP_VIA",
            "REMOTE_ADDR"
    };

    public static String generateState() {
        SecureRandom random = new SecureRandom();
        return new BigInteger(130, random).toString(32);
    }


    /**
     * methodName : getClientIp
     * author : Doo-Won Lee
     * description : request Header에 존재하는 IP를 확인후  리턴 없으면 remoteAddr을 리텅
     *
     * @param request
     */
    public static String getClientIp(HttpServletRequest request) {
        for (String header: IP_HEADER_LIST) {
            String ipFromHeader = request.getHeader(header);
            if (Objects.nonNull(ipFromHeader) && ipFromHeader.length() != 0 && !"unknown".equalsIgnoreCase(ipFromHeader)) {
                String ip = ipFromHeader.split(",")[0];
                return ip;
            }
        }
        return request.getRemoteAddr();
    }

}
