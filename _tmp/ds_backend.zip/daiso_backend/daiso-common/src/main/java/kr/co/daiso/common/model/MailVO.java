package kr.co.daiso.common.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : MailVO
 * author         : kjm
 * date           : 2022-01-05
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-05       kjm            최초생성
 */
@Data
public class MailVO {
    private boolean send;
    private String errorMessage;
}
