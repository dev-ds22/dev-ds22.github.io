package kr.co.daiso.common.exception;

import lombok.Builder;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;

/**
 * packageName    : kr.co.daiso.common.exception
 * fileName       : ErrorResponse
 * author         : leechangjoo
 * date           : 2021-11-09
 * description    : Error 응답 형태
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-09          leechangjoo         최초생성
 **/
@Getter
@Builder
public class ErrorResponse {
    private final LocalDateTime timestamp = LocalDateTime.now();
    private final int status;
    private final String error;
    private final String code;
    private final String message;

    public static ResponseEntity<ErrorResponse> toResponseEntity(HttpStatus httpStatus, String msg) {

        return ResponseEntity
                .status(httpStatus)
                .body(ErrorResponse.builder()
                        .status(httpStatus.value())
                        .error(httpStatus.name())
                        .message(msg)
                        .build()
                );
    }
}
