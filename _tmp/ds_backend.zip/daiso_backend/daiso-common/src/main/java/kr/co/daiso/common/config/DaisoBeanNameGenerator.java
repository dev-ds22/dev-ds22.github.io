package kr.co.daiso.common.config;

import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanNameGenerator;

/**
 * packageName    : kr.co.daiso.common.config
 * fileName       : DaisoBeanNameGenerator
 * author         : Doo-Won Lee
 * date           : 2022-01-13
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13      Doo-Won Lee         최초생성
 */
public class DaisoBeanNameGenerator implements BeanNameGenerator {

//    private final AnnotationBeanNameGenerator defaultGenerator = new AnnotationBeanNameGenerator();

    @Override
    public String generateBeanName(BeanDefinition definition, BeanDefinitionRegistry registry) {
        final String daisoBeanName;

        daisoBeanName = ((AnnotatedBeanDefinition)definition).getMetadata().getClassName();
        //daisoBeanName = this.defaultGenerator.generateBeanName(definition, registry);
        return daisoBeanName;
    }
}
