package kr.co.daiso.common.constants;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
/**
 * packageName    : kr.co.daiso.common.constants
 * fileName       : CommonConstants
 * author         : Doo-Won Lee
 * date           :
 * description    : 공통사용 상수 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13               최초생성
 */
@Slf4j
public class CommonConstants {

    private CommonConstants(){
        log.info("CommonConstants");
    }

    public static final String JWT_SECRET_KEY_FO = "JWT_SECRET_KEY_FO_KCAR_45678901234567890123";
    public static final String JWT_SECRET_KEY_ADMIN = "JWT_SECRET_KEY_ADMIN_KCAR_123e7827384456789";

    public static final String FO_ACCESS_TOKEN_NAME = "foAccessToken";                          // FO Access Token 이름
    public static final String FO_REFRESH_TOKEN_NAME = "foRefreshToken";                        // FO Refresh Token 이름
    public static final long FO_ACCESS_TOKEN_VALIDATION_SECOND = 1000L * 60 * 10;				// Access Token 유효기간
    public static final long FO_REFRESH_TOKEN_VALIDATION_SECOND = 1000L * 60 * 60 * 24;		    // Refresh Token 유효기간
    public static final String PREFIX_REDIS_KEY_FO_REFRESH = "fo:refresh:";                     // FO Refresh Token Redis Key Prefix
    public static final long FO_CSRF_TOKEN_VALIDATION_SECOND = 1000L * 60 * 60 * 24;


    public static final String ADMIN_ACCESS_TOKEN_NAME = "adminAccessToken";                          // FO Access Token 이름
    public static final String ADMIN_REFRESH_TOKEN_NAME = "adminRefreshToken";                        // FO Refresh Token 이름
    public static final long ADMIN_ACCESS_TOKEN_VALIDATION_SECOND = 1000L * 60 * 10;				// Access Token 유효기간
    public static final long ADMIN_REFRESH_TOKEN_VALIDATION_SECOND = 1000L * 60 * 60 * 24;		    // Refresh Token 유효기간
    public static final String PREFIX_REDIS_KEY_ADMIN_REFRESH = "admin:refresh:";                     // Admin Refresh Token Redis Key Prefix
    public static final String PREFIX_REDIS_KEY_ADMIN_MULTIACCESS = "admin:multiaccess:";             // AdminMultiAccess Token Redis Key Prefix
    public static final long ADMIN_CSRF_TOKEN_VALIDATION_SECOND = 1000L * 60 * 60 * 24;

    public static final int FO_AUTO_LOGIN_TOKEN_EXPIRE_DATE = 30;
    public static final String FO_AUTO_LOGIN_TOKEN_ENCRYPT_KEY = "daisob2c";


    public static final String APPLE_TOKEN_VALUE = "abcdefg12345";                              //KCAR APPLE TOKEN

    public static final String EXCEL_EXTENTION = ".xlsx";
    public static final String EXCEL_XLS_EXTENTION = "xls";
    public static final String EXCEL_XLSX_EXTENTION = "xlsx";


    public static final HttpStatus BAD_REQUEST = HttpStatus.BAD_REQUEST;
    public static final HttpStatus UNAUTHORIZED = HttpStatus.UNAUTHORIZED;
    public static final HttpStatus NOT_FOUND = HttpStatus.NOT_FOUND;
    public static final HttpStatus CONFLICT = HttpStatus.CONFLICT;

    public static final String REDIS_KEY_ADMIN_AUTH_GROUP = "admin:authgrp:types";      //관리자 접근 가능한 권한 그룹 타입
    public static final String REDIS_KEY_ADMIN_IP_LIST = "admin:logind:iplist";         //관리자 접근 가능한 IP목록

    public static final String SYSTEM_ID = "SYSTEM";
    public static final long LIMIT_SIZE_OF_UPLOAD =  1024*1024*15L;

    public static final String PC_WEB_AUTO_LOGIN_TOKEN = "fo:autoLogin:pc";
    public static final String MOBILE_WEB_AUTO_LOGIN_TOKEN =  "fo:autoLogin:mobileWeb";
    public static final String MOBILE_APP_AUTO_LOGIN_TOKEN =  "fo:autoLogin:mobileApp";
    public static final long AUTO_LOGIN_EXPIRE_TIME = 1000L * 60 * 60 * 24 * 30;

}
