package kr.co.daiso.common.util;

import kr.co.daiso.common.exception.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.lang.Nullable;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;

/**
 * packageName    : kr.co.daiso.mg.util
 * fileName       : KCarRestTemplate
 * author         : Doo-Won Lee
 * date           : 2021-11-04
 * description    : RestTemplate Helper 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-04      Doo-Won Lee     최초생성
 */
@Slf4j
public final class DaisoRestTemplate {

    private final int connectTimeOut = 5000*1;
    private final int readTimeOut = 5000*2;

    private boolean bAsync = false;
    private String url;
    private HttpMethod method = HttpMethod.POST;
    private RestTemplate restTemplate;

    //org.apache.http.client.HttpClient
    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

    public DaisoRestTemplate(String url) {
        this(url, HttpMethod.POST, false);
    }

    public DaisoRestTemplate(String url, HttpMethod method) {
        this(url, method, false);
    }

    public DaisoRestTemplate(String url, boolean bAsync) {
        this(url, HttpMethod.POST, bAsync);
    }


    public DaisoRestTemplate(String url, HttpMethod method, boolean bAsync) {
        this.url = url;
        this.method = method;
        this.bAsync = bAsync;

        requestFactory.setConnectTimeout(this.connectTimeOut);
        requestFactory.setReadTimeout(this.readTimeOut);

        this.restTemplate = new RestTemplate(requestFactory);
    }

    public ResponseEntity exchage(@Nullable Object data, @Nullable HttpHeaders headers, Class cls) throws CommonException {
        if (null == this.url) throw new CommonException("Url is Undefined ", HttpStatus.BAD_REQUEST);

        if (null == headers) headers = HttpHeaders.EMPTY;

        trustSelfSignedSSL();

        Date startDt = new Date();
        log.info("#### KCarRestTemplate.exchage.start: {}, {}, {}", this.url, startDt, startDt.getTime());
        ResponseEntity result = restTemplate.exchange(this.url, this.method
                , new HttpEntity<>(data, headers), cls);
        Date endDt = new Date();
        log.info("#### KCarRestTemplate.exchage.end: {}, {}, {}, {}", this.url, endDt, endDt.getTime(), endDt.getTime() - startDt.getTime());


        return result;
    }

    public ResponseEntity exchage(HttpMethod method, @Nullable Object data, @Nullable HttpHeaders headers, Class cls) throws CommonException {
        if (null == this.url) throw new CommonException("Url is Undefined ", HttpStatus.BAD_REQUEST);

        if (null == headers) headers = HttpHeaders.EMPTY;

        trustSelfSignedSSL();

        Date startDt = new Date();
        log.info("#### KCarRestTemplate.exchage.start: {}, {}, {}", this.url, startDt, startDt.getTime());
        ResponseEntity result = restTemplate.exchange(this.url, method
                , new HttpEntity<>(data, headers), cls);
        Date endDt = new Date();
        log.info("#### KCarRestTemplate.exchage.end: {}, {}, {}, {}", this.url, endDt, endDt.getTime(), endDt.getTime() - startDt.getTime());


        return result;
    }

    public ResponseEntity exchage(String url, HttpMethod method, @Nullable Object data, @Nullable HttpHeaders headers, Class cls) {
        this.url = url;
        this.method = method;
        if (null == headers) headers = HttpHeaders.EMPTY;

        trustSelfSignedSSL();

        Date startDt = new Date();
        log.info("#### KCarRestTemplate.exchage.start: {}, {}, {}", this.url, startDt, startDt.getTime());
        ResponseEntity result = restTemplate.exchange(this.url, this.method
                , new HttpEntity<>(data, headers), cls);
        Date endDt = new Date();
        log.info("#### KCarRestTemplate.exchage.end: {}, {}, {}, {}", this.url, endDt, endDt.getTime(), endDt.getTime() - startDt.getTime());


        return result;
    }

//    public List<HttpMessageConverter<?>> getMessageConverters() {
//        return this.restTemplate.getMessageConverters();
//    }

    public void trustSelfSignedSSL() {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {

//                public void checkClientTrusted(X509Certificate[] xcs,
//                                               String string) throws CertificateException {
//                }
//
//                public void checkServerTrusted(X509Certificate[] xcs,
//                                               String string) throws CertificateException {
//                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override
                public void checkClientTrusted(
                        X509Certificate[] arg0, String arg1)
                        throws CertificateException {
                    log.debug("checkClientTrusted");
                }

                @Override
                public void checkServerTrusted(
                        X509Certificate[] arg0, String arg1)
                        throws CertificateException {
                    log.debug("checkServerTrusted");
                }
            };
            ctx.init(null, new TrustManager[]{tm}, null);
            SSLContext.setDefault(ctx);
        } catch (Exception ex) {
            throw new RuntimeException("DaisoRestTemplate Exception ", ex);
        }
    }
}
