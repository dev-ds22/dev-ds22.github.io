package kr.co.daiso.common.util;


import org.apache.commons.lang3.math.NumberUtils;

import java.text.DecimalFormat;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : NumberUtil
 * author         : 이강욱
 * date           : 2022-05-06
 * description    : 숫자 유틸리티 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-06       이강욱         최초생성
 */
public class NumberUtil extends NumberUtils {
    private NumberUtil() {}

    public static int toInt(Integer value) {
        return (value == null) ? 0 : value.intValue();
    }

    public static int toInt(Object value) {
        return toInt(StringUtil.defaultString(value));
    }

    public static String format(long number, String pattern) {
        DecimalFormat formatter = new DecimalFormat(pattern);
        return formatter.format(number);
    }
}


