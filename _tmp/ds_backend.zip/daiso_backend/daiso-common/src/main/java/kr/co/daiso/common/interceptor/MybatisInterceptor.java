package kr.co.daiso.common.interceptor;

import kr.co.daiso.common.model.CommonPagingVo;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : MybatisInterceptor
 * author         : kjm
 * date           : 2021-12-01
 * description    : 마이바티스 쿼리 인터셉터
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01    kjm       최초생성
 */
@Intercepts({@Signature(
            type = Executor.class,
            method = "query",
            args = {  MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class})
})
public class MybatisInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {

        Object[] args = invocation.getArgs();
        MappedStatement mappedStatement = (MappedStatement) args[0];
        BoundSql boundSql = mappedStatement.getBoundSql(args[1]);
        String sql = boundSql.getSql().trim();

        if(boundSql.getParameterObject() instanceof CommonPagingVo) { // 파라미터가 페이징 타입인 경우만

            CommonPagingVo parameterObject = (CommonPagingVo) boundSql.getParameterObject();

            if(parameterObject.getTotal() != 0) { // 전체 개수가 정해진 쿼리만 페이징 조건 추가

                BoundSql newBoundSql = new BoundSql(
                        mappedStatement.getConfiguration(),
                        getPagingSQL(sql, (CommonPagingVo) boundSql.getParameterObject()),
                        boundSql.getParameterMappings(),
                        boundSql.getParameterObject());

                MappedStatement newMappedStatement = new MappedStatement.Builder(
                    mappedStatement.getConfiguration(),
                    mappedStatement.getId(),
                    param -> newBoundSql,
                    mappedStatement.getSqlCommandType()).resource(mappedStatement.getResource())
                                                        .fetchSize(mappedStatement.getFetchSize())
                                                        .statementType(mappedStatement.getStatementType())
                                                        .keyGenerator(mappedStatement.getKeyGenerator())
                                                        .timeout(mappedStatement.getTimeout())
                                                        .parameterMap(mappedStatement.getParameterMap())
                                                        .resultMaps(mappedStatement.getResultMaps())
                                                        .resultSetType(mappedStatement.getResultSetType())
                                                        .cache(mappedStatement.getCache())
                                                        .flushCacheRequired(mappedStatement.isFlushCacheRequired())
                                                        .useCache(mappedStatement.isUseCache())
                                                        .build();
                args[0] = newMappedStatement;
            }
        }
        return invocation.proceed();
    }

    // 페이징 조건 추가
    public String getPagingSQL(String sql, CommonPagingVo commonPagingVo) {
        StringBuilder sb = new StringBuilder("SELECT b.* FROM (\n    SELECT ROWNUM as RNUM, a.* FROM ( \n       ");
        sb.append(sql);
        sb.append(" ) a ) b \n");
        sb.append(" WHERE RNUM >= " + commonPagingVo.getFirstIndex() + " AND RNUM <= " + commonPagingVo.getLastIndex());
        return sb.toString();
    }
}
