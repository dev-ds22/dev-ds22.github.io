package kr.co.daiso.common.util;

import com.google.gson.Gson;
import kr.co.daiso.common.model.MailVO;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.Properties;

/**
 * packageName    : kr.co.daiso.mg.util
 * fileName       : MailUtil
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */
@Slf4j
@Component
public class MailUtil {

    private Properties mailProp;

    @Value("${mail.mailer_server}")
    private String mailerServer;

    @Value("${mail.mailer_userid}")
    private String mailerUserid;

    @Value("${mail.mailer_passwd}")
    private String mailerPasswd;

    public boolean initMailer() {

        boolean result = true;

        try {
            mailProp = new Properties();

            mailProp.put("mail.smtp.host", mailerServer);
            mailProp.put("mail.smtp.starttls.enable", "true");
            mailProp.put("mail.smtp.auth", "true");
//			mailProp.put("mail.transport.protocol", "smtp");
//			mailProp.put("mail.smtp.port", mailServerPort);
//			mailProp.setProperty("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");

            //인증없이
//			mailProp.put("mail.smtp.host", mailServerIp);
//			mailProp.put("mail.smtp.auth", "false");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

//    public boolean getProperties() {
//        boolean result = true;
//        try {
////            mailServerIp	= mailerServer;
////            mailUserId		= mailerUserid;
////            mailPasswd		= CmFunction.getStringValue(CmPathInfo.MAILER_PASSWD);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return result;
//    }

    /**
     * 메일 보내기
     * @param fromName
     * @param fromEmail
     * @param to
     * @param cc
     * @param title
     * @param content
     * @return
     */
    public MailVO send(String fromName, String fromEmail, String to, String cc, String title, String content) {
        return send(fromName, fromEmail, to, cc, title, content, null);
    }

    /**
     * 메일 보내기
     * @param fromName
     * @param fromEmail
     * @param to
     * @param cc
     * @param title
     * @param content
     * @param fileName
     * @return
     */
    public MailVO send(String fromName, String fromEmail, String to, String cc, String title, String content, String[] fileName) {

        log.info(" MailVO send start");

        MailVO mailVO = new MailVO();
        mailVO.setSend(true);

//        if (!initMailConfig()) {
//            mailVO.setSend(false);
//            mailVO.setErrorMessage("이메일 환경설정 내용을 찾을 수 없습니다.");
//            return mailVO;
//        }
        log.info(" initMailer check ----");
        if (!initMailer()) {
//            System.out.println(" email server setting fail ----");
            mailVO.setSend(false);
            mailVO.setErrorMessage("이메일 서버설정을 완료할 수 없습니다.");
            return mailVO;
        }
        //인증없이
        Session session = null;

        try {
            log.info(" try email sessoin -----------");
            session = Session.getInstance(mailProp, null);
            log.info(" email sessoin - OK----------");
        } catch (Exception e) {
            log.info(" mail 메일 초기화중 오류가 발생----------");
            e.printStackTrace();

            mailVO.setSend(false);
            mailVO.setErrorMessage("mail 메일 초기화중 오류가 발생했습니다.");
            return mailVO;
        }

        try {

            log.info("mail 메일 발송 정보 세팅  start----------");
            MimeMessage msg = new MimeMessage(session);
            Multipart mp = new MimeMultipart();
            MimeBodyPart msg_part = new MimeBodyPart();
            MimeBodyPart file_part = new MimeBodyPart();

            msg.setContentLanguage(new String[]{"EUC-KR", "8859_1", "UTF-8"});

            log.info(" mail from settting  start----------");
            // 보내는 사람 주소
            if (fromEmail != null && !fromEmail.equals("")) {
                fromName = MimeUtility.encodeText(fromName, "EUC-KR", "Q");
                msg.setFrom(new InternetAddress(fromName + "<" + fromEmail + ">"));

            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("보내는 사람 주소가 없습니다.");
                return mailVO;
            }

            // 스펨메일 방지용으로 추가
            InternetAddress[] address = {new InternetAddress(fromEmail)};
            msg.setReplyTo(address);

            log.info("mail receiver settting  start----------");
            // 받는 사람 주소
            if (to != null && !to.equals("")) {
                to = new String(to.replace(" ", "%20").getBytes("UTF-8"), "8859_1");
                msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("받을 사람 주소가 없습니다.");
                return mailVO;
            }

            log.info("mail cc settting  start----------");
            if (cc != null && !"".equals(cc)) {
                cc = new String(cc.replace(" ", "%20").getBytes("UTF-8"), "8859_1");
//                cc	= new String(CmFunction.replace(cc, " ", "%20").getBytes("UTF-8"), "8859_1");
                msg.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(cc, false));
            }

            log.info("mail title settting  start----------");
            // 메일 제목
            if (title != null && !"".equals(title)) {
                msg.setSubject(MimeUtility.encodeText(title, "EUC-KR", "Q"));
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("메일 제목이 없습니다.");
                return mailVO;
            }

            log.info("mail content settting  start----------");
            // 메일 내용
            if (content != null && !"".equals(content)) {
                msg_part.setContent(content, "text/html; charset=utf-8");
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("메일 내용이 없습니다.");
                return mailVO;
            }

            log.info("mail body settting  start----------");
            mp.addBodyPart(msg_part);

            if (fileName != null) {

                for (int i = 0; i < fileName.length; i++) {
//                    if ("".equals(CmFunction.getStringValue(fileName[i])))
                    if (Optional.ofNullable(fileName[i]).map(""::equals).orElse(false)) {
                        continue;
                    }
                    mp.addBodyPart(file_part);
                }
            }
            msg.setContent(mp);

            log.info("mail try try send start----------");
            if (mailVO.isSend()) {

                log.info("mail Transport connect start----------");
                Transport tr = session.getTransport("smtp");
                tr.connect(mailerServer, mailerUserid, mailerPasswd);
                //인증없이
//				tr.connect(mailServerIp, null);
                log.info("mail Transport send start----------");
                tr.sendMessage(msg, msg.getAllRecipients());
                log.info("mail Transport send finished----------");
                tr.close();
            }

        } catch (MessagingException e) {
            log.info("mail try try MessagingException----------:"+e);
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        } catch (IOException e) {
            log.info("mail try try IOException----------:"+e);
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        } catch (Exception e) {
            log.info("mail try try Exception----------:"+e);
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        }

        log.info("mail return =-------------------");
        return mailVO;
    }

    public MailVO send(String fromName, String fromEmail, String to, String cc, String title, String content, String[] fileName, String realFileName) {
        MailVO mailVO = new MailVO();
        mailVO.setSend(true);

//        if (!initMailConfig()) {
//            mailVO.setSend(false);
//            mailVO.setErrorMessage("이메일 환경설정 내용을 찾을 수 없습니다.");
//            return mailVO;
//        }

        if (!initMailer()) {
            mailVO.setSend(false);
            mailVO.setErrorMessage("이메일 서버설정을 완료할 수 없습니다.");
            return mailVO;
        }
        //인증없이
//		CmMailAuthenticator	mailAuth = new CmMailAuthenticator(mailUserId, mailPasswd);
        Session session = null;

        try {

            session = Session.getInstance(mailProp, null);

        } catch (Exception e) {
//			System.out.println("### CmMail.send ###");
            e.printStackTrace();

            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 초기화중 오류가 발생했습니다.");
            return mailVO;
        }

        try {

            MimeMessage msg = new MimeMessage(session);
            Multipart mp = new MimeMultipart();
            MimeBodyPart msg_part = new MimeBodyPart();
            MimeBodyPart file_part = new MimeBodyPart();

            msg.setContentLanguage(new String[]{"EUC-KR", "8859_1", "UTF-8"});

            // 보내는 사람 주소
            if (fromEmail != null && !fromEmail.equals("")) {
//				System.out.println("##보낸사람주소:"+fromEmail);

                //fromName	= new String(CmFunction.replace(fromName, " ", "%20").getBytes("UTF-8"), "8859_1");
                fromName = MimeUtility.encodeText(fromName, "EUC-KR", "Q");
                msg.setFrom(new InternetAddress(fromName + "<" + fromEmail + ">"));

            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("보내는 사람 주소가 없습니다.");
                return mailVO;
            }

            // 스펨메일 방지용으로 추가
            InternetAddress[] address = {new InternetAddress(fromEmail)};
            msg.setReplyTo(address);

            // 받는 사람 주소
            if (to != null && !to.equals("")) {
                to = new String(to.replace(" ", "%20").getBytes("UTF-8"), "8859_1");
//                to	= new String(CmFunction.replace(to, " ", "%20").getBytes("UTF-8"), "8859_1");
                msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("받을 사람 주소가 없습니다.");
                return mailVO;
            }

            if (cc != null && !"".equals(cc)) {
                cc = new String(cc.replace(" ", "%20").getBytes("UTF-8"), "8859_1");
//                cc	= new String(CmFunction.replace(cc, " ", "%20").getBytes("UTF-8"), "8859_1");
                msg.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(cc, false));
            }

            // 메일 제목
            if (title != null && !"".equals(title)) {
                msg.setSubject(MimeUtility.encodeText(title, "EUC-KR", "Q"));
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("메일 제목이 없습니다.");
                return mailVO;
            }

            // 메일 내용
            if (content != null && !"".equals(content)) {
                msg_part.setContent(content, "text/html; charset=utf-8");
            } else {
                mailVO.setSend(false);
                mailVO.setErrorMessage("메일 내용이 없습니다.");
                return mailVO;
            }

            mp.addBodyPart(msg_part);

            if (fileName != null) {
                for (int i = 0; i < fileName.length; i++) {
                    if (Optional.ofNullable(fileName[i]).map(""::equals).orElse(false)) {
                        continue;
                    }

//					FileDataSource fds	= new FileDataSource(fileName[i]);
//
//					file_part.setDataHandler(new DataHandler(fds));
//                    System.out.println("*********************"+fileName[i]+"**********************");
                    File targetFile = new File(fileName[i]);
//                    if (targetFile.isFile()){
//                        System.out.println("File right!!!!!!!!!!!!!!!!!!!!!!");
//                    }
//                    else{
//                        System.out.println("What?????????????????????");
//                    }

                    file_part.setFileName(MimeUtility.encodeText(realFileName, "EUC-KR", "Q"));
                    file_part.attachFile(targetFile);
                    mp.addBodyPart(file_part);
                }
            }
            msg.setContent(mp);

            if (mailVO.isSend()) {
                Transport tr = session.getTransport("smtp");
                tr.connect(mailerServer, mailerUserid, mailerPasswd);
                //인증없이
                tr.sendMessage(msg, msg.getAllRecipients());
                tr.close();
            }
            mailVO.setErrorMessage("전송완료");
        } catch (MessagingException e) {
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        } catch (IOException e) {
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        } catch (Exception e) {
            e.printStackTrace();
            mailVO.setSend(false);
            mailVO.setErrorMessage("메일 전송시 오류가 발생하였습니다");
            return mailVO;
        }

        return mailVO;
    }

    /**
     * 메일 보내기(IDC로 전달)
     * @param idcFoDomain
     * @param fromName
     * @param fromEmail
     * @param to
     * @param cc
     * @param title
     * @param content
     * @return
     */
    public MailVO idcSend(String idcFoDomain, String fromName, String fromEmail, String to, String cc, String title, String content) throws Exception{
        return idcSend(idcFoDomain, fromName, fromEmail, to, cc, title, content, null);
    }

    /**
     * 메일 보내기(IDC로 전달)
     * @param idcFoDomain
     * @param fromName
     * @param fromEmail
     * @param to
     * @param cc
     * @param title
     * @param content
     * @param fileName
     * @return
     */
    public MailVO idcSend(String idcFoDomain, String fromName, String fromEmail, String to, String cc, String title, String content, String[] fileName) throws Exception{

        log.info(" MailVO pass to  idc ");
        String idcFoUrl = idcFoDomain+ "/common/idcMailSendAssign";

        DaisoRestTemplate daisoRestTemplate = new DaisoRestTemplate(idcFoUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("fromName",fromName);
        body.add("fromEmail",fromEmail);
        body.add("to",to);
        body.add("cc",cc);
        body.add("title",title);
        body.add("content",content);
        if (null!=fileName && fileName.length>0){
            body.add("fileName",String.join(",",fileName));
        }
        else{
            body.add("fileName",null);
        }
        body.add("fileName",fileName);

        MailVO resultMailVo = new MailVO();


        JSONParser parser = new JSONParser();
        ResponseEntity idcResult = daisoRestTemplate.exchage(body, headers, String.class);

        log.info("idcResult = " + idcResult);

        JSONObject jsonOb = (JSONObject) parser.parse((String) idcResult.getBody());
//        return idcResult;
        boolean isSuccess = (boolean) jsonOb.get("success");

//        if (isSuccess) {
//            resultMailVo = (MailVO) jsonOb.get("data");
//        }

        if (isSuccess) {
            Gson gson = new Gson();
            log.info("idcResult datadatadatadata = " + jsonOb.get("data"));

            resultMailVo = gson.fromJson(jsonOb.get("data").toString(), MailVO.class);
        }

        return resultMailVo;
    }

    public MailVO idcSend(String idcFoDomain, String fromName, String fromEmail, String to, String cc, String title, String content, String[] fileName, String realFileName) throws Exception {

        log.info(" MailVO pass to  idc ");
        String idcFoUrl = idcFoDomain+ "/common/idcMailSendAssignWithFile";

        DaisoRestTemplate daisoRestTemplate = new DaisoRestTemplate(idcFoUrl);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("fromName",fromName);
        body.add("fromEmail",fromEmail);
        body.add("to",to);
        body.add("cc",cc);
        body.add("title",title);
        body.add("content",content);
        if (null!=fileName && fileName.length>0){
            body.add("fileName",String.join(",",fileName));
        }
        else{
            body.add("fileName",null);
        }
//        body.add("fileName",fileName);
        body.add("realFileName",realFileName);

        MailVO resultMailVo = new MailVO();


        JSONParser parser = new JSONParser();
        ResponseEntity idcResult = daisoRestTemplate.exchage(body, headers, String.class);

        log.info("idcResult = " + idcResult);

        JSONObject jsonOb = (JSONObject) parser.parse((String) idcResult.getBody());
//        return idcResult;
        boolean isSuccess = (boolean) jsonOb.get("success");

        if (isSuccess) {
            Gson gson = new Gson();
            log.info("idcResult datadatadatadata = " + jsonOb.get("data"));

            resultMailVo = gson.fromJson(jsonOb.get("data").toString(), MailVO.class);
        }

        return resultMailVo;

    }
}