package kr.co.daiso.common.annotation;

import java.lang.annotation.*;

/**
 * packageName    : kr.co.daiso.common.annotation
 * fileName       : MaskingClass
 * author         : Doo-Won Lee
 * date           : 2022-01-13
 * description    : Masking 필요한 클래스를 표시하기 위한 Annotation
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13      Doo-Won Lee       최초생성
 */
@Inherited
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface MaskingClass {

}

