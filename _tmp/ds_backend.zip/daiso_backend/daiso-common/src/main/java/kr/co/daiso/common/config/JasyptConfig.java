package kr.co.daiso.common.config;

import lombok.RequiredArgsConstructor;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanNameGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * packageName    : kr.co.daiso.common.config
 * fileName       : JasyptConfig
 * author         : Won-Tae Kim
 * date           : 2022-12-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-12-12      Won-Tae Kim   최초생성
 */
// @RequiredArgsConstructor
// @Configuration
public class JasyptConfig {
	
    private static final String ENCRYPT_KEY = "daiso_enc_k";

    @Bean("jasyptStringEncryptor")
    public StringEncryptor stringEncryptor(){
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(ENCRYPT_KEY);                                            //암호화에 사용할 key
        config.setAlgorithm("PBEWithMD5AndDES");                                    //사용할 알고리즘
        config.setKeyObtentionIterations("1000");                                   //해싱 횟수
        config.setPoolSize("1");                                                    //인스턴스 pool
        config.setProviderName("SunJCE");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator"); // salt 생성 클래스
        config.setIvGeneratorClassName("org.jasypt.iv.NoIvGenerator");
        config.setStringOutputType("base64");                                    //인코딩방식
        encryptor.setConfig(config);
        return encryptor;
    }

}
