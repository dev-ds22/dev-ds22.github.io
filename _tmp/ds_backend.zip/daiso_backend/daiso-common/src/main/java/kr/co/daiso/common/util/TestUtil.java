package kr.co.daiso.common.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestUtil {
    public void testPrint(){
        log.info("Test");
    }
}
