package kr.co.daiso.common.util;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * packageName    : kr.co.daiso.common.util
 * fileName       : StringUtil
 * author         : 이강욱
 * date           : 2022-04-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       이강욱         최초생성
 */
public class DateUtil extends DateUtils {
    private DateUtil() {}

    /**
     * 주어진 일시 문자열을 Date 객체로 변환
     *
     * @param dateString 일시 문자열
     * @param pattern DateFormat 패턴
     * @return Date 객체로 변환된 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static Date toDate(String dateString, String pattern) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        formatter.setTimeZone(TimeZone.getDefault());

        return formatter.parse(dateString);
    }

    /**
     * 주어진 Date 객체를 지정된 DateFormat 패턴 문자열로 변환
     *
     * @param date Date 객체
     * @param pattern DateFormat 패턴
     * @return DateFormat 패턴 문자열로 변환된 시간
     */
    public static String format(Date date, String pattern) {
        return DateFormatUtils.format(date, pattern);
    }

    /**
     * 현재일시를 주어진 패턴의 문자열로 가져온다.
     *
     * @param pattern DateFormat 패턴
     * @return 현재일시
     */
    public static final String getNowString(String pattern) {
        return format(new java.util.Date(), pattern);
    }

    /**
     * 현재일시에 지정된 년만큼 더한 일시를 가져온다.
     *
     * @param amount 년
     * @param pattern DateFormat 패턴
     * @return 지정된 년만큼 더한 일시
     */
    public static String addYears(int amount, String pattern)  {
        return format(addYears(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 년만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 년
     * @param pattern DateFormat 패턴
     * @return 지정된 년만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addYears(String dateString, int amount, String pattern) throws ParseException {
        return format(addYears(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 현재일시에 지정된 달만큼 더한 일시를 가져온다.
     *
     * @param amount 달
     * @param pattern DateFormat 패턴
     * @return 지정된 달만큼 더한 일시
     */
    public static String addMonths(int amount, String pattern) {
        return format(addMonths(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 달만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 달
     * @param pattern DateFormat 패턴
     * @return 지정된 달만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addMonths(String dateString, int amount, String pattern) throws ParseException {
        return format(addMonths(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 현재일시에 지정된 일만큼 더한 일시를 가져온다.
     *
     * @param amount 일
     * @param pattern DateFormat 패턴
     * @return 지정된 일만큼 더한 일시
     */
    public static String addDays(int amount, String pattern) {
        return format(addDays(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 일만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 일
     * @param pattern DateFormat 패턴
     * @return 지정된 일만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addDays(String dateString, int amount, String pattern) throws ParseException {
        return format(addDays(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 현재일시에 지정된 시간만큼 더한 일시를 가져온다.
     *
     * @param amount 시간
     * @param pattern DateFormat 패턴
     * @return 지정된 시간만큼 더한 일시
     */
    public static String addHours(int amount, String pattern) {
        return format(addHours(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 시간만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 시간
     * @param pattern DateFormat 패턴
     * @return 지정된 시간만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addHours(String dateString, int amount, String pattern) throws ParseException {
        return format(addHours(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 현재일시에 지정된 분만큼 더한 일시를 가져온다.
     *
     * @param amount 분
     * @param pattern DateFormat 패턴
     * @return 지정된 분만큼 더한 일시
     */
    public static String addMinutes(int amount, String pattern)  {
        return format(addMinutes(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 분만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 분
     * @param pattern DateFormat 패턴
     * @return 지정된 분만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addMinutes(String dateString, int amount, String pattern) throws ParseException {
        return format(addMinutes(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 현재일시에 지정된 초만큼 더한 일시를 가져온다.
     *
     * @param amount 초
     * @param pattern DateFormat 패턴
     * @return 지정된 초만큼 더한 일시
     */
    public static String addSeconds(int amount, String pattern)  {
        return format(addSeconds(new Date(), amount), pattern);
    }

    /**
     * 주어진 일시에 지정된 초만큼 더한 일시를 가져온다.
     *
     * @param dateString 일시 문자열
     * @param amount 초
     * @param pattern DateFormat 패턴
     * @return 지정된 초만큼 더한 일시
     * @throws ParseException 유효한 일시, 패턴이 아닌 경우
     */
    public static String addSeconds(String dateString, int amount, String pattern) throws ParseException {
        return format(addSeconds(toDate(dateString.substring(0, pattern.length()), pattern), amount), pattern);
    }

    /**
     * 주어진 일시 문자열의 요일을 얻는다.
     *
     * @param dateString 일시 문자열
     * @param pattern DateFormat 패턴
     * @return 요일 (Calendar.SUNDAY=1, Calendar.MONDAY=2, ..., Calendar.SATURDAY=7)
     * @throws ParseException
     */
    public static int getDayOfWeek(String dateString, String pattern) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(toDate(dateString, pattern));
        return calendar.get(Calendar.DAY_OF_WEEK);
    }
}
