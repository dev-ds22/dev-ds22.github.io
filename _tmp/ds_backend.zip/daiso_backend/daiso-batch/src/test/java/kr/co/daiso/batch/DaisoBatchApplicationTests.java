package kr.co.daiso.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaisoBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
