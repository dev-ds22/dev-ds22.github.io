package kr.co.daiso.batch.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class JobExecutionStorageListener implements JobExecutionListener {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void beforeJob(JobExecution jobExecution) {
        JobScopeUtil.setJobExecution(jobExecution);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        JobScopeUtil.clear();
    }
}
