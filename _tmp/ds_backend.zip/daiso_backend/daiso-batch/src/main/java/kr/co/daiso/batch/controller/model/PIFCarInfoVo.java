package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PIFCarInfoVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PIFCarInfoVo {

    @ApiModelProperty(value = "ifKey", required = true, notes = "인터페이스키를 입력해주세요", example = "52401241, 52401250, ...")
    @NotBlank(message="인터페이스키를 입력해주세요")
    private String ifKey;
}
