package kr.co.daiso.batch.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IFTbUpdateVo extends  DblinkVo{

    private String ifKey;
    private String iftb;
    private String procStatus;
    private String errMsg;
}
