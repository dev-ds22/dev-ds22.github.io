package kr.co.daiso.batch.mb.service.Impl;

import kr.co.daiso.batch.mb.mapper.oracle.UpdateMemberLeaveMapper;
import kr.co.daiso.batch.mb.service.UpdateMemberLeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * packageName    : kr.co.daiso.batch.mb.service.Impl
 * fileName       : UpdateMemberLeaveServiceImpl
 * author         : kjm
 * date           : 2022-04-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       kjm            최초생성
 */
@Service
public class UpdateMemberLeaveServiceImpl implements UpdateMemberLeaveService {

    @Autowired
    UpdateMemberLeaveMapper updateMemberLeaveMapper;

    @Override
    public void updateLeaveMember() {
        updateMemberLeaveMapper.updateLeaveMember();
    }

    @Override
    public void deleteSNSMapping() {
        updateMemberLeaveMapper.deleteSNSMapping();
    }
}
