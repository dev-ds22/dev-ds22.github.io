package kr.co.daiso.batch.sample.mapper.mysql;

import kr.co.daiso.batch.sample.model.SampleModel;

import java.util.List;

//Mysql을 사용하지 않아 사용 안함
//@Mapper
public interface SampleMysqlMapper {

    List<SampleModel> getSampleCode();

}
