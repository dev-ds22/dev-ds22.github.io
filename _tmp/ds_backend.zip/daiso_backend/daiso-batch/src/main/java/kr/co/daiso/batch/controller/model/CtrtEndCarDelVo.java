package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : CtrtEndCarDelVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@ToString
@Data
@EqualsAndHashCode(callSuper=false)
public class CtrtEndCarDelVo extends DblinkVo {

    private String bccSndCtrtNo;
    private String usrId;

    private String delerCoCd;
    private String showRoomCd;

    private String carCd;
}
