package kr.co.daiso.batch.mb.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.mb.model
 * fileName       : UserVO
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */

@Data
public class MemberVO {
    private String membCd;
    private String membKnd;
    private String membId;
    private String pwd;
    private String membNm;
    private String atclAgreYn;
    private String indvInfoAgreYn;
    private String birdt;
    private String nicknm;
    private String ctad;
    private String mbpno;
    private String email;
    private String emailRcvAgreYn;
    private String phtoNm;
    private String phtoPath;
    private String phtoExt;
    private String intrst;
    private String etcInq;
    private String cdno;
    private String wtdrYn;
    private String wtdrDt;
    private String wtdrRsn;
    private String sex;
    private String joinChnl;
    private String chmuId;
    private String moblcrr;
    private String sidoDvs;
    private String carKnd;
    private String mnuftr;
    private String model;
    private String grd;
    private String dtlGrd;
    private String smsRcvAgreYn;
    private String ovlapKey;
    private String indvInfoChcAgreYn;
    private String pwdErrCnt;
    private String usrRgn;
    private String joinPath;
    private String joinPathDrectInp;
    private String fnlCnntnDt;
    private String pchsHopeDd;
    private String dlercoCd;
    private String shwroomCd;
    private String dealEmpcrdNo;
    private String fstLoginYn;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;
    private String adaptSrcCarUse;
    private String adaptSrcPrefCarctgr;
    private String adaptSrcPchsBdgt;
    private String adaptSrcRgnCd;
    private String adaptSrcAgegCd;
    private String adaptSrcSex;
}
