package kr.co.daiso.batch.jobs.mb;

import kr.co.daiso.batch.mb.service.IndvInfoUseBkdnNtfyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class IndvInfoUseBkdnNtfyJob {

    @Autowired
    JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    IndvInfoUseBkdnNtfyService indvInfoUseBkdnNtfyService;

    private final String JOB_NAME = "indvInfoUseBkdnNtfyJob";
    private final String STEP_NAME = JOB_NAME + "_step";

    @Bean(JOB_NAME)
    public Job indvInfoUseBkdnNtfyJob(){
        return jobBuilderFactory.get(JOB_NAME)
                .incrementer(new RunIdIncrementer())
                .start(indvInfoUseBkdnNtfyStep())
                .build();
    }

    @Bean
    @JobScope
    public Step indvInfoUseBkdnNtfyStep(){
        return stepBuilderFactory.get(STEP_NAME)
                .tasklet((contribution, chunkContext) -> {
                    indvInfoUseBkdnNtfyService.indvInfoUseBkdnNtfySend();
                    return RepeatStatus.FINISHED;
                })
                .build();
    }
}
