package kr.co.daiso.batch.common.service.impl;

import kr.co.daiso.batch.common.mapper.oracle.CommonCodeManageOracleMapper;
import kr.co.daiso.batch.common.service.CommonCodeService;
import kr.co.daiso.batch.common.model.CommonCodeManageVO;
import kr.co.daiso.batch.common.model.CommonCodeSearchVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.common.service.impl
 * fileName       : CommonCodeServiceImpl
 * author         :
 * date           : 2022-05-24
 * description    : CommonCodeService 구현체 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-24                최초생성
 */
@Service
public class CommonCodeServiceImpl implements CommonCodeService {

    @Autowired
    CommonCodeManageOracleMapper commonCodeManageMapper;
    /**
     * methodName : getSubCodeListCount
     * author : Doo-Won Lee
     * description : 서브 코드의 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int getSubCodeListCount(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getSubCodeListCount(searchVo);
    }

    /**
     * methodName : getSubCodeList
     * author : Doo-Won Lee
     * description : 서브 코드의 목록을 구한다
     *
     * @param searchVo
     * @return List<CommonCodeManageVo>
     */
    @Override
    public List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getCmSubCodeList(searchVo);
    }

    @Override
    public List<CommonCodeManageVO> getSubCodeListByMasterCd(String masterCd) {
        CommonCodeSearchVO searchVo = new CommonCodeSearchVO();
        searchVo.setSMstCode(masterCd);
        return commonCodeManageMapper.getCmSubCodeList(searchVo);
    }

    @Override
    public List<CommonCodeManageVO> getSubCodeList(String sMstCode) {
        CommonCodeSearchVO searchVo = new CommonCodeSearchVO();
        searchVo.setSMstCode(sMstCode);
        return commonCodeManageMapper.getCmSubCodeList(searchVo);
    }

    /**
     * 첫번째 서브 코드를 가져온다.
     */
    public CommonCodeManageVO getFirstSubCode(CommonCodeSearchVO searchVo) {
        List<CommonCodeManageVO> subCodeList = commonCodeManageMapper.getCmSubCodeList(searchVo);
        return (subCodeList == null) ? null :  subCodeList.get(0);
    }
}
