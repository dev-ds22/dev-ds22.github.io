package kr.co.daiso.batch.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;

/**
 * Rest 통신 처리에 대한 기본 Timeout을 지정한 모듈이다.
 */
@Configuration
public class CmRestTemplateConfig {

    // 기본 타임아웃 20초
    private static final int CONN_TIMEOUT = 5000 * 10;
    private static final int READ_TIMOUT  = 5000 * 10;

    @Bean("CmRestTemplate")
    public RestTemplate simpleRestTemplate() {
        SimpleClientHttpRequestFactory httpRequestFactory = new SimpleClientHttpRequestFactory();

        httpRequestFactory.setConnectTimeout(CONN_TIMEOUT);
        httpRequestFactory.setReadTimeout(READ_TIMOUT);

        RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));

        return restTemplate;
    }

    // 비동기 통신용 TaskExecutor 빈 작성
    @Bean("CmAsyncRestTemplate")
    public AsyncRestTemplate simpleAsyncRestTemplate() {
        ThreadPoolTaskScheduler taskExecutor = new ThreadPoolTaskScheduler();
        taskExecutor.setPoolSize(20);
        taskExecutor.setThreadNamePrefix("AsyncRestTemplate Thread_");
        taskExecutor.initialize();

        SimpleClientHttpRequestFactory httpRequestFactory = new SimpleClientHttpRequestFactory();

        httpRequestFactory.setConnectTimeout(CONN_TIMEOUT);
        httpRequestFactory.setReadTimeout(READ_TIMOUT);
        httpRequestFactory.setTaskExecutor(taskExecutor);

        return new AsyncRestTemplate(httpRequestFactory);
    }
}
