package kr.co.daiso.batch.common.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : CommonPathInfo
 * author         : kjm
 * date           : 2022-02-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15       kjm            최초생성
 */
@Component
public class CommonPathInfo {

    public static String ROOT_FULL_URL;

    //SMS 발송 관련
    public static String CAR_INFO_FROM_SMS_TITLE;
    public static String CAR_INFO_FROM_SMS;

    public static String	ROOT_FULL_SSL;

    /** 도메인 이후 url */
    public static String IF_UCMS_URL_AFTER;

    // 가상계좌 확인 API
    public static String VIRTUAL_AC_DATA;

    /** 확인 url */
    public static String CAPITAL_API_URL;

    /** 확인 url url뒤 */
    public static String CAPITAL_URL_CHECK;


    @Value("${pms_full_ssl}")
    public void setRootFullUrl(String rootFullUrl) {
        ROOT_FULL_URL = rootFullUrl;
    }

    @Value("${sms.car_info_from_sms_title}")
    public void setCarInfoFromSmsTitle(String carInfoFromSmsTitle) { CAR_INFO_FROM_SMS_TITLE = carInfoFromSmsTitle; }

    @Value("${sms.car_info_from_sms}")
    public void setCarInfoFromSms(String carInfoFromSms) { CAR_INFO_FROM_SMS = carInfoFromSms;  }

    @Value("${pms_full_ssl}")
    public void setRootFullSsl(String rootFullSsl) {
        ROOT_FULL_SSL = rootFullSsl;
    }

    @Value("${if_ucms_url_after}")
    public void setIfUcmsUrlAfter(String ifUcmsUrlAfter) { IF_UCMS_URL_AFTER = ifUcmsUrlAfter; }

    @Value("${ac.virtual_ac_data}")
    public void setVirtualAcData(String virtualAcData) { VIRTUAL_AC_DATA = virtualAcData;}

    @Value("${capital.capital_api_url}")
    public void setCapitalApiUrl(String capitalApiUrl) { CAPITAL_API_URL = capitalApiUrl; }

    @Value("${capital.capital_url_check}")
    public void setCapitalUrlCheck(String capitalUrlCheck) { CAPITAL_URL_CHECK = capitalUrlCheck; }


    public static String 	CHARSET		= "UTF-8";

    // IF_UCMS_URL
    // 인터페이스 용 url
    public static String IF_UCMS_URL; // url 도메인

    public static String STATUS;

    public static String CONTAINER;
}
