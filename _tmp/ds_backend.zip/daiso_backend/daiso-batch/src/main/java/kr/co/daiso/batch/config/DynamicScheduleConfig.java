package kr.co.daiso.batch.config;

import kr.co.daiso.batch.controller.model.PThemeExhbtMgtVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.batik.transcoder.keys.StringKey;
import org.apache.commons.lang3.StringUtils;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.JobLocator;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

/**
 * packageName    : kr.co.daiso.batch.config
 * fileName       : DynamicScheduleConfig
 * author         : chungwoo35
 * date           : 2022-04-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-14          chungwoo35         최초생성
 */
@Slf4j
@Component
public class DynamicScheduleConfig {

    public  Scheduler scheduler;
    private SchedulerFactory schedulerFactory;
    private SchedulerFactoryBean schedulerFactoryBean;

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private JobLocator jobLocator;

    @Qualifier("themeExbt")
    private Job job;

    @Autowired
    ApplicationContext applicationContext;

    @PostConstruct
    public void dynamicSchedulerStart() throws SchedulerException{

        schedulerFactory = new StdSchedulerFactory();
        this.scheduler = schedulerFactory.getScheduler();
        this.scheduler.start();
    }


    public JobDetail makeJobDetail(String jobName,  PThemeExhbtMgtVO themeExhbtMgtVO){

        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("jobName", jobName);
        jobDataMap.put("jobLauncher", jobLauncher);
        jobDataMap.put("jobLocator", jobLocator);
        jobDataMap.put("triggerName", jobName);
        jobDataMap.put("themeExhbtMgtVO", themeExhbtMgtVO);
        jobDataMap.put("applicationContext", applicationContext);
        log.info("applicationContext : {}", applicationContext);

        return JobBuilder.newJob(DaisoQuartzJob.class)
                .setJobData(jobDataMap)
                .withIdentity(jobName)
                .build();
    }

        public JobDetail makeJobDetail(Job job){
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("jobName", job.getName());

        jobDataMap.put("jobLauncher", jobLauncher);
        jobDataMap.put("jobLocator", jobLocator);

        return JobBuilder.newJob(DaisoQuartzJob.class)
                .setJobData(jobDataMap)
                .withIdentity(job.getName())
                .build();
    }

    public Trigger makeJobTrigger(JobDetail jobDetail, String jobName, String cronStr){
        return TriggerBuilder.newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobName)
                .withDescription(cronStr)
                .withSchedule(CronScheduleBuilder.cronSchedule(cronStr))
                .build();
    }

    public JobKey findJobByJobName(String jobName){
        try {
            for (JobKey jobKey : this.scheduler.getJobKeys(null)) {
                if (StringUtils.equalsIgnoreCase(jobKey.getName(), jobName)){
                    return jobKey;
                }
            }
        }catch (SchedulerException se){
            log.error("[[ERROR]] findJobByJobName !!! | jobId: {} | msg: {}",jobName,  se.getMessage());
        }
        return null;
    }

    public List<Map<String, Object>> listJobTrigger() throws SchedulerException {
        List<Map<String, Object>> out = new ArrayList<>() ;

        for (String name : this.scheduler.getTriggerGroupNames())
        {
            log.info("name:{}", name);
            Set<TriggerKey> keys = this.scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(name));

            Trigger trigger;
            for(TriggerKey triggerkey : keys){
                trigger = this.scheduler.getTrigger(triggerkey);
                log.info("trigger:{}", trigger);
                log.info("getJobKey:{}", trigger.getJobKey());
                log.info("getPreviousFireTime:{}", trigger.getPreviousFireTime());
                log.info("trigger starttime:{}", trigger.getStartTime());
                log.info("trigger nexttime:{}", trigger.getNextFireTime());
                log.info("getDescription:{}", trigger.getDescription());

                Map<String, Object> map = new HashMap<>();
                map.put("name", trigger.getJobKey());
                map.put("starttime", trigger.getStartTime());
                map.put("prevtime", trigger.getPreviousFireTime());
                map.put("nexttime", trigger.getNextFireTime());
                map.put("desc", trigger.getDescription());
                out.add(map);
            }
        }
        return out;
    }


    public List<String> listJobName() {
        List<String> out = new ArrayList<>();

        try {
            for (JobKey jobKey : this.scheduler.getJobKeys(null)) {
                out.add(jobKey.getName());
            }
            return out;
        }catch (SchedulerException se){
            log.error("[[ERROR]] findJobByJobName !!! | msg: {}",se.getMessage());
        }
        return null;
    }


    public boolean addJob(String jobName, String cronStr, PThemeExhbtMgtVO themeExhbtMgtVO){
        try {
            JobDetail jobDetail = makeJobDetail(jobName, themeExhbtMgtVO);
            Trigger trigger = makeJobTrigger(jobDetail, jobName, cronStr);

            this.scheduler.scheduleJob(jobDetail, trigger);
        }
        catch (SchedulerException se){
            log.error("[[ERROR]] addJob !!! | jobId: {} | msg: {}", jobName,  se.getMessage());
            return false;
        }
        return true;
    }

    public boolean updateJob(String jobName,String cronStr, PThemeExhbtMgtVO themeExhbtMgtVO) {
        try {
            JobDetail jobDetail = makeJobDetail(jobName, themeExhbtMgtVO);
            Trigger trigger = makeJobTrigger(jobDetail, jobName,cronStr);
            scheduler.rescheduleJob(new TriggerKey(jobName), trigger);
        } catch (Exception se) {
            log.error("[[ERROR]] updateJob !!! | jobId: {} | msg: {}", jobName,  se.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteJob(String jobName){
        try {
            this.scheduler.deleteJob(findJobByJobName(jobName));
            return true;
        } catch (SchedulerException se){
            log.error("[[ERROR]] deleteJob !!! | jobId: {} | msg: {}", jobName,  se.getMessage());
            return false;
        }
    }

}
