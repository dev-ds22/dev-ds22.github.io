package kr.co.daiso.batch.jobs.mb;

import kr.co.daiso.batch.config.DuplicateJobCheckListener;
import kr.co.daiso.batch.mb.service.UpdateMemberLeaveService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * packageName    : kr.co.daiso.batch.jobs.mb
 * fileName       : UpdateMemberLeaveJob
 * author         : kjm
 * date           : 2022-04-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       kjm            최초생성
 */
@Slf4j
@Configuration
public class UpdateMemberLeaveJob {

    @Autowired
    JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    SqlSessionFactory sqlSessionFactory;

    @Autowired
    UpdateMemberLeaveService updateMemberLeaveService;

    private String updateMemberLeaveJobName = "UpdateMemberLeaveJob";
    private String updateMemberLeaveStepName = "UpdateMemberLeaveStep";

    private String deleteSNSMappingStepName = "DeleteSNSMappingStep";

    @Bean
    public Job updateMemberLeaveJob(DuplicateJobCheckListener sampelJobListener, Step updateMemberLeaveStep, Step deleteSNSMappingStep) {
        return jobBuilderFactory.get(updateMemberLeaveJobName)
                .incrementer(new RunIdIncrementer())
                .flow(updateMemberLeaveStep)
                .next(deleteSNSMappingStep)
                .end()
                .build();
    }

    @Bean
    @JobScope
    public Step updateMemberLeaveStep() {
        return stepBuilderFactory.get(updateMemberLeaveStepName)
                .tasklet((contribution, chunkContext) -> {
                    updateMemberLeaveService.updateLeaveMember();
                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    @JobScope
    public Step deleteSNSMappingStep() {
        return stepBuilderFactory.get(deleteSNSMappingStepName)
                .tasklet((contribution, chunkContext) -> {
                    updateMemberLeaveService.deleteSNSMapping();
                    return RepeatStatus.FINISHED;
                })
                .build();
    }
}
