package kr.co.daiso.batch.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.CodeSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import java.util.HashMap;
import java.util.Map;

//@Aspect
//@Component
@Slf4j
public class ParameterAop {

    @Pointcut("execution(* kr.co.daiso.batch.controller.procedure.*Controller.*(..))")
    public void onRequest() { }

    @Pointcut("@annotation(org.springframework.web.bind.annotation.PostMapping)")
    public void postMapping() {}

    @Around("postMapping()")
    public Object ParameteAction(ProceedingJoinPoint joinPoint) throws Throwable {

        StopWatch stopWatch = new StopWatch();
	    stopWatch.start();

        Object result = null;
        try {
            result = joinPoint.proceed(joinPoint.getArgs());
            return result;
        } finally {
            ObjectMapper objectMapper = new ObjectMapper();
            stopWatch.stop();
            log.info("====================================================================");
            log.info("info: {}.{}",  joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
            log.info("parameters : {}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(params(joinPoint)));
            log.info("response : {}", objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result));
            log.info("controller time: {}", stopWatch.getTotalTimeMillis());
            log.info("controller time: {}", stopWatch.prettyPrint());
            log.info("====================================================================");
        }
    }

    private Map<String, Object> params(JoinPoint joinPoint) {
      CodeSignature codeSignature = (CodeSignature) joinPoint.getSignature();
      String[] parameterNames = codeSignature.getParameterNames();
      Object[] args = joinPoint.getArgs();
      Map<String, Object> params = new HashMap<>();
      for (int i = 0; i < parameterNames.length; i++) {
          params.put(parameterNames[i], args[i]);
      }
      return params;
    }
}
