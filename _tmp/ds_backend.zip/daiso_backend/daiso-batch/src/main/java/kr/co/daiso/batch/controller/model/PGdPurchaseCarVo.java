package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.fo.api.procedure.model
 * fileName       : PGdPurchaseCarVo
 * author         : m2m0020
 * date           : 2022-05-04
 * description    : TB_GD_PURCHASE_CAR VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-04          m2m0020         최초생성
 **/
@Data
public class PGdPurchaseCarVo {
    @ApiModelProperty(value = "제조사 코드")
    @NotBlank(message="MNUFTR_CD_NOT_FOUND")
    private String mnuftrCd; //makeCd;

    @ApiModelProperty(value = "모델 코드")
    @NotBlank(message="MODEL_CD_NOT_FOUND")
    private String modelCd;

    @ApiModelProperty(value = "등급코드")
    @NotBlank(message="GTD_CD_NOT_FOUND")
    private String grdCd; //classHeadCd;

    @ApiModelProperty(value = "호출자 ID")
    @NotBlank(message="CLOUT_PSN_ID_NOT_FOUND")
    private String cloutPsnId;

}
