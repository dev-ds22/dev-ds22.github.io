package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : DblinkVo
 * author         : m2m0020
 * date           : 2022-04-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-11     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class DblinkVo {

    @ApiModelProperty(notes = "DBLINK", hidden = true)
    private String dblink;
}
