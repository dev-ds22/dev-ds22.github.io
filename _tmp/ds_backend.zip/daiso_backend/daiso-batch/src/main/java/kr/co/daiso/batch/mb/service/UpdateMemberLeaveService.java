package kr.co.daiso.batch.mb.service;

/**
 * packageName    : kr.co.daiso.batch.mb.service
 * fileName       : UpdateMemberLeaveService
 * author         : kjm
 * date           : 2022-04-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       kjm            최초생성
 */
public interface UpdateMemberLeaveService {
    void updateLeaveMember();

    void deleteSNSMapping();
}
