package kr.co.daiso.batch.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : CommonExVo
 * author         : rms
 * date           : 2022-02-10
 * description    : 공통 VO 추가
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-10     rms             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonExVo extends CommonVo{

    private String cno;
}