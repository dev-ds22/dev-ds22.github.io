package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : IFCarInfoVo
 * author         : m2m0020
 * date           : 2022-04-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-06     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class IFCarInfoVo extends CommonVo {

    private String carId;

    private String carCd;

    private String ifKey;

    private String carNumber;
    
    private String carHistNo;

    private String parameter;


    private String newPhotoUrl;
    private String new3dPhotoUrl;

    private String phtoViewType;
    private String aplySiteDcd;
    private String dgnosScrAplyYn;
    private String vElanRgsid;
    private String upldStatCd;
    private String rentStatCd;

    private int tmpCnt;
    private int tmpCnt3;

    private String carImgVer;

    private List<String> photoPathList;

    private String statCd;
    private String stckYn;

    private String vCarCd;

    private String wrkId;
    private String pkVal;

    private String rentCarCd;
    private String rentType;

    private String aplpsNm;     //  관심차량 알림
    private String membId;      //  관심차량 알림 아이디

}
