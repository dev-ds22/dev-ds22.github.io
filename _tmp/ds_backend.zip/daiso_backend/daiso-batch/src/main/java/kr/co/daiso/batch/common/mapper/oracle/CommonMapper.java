package kr.co.daiso.batch.common.mapper.oracle;


import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommonMapper {


    List<String> selectJobNames();
}
