package kr.co.daiso.batch.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : ClsCommonReqVO
 * author         : bsj
 * date           : 2022-02-03
 * description    : 공통코드 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       bsj           최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ClsCommonReqVO implements Serializable {

    private static final long serialVersionUID = -2279590516095352806L;

    //Code 공통정보
    private String	ucmsCdYn;       //Ucms 사용여부
    private String	useYn;          //사용여부
    private String	delYn;          //삭제여부
    private String  rgpsId;         //등록자 ID
    private String  regDttm;        //등록일시
    private String  mdpsId;         //최종수정자 ID
    private String  modDttm;        //최종수정일시

    //마스터코드 정보
    private String	masterCd;       //마스터 코드
    private String	masterCdNm;     //마스터 코드명
    private String	masterCdEngNm;  //마스터 코드 영문명

    //서브코드 정보
    private String	subCd;          //서브코드
    private String	subCdNm;        //서브코드명
    private String	subCdEngNm;     //서브코드 영문명
    private int sortOrdr;           //순번
    private String hrnkGrpCd;       //상위 그룹코드

    private String	addtFld1;       //추가 필드1
    private String	addtFld2;       //추가 필드2
    private String	addtFld3;       //추가 필드3

    private String	addtFld11;      //추가 필드11
    private String	addtFld12;      //추가 필드12
    private String	addtFld13;      //추가 필드13
    private String	addtFld14;      //추가 필드14
    private String	addtFld15;      //추가 필드15
    private String	addtFld16;      //추가 필드16
    private String	addtFld17;      //추가 필드17
    private String	addtFld18;      //추가 필드18

    private String	i_sTranPhone;
    private String	i_sTranCallBack;
    private String	i_sMessage;
    private String	i_sFlagStatus;
    private String	i_sReceiverCd;

    private String	i_sTitle;
    private String  s_REQUEST_TIME;
    private String s_MT_PR;

    public SmsVO toSmsVo() {
        SmsVO smsVo = new SmsVO();
        smsVo.setText(this.i_sMessage);
        smsVo.setDstaddr(this.i_sTranPhone);
        smsVo.setCallback(this.i_sTranCallBack);
        smsVo.setSubject(this.i_sTitle);
        smsVo.setRequestTime(this.s_REQUEST_TIME);
        smsVo.setMtPr(this.s_MT_PR);
        smsVo.setReceiverCd(this.i_sReceiverCd);

        return smsVo;
    }

}
