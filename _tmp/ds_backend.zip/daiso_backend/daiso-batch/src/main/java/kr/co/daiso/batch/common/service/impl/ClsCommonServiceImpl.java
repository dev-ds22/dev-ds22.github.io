package kr.co.daiso.batch.common.service.impl;

import kr.co.daiso.batch.common.mapper.oracle.CommonMapper;
import kr.co.daiso.batch.common.model.TbSmSmsSendLogVO;
import kr.co.daiso.batch.common.service.ClsCommonService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.common.service.impl
 * fileName       : ClsCommonServiceImpl
 * author         : bsj
 * date           : 2022-02-04
 * description    : 공통작업 인터페이스 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-04     bsj             최초생성
 */
@Slf4j
@Service
@Transactional
public class ClsCommonServiceImpl implements ClsCommonService {

    @Autowired
    CommonMapper commonMapper;

    public ClsCommonServiceImpl() {
    }

    @Override
    public void insertSms(TbSmSmsSendLogVO reqVo) {
        /**
         * TODO...
         * SMS 실전송
         */
    }

    @Override
    public List<String> selectJobNames() {
        return commonMapper.selectJobNames();
    }
}


