package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.fo.api.procedure.model
 * fileName       : GdPurchaseCarVo
 * author         : m2m0020
 * date           : 2022-02-18
 * description    : TB_GD_PURCHASE_CAR VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-18          m2m0020         최초생성
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class GdPurchaseCarVo extends CommonVo {

    @ApiModelProperty(value = "CAR_ID")
    private String cntrCd;

    @ApiModelProperty(value = "제조사 코드")
    @NotBlank(message="MNUFTR_CD_NOT_FOUND")
    private String mnuftrCd; //makeCd;

    @ApiModelProperty(value = "모델 코드")
    @NotBlank(message="MODEL_CD_NOT_FOUND")
    private String modelCd;

    @ApiModelProperty(value = "등급코드")
    @NotBlank(message="GTD_CD_NOT_FOUND")
    private String grdCd; //classHeadCd;

    @ApiModelProperty(value = "호출자 ID")
    @NotBlank(message="CLOUT_PSN_ID_NOT_FOUND")
    private String cloutPsnId;

    @ApiModelProperty(value = "결과코드")
    private String resultCd;

    @ApiModelProperty(value = "업데이트수")
    private int updateCnt;
}