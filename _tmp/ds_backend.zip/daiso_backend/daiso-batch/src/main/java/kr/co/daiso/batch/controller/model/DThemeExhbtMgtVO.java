package kr.co.daiso.batch.controller.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DThemeExhbtMgtVO {

    @ApiModelProperty(value = "테마기획전 순번")
    @NotBlank(message="테마기획전 순번을 입력해 주세요")
    private String themeExhbtSq;

    @ApiModelProperty(value = "UserId")
    @NotBlank(message="UserId를 입력해 주세요")
    private String userId;
}
