package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarCalcVo
 * author         : m2m0020
 * date           : 2022-04-26
 * description    : RcCarCalcVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-26     m2m0020             최초생성
 */
@Data
public class RcCarCalcVo {
    private String rentCarCd;
    private String rentPerdCd;
    private double accbkAcqPrcst;
    private double roic;
    private int dprexp20000;
    private int dprexp30000;
    private int fxcst;
    private double carInsfee;
    private int carTax;
    private int mantCost20000;
    private int mantCost30000;
    private int tourMantCost20000;
    private int tourMantCost30000;
    private int lwprMantCost20000;
    private int lwprMantCost30000;
    private double garageCost;
    private int etcVarcst;
    private int agCmsn;
    private String ecCarCd;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;
}
