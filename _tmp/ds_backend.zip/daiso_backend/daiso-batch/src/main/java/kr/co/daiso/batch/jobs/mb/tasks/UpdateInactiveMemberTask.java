package kr.co.daiso.batch.jobs.mb.tasks;

import kr.co.daiso.batch.mb.service.InactiveMemberService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * packageName    : kr.co.daiso.batch.jobs.sample.tasks
 * fileName       : UpdateInactiveMemberTask
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */
@Slf4j
@Component
@StepScope
public class UpdateInactiveMemberTask implements Tasklet, StepExecutionListener {

    @Autowired
    InactiveMemberService inactiveMemberService;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("*** UpdateInactiveMemberTask ***");
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return ExitStatus.COMPLETED;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        inactiveMemberService.insertEmailQueueTarget(); // 1. 휴면회원 예정메일
        inactiveMemberService.insertEmailQueue();       // 2. 휴면회원 전환메일
        inactiveMemberService.getInactiveMemberList().forEach(memberVO -> {
            inactiveMemberService.insertInactiveMember(memberVO); // 3. 휴면회원 테이블로 분리
            inactiveMemberService.deleteInactiveMember(memberVO); // 4. 분리회원 삭제
        });

        return RepeatStatus.FINISHED;
    }
}
