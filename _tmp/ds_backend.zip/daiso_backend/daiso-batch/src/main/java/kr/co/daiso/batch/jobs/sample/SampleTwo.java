package kr.co.daiso.batch.jobs.sample;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
//@Configuration
public class SampleTwo {

    @Autowired
    JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    SqlSessionFactory sqlSessionFactory;

    String jobName = "SampleTwo";

    String stepName1 = "stepName100";

    @Bean
    public Job SampleTwoJob(){
        return jobBuilderFactory.get(jobName)
                .incrementer(new RunIdIncrementer())
                .flow(sampleTwoStep1())
                //.next(sampleStep2())
//                .next(sampleStep3())
                .end()
                .build();
    }


    @Bean
    @JobScope
    public Step sampleTwoStep1(){
        return stepBuilderFactory.get(stepName1)
                .tasklet((contribution, chunkContext) -> {
                    for(int idx = 0 ; idx < 10 ; idx++) {
                        log.info("[SampleTwoName] : " + idx);
                    }
                    return RepeatStatus.FINISHED;
                })
                .build();
    }
}
