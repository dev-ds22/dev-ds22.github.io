package kr.co.daiso.batch.mb.mapper.oracle;

import kr.co.daiso.batch.mb.model.MailQueueVO;
import kr.co.daiso.batch.mb.model.MemberVO;
import kr.co.daiso.batch.mb.model.SubCdVO;
import org.mybatis.spring.annotation.MapperScan;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.mb.mapper.oracle
 * fileName       : InactiveMemberMapper
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */

@MapperScan
public interface InactiveMemberMapper {
    List<MemberVO> getInactiveMemberList();

    void insertInactiveMember(MemberVO memberVO);

    void deleteInactiveMember(MemberVO memberVO);

    List<MemberVO> getEmailTargetInactiveMemberList();

    List<MailQueueVO> emailQueuePopAll();

    List<SubCdVO> getSubCodeList(SubCdVO subCdVO);

    void updateCmMailQueueSendStatus(MailQueueVO mailInfo);

    void insertEmailQueue();

    void insertEmailQueueTarget();
}
