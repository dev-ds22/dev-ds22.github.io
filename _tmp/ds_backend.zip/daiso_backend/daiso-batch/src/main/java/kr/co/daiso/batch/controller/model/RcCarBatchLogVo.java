package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarBatchLogVo
 * author         : m2m0020
 * date           : 2022-04-25
 * description    : RcCarBatchLogVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-25     m2m0020             최초생성
 */
@Data
public class RcCarBatchLogVo {
    private String batcCd;
    private String rsltCd;
    private int totCnt;
    private int scsCnt;
    private int failrCnt;
    private String failrDesc;
    private String regDttm;
}
