package kr.co.daiso.batch.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * packageName    : kr.co.daiso.batch.config
 * fileName       : DuplicateJobCheckListener
 * author         : Doo-Won Lee
 * date           : 2022-02-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-24       Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public class DuplicateJobCheckListener extends JobExecutionListenerSupport{

    @Autowired
    JobExplorer jobExplorer;

    @Autowired
    JobOperator jobOperator;

    @Bean
    public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
        JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
        jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
        return jobRegistryBeanPostProcessor;
    }


    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("******************************** beforeJob :"+jobExecution.getJobInstance().getJobName());
        Set<JobExecution> jobExecutionSet = jobExplorer.findRunningJobExecutions(jobExecution.getJobInstance().getJobName());
        if (jobExecutionSet.size() > 1) {
            log.info("**********************Exist********** beforeJob :"+jobExecution.getJobInstance().getJobName());
            log.info("**********************StopId********** beforeJob :"+jobExecution.getId());
            try {
                jobOperator.stop(jobExecution.getId());
            } catch (NoSuchJobExecutionException e) {
                e.printStackTrace();
            } catch (JobExecutionNotRunningException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("******************************** afterJob :"+jobExecution.getJobInstance().getJobName());
        log.info("******************************** afterJobId :"+jobExecution.getId());
    }
}
