package kr.co.daiso.batch.jobs.sample;

import kr.co.daiso.batch.config.DuplicateJobCheckListener;
import kr.co.daiso.batch.jobs.sample.tasks.SampleTask1;
import kr.co.daiso.batch.sample.model.SampleModel;
import kr.co.daiso.batch.sample.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisCursorItemReader;
import org.mybatis.spring.batch.builder.MyBatisCursorItemReaderBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * packageName    : kr.co.daiso.batch.jobs
 * fileName       : Samplejob
 * author         : Doo-Won Lee
 * date           : 2021-11-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-18     Doo-Won Lee      최초생성
 */
@Slf4j
@Configuration
public class Samplejob {

    @Autowired
    JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    SqlSessionFactory sqlSessionFactory;

    @Autowired
    SampleService sampleService;

    String jobName = "Samplejob";

    String stepName1 = "stepName1";
    String stepName2 = "stepName2";
    String stepName3 = "stepName3";

    @Autowired
    SampleTask1 sampleTask1;

    //java- jar demo.jar exectuonDate(date)=2020/12/27

    @Bean
    //public Job sampleJob(SampleJobListener sampelJobListener, @Value("#{jobParameters[date]}") String date){
    public Job sampleJob(DuplicateJobCheckListener sampelJobListener){
        return jobBuilderFactory.get(jobName)
                .incrementer(new RunIdIncrementer())
                //.listener(sampelJobListener)
                .start(sampleStep1())
                //.next(sampleStep2())
//                .next(sampleStep3())
                //.end()
                .build();
    }


    @Bean
    public Step sampleStep1(){
        return stepBuilderFactory.get(stepName1)
                //.tasklet(sampleTask1)
                .tasklet((contribution, chunkContext) -> {
                    sampleService.testOracle();
                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    @JobScope
    public Step sampleStep2(@Value("#{jobParameters[date]}") String date){
        return stepBuilderFactory.get(stepName2)
                .tasklet((contribution, chunkContext) -> {

                    String name = (String) chunkContext.getStepContext() /* StepContext */
                            .getJobParameters()
                            .get("name");
                    log.info("name: none : {}", name);

                    ExecutionContext jobContext = chunkContext.getStepContext() /* 스텝 */
                            .getStepExecution()
                            .getExecutionContext();

                    jobContext.put("user.name", name);

                    for(int idx = 0 ; idx < 10 ; idx++) {
                        log.info("[sampleStep2] :{}, {}", idx, date);
                    }
                    return RepeatStatus.FINISHED;
                })
                .build();
    }

    @Bean
    @JobScope
    public Step sampleStep3(){
        return stepBuilderFactory.get(stepName3)
                .<SampleModel,String>chunk(10)
                .reader(itemReader())
                //.processor(processor())
                .writer(itemWriter())
                .build();

    }

    @Bean
    public MyBatisCursorItemReader<SampleModel> itemReader(){
        log.info("itemReader");
        return new MyBatisCursorItemReaderBuilder<SampleModel>()
                .sqlSessionFactory(sqlSessionFactory)
                .queryId("kr.co.daiso.batch.sample.mapper.oracle.SampleOracleMapper.testOracle")
                .build();
    }

    @Bean
    public ItemProcessor<SampleModel,String> processor(){
        log.info("processor12");
        //log.info(sample.toString());

        //return new TestProcessor();
        //System.out.println("*******************************");
        //return sample -> sample.getAaa();

        return sample -> {
            log.info(sample.getAaa());
            System.out.println("=================================");
           return sample.getAaa();
        };


    }

    @Bean
    public ItemWriter<String> itemWriter(){
        log.info("writer");
        return items -> {
            for(String item : items){
                log.info("ItemWriter item :"+item);
            }
        };
    }
}
