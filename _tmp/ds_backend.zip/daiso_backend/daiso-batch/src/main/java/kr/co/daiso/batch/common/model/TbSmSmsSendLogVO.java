package kr.co.daiso.batch.common.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : TbSmSmsSendLogVO
 * author         : bsj
 * date           : 2022-02-03
 * description    : SMS발송로그 테이블(TB_SM_SMS_SEND_LOG)의 Entity
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       bsj           최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class TbSmSmsSendLogVO implements Serializable {

    private static final long serialVersionUID = -4023551575607519260L;
    private String smsCd;                               // SMS코드
    private String recvPersonMbpno;                     // 받는사람휴대폰번호
    private String sndPersonMbpno;                      // 보내는사람휴대폰번호
    private String trnsMsg;                             // 전송메시지
    private String trnsYn;                              // 전송여부
    private String trnsDd;                              // 전송일
    private String recvPersonCd;                        // 받는사람코드
    private String chnl;                                // 채널
    private String trnsStat;                            // 전송상태
    private String titl;                                // 제목
    private String trnsScsYn;                           // 전송성공여부
    private String rgpsId;                              // 등록자ID
    private String regDttm;                             // 등록일시
    private String mdpsId;                              // 수정자ID
    private String modDttm;                             // 수정일시
}
