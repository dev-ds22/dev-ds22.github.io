package kr.co.daiso.batch.config;

import org.quartz.JobExecutionContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import io.micrometer.core.lang.NonNullApi;
import kr.co.daiso.batch.controller.model.PThemeExhbtMgtVO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;

/**
 * packageName    : kr.co.daiso.batch.config
 * fileName       : DaisoQuartzJob
 * author         : chungwoo35
 * date           : 2022-04-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-14          chungwoo35         최초생성
 */
@EqualsAndHashCode(callSuper=false)
@Data
@Slf4j
@NonNullApi
public class DaisoQuartzJob extends QuartzJobBean {

    @Override
    protected void executeInternal(JobExecutionContext context) {
        try{
            PThemeExhbtMgtVO pthemeExhbtMgtVO = (PThemeExhbtMgtVO) context.getMergedJobDataMap().get("themeExhbtMgtVO");
//            DsThemeExhbtMstVo dsthemeExhbtMstVO = new DsThemeExhbtMstVo();
//            BeanUtils.copyProperties(pthemeExhbtMgtVO, dsthemeExhbtMstVO);
//            ApplicationContext ctx = (ApplicationContext) context.getMergedJobDataMap().get("applicationContext");
//            ThemeExbtService themeExbtService = ctx.getBean(ThemeExbtService.class);
//
//            log.info("themeExhbtMgtVo : {}", pthemeExhbtMgtVO);
//            log.info("themeExbtService:{} ", themeExbtService);
//
//            themeExbtService.themeExbtServiceProc(dsthemeExhbtMstVO, pthemeExhbtMgtVO.getUserId());
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

}
