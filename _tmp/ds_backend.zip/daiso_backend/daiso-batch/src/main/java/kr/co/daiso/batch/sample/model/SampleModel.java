package kr.co.daiso.batch.sample.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class SampleModel implements Serializable {
    String grCode;
    String grCodeNm;
    String useYn;
    String aaa;
}
