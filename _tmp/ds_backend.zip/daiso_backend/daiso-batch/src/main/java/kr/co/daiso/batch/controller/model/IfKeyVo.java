package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : IfKeyVo
 * author         : m2m0020
 * date           : 2022-05-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-03     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class IfKeyVo extends CommonVo {
    private String ifKey;

    private String check;
}
