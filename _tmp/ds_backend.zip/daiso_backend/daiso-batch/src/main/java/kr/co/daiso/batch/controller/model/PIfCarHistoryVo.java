package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PIfCarHistoryVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    : PIfCarHistoryVo VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PIfCarHistoryVo {

    //@ApiModelProperty(value = "CarId", required = true, notes = "CarId를 입력해주세요", example = "60238128, 60196442, 60196923, ...")
    //@NotBlank(message="CarId를 입력해주세요")
    //private String carId;

    @ApiModelProperty(value = "CarCd", required = true, notes = "CarCd를 입력해주세요", example = "EC60238128, EC60196442, EC60196923, ...")
    @NotBlank(message="CarCd 입력해주세요")
    private String carCd;


    @ApiModelProperty(value = "차량번호", required = true, notes = "차량번호를 입력해주세요", example = "00가1234")
    @NotBlank(message="차량번호를 입력해주세요")
    private String cno;
}
