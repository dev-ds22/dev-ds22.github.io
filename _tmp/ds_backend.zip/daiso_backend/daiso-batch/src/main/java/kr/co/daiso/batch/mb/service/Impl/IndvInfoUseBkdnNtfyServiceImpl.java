package kr.co.daiso.batch.mb.service.Impl;

import kr.co.daiso.batch.common.mapper.oracle.CommonCodeManageOracleMapper;
import kr.co.daiso.batch.common.model.ClsCommonReqVO;
import kr.co.daiso.batch.common.model.CommonPathInfo;
import kr.co.daiso.batch.mb.model.MailQueueVO;
import kr.co.daiso.batch.mb.service.InactiveMemberService;
import kr.co.daiso.batch.mb.service.IndvInfoUseBkdnNtfyService;
import kr.co.daiso.common.model.MailVO;
import kr.co.daiso.common.util.MailUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@Service
public class IndvInfoUseBkdnNtfyServiceImpl implements IndvInfoUseBkdnNtfyService {

    @Autowired
    private InactiveMemberService inactiveMemberService;

    @Autowired
    CommonCodeManageOracleMapper commonCodeManageOracleMapper;

    private ExecutorService executorService;

    @Autowired
    MailUtil mailUtil;

    @Override
    public void indvInfoUseBkdnNtfySend() {
        List<ClsCommonReqVO> cdLst;
        ClsCommonReqVO cdVO = new ClsCommonReqVO();

        try {
            this.executorService = Executors.newFixedThreadPool(4);

            cdVO.setMasterCd("EMAIL_TEMPLATE");
            cdVO.setSubCd("INACT_0003");
            // 공통코드 조회
            cdLst = commonCodeManageOracleMapper.getSubCodeList(cdVO);
            String templateType = "INACT_0003";
            String title = "";
            String contentTemplate = "";
            String rootFullUrl = CommonPathInfo.ROOT_FULL_URL;
            String addtFld = "";
            for(ClsCommonReqVO cdInfo: cdLst) {
                if(templateType.equals(cdInfo.getSubCd())) {
                    title = cdInfo.getAddtFld1();
                    if(rootFullUrl.lastIndexOf("/") == (rootFullUrl.length() - 1)) {
                        addtFld = cdInfo.getAddtFld2().substring(1);
                    }else {
                        addtFld = cdInfo.getAddtFld2();
                    }
                    contentTemplate = this.urlToString(rootFullUrl + addtFld);
                }
            }
            // 메일 Queue 조회
            List<MailQueueVO> mailQueueLst = inactiveMemberService.emailQueuePopAll();
            int sendMailCount = 0;
            int noticeTargetCnt = 0;
            for(MailQueueVO target: mailQueueLst) {
                if(!templateType.isEmpty() && templateType.equals(target.getEmailTmplKnd())) {
                    target.setTitle(title);
                    target.setContent(this.makeEmailContent(contentTemplate, ""));
                    // 메일 발송
                     executorService.execute(() -> {
                         MailVO result = mailUtil.send(target.getSndrNm(), target.getSndrEmailAddr(), target.getRcvrEmailAddr(), null, target.getTitle(), target.getContent());
                         if(result.isSend()) {
                             target.setSendStat("S");
                         }else {
                             target.setSendStat("F");
                         }
                         inactiveMemberService.updateCmMailQueueSendStatus(target);
                     });

                    noticeTargetCnt++;
                    sendMailCount++;
                    if(sendMailCount % 100 == 0) {
                        Thread.sleep(1000);
                    }
                }
            }
            this.executorService.shutdown();

            if(noticeTargetCnt > 0) {
                String resultMailContent = "개인정보 이용 통지 안내 발송 수 : " + noticeTargetCnt;
                mailUtil.send("K Car 직영몰", "daiso@daiso.com", "angeljjokk@gmail.com", "angeljjo@gmail.com", title, resultMailContent);
            }
        }catch (Exception e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }

    private String urlToString(String value) {
        String rtn = "";

        try {
            URL url = new URL(value);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            byte[] bTmp = null;
            InputStream in = null;

            conn.connect();

            in = conn.getInputStream();
            bTmp = this.fileToByte(in);
            rtn = new String(bTmp, "UTF-8");
        }catch (Exception e) {
            e.printStackTrace();
        }

        return rtn;
    }

    private byte[] fileToByte(InputStream in) throws IOException {
        byte[] bResult = null;
        byte[] bTmp = new byte[1024];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        int j;
        while((j = in.read(bTmp)) != -1){
            baos.write(bTmp, 0, j);
        }
        bResult	= baos.toByteArray();

        return bResult;
    }

    private String makeEmailContent(String contentTemplate, String templateParam) {
        if(templateParam.isEmpty()) {
            return contentTemplate;
        }else {
            String[] params = templateParam.split("\\|");
            for(int i = params.length; i > 0; i--){
                contentTemplate = contentTemplate.replaceAll("PARAM#"+i, params[i-1]);
            }

            return contentTemplate;
        }
    }
}
