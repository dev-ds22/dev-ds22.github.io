package kr.co.daiso.batch.mb.service;

public interface IndvInfoUseBkdnNtfyService {

    // 개인정보이용 통지 메일 발송
    public void indvInfoUseBkdnNtfySend();
}
