package kr.co.daiso.batch.controller.model;


import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : JoyVo
 * author         : m2m0020
 * date           : 2022-04-25
 * description    : JoyVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-25     m2m0020             최초생성
 */
@Data
public class JoyVo {
    private String SORT_NO;
    private String CAR_CLCD;
    private String ITEM_DESC;
    private String EST_COM_JY_201808;
    private String EST_Sunting_Coupon;
    private String CAR_EXAUST;
    private String EST_COM_JY_TEMP;
    private String CREATOR;
    private String ANY_CAR_CLNM;
    private String CAR_OILTANK;
    private String BACK_TIRE_SIZE;
    private String FUELTYPE;
    private String ANY_CARCLASSGRP;
    private String FUEL_EFFICIENCY2;
    private String FUEL_EFFICIENCY3;
    private String ANY_CARCLASSGRPNAME;
    private String ITEM_LVL;
    private String BASECOST;
    private String SALE_YN;
    private String UPPER_ITEM_ID;
    private String BACK_TIRE;
    private String ChulHaJang;
    private String GEARTYPE;
    private String DRIVE_SHAFT;
    private String MT_COST_TYPE;
    private String ITEM_KOR_NAME;
    private String CARCLASSTYPE;
    private String LENDCOSTGRP_TEMP;
    private String EST_COM_PC;
    private String USEYN;
    private String CAR_OILTANK2;
    private String EST_PER_NUM;
    private String EST_COM_IC;
    private String CAR_CLNM;
    private String UPDATEDATE;
    private String EST_COM_ST;
    private String Agent_Open_YN;
    private String ITEM_ID;
    private String CAR_CLEN;
    private String CAR_GRADE_M;
    private String GRP_CODE;
    private String CAR_GRADE_L;
    private String CAR_TYPE;
    private String LENDCOSTGRP;
    private String SP_Rate_Type;
    private String FUEL_EFFICIENCY;
    private String FRONT_TIRE;
    private String ANY_CAR_CLCD;
    private String GRP_NAME;
    private String CARCLASSGRP;
    private String UPDATOR;
    private String EST_COM_CH;
    private String ITEM_ENG_NAME;
    private String SELFCOST;
    private String FRONT_TIRE_SIZE;
    private String EST_COM_JY;
    private String CAR_GRADE_M2;
    private String CREATEDATE;
    private String INSURANCE_GRADE;
    private String BASECOST_TEMP;
    private String ITEM_CODE;
    private String UPPER_ITEM_KOR_NAME;
    private String Regist_Date;
    private String EST_COM_GJ;
    private String MANAGEMENT_GRADE;
}
