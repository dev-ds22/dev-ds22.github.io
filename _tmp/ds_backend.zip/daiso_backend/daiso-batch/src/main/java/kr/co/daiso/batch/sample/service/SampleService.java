package kr.co.daiso.batch.sample.service;

public interface SampleService {
    //샘플
//    public List<SampleModel> getSampleCode();
    //샘플
//    public List<SampleModel> getSampleCode(Map<String, String> param);
    //오라클 연동 테스트
    public void testOracle();

}
