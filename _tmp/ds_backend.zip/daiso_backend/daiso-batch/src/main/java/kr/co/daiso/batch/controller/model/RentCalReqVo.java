package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RentCalReqVo
 * author         : m2m0020
 * date           : 2022-04-26
 * description    : RentCalReqVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-26     m2m0020             최초생성
 */
@Data
public class RentCalReqVo {
    private String rentCarCd;
    private String rentPerdCd;
    private String trrcCarDvs;
    private double accbkAcqPrcst;
    private double roic;
    private double dprexp20000;
    private double dprexp30000;
    private double fxcst;
    private double carInsfee;
    private double carTax;
    private double mantCost20000;
    private double mantCost30000;
    private double tourMantCost20000;
    private double tourMantCost30000;
    private double lwprMantCost20000;
    private double lwprMantCost30000;
    private double garageCost;
    private double etcVarcst;
    private double agCmsn;
    private String ecCarCd;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;
    private String rentMth;
    private String avcRecvAmt;
    private double rentAmtN1;
    private double rentAmtN2;
    private double rentAmtN3;
    private double rentAmtN4;
    private String depositAvcRecvTypeN1;
    private String depositAvcRecvTypeN2;
    private String spclRentAmtN1;
    private String spclRentAmtN2;
    private String spclRentAmtN3;
    private String spclRentAmtN4;

    private String cno;
    private String mnuftrCd;
    private String mnuftrNm;
    private String modelCd;
    private String modelNm;
    private String grdCd;
    private String grdNm;
    private double regAmt;
    private double chngAmt;
    private String execDt;
    private double regMmRentCharge;
    private double chngMmRentCharge;
    private String rentPerd;

    private double nPrice;
    private double nRentPrice;

}
