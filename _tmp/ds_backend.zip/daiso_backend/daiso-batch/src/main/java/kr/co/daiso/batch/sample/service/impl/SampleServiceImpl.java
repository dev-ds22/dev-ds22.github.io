package kr.co.daiso.batch.sample.service.impl;

import kr.co.daiso.batch.sample.mapper.oracle.SampleOracleMapper;
import kr.co.daiso.batch.sample.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SampleServiceImpl implements SampleService {

    @Autowired
    SampleOracleMapper sampleOracleMapper;

//    @Autowired
//    SampleMysqlMapper sampleMysqlMapper;


//    @Override
//    public List<SampleModel> getSampleCode() {
//        return sampleMysqlMapper.getSampleCode();
//    }

    @Override
    public void testOracle() {
        sampleOracleMapper.testOracle();
    }

//
//    @Override
//    public List<SampleModel> getSampleCode(Map<String,String> params) {
//        return sampleMysqlMapper.getSampleCode();
//    }

}


