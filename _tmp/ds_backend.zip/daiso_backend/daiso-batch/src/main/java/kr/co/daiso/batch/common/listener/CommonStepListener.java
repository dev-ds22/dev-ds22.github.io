package kr.co.daiso.batch.common.listener;


import kr.co.daiso.batch.common.service.ClsCommonService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Slf4j
public class CommonStepListener implements StepExecutionListener {

    @Autowired
    ClsCommonService clsCommonService;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        String name = stepExecution.getJobExecution().getJobInstance().getJobName();
        log.info("Start : {}", name);

        List<String> jobNames = clsCommonService.selectJobNames();

        if (jobNames.contains(name)) {
            stepExecution.setTerminateOnly();
        }
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        log.info("end : {}", stepExecution.getJobExecution().getJobInstance().getJobName());
        return null;
    }
}
