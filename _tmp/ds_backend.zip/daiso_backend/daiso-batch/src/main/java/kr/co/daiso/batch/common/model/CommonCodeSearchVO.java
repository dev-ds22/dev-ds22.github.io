package kr.co.daiso.batch.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : CommonCodeSearchVo
 * author         :
 * date           : 2022-05-24
 * description    : 공통코드 검색용 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-24           최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonCodeSearchVO extends CommonPagingVo {

    private String sMstCode;        //검색 마스터 코드
    private String sMstCodeNm;      //검색 마스터 코드명

    private String sSubCode;        //검색 서브 코드
    private String sSubCodeNm;      //검색 서브 코드명

    private String useYn;           //사용 여부
    private String delYn;           //삭제 여부
    private String ucmsCdYn;        //UCMS 코드 여부

    private String	addtFld1;       //추가 필드1
    private String	addtFld2;       //추가 필드2
    private String	addtFld3;       //추가 필드3

    private String[] arrSubCd;

}