package kr.co.daiso.batch.jobs.mb.tasks;

import kr.co.daiso.batch.common.model.CommonPathInfo;
import kr.co.daiso.batch.mb.model.MailQueueVO;
import kr.co.daiso.batch.mb.model.SubCdVO;
import kr.co.daiso.batch.mb.service.InactiveMemberService;
import kr.co.daiso.common.model.MailVO;
import kr.co.daiso.common.util.MailUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * packageName    : kr.co.daiso.batch.jobs.mb.tasks
 * fileName       : EmailInactiveMemberTask
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */
@Slf4j
@Component
@StepScope
public class EmailInactiveMemberTask implements Tasklet, StepExecutionListener {

    @Autowired
    private InactiveMemberService inactiveMemberService;

    @Autowired
    private MailUtil mailUtil;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("**** EmailInactiveMember ****");
    }

    private ExecutorService executorService;

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

        log.info("CommonPathInfo.ROOT_FULL_URL: {}", CommonPathInfo.ROOT_FULL_URL);
        this.executorService = Executors.newFixedThreadPool(4);

        SubCdVO subCdVO = new SubCdVO();
        subCdVO.setMasterCd("EMAIL_TEMPLATE");
        List<SubCdVO> subCodeList = inactiveMemberService.getSubCodeList(subCdVO);
        List<MailQueueVO> mailQueueList = inactiveMemberService.emailQueuePopAll();

        log.info("subCodeList: {}", subCodeList);
        log.info("mailQueueList: {}", mailQueueList);

        String templateType = "";
        String title = "";
        String contentTemplate = "";

        int sendMailCount = 0;
        int inactiveTargetCnt = 0;
        int inactivedCnt = 0;

        for (MailQueueVO target : mailQueueList) {
            // 최초 1회, templateType이 다른 경우만 기본 템플릿 정보 변경
            if (templateType.isEmpty() || (!templateType.isEmpty() && !templateType.equals(target.getEmailTmplKnd()))) {
                templateType = target.getEmailTmplKnd();
                for (SubCdVO subCd : subCodeList) {
                    if (templateType.equals(subCd.getSubCd())) {
                        title = subCd.getAddtFld1();
                        contentTemplate = urlToString(CommonPathInfo.ROOT_FULL_URL.substring(0, CommonPathInfo.ROOT_FULL_URL.length()-1) + subCd.getAddtFld2());
                    }
                }
            }
            target.setTitle(title);
            target.setContent(makeEmailContent(contentTemplate, target.getEmailTmplParam()));

            if ("INACT_0001".equals(templateType)) {
                inactiveTargetCnt++;
            } else if ("INACT_0002".equals(templateType)) {
                inactivedCnt++;
            }

            MailQueueVO mailInfo = target;
            this.executorService.execute(() -> {
                MailVO result = mailUtil.send(mailInfo.getSndrNm(), mailInfo.getSndrEmailAddr(), mailInfo.getRcvrEmailAddr(), null, mailInfo.getTitle(), mailInfo.getContent());
                if (result.isSend()) {
                    mailInfo.setSendStat("S");
                    inactiveMemberService.updateCmMailQueueSendStatus(mailInfo);
                } else {
                    mailInfo.setSendStat("F");
                    inactiveMemberService.updateCmMailQueueSendStatus(mailInfo);
                }
            });
            sendMailCount++;
            if (sendMailCount % 100 == 0) {
                Thread.sleep(1000);
            }
        }

        return RepeatStatus.FINISHED;
    }

    public static byte[] fileToByte(InputStream in) throws IOException {

        byte[] bResult = null;
        byte[] bTmp = new byte[1024];

        try(ByteArrayOutputStream baos = new ByteArrayOutputStream();) {
            int j;
            while ((j = in.read(bTmp)) != -1) {
                baos.write(bTmp, 0, j);
            }

            bResult = baos.toByteArray();
        }

        return bResult;
    }

    private String makeEmailContent(String contentTemplate, String templateParam) {
        if (templateParam.isEmpty()) {
            return contentTemplate;
        } else {
            String[] params = templateParam.split("\\|");

            for (int i = params.length; i > 0; i--) {
                contentTemplate = contentTemplate.replaceAll("PARAM#" + i, params[i - 1]);
            }
            return contentTemplate;
        }
    }

    public static String urlToString(String i_sUrl) {

        String sReturn = "";
        try {
            URL url = new URL(i_sUrl);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = null;
            httpURLConnection.connect();
            inputStream = httpURLConnection.getInputStream();
            sReturn = new String(fileToByte(inputStream), "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sReturn;
    }
}
