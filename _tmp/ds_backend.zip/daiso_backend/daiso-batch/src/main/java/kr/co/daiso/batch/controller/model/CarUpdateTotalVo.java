package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;


/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : CarUpdateTotalVo
 * author         : m2m0020
 * date           : 2022-04-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-11     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CarUpdateTotalVo extends  DblinkVo{

    @ApiModelProperty(value = "IfKey", required = true, notes = "검색할 인터페이스 KEY입력", example = "52401236, 52401241, ...")
    @NotBlank(message="ifKey를 입력해 주세요")
    private String ifKey;

    @ApiModelProperty(value = "파라미터", required = true, notes = "수행해야할 parameter입력", example = "000|010|020|030|040|050|060|070|080|090")
    @NotBlank(message="파라미터를 입력해 주세요")
    private String parameter;

}