package kr.co.daiso.batch.common.service;

import kr.co.daiso.batch.common.model.CommonCodeManageVO;
import kr.co.daiso.batch.common.model.CommonCodeSearchVO;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.common.service
 * fileName       : CommonCodeService
 * author         :
 * date           : 2022-05-24
 * description    : 공통코드 관련 Util
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-24               최초생성
 */
@Component
public interface CommonCodeService {

    //서브 코드의 카운트를 구한다.
    public int getSubCodeListCount(CommonCodeSearchVO searchVo);

    //서브 코드의 목록을 구한다
    public List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO searchVo) ;

    public List<CommonCodeManageVO> getSubCodeListByMasterCd(String masterCd) ;

    public List<CommonCodeManageVO> getSubCodeList(String sMstCode) ;

    /**
     * 첫번째 서브 코드를 가져온다.
     */
    public CommonCodeManageVO getFirstSubCode(CommonCodeSearchVO searchVo) ;
}


