package kr.co.daiso.batch.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.mb.model
 * fileName       : SubCodeVO
 * author         : kjm
 * date           : 2022-02-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-11       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SubCdVO extends BaseModel {
    private String masterCd;
    private String subCd;
    private String subCdNm;
    private String subCdEngNm;
    private String sortOrdr;
    private String hrnkGrpCd;
    private String ucmsCdYn;
    private String addtFld1;
    private String addtFld2;
    private String addtFld3;
    private String addtFld11;
    private String addtFld12;
    private String addtFld13;
    private String addtFld14;
    private String addtFld15;
    private String addtFld16;
    private String addtFld17;
    private String addtFld18;
    private String useYn;
    private String delYn;
}
