package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarJoyMasterVo
 * author         : m2m0020
 * date           : 2022-04-25
 * description    : RcCarJoyMasterVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-25     m2m0020             최초생성
 */
@Data
public class RcCarJoyMasterVo {
    private String itemId;
    private String registDate;
    private String itemCode;
    private String itemKorName;
    private String itemEngName;
    private String upperItemId;
    private String upperItemKorName;
    private String itemDesc;
    private String itemLvl;
    private String grpCode;
    private String grpName;
    private String carclassgrp;
    private String carClcd;
    private String carClnm;
    private String carClen;
    private String carType;
    private String carExaust;
    private String fuelEfficiency;
    private String fuelEfficiency2;
    private String fuelEfficiency3;
    private String fueltype;
    private String carOiltank;
    private String carOiltank2;
    private String carGradeL;
    private String carGradeM;
    private String carGradeM2;
    private String lendcostgrp;
    private String lendcostgrpTemp;
    private String mtCostType;
    private String basecost;
    private String basecostTemp;
    private String selfcost;
    private String insuranceGrade;
    private String managementGrade;
    private String agentOpenYn;
    private String carclasstype;
    private String anyCarclassgrp;
    private String anyCarclassgrpname;
    private String anyCarClcd;
    private String anyCarClnm;
    private String estComJy;
    private String estComJyTemp;
    private String estComJy201808;
    private String estComCh;
    private String estComGj;
    private String estComSt;
    private String driveShaft;
    private String frontTireSize;
    private String backTireSize;
    private String frontTire;
    private String backTire;
    private String estComIc;
    private String estComPc;
    private String estPerNum;
    private String estSuntingCoupon;
    private String geartype;
    private String chulhajang;
    private String spRateType;
    private String saleYn;
    private String useyn;
    private String sortNo;
    private String vUploadDtm;
}
