package kr.co.daiso.batch.sample.mapper.oracle;

import kr.co.daiso.batch.sample.model.SampleModel;
import io.micrometer.core.instrument.Timer;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SampleOracleMapper {
    //Oracle 연동 테스트
    List<SampleModel> testOracle();

}
