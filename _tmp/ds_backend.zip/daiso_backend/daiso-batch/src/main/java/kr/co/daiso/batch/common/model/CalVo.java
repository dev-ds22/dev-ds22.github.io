package kr.co.daiso.batch.common.model;

import lombok.Data;

@Data
public class CalVo {
	private String	v_date;     // 년월일
	private String	v_what;     // 휴일 , 지점 휴점일 등등

	private String	v_year;     // 년
	private String	v_month;    // 월
	private String	v_day;      // 일

	private String	v_type;     // datepicker.type
	private String	v_title;    // datepicker.title, 설명

	private String ymd;
}
