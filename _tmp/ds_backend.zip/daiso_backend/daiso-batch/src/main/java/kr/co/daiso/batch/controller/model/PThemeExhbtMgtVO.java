package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;


@Data
public class PThemeExhbtMgtVO {

    @ApiModelProperty(value = "테마기획전 순번")
    @NotBlank(message="테마기획전 순번을 입력해 주세요")
    private String themeExhbtSq;

    @ApiModelProperty(value = "차량갱신구분코드")
    @NotBlank(message="차량갱신구분코드을 입력해 주세요")
    private String carRnewDcd;

    @ApiModelProperty(value = "갱신주기코드")
    @NotBlank(message="갱신주기코드를 입력해 주세요")
    private String rnewCyclCd;

    @ApiModelProperty(value = "UserId")
    @NotBlank(message="UserId를 입력해 주세요")
    private String userId;

}
