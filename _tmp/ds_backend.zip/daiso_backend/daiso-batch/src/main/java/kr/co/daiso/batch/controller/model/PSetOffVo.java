package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PSetOffVo
 * author         : m2m0020
 * date           : 2022-05-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-03     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PSetOffVo {

    @ApiModelProperty(value = "CarId", notes = "CarId를 입력해주세요", example = "60442891, 60442894, 60442896...")
    @NotBlank(message="CarId를 입력해주세요")
    private String carId;
}
