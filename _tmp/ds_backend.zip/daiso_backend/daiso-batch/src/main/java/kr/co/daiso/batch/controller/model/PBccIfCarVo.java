package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class PBccIfCarVo {

    //@ApiModelProperty(value = "CarId", required = true, notes = "CarId를 입력해 주세요", example = "60442894, 60442902, 60442914")
    //@Digits(integer = 99999999, fraction = 0)
    //private Integer carId;


    @ApiModelProperty(value = "carCd", required = true, notes = "carCd를 입력해 주세요", example = "BC60442894, BC60442902, BC60442914")
    private String carCd;

}
