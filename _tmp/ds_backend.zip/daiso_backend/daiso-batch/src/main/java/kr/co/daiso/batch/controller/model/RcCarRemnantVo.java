package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarPrcVo
 * author         : m2m0020
 * date           : 2022-04-26
 * description    : RcCarPrcVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-26     m2m0020             최초생성
 */
@Data
public class RcCarRemnantVo {
    private double rentMcnt;
    private String remvalGrdVp;
    private String remvalGrdV;
    private String remvalGrdSp;
    private String remvalGrdS;
    private String remvalGrdA;
    private String remvalGrdB;
    private String remvalGrdC;
    private String remvalGrdD;
    private String remvalGrdE;
    private String remvalGrdF;
    private String remvalGrdG;

    private String remvalGrd;//REMVAL_GRD   잔가 등급
    private Double val; //  밸류
}
