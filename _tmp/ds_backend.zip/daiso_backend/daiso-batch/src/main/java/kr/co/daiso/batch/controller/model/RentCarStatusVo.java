package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : IFCarInfoVo
 * author         : RentCarStatusVo
 * date           : 2022-04-08
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-08     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class RentCarStatusVo {

    /*
    @ApiModelProperty(value = "Car ID")
    @NotBlank(message="CAR_ID_NOT_FOUND")
    private String carId;

     */

    @ApiModelProperty(value = "Car Cd")
    @NotBlank(message="CAR_Cd_NOT_FOUND")
    private String carCd;

    @ApiModelProperty(value = "렌트 등록 여부")
    @NotBlank(message="RENT_REG_YN_NOT_FOUND")
    private String rentRegYn;

}
