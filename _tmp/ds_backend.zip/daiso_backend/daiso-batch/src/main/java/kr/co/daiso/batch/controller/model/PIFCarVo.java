package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PIFCarVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PIFCarVo {

    @ApiModelProperty(value = "차량번호", required = true, notes = "차량번호를 입력해주세요", example = "00가1234")
    @NotBlank(message="차량번호를 입력해주세요")
    private String carNumber;
}
