package kr.co.daiso.batch.common.mapper.oracle;

import kr.co.daiso.batch.common.model.ClsCommonReqVO;
import kr.co.daiso.batch.common.model.CommonCodeManageVO;
import kr.co.daiso.batch.common.model.CommonCodeSearchVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommonCodeManageOracleMapper {
    // 서브 코드 목록 조회
    List<ClsCommonReqVO> getSubCodeList(ClsCommonReqVO vo);

    //서브 코드의 카운트를 구한다.
    int getSubCodeListCount(CommonCodeSearchVO reqVo);

    //서브 코드의 목록을 구한다.
    List<CommonCodeManageVO> getCmSubCodeList(CommonCodeSearchVO reqVo);
}
