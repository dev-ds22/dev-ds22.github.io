package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarPrcVo
 * author         : m2m0020
 * date           : 2022-04-26
 * description    : RcCarPrcVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-26     m2m0020             최초생성
 */
@Data
public class RcCarPrcVo {
    private String rentCarCd;
    private String rentMth;
    private String avcRecvAmt;
    private String rentAmtN1;
    private String rentAmtN2;
    private String rentAmtN3;
    private String rentAmtN4;
    private String depositAvcRecvTypeN1;
    private String depositAvcRecvTypeN2;
    private String spclRentAmtN1;
    private String spclRentAmtN2;
    private String spclRentAmtN3;
    private String spclRentAmtN4;
}
