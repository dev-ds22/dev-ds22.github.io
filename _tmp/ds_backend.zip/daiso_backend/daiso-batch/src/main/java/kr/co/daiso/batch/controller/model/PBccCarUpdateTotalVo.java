package kr.co.daiso.batch.controller.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : BccCarUpdateTotalVo
 * author         : m2m0020
 * date           : 2022-04-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PBccCarUpdateTotalVo {

    @ApiModelProperty(value = "parameter", required = true, notes = "parameter 입력", example = "CAR_REG, CAR_CHG, MALL_REG, MALL_CHG, MALL_RLS, MALL_CHG, SAL_REG, CAR_DEL, RSV_REG, RSV_RLS")
    @NotBlank(message="parameter를 입력해 주세요")    
    private String param;

    //@ApiModelProperty(value = "CarId", required = true, notes = "CarId를 입력해 주세요", example = "60442894, 60442902")
    //@Digits(integer = 99999999, fraction = 0)
    //private Integer carId;

    @ApiModelProperty(value = "CarCd", required = true, notes = "CarCd를 입력해 주세요", example = "BC60442894, BC60442902, BC60442914")
    @NotBlank(message="carCd를 입력해 주세요")
    private String carCd;

    @ApiModelProperty(value = "UserID", notes = "USER_ID를 입력해주세요")
    @NotBlank(message="USER_ID를 입력해주세요")
    private String usrId;


}
