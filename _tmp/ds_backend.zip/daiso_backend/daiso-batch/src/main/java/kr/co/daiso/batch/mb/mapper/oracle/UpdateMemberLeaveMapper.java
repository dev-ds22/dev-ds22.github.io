package kr.co.daiso.batch.mb.mapper.oracle;

import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.batch.mb.mapper.oracle
 * fileName       : UpdateMemberLeaveMapper
 * author         : kjm
 * date           : 2022-04-21
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-21       kjm            최초생성
 */
@Mapper
public interface UpdateMemberLeaveMapper {
    void updateLeaveMember();

    void deleteSNSMapping();
}
