package kr.co.daiso.batch.message.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.beans.factory.annotation.Value;

/**
 * packageName    : kr.co.daiso.batch.message.model
 * fileName       : SmsVO
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */

@Data
@EqualsAndHashCode(callSuper=false)
public class SmsVO extends BaseModel {

    @Value("${dblink}")
    private String dbLinkValue;

    private String receiverCd; //2022-01-28 이두원추가
    private String mtPr; //2022-01-28 이두원추가 
    private String smsCd;   //2022-02-03 이두원추가

    private String mseq;
    private String msgType;   //I_iTranType 알림톡동시건이면 X mtpr
    private String sendType;
    private String dkey;
    private String dcnt;
    private String dstaddr;    //수신번호
    private String callback;    //발신번호
    private String stat;
    private String subject;
    private String textType;
    private String text;
    private String expiretime;
    private String filecnt;
    private String fileloc1;
    private String filesize1;
    private String fileloc2;
    private String filesize2;
    private String fileloc3;
    private String filesize3;
    private String fileloc4;
    private String filesize4;
    private String fileloc5;
    private String filesize5;
    private String filecntCheckup;
    private String insertTime;
    private String requestTime;
    private String sendTime;
    private String reportTime;
    private String tcprecvTime;
    private String saveTime;
    private String telecom;
    private String result;
    private String repcnt;
    private String serverId;
    private String optId;
    private String optCmp;
    private String optPost;
    private String optName;
    private String extCol0;
    private String extCol1;
    private String extCol2;
    private String extCol3;

}
