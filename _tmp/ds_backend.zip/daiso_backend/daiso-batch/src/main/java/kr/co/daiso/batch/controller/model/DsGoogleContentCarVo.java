package kr.co.daiso.batch.controller.model;

import lombok.Data;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : DsGoogleContentCarVo
 * author         : m2m0020
 * date           : 2022-05-19
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-19     m2m0020             최초생성
 */
@Data
public class DsGoogleContentCarVo {

    private String carCd;
    private String encarCd;
    private char statCd;
    private char stckYn;
    private String modelNm;
    private String middleImg;
    private String stckNm;
    private int salprc;
    private String mnuftrNm;
    private String extrColorNm;
    private String carctgrCd;
    private String mfgDt;
    private String regModelyr;
    private String milg;
    private String fuelType;
    private String trnsmsnCd;
    private String modDttm;
    private String erCd;
    private String erMsg;

    private String[] carCdList;
}
