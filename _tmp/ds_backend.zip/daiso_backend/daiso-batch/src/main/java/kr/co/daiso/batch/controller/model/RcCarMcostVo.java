package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RcCarMcostVo
 * author         : m2m0020
 * date           : 2022-04-27
 * description    : RcCarMcostVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-27     m2m0020             최초생성
 */
@Data
public class RcCarMcostVo {
    private String rentMcnt;
    private String milg;
    private String mantMthd;
    private String engdispmntGrdA;
    private String engdispmntGrdB;
    private String engdispmntGrdC;
    private String engdispmntGrdD;
    private String engdispmntGrdE;
    private String engdispmntGrdF;
    private String engdispmntGrdRa;
    private String engdispmntGrdRb;
    private String engdispmntGrdVa;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;

    private String type;    // type
    private int tour;    // 순회정비
    private int mant;    // 입고정비
    private int basic;   // 베이직
    private int lwpr;    // 실속형
}
