package kr.co.daiso.batch.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

/**
 * packageName    : kr.co.daiso.batch.config
 * fileName       : MybatisMySqlConfig
 * author         : Doo-Won Lee
 * date           : 2021-10-29
 * description    : MySql 사용을 위한 configuration 클래스 (Oracle 사용 결정으로 사용하지 않음)
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-29      Doo-Won Lee         최초생성
 */
//@Configuration
//@MapperScan(basePackages = "kr.co.daiso.batch.**.mapper.mysql", sqlSessionFactoryRef = "mySqlSessionFactory")
public class MybatisMySqlConfig {

    @Primary
    @Bean("sqlServerDataSource")
    @ConfigurationProperties(prefix ="spring.datasource.sqlserver")
    public DataSource sqlServerDataSource(){
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "sqlServerSessionFactory")
    public SqlSessionFactory sqlSessionFactory(
            @Qualifier("sqlServerDataSource") DataSource dataSource, ApplicationContext applicationContext) throws Exception {
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(dataSource);
        sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:mybatis-config.xml"));
        sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mapper/**/*.xml"));

        return sqlSessionFactoryBean.getObject();
    }

    @Primary
    @Bean(name = "sqlServerSessionTemplate")
    public SqlSessionTemplate sqlSessionTemplate(
            @Qualifier("sqlServerSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
