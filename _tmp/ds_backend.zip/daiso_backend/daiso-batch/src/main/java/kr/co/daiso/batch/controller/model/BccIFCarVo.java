package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@EqualsAndHashCode(callSuper=false)
public class BccIFCarVo extends DblinkVo {

    private Integer carId;

    private String carCd;

    private String cno;

    private String carHistNo;
}
