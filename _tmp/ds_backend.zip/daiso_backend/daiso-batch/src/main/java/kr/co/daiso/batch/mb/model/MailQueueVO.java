package kr.co.daiso.batch.mb.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.mb.model
 * fileName       : MailQueueVO
 * author         : kjm
 * date           : 2022-02-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-11       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MailQueueVO extends BaseModel {

    private String seq;
    private String sndrEmailAddr;
    private String sndrNm;
    private String rcvrEmailAddr;
    private String emailTmplKnd;
    private String emailTmplParam;
    private String sendStat;

    private String title;
    private String content;
}
