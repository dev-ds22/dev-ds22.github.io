package kr.co.daiso.batch.jobs.mb;

import kr.co.daiso.batch.jobs.mb.tasks.EmailInactiveMemberTask;
import kr.co.daiso.batch.jobs.mb.tasks.UpdateInactiveMemberTask;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * packageName    : kr.co.daiso.batch.jobs.mb
 * fileName       : MbJobs
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */

@Slf4j
@Configuration
public class InactiveUserUpdateJob {

    @Autowired
    JobBuilderFactory jobBuilderFactory;

    @Autowired
    StepBuilderFactory stepBuilderFactory;

    @Autowired
    SqlSessionFactory sqlSessionFactory;

    @Autowired
    UpdateInactiveMemberTask updateInactiveMemberTask;

    @Autowired
    EmailInactiveMemberTask emailInactiveMemberTask;

    String jobName = "mbJobName001";
    String stepName = "mbStepName001";
    String stepName2 = "mbStepName002";

    @Bean
    public Job inactiveUserUpdateJob() {
        return jobBuilderFactory.get(jobName)
                .incrementer(new RunIdIncrementer())
                .flow(updateInactiveMemberStep())
                .next(emailInactiveMemberStep())
                .end()
                .build();
    }

    @Bean
    @JobScope
    public Step updateInactiveMemberStep() {
        return stepBuilderFactory.get(stepName)
                .tasklet(updateInactiveMemberTask)
                .build();
    }

    @Bean
    @JobScope
    public Step emailInactiveMemberStep() {
        return stepBuilderFactory.get(stepName2)
                .tasklet(emailInactiveMemberTask)
                .build();
    }
}
