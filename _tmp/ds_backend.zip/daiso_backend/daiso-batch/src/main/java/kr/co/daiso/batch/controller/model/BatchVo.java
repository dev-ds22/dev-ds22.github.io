package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;

public class BatchVo extends CommonVo {

}
