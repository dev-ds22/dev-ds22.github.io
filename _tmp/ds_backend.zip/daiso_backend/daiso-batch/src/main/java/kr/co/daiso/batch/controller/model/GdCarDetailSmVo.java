package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : GdCarDetailSmVo
 * author         : m2m0020
 * date           : 2022-05-19
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-19     m2m0020             최초생성
 */
@Data
public class GdCarDetailSmVo {
    private String carCd;
    private int salprc;
    private String modelNm;
    private String mfgDt;
    private String regModelyr;
    private String milg;
    private String fuelType;
    private String trnsmsnCd;
    private String middleImg;
    private String mnuftrNm;
    private String extrColorNm;
    private String carctgrNm;
    private String dblink;
}
