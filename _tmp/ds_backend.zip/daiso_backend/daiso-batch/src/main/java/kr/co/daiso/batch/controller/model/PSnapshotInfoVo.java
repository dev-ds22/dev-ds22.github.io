package kr.co.daiso.batch.controller.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PSnapshotInfoVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel(value="브랜드 인증관 스냅샵 vo")
public class PSnapshotInfoVo {

    @ApiModelProperty(value = "CarCd", required = true, notes = "CarCd를 입력해주세요", example = "BC60442891, BC60442894, BC60442896...")
    @NotBlank(message="CarCd를 입력해주세요")
    private String CarCd;

    @ApiModelProperty(value = "파라미터", notes = "브랜드 인증차량 SNAPSHOP 정보 업데이트를 위한 파라미터 입니다.", example = "MALL_REG, MALL_CHG, RSV_REG, RSV_RLS, MALL_RLS, SAL_REG, CAR_DEL")
    @NotBlank(message="파라미터를 입력해 주세요")
    private String param;

    @ApiModelProperty(value = "UserID", notes = "USER_ID를 입력해주세요")
    @NotBlank(message="USER_ID를 입력해주세요")
    private String usrId;
}
