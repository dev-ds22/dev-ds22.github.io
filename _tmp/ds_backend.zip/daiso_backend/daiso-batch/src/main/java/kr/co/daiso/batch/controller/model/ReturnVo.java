package kr.co.daiso.batch.controller.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Getter
@Setter
public class ReturnVo {
    private String status;
    //private String content;
    private List<String> messages;
    private List<Map<String, Object>> info;

    /*
    public ReturnVo(String status, List<String> messages)
    {
        this.status = status;
        this.messages = messages;
    }
    */


    public ReturnVo(String status, List<Map<String, Object>> info)
    {
        this.status = status;
        this.info = info;
    }

    public ReturnVo(String status, String messages)
    {
        this.status = status;
        this.messages = new ArrayList<>();
        this.messages.add(messages);
    }
}
