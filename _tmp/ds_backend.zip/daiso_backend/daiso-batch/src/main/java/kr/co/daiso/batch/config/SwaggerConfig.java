package kr.co.daiso.batch.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * packageName    : kr.co.daiso.batch.config
 * fileName       : SwaggerConfig
 * author         : m2m0020
 * date           : 2021-04-06
 * description    : Swagger 설정파일
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-04-06          m2m0020         최초생성
 **/
//@EnableWebMvc
@Configuration
public class SwaggerConfig {
    @Bean
    public Docket api(){
        return new Docket(DocumentationType.OAS_30)
                .select()
                .apis(RequestHandlerSelectors.basePackage("kr.co.daiso.batch"))
                //.apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.any())
                //.paths(PathSelectors.ant("/proc/**"))
                .build();
//
//                .operationOrdering(new Ordering<>() {
//                    @Override
//                    public int compare(Operation left, Operation right) {
//                        return left.getMethod().name().compareTo(right.getMethod().name());
//                    }
//                });
    }
/*
    @Bean
    public UiConfiguration uiConfig() {
        return UiConfigurationBuilder
                .builder()
                .operationsSorter(OperationsSorter.METHOD)
                .build();
    }

 */
}
