package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : RentCalVo
 * author         : m2m0020
 * date           : 2022-04-26
 * description    : RentCalVo
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-26     m2m0020             최초생성
 */
@Data
public class RentCalVo {
    private String rentCarCd;
    private String rentPerdCd;
    private String mnuftrCd;
    private String modelCd;
    private String grdCd;
    private String grdDtlCd;
    private String mnuftrNm;
    private String modelNm;
    private String grdNm;
    private String grdDtlNm;
    private String cno;
    private int salprc;
    private int nPrice;
    private int prc;
    private int enPrice;
    private String ecCarCd;
    private String regDttm;
    private String modDttm;
    private String calcYn   ;
    private String roic;
    private int nwcaPrc;
    private String nRentNcarPrc;
    private int engdispmnt;
    private String joyRentCarctgr;
    private String carCtgrCd;
    private int agtCmsn;
    private String nAgentFee        ;
    private String prdcnMm;
    private String prdcnYr;
    private String remvalGrd;
    private String depositAmt;
    private String fuelCd   ;
    private String trrcCarDvs       ;
    private int mmRentCharge;
    private int nRentPrice;
    //private String gpsCost0nGpsCost;
    private int gpsCost;
    private int buyPrcst;   // 매입원가
    private int nSalsPrcst; // 매입원가
    private int addtInsfee;  // 추가 보험료 ADDT_INSFEE
    private String rentType;


    private String rentMth;
    private String mfgDt;
    private int hbrdRxpAmt;      // 하이브리드 감면액

    //private int maintenanceMonth;   //  전체 렌트 개월수
    private int rentMcnt; //RENT_MCNT 전체 렌트 개월수
}
