package kr.co.daiso.batch.mb.service.Impl;

import kr.co.daiso.batch.mb.mapper.oracle.InactiveMemberMapper;
import kr.co.daiso.batch.mb.model.MailQueueVO;
import kr.co.daiso.batch.mb.model.MemberVO;
import kr.co.daiso.batch.mb.model.SubCdVO;
import kr.co.daiso.batch.mb.service.InactiveMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.mb.service.Impl
 * fileName       : InactiveMemberServiceImpl
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */

@Service
public class InactiveMemberServiceImpl implements InactiveMemberService {

    @Autowired
    InactiveMemberMapper inactiveMemberMapper;

    @Override
    public List<MemberVO> getInactiveMemberList() {
        return inactiveMemberMapper.getInactiveMemberList();
    }

    @Override
    @Transactional
    public void insertInactiveMember(MemberVO memberVO) {
        inactiveMemberMapper.insertInactiveMember(memberVO);
    }

    @Override
    @Transactional
    public void deleteInactiveMember(MemberVO memberVO) {
        inactiveMemberMapper.deleteInactiveMember(memberVO);
    }

    @Override
    public List<MemberVO> getEmailTargetInactiveMemberList() {
        return inactiveMemberMapper.getEmailTargetInactiveMemberList();
    }

    @Override
    public List<MailQueueVO> emailQueuePopAll() {
        return inactiveMemberMapper.emailQueuePopAll();
    }

    @Override
    public List<SubCdVO> getSubCodeList(SubCdVO subCdVO) {
        return inactiveMemberMapper.getSubCodeList(subCdVO);
    }

    @Override
    @Transactional
    public void updateCmMailQueueSendStatus(MailQueueVO mailInfo) {
        inactiveMemberMapper.updateCmMailQueueSendStatus(mailInfo);
    }

    @Override
    @Transactional
    public void insertEmailQueue() {
        inactiveMemberMapper.insertEmailQueue();
    }

    @Override
    @Transactional
    public void insertEmailQueueTarget() {
        inactiveMemberMapper.insertEmailQueueTarget();
    }
}
