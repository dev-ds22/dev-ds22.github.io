package kr.co.daiso.batch.controller.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : MbAlmLogVo
 * author         : m2m0020
 * date           : 2022-06-17
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-06-17     m2m0020             최초생성
 * 2022-07-11     m2m0021             2개 추가
 */
@Data
public class MbAlmLogVo {
    private String almCd;
    private String almCnts;
    private String iqyDttm;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;
    private String seq;
    private String iqyYn;
    private String membId;
    private String almDttm;
    private String carId;

    // insert by m2m0021 (Choi in kyu) 2022-07-11
    private String aplSn;
    private String svsbAplCd;
}
