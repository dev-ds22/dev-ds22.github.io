package kr.co.daiso.batch.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : CsEmailSendStatVo
 * author         : m2m0020
 * date           : 2022-05-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-03     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CsEmailSendStatVo {
    private String seq;
    private String sndrEmailAddr;
    private String sndrNm;
    private String rcvrEmailAddr;
    private String emailTmplKnd;
    private String emailTmplParam;
    private String sendStat;
    private String rgpsId;
    private String regDttm;
    private String mdpsId;
    private String modDttm;
}
