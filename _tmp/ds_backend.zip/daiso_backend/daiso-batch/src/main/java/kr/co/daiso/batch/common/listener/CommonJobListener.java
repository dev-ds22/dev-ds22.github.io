package kr.co.daiso.batch.common.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

/**
 * packageName    : kr.co.daiso.batch.common.listener
 * fileName       : CommonJobListener
 * author         : rms
 * date           : 2022-02-10
 * description    : Job생성시 공통으로 사용하는 Listener
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-10     rms             최초생성
 */
@Slf4j
public class CommonJobListener implements JobExecutionListener {

    @Autowired
    JobExplorer jobExplorer;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String jobname = jobExecution.getJobInstance().getJobName();
        log.info("Start : {}", jobname);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("end : {}", jobExecution.getJobInstance().getJobName());
    }
}
