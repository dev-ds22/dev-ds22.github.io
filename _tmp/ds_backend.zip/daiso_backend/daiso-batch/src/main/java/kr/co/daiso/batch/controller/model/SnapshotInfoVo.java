package kr.co.daiso.batch.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : PSnapshotInfoVo
 * author         : m2m0020
 * date           : 2022-04-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-12     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SnapshotInfoVo extends DblinkVo{
    public String param;
    //public String carId;
    public String carCd;
    public String usrId;
}
