package kr.co.daiso.batch.common.service;

import kr.co.daiso.batch.common.model.TbSmSmsSendLogVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.common.service
 * fileName       : ClsCommonService
 * author         : bsj
 * date           : 2022-02-04
 * description    : 공통작업 인터페이스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-04     bsj             최초생성
 */
public interface ClsCommonService {
    /**
     * sms 전송 db에 등록
     * @param reqVo
     */
    public void insertSms(TbSmSmsSendLogVO reqVo);
    public List<String> selectJobNames();
}
