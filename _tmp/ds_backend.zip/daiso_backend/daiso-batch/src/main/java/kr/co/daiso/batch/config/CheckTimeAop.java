package kr.co.daiso.batch.config;

import lombok.extern.slf4j.Slf4j;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;


//@Aspect
//@Component
@Slf4j
public class CheckTimeAop {

    @Around("execution(* kr.co.daiso.batch.controller.procedure.*Controller.*(..))")
    public Object executionAspect(ProceedingJoinPoint joinPoint) throws Throwable
    {
        StopWatch stopWatch = new StopWatch();
	    stopWatch.start();

        Object result = joinPoint.proceed();

	    stopWatch.stop();
        log.info("controller time: {}", stopWatch.getTotalTimeMillis());
        log.info("controller time: {}", stopWatch.prettyPrint());

        return result;
    }
}
