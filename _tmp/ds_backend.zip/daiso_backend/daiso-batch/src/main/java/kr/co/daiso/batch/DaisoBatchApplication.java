package kr.co.daiso.batch;

import java.util.Date;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import kr.co.daiso.common.config.DaisoBeanNameGenerator;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableBatchProcessing
@SpringBootApplication
@ComponentScan(nameGenerator = DaisoBeanNameGenerator.class, basePackages = {"kr.co.daiso.common","kr.co.daiso.batch"})
public class DaisoBatchApplication extends SpringBootServletInitializer {

    //Batch
    public static void main(String[] args) {

        log.info("****************************************************", (new Date().toString()));

        SpringApplication application = new SpringApplication(DaisoBatchApplication.class);
        application.run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(DaisoBatchApplication.class);
    }

}

