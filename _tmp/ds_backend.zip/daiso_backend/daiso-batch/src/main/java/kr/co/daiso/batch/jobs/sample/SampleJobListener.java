package kr.co.daiso.batch.jobs.sample;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SampleJobListener extends JobExecutionListenerSupport {

    /*
    @Autowired
    public SampleJobListener() {
        System.out.println("1");
    }
    */

    @Override
    public void beforeJob(JobExecution jobExecution) {
        if(jobExecution.getStatus() == BatchStatus.STARTED) {
        System.out.println("2, " + jobExecution.getJobInstance().getJobName());
        System.out.println("2, " + jobExecution.getJobInstance().getInstanceId());
        System.out.println("2, " + jobExecution.getJobId());
        System.out.println("2, " + jobExecution.getCreateTime());
        System.out.println("2, " + jobExecution.getStartTime());
        System.out.println("2, " + jobExecution.getJobConfigurationName());
        }

    }
    @Override
    public void afterJob(JobExecution jobExecution) {
        System.out.println("3, " + jobExecution.getJobInstance().getJobName());
    }
}

