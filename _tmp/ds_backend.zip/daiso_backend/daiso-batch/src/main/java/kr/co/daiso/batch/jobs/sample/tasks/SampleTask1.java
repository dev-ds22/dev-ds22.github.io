package kr.co.daiso.batch.jobs.sample.tasks;

import kr.co.daiso.batch.sample.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import javax.annotation.Nullable;

/**
 * packageName    : kr.co.daiso.batch.jobs.sample.tasks
 * fileName       : sampleTask1
 * author         : Doo-Won Lee
 * date           : 2021-11-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-18        Doo-Won Lee         최초생성
 */
@Component
@Slf4j
@StepScope
public class SampleTask1 implements Tasklet, StepExecutionListener {

    SampleService sampleService;

    public SampleTask1(SampleService sampleService){
        this.sampleService = sampleService;
    }

    @Override
    public RepeatStatus execute(@Nullable StepContribution contribution, @Nullable ChunkContext chunkContext){
//        sampleService.getSampleCode()
//                .stream().map(code -> code.getGrCode())
//                .forEach(log::info);

        //throw new IllegalStateException("check error at processor.");
        //sampleService.testOracle();
        return RepeatStatus.FINISHED;
    }

    @Override
    public void beforeStep(@Nullable StepExecution stepExecution) {
        log.info("beforeStep");
    }

    @Override
    public ExitStatus afterStep(@Nullable StepExecution stepExecution) {
        log.info("afterStep");
        return ExitStatus.FAILED;
        //return ExitStatus.COMPLETED;
    }
}
