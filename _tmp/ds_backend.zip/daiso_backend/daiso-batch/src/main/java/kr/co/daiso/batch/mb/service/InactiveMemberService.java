package kr.co.daiso.batch.mb.service;

import kr.co.daiso.batch.mb.model.MailQueueVO;
import kr.co.daiso.batch.mb.model.MemberVO;
import kr.co.daiso.batch.mb.model.SubCdVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.batch.mb.service
 * fileName       : InactiveMemberService
 * author         : kjm
 * date           : 2022-02-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-03       kjm            최초생성
 */
public interface InactiveMemberService {
    List<MemberVO> getInactiveMemberList();

    void insertInactiveMember(MemberVO memberVO);

    void deleteInactiveMember(MemberVO memberVO);

    List<MemberVO> getEmailTargetInactiveMemberList();

    List<MailQueueVO> emailQueuePopAll();

    List<SubCdVO> getSubCodeList(SubCdVO subCdVO);

    void updateCmMailQueueSendStatus(MailQueueVO mailInfo);

    void insertEmailQueue();

    void insertEmailQueueTarget();
}
