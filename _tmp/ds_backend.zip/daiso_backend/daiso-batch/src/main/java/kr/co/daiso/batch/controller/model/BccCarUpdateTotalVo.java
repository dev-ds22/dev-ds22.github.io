package kr.co.daiso.batch.controller.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.batch.controller.model
 * fileName       : BccCarUpdateTotalVo
 * author         : m2m0020
 * date           : 2022-04-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-18     m2m0020             최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class BccCarUpdateTotalVo {

    private String param;
    private String carCd;
    private int carId;
    private String usrId;
    private int carRegCnt;
    private String mallRegYn;

    private String statCd;
    private String sellStatCd;

    private String statChngDt;
    private String carDeldt;
    private String resvYn;

    private String fstMallRegYn;
}
