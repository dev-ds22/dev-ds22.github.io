package kr.co.daiso.batch.controller.model;

import kr.co.daiso.batch.common.model.CommonVo;
import kr.co.daiso.common.exception.CommonException;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

@Data
@EqualsAndHashCode(callSuper=false)
public class IFCarVo extends CommonVo {

    private String carNumber;

}
