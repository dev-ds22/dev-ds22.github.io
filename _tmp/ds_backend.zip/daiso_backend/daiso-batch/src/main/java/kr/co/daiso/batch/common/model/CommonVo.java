package kr.co.daiso.batch.common.model;


import kr.co.daiso.common.annotation.MaskingField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;

import java.io.Serializable;
import java.util.List;


/**
 * packageName    : kr.co.daiso.batch.common.model
 * fileName       : CommonVo
 * author         : rms
 * date           : 2022-02-10
 * description    : 공통 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-10     rms             최초생성
 */
@RequiredArgsConstructor
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonVo implements Serializable {
//public class CommonVo {

    @Value("${dblink}")
    private String dblink;

    @MaskingField(MaskingField.MaskingType.NAME)
    private String rgpsId;
    private String regDttm;

    @MaskingField(MaskingField.MaskingType.NAME)
    private String mdpsId;
    private String modDttm;

    private int RNUM;

    private int i_iStartRownum;
    private int i_iEndRownum;

    private List<String> jobNames;
}