package kr.co.daiso.batch.scheduler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

@Slf4j
@Component
@EnableScheduling
public class BatchScheduler {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    protected JobRegistry jobRegistry;

    @Autowired
    JobExplorer jobExplorer;

    //임직원 정보 연계
    @Autowired
    private Job userUpdateBatch;

    //코드 정보 연계
    @Autowired
    private Job eccOptionPr;

    // 테마 기획전 사용기간 검사
    @Autowired
    private Job updateInactiveTheme;

    //UCMS 차량 정보 갱신
    @Autowired
    private Job purchaseCarList;

    //사고이력 동기화
    @Autowired
    private Job updateCarHistoryBatch;

    // 판매 준비차량 광고등록 고객 문자 알림
    @Autowired
    private Job purchaseCarBatch;

    //판매준비차량 신청내역 자동취소
    @Autowired
    private Job ManagePrepareCarAutoCancels;

    //차량 조회
    @Autowired
    @Qualifier("CarViewLogProc")
    private Job CarViewLogProcJob;

    //차량 정렬정보 업데이트
    @Autowired
    @Qualifier("CarUpdateOrder")
    private Job CarUpdateOrderJob;

    //구해줘 엔카 서치카 종료 게시물 상태 자동 변경
    @Autowired
    @Qualifier("HelpStatusUpdatePr")
    private Job HelpStatusUpdatePrJob;

    //통계 - 차량별 일별 조회 카운트
    @Autowired
    @Qualifier("CarViewDayTotal")
    private Job CarViewDayTotalJob;

    //관리비용 업데이트 매일 00시
    @Autowired
    @Qualifier("MgtcostListUpdatePr")
    private Job MgtcostListUpdatePrJob;


    //model change
    @Autowired
    @Qualifier("ModelChange")
    private Job ModelChangeJob;

    //  deleteSearchCar
    @Autowired
    @Qualifier("deleteSearchCarBatch")
    private Job deleteSearchCarBatchJob;


    //10분마다 납부관리 배치 검사
    @Autowired
    @Qualifier("CarCashBatchJob")
    private Job carCashBatchJob;

    //해피콜 상태
    @Autowired
    @Qualifier("HappyCallStatusJob")
    private Job happyCallStatusJob;

    //가상계좌 잔여 10%(20%) 시 SMS 발송 (2시간마다 실행)
    @Autowired
    @Qualifier("GetImgnAcnoRatioJob")
    private Job getImgnAcnoRatioJob;

    //  관심차량등록 문자알림 (매 30분마다 실행)
    @Autowired
    @Qualifier("HelpSearchCarSms")
    private Job HelpSearchCarSmsJob;

    //  렌터카 가격 갱신한다.
    @Autowired
    @Qualifier("UpdateRentcarNPriceBatch")
    private Job UpdateRentcarNPriceJob;

    //  조이렌트 차량 마스터 업데이트
    @Autowired
    @Qualifier("UpdateJoyMasterBatch")
    private Job UpdateJoyMasterJob;

    //  구글 GA
    @Autowired
    @Qualifier("UpdateGoogleContentApiBatch")
    private Job UpdateGoogleContentApiJob;

    //  UCMS으로 부터 받아온 휴일을 업데이트한다.
    @Autowired
    @Qualifier("updateHolyDayBatch")
    private Job updateHolyDayJob;

    // 장기재고 위클리 이벤트 매주 화요일 오전 10시 업데이트
    @Autowired
    @Qualifier("StockCarInfoUpdatePrBatch")
    private Job StockCarInfoUpdatePrJob;

    // 휴면회원 전환 및 메일발송
    @Autowired
    private Job inactiveUserUpdateJob;

    // 탈퇴회원 정보 업데이트
    @Autowired
    private Job updateMemberLeaveJob;

    // 홈서비스 신청 5시간 이내 없을 시 SMS 발송
    @Autowired
    @Qualifier("homeSvcAplZeroJobJob")
    private Job homeSvcAplZeroJobJob;

    // 개인정보 이용 통지 안내 메일 발송 (구:메일 재발송 - 잘못 발송된 메일에 대한 사과메일)
    @Autowired
    @Qualifier("indvInfoUseBkdnNtfyJob")
    private Job indvInfoUseBkdnNtfyJob;

    // 잘못된 차량 판매 처리
    @Autowired
    @Qualifier("CarDataUpdatePrJob")
    private Job CarDataUpdatePrJob;

    // 인기차량 등록
    @Autowired
    @Qualifier("PopurtCarRegJob")
    private Job PopurtCarRegJob;

    /**
     * 05-03 관심차량알림 기간종료 삭제
     *  배치ID KCAR-BT-007
     * 실행주기 0 0 2 * * * (1일 / 1회 / 02시)
     */
    @Scheduled(cron="0 0 2 * * *")
    public void DeleteSearchCarBatch() {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(deleteSearchCarBatchJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 02-24
     * 배치ID KCAR-BT-038
     * 배치명 모델을 변경한다.
     * JobID modelChange
     * 프로그램ID PMPGD16160B
     * 실행주기 1일 / 1회 / 10시
     */
    @Scheduled(cron="0 0 10 * * *")
    public void ModelChangeBatch() {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(ModelChangeJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 관리비용 업데이트 매일 00시
     * 배치ID KCAR-BT-037
     * 배치명 관리비용 업데이트 (매일 00시 1회 실행)
     * JobID
     * 프로그램ID PMPGD16150B
     * 실행주기 1일 / 1회 / 00시
     */
    @Scheduled(cron="0 0 0 * * *")
    public void MgtcostListUpdatePrBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(MgtcostListUpdatePrJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

/**
     * 통계 - 차량별 일별 조회 카운트
     * 배치ID KCAR-BT-029
     * 배치명 차량별 일별 조회 카운트
     * JobID carViewDayTotal
     * 프로그램ID PMPGD16140B
     * 실행주기 1일 / 1회 / 22시
     */
    @Scheduled(cron="0 0 22 * * *")
    public void CarViewDayTotalBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(CarViewDayTotalJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }
    /**
     * 구해줘 엔카 서치카 종료 게시물 상태 자동변경
     * 배치ID KCAR-BT-029
     * 배치명 차량 정렬정보 업데이트
     * JobID HelpStatusUpdatePrBatch
     * 프로그램ID PMPGD16130B
     * 실행주기 1일 / 1시간마다
     */
    @Scheduled(cron="0 0 */1 * * *")
    public void HelpStatusUpdatePrBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(HelpStatusUpdatePrJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 차량 정렬정보 업데이트
     * 배치ID KCAR-BT-029
     * 배치명 차량 정렬정보 업데이트
     * JobID CarUpdateOrder
     * 프로그램ID PMPGD16080B
     * 실행주기 1일 / 1회 / 21시48분
     */
    @Scheduled(cron="0 48 21 * * *")
    public void CarUpdateOrderBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(CarUpdateOrderJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 차량 조회 로그 처리
     * 배치ID KCAR-BT-030
     * 배치명 차량 조회 로그 처리
     * JobID CarViewLogProcJob
     * 프로그램ID PMPGD16060B
     * 실행주기 1일 / 1회 / 21시48분
     */
    @Scheduled(cron="0 48 12 * * *")
    public void CarViewLogProcBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(CarViewLogProcJob, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 판매준비차량 광고등록 고객 문자알림
     * 배치ID KCAR-BT-010
     * 배치명 판매준비차량 신청내역 자동취소 관리
     * JobID ManagePrepareCarAutoCancelsBatch
     * 프로그램ID PMPGD16060B
     * 실행주기 매시 10분마다 배치 동작
     */
    @Scheduled(cron="0 */10 * * * *")
    public void ManagePrepareCarAutoCancelsBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(ManagePrepareCarAutoCancels, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }


    /**
     * 판매준비차량 광고등록 고객 문자알림
     * 배치ID KCAR-BT-005
     * 배치명 판매준비차량 광고등록 고객 문자알림
     * JobID checkPurchaseCarBatch
     * 프로그램ID PMPGD16050B
     * 실행주기 1일 / 8-20시 / 3분
     */
    @Scheduled(cron="0 */3 8-20 * * *")
    public void checkPurchaseCarBatch()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(purchaseCarBatch, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 사고이력 동기화
     * 배치ID KCAR-BT-004
     * 배치명 사고이력 동기화
     * JobID updateCarHistory
     * 프로그램ID PMPGD16030B
     * 실행주기 1일 / 매시간마다
     */
    @Scheduled(cron="0 0 */1 * * *")
    public void updateCarHistory()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(updateCarHistoryBatch, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * UCMS 매입등록차량 테이블에서 직영몰 테이블로 동기화
     * 배치ID KCAR-BT-004
     * 배치명 직영몰 테이블 동기화
     * JobID mergePurchaseCarList
     * 프로그램ID PMPGD16010B
     * 실행주기 1일 / 8-20시 / 05분, 35분마다
     */
    @Scheduled(cron="0 05,35 8-20 * * *")
    public void purchaseCar()  {
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(purchaseCarList, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /**
     * 테마기획전 사용기간 검사
     * 배치ID KCA_BT_0011
     * 배치명 테마기획전 사용기간 검사
     * JobID updateInactiveTheme
     * 프로그램ID PMPDS01010B
     * 실행주기 1일 / 1회 / 00시 10분
     */
    @Scheduled(cron="0 10 0 * * *")
    public void updateInactiveTheme()  {
        try {
            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(updateInactiveTheme, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();

        }
    }



    /**
     * 코드정보를 UPDATE한다
     * 배치ID KCA_BT_0033
     * 배치명 직원 정보 동기화
     * JobID eccOptionPr
     * 프로그램ID PMPSM02110B
     * 실행주기 매일 / 1시간마다
     */
    @Scheduled(cron="0 0 */1 * * *")
    public void eccOptionPr(){
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();
            JobExecution jobExecution = jobLauncher.run(eccOptionPr, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();

        }
    }

    /**
     * 직원 정보 동기화 배치
     * 배치ID KCA_BT_0019
     * 배치명 직원 정보 동기화
     * JobID userUpdateBatch
     * 프로그램ID PMPSM02100B
     * 실행주기 1일 / 8-23시 매시간마다
     */
    @Scheduled(cron="0 0 08-23/1 * * *")
    public void userUpdateBatch(){
        try {

            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();
            JobExecution jobExecution = jobLauncher.run(userUpdateBatch, jobParameters);

            log.info("name : {} ", jobExecution.getJobInstance().getJobName());
            log.info("status : {}", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();

        }
    }

    /*
     * 10분마다 납부관리 배치 검사
     * @배치ID KCA_BT_0013
     * @배치명 납부관리 배치검사
     * @JobID carCashBatch
     * @프로그램ID PMPBC01010B
     * @실행주기 1일 / 10분마다
     */
    @Scheduled(cron="0 */10 * * * *")
    public void carCashBatchJob(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(carCashBatchJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

/*
     * 해피콜상태 업데이트
     * @배치ID KCA_BT_0016
     * @배치명 해피콜상태
     * @JobID happyCallStatus
     * @프로그램ID PMPCS01010B
     * @실행주기 1일 / 1회 / 00시 10분
     */
    @Scheduled(cron="0 10 0 * * *")
    public void happyCallStatusJob(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(happyCallStatusJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * 사용가능한 가상계좌 잔여 10%(20%) 미만 시 SMS 문자발송
     * @배치ID KCA_BT_0008
     * @배치명 가상계좌 SMS발송
     * @JobID getImgnAcnoRatio
     * @프로그램ID PMPBC01020B
     * @실행주기 1일 / 2시간마다
     */
    @Scheduled(cron="0 0 */2 * * *")
    public void getImgnAcnoRatioScheduler(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(getImgnAcnoRatioJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     관심차량 문자관리관심차량등록 문자알림 (매 30분마다 실행)
     * @프로그램ID  PMPGD01090B
     * @실행주기    1일 / 9-18시 / 30분
     */
//    @Scheduled(cron="0 */30 9,10,11,12,13,14,15,16,17,18 * * *")
    public void searchCarSmsSend(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(HelpSearchCarSmsJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     렌터카 가격 갱신한다.
     * @프로그램ID  PMPRM01010B
     * @실행주기    1일 / 1회 / 2시
     */
    @Scheduled(cron="0 0 2 * * *")
    public void UpdateRentcarNPrice(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(UpdateRentcarNPriceJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     조이렌트 차량 마스터 업데이트(RE)
     * @프로그램ID  PMPRM01020B
     * @실행주기    1일 / 1회 / 5시
     */
    @Scheduled(cron="0 0 5 * * *")
    public void JoyMaster(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(UpdateJoyMasterJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     구글 GA
     * @프로그램ID  PMPGD01120B
     * @실행주기    1일 / 20분마다
     */
    @Scheduled(cron="0 */20 * * * *")
    public void googleGA(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(UpdateGoogleContentApiJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     UCMS으로 부터 받아온 휴일을 업데이트한다.
     * @프로그램ID  PMPGD01100B
     * @실행주기    1일 / 1회 / 2시
     */
    @Scheduled(cron="0 0 2 * * *")
    public void updateHolyDay(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(updateHolyDayJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

   /*
     * @배치명     장기재고 위클리 이벤트 오전 10시 업데이트
     * @프로그램ID
     * @실행주기    1일 / 1회 / 10시
     */
    @Scheduled(cron="0 0 10 * * *")
    public void StockCarInfoUpdatePr(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(StockCarInfoUpdatePrJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * 9시30분 휴면회원 전환 및 메일발송
     * @배치ID KCAR-BT-006
     * @배치명 휴면계정 전환 메일발송
     * @JobID inactiveUserUpdateJob
     * @프로그램ID PMPMB05010B, PMPMB05020B
     * @실행주기 1일 / 09시 30분
     */
    @Scheduled(cron="0 30 9 * * ?")
    public void updateInactiveUserBatchJob(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();
        try {
            JobExecution jobExecution = jobLauncher.run(inactiveUserUpdateJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * 00시 탈퇴회원 정보 업데이트
     * @배치ID KCAR-BT-062
     * @배치명 회원탈퇴 업데이트
     * @JobID updateMemberLeaveJob
     * @프로그램ID PMPMG00010B
     * @실행주기 1일 / 00시 00분
     */
    @Scheduled(cron="0 0 0 * * ?")
    public void updateMemeberLeaveBatchJob(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();
        try {
            JobExecution jobExecution = jobLauncher.run(updateMemberLeaveJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * 홈서비스 신청 5시간 이내 없을 시 SMS 발송
     * @배치ID KCAR-BT-009
     * @배치명 홈서비스 신청 SMS 발송
     * @JobID homeSvcAplZeroJobJob
     * @프로그램ID PMPBC02010B
     * @실행주기 30분마다 실행
     */
    @Scheduled(cron="0 */30 * * * *")
    public void homeSvcAplZeroJobJob(){
        try {
            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(homeSvcAplZeroJobJob, jobParameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * 개인정보 이용 통지 안내 메일 발송 (구:메일 재발송 - 잘못 발송된 메일에 대한 사과메일)
     * @배치ID KCAR-BT-018
     * @배치명 개인정보 이용 내역 통지
     * @JobID indvInfoUseBkdnNtfyJob
     * @프로그램ID PMPMB05030B
     * @실행주기 12월 28일 10시
     */
//    @Scheduled(cron="0 0 10 28 12 *")
    public void indvInfoUseBkdnNtfyJob(){
        try {
            JobParameters jobParameters = new JobParametersBuilder()
                    .addDate("date", new Date())
                    .toJobParameters();

            JobExecution jobExecution = jobLauncher.run(indvInfoUseBkdnNtfyJob, jobParameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     잘못된 차량 판매 처리
     * @프로그램ID  PMPGD16070B
     * @실행주기    1일 / 1시간마다
     */
//    @Scheduled(cron="0 0 */1 * * *")
    public void CarDataUpdatePr(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(CarDataUpdatePrJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }

    /*
     * @배치명     인기차량 등록
     * @프로그램ID  PMPGD01140B
     * @실행주기    1일 / 3시
     */
    @Scheduled(cron="0 0 3 * * *")
    public void popurtCarReg(){
        JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution jobExecution = jobLauncher.run(PopurtCarRegJob, jobParameters);
            log.info("JOB STATUS:::{}", jobExecution.getStatus());
            log.info("JOB IS:::{}", jobExecution);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            e.printStackTrace();
        }
    }
}