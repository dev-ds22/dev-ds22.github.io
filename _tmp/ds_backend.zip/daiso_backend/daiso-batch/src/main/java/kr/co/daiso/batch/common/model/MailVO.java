package kr.co.daiso.batch.common.model;

import lombok.Data;

@Data
public class MailVO {

    private boolean send;
    private String errorMessage;
}
