package kr.co.daiso.batch.common.model;

import lombok.Data;
/**
 * packageName    : kr.co.daiso.batch.jobs.extra.model
 * fileName       : CmSubCdVo
 * author         : rms
 * date           : 2022-02-10
 * description    : TB_CM_SUB_CD
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-10     rms             최초생성
 */
@Data
public class CmSubCdVo {
    private String masterCd;  // 마스터코드
    private String subCd;  // 서브코드
    private String subCdNm;  // 서브코드명
    private String subCdEngNm;  // 서브코드영문명
    private String sortOrdr;  // 정렬순서
    private String hrnkGrpCd;  // 상위그룹코드
    private String ucmsCdYn;  // UCMS코드여부
    private String addtFld1;  // 추가필드1
    private String addtFld2;  // 추가필드2
    private String addtFld3;  // 추가필드3
    private String addtFld11;  // 추가필드11
    private String addtFld12;  // 추가필드12
    private String addtFld13;  // 추가필드13
    private String addtFld14;  // 추가필드14
    private String addtFld15;  // 추가필드15
    private String addtFld16;  // 추가필드16
    private String addtFld17;  // 추가필드17
    private String addtFld18;  // 추가필드18
    private String useYn;  // 사용여부
    private String delYn;  // 삭제여부
    private String rgpsId;  // 등록자아이디
    private String regDttm;  // 등록일시
    private String mdpsId;  // 수정자아이디
    private String modDttm;  // 수정일시

    private String[] subCdList;
}
