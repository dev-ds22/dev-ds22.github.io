package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : CommonCodeMangeMapper
 * author         : Doo-Won Lee
 * date           : 2021-12-01
 * description    : 공통코드 관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01        Doo-Won Lee         최초생성
 */
@Mapper
public interface CommonCodeManageMapper {

     //마스터 코드의 카운트를 구한다.
     int getMstCodeListCount(CommonCodeSearchVO reqVo);

     //마스터 코드의 목록을 구한다.
     List<CommonCodeManageVO> getMstCodeList(CommonCodeSearchVO reqVo);

     //서브 코드의 카운트를 구한다.
     int getSubCodeListCount(CommonCodeSearchVO reqVo);

     //서브 코드의 목록을 구한다.
     List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO reqVo);

     //그룹코드를 저장한다.
     int insertMasterCode(List<CommonCodeManageVO> createRows);

     //그룹코드를 수정한다.
     int updateMasterCode(List<CommonCodeManageVO> updateRows);

     //서브코드를 저장한다.
     int insertSubCode(List<CommonCodeManageVO> createRows);

     //서브코드를 수정한다.
     int updateSubCode(List<CommonCodeManageVO> updateRows);
}
