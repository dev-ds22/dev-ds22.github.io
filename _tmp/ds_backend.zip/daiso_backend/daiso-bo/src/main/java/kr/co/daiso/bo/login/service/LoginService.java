package kr.co.daiso.bo.login.service;

import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.login.model.LoginReqVO;
import kr.co.daiso.common.model.CommonResponseModel;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.login.service
 * fileName       : LoginService
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    : 관리자 로그인 처리 서비스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02      Doo-Won Lee         최초생성
 */
public interface LoginService {

    //관리자로 접근 가능한 권한 그룹 조회
    public List<String> getAdminAuthGrpCd();
    //로그인 처리
    public ResponseEntity<CommonResponseModel> loginProcess(LoginReqVO loginParams, HttpServletResponse response, HttpServletRequest request);
    //관리자 비밀번호 변경
    public ResponseEntity<CommonResponseModel> changePassword(AdminAccountInfo adminAccountInfo, HttpServletResponse response, HttpServletRequest request);
    //로그아웃 처리
    public ResponseEntity<CommonResponseModel> logoutProcess(LoginReqVO loginParams, HttpServletResponse response, HttpServletRequest request);
    //로그인된 관리자 정보 조회
    public ResponseEntity<CommonResponseModel> getLoginAdmininfo(HttpServletResponse response, HttpServletRequest request);
}
