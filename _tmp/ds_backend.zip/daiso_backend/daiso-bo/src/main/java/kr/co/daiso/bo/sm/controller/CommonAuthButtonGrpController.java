package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.bo.sm.model.CommonAuthBtnVO;
import kr.co.daiso.bo.sm.service.CommonAuthButtonGrpService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : CommonAuthButtonGrpController
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 관리자 공통 버튼 그룹관련 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08     Doo-Won Lee      최초생성
 */
@RestController
@RequestMapping("/sysmg/commonAuthBtn")
@Api(tags = {"관리자 공통 버튼 그룹관련 컨트롤러"})
public class CommonAuthButtonGrpController {

    @Autowired
    CommonAuthButtonGrpService commonAuthButtonGrpService;

    @ApiOperation("공통버튼 사용가능 정보 조회")
    @GetMapping("/getAuthButtonAvailable")
    public ResponseEntity<CommonResponseModel> getAuthButtonAvailable(CommonAuthBtnVO reqVo){
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(commonAuthButtonGrpService.getAuthButtonAvailable(reqVo)), HttpStatus.OK);
    }
}
