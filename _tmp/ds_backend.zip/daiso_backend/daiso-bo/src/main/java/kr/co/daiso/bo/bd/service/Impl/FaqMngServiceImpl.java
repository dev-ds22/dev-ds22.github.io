package kr.co.daiso.bo.bd.service.Impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.bd.mapper.oracle.FaqMngMapper;
import kr.co.daiso.bo.bd.model.FaqVO;
import kr.co.daiso.bo.bd.service.FaqMngService;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * packageName    : kr.co.daiso.bo.bd.service
 * fileName       : FaqMngServiceImpl
 * author         : kjm
 * date           : 2022-01-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       kjm            최초생성
 */
@Service
public class FaqMngServiceImpl implements FaqMngService {

    @Autowired
    private FaqMngMapper faqMngMapper;

    @Autowired
    private AdminAccountInfoUtil adminAccountInfoUtil;

    @Autowired
    CommonCodeManageService commonCodeManageService;

    /**
     * methodName : searchFaqList
     * author : kjm
     * description : FAQ 목록 조회
     *
     * @param faqVO
     * @return List<FaqVO>
     */
    @Override
    public List<FaqVO> searchFaqList(FaqVO faqVO) {
        CommonCodeSearchVO searchVo = new CommonCodeSearchVO();
        searchVo.setSMstCode("KCA_FAQ_CATE");
        Map<String, String> qstnClsfMap = commonCodeManageService
                                            .getSubCodeList(searchVo)
                                            .stream()
                                            .collect(Collectors.toMap(CommonCodeManageVO::getSubCd, CommonCodeManageVO::getSubCdNm));
        List<FaqVO> faqList = faqMngMapper.searchFaqList(faqVO);
        faqList.stream().forEach(faq -> faq.setQstnClsf(qstnClsfMap.get(faq.getQstnClsf())));
        return faqList;
    }

    /**
     * methodName : getFaqTotalCount
     * author : kjm
     * description : FAQ 목록 개수 조회
     *
     * @param faqVO
     * @return int
     */
    @Override
    public int getFaqTotalCount(FaqVO faqVO) {
        return faqMngMapper.getFaqTotalCount(faqVO);
    }

    /**
     * methodName : searchFaqDetail
     * author : kjm
     * description : FAQ 상세 조회
     *
     * @param sq
     * @return FaqVO
     */
    @Override
    public FaqVO searchFaqDetail(String sq) {
        return faqMngMapper.searchFaqDetail(sq);
    }

    /**
     * methodName : updateFaq
     * author : kjm
     * description : FAQ 등록, 수정
     *
     * @param faqVO
     * @return int
     */
    @Override
    public int updateFaq(FaqVO faqVO) {
        String userId = adminAccountInfoUtil.getUsrId();
        faqVO.setRgpsId(userId);  // 회원아이디로
        faqVO.setMdpsId(userId);

        if(!StringUtils.hasText(faqVO.getSq())) {
          faqVO.setSq(faqMngMapper.getNewFaqSq());
        }
        return faqMngMapper.updateFaq(faqVO);
    }

    /**
     * methodName : updateFaqOnGrid
     * author : kjm
     * description : faq 그리드에서 수정
     *
     * @param linkedHashMap
     */
    @Override
    public void updateFaqOnGrid(LinkedHashMap<String, Object> linkedHashMap) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<FaqVO> updatedRows =  objectMapper.convertValue(linkedHashMap.get("updatedRows"), new TypeReference<List<FaqVO>>() {});
        updatedRows.forEach(faqMngMapper::updateFaqOnGrid);
    }
}
