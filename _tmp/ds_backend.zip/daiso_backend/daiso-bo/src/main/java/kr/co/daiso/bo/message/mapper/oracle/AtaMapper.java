package kr.co.daiso.bo.message.mapper.oracle;

import kr.co.daiso.bo.message.model.AtaVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.bo.message.mapper.oracle
 * fileName       : AtaMapper
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */
@Mapper
public interface AtaMapper {

    String selectMessage(AtaVO ataVO);

    String selectMtpr(AtaVO ataVO);

    void insertAta(AtaVO ataVO);
}
