package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AdminCnntnLogSearchVO
 * author         : Doo-Won Lee
 * date           : 2022-02-04
 * description    : 관리자 접속로그 조회검색VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-04      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AdminCnntnLogSearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String keyword;  //검색어
    private String authGrpType; //권한 그룹 유형
}
