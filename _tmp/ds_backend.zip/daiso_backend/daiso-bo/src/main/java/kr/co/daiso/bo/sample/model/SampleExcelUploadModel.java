package kr.co.daiso.bo.sample.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sample.model
 * fileName       : SampleExcelUploadModel
 * author         : Doo-Won Lee
 * date           : 2021-12-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-24      Doo-Won Lee        최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SampleExcelUploadModel extends BaseModel {
    private String id;
    private String name;
    private String gender;
    private String useYn;
}
