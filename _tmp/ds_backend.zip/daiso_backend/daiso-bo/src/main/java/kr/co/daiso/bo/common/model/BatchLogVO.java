package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : BatchLogVO
 * author         : Doo-Won Lee
 * date           : 2022-02-15
 * description    : 배치실행 결과 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class BatchLogVO extends CommonPagingVo {

    private String jobInstanceId;    //Job Instance ID
    private String jobName;          //JobName
    private String createTime;       //CreateTime
    private String startTime;        //Start Time
    private String endTime;          //End Time
    private String status;           //Status
    private String exitCode;         //ExitCode
    private String exitMessage;      //ExitMessage
}
