package kr.co.daiso.bo.message.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.bo.message.model
 * fileName       : AtaVO
 * author         : kjm
 * date           : 2022-01-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-03       kjm            최초생성
 */
@Data
public class AtaVO {

    private String dbLinkValue;

    private String mtPr;
    private String mtRefkey;
    private String priority;
    private String msgClass;
    private String dateClientReq;
    private String subject;    //메세지제목
    private String contentType;
    private String content;
    private String attachFileGroupKey;
    private String callback;
    private String serviceType;    // 3 카카오톡 알림톡
    private String broadcastYn;
    private String msgStatus;        // 메세지상태(1-전송대기, 2-결과대기, 3-완료)
    private String recipientNum; //
    private String dateMtSent;
    private String dateRslt;
    private String dateMtReport;
    private String mtReportCodeIb;
    private String mtReportCodeIbtype;
    private String carrier;
    private String ssId;
    private String recipientNet;
    private String recipientNpsend;
    private String countryCode;
    private String charset;
    private String msgType;    // 메시지종류(1008-카카오톡 알림톡, 1009-카카오톡 친구톡)
    private String cryptoYn;
    private String ttl;
    private String ataId;
    private String regDate;
    private String mtResCnt;
    private String senderKey;    // 카카오톡 알림톡 발신 프로필 키
    private String templateCode;
    private String responseMethod;
    private String messageGroupCode;
    private String attachmentType;
    private String attachmentName;
    private String attachmentUrl;
    private String imgUrl;
    private String imgLink;
    private String etcText1;
    private String etcText2;
    private String etcText3;
    private String etcNum1;
    private String etcNum2;
    private String etcNum3;
    private String etcDate1;
    private String eogTable;
    private String tmplType;
}
