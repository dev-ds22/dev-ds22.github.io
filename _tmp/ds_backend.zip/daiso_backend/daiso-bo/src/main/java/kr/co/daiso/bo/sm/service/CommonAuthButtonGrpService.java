package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.CommonAuthBtnVO;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : CommonAuthButtonGrpService
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 공통 버튼 그룹처리 Interface
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       Doo-Won Lee     최초생성
 */
public interface CommonAuthButtonGrpService {

    //공통버튼 사용가능 정보 조회
    public CommonAuthBtnVO getAuthButtonAvailable(CommonAuthBtnVO reqVo);
}
