package kr.co.daiso.bo.sm.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : CommonCodeManageController
 * author         : Doo-Won Lee
 * date           : 2021-12-01
 * description    : 공통코드 관리 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01      Doo-Won Lee     최초생성
 */
@Slf4j
@RestController
@RequestMapping("/sysmg/commoncode")
@Api(tags = {"공통코드 관리 컨트롤러"})
public class CommonCodeManageController {

    @Autowired
    CommonCodeManageService commonCodeManageService;

    @ApiOperation("그룹 코드 목록 조회")
    @GetMapping("/getMasterCodeList")
    public ResponseEntity<CommonResponseModel> getMasterCodeList(@ApiParam("그룹 코드 검색 정보") CommonCodeSearchVO searchVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.getMasterCodeList");
        Map<String, Object> resultMap = new HashMap<>();

//        int recordCnt	= commonCodeManageService.getMstCodeListCount(searchVo);
        List<CommonCodeManageVO> list	= commonCodeManageService.getMstCodeList(searchVo);
        resultMap.put("commonCodeList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("서브 코드 목록 조회")
    @GetMapping("/getSubCodeList")
    public ResponseEntity<CommonResponseModel> getSubCodeList(@ApiParam("서브 코드 검색 정보") CommonCodeSearchVO searchVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.getSubCodeList");
        Map<String, Object> resultMap = new HashMap<>();

//        int recordCnt	= commonCodeManageService.getSubCodeListCount(searchVo);
        List<CommonCodeManageVO> list	= commonCodeManageService.getSubCodeList(searchVo);
        resultMap.put("commonSubCodeList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("그룹 코드 목록 조회(페이징사용)")
    @GetMapping("/getMasterCodePagingList")
    public ResponseEntity<CommonResponseModel> getMasterCodePagingList(@ApiParam("그룹 코드 검색 정보") CommonCodeSearchVO searchVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.getMasterCodePagingList");
        Map<String, Object> resultMap = new HashMap<>();
        searchVo.setTotal(commonCodeManageService.getMstCodeListCount(searchVo));
//        int recordCnt	= commonCodeManageService.getMstCodeListCount(searchVo);
        List<CommonCodeManageVO> list	= commonCodeManageService.getMstCodeList(searchVo);
        resultMap.put("commonCodeList", list);
        resultMap.put("searchInfo", searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("서브 코드 목록 조회(페이징사용)")
    @GetMapping("/getSubCodePagingList")
    public ResponseEntity<CommonResponseModel> getSubCodePagingList(@ApiParam("서브 코드 검색 정보") CommonCodeSearchVO searchVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.getSubCodePagingList");
        Map<String, Object> resultMap = new HashMap<>();
        searchVo.setTotal(commonCodeManageService.getSubCodeListCount(searchVo));

        List<CommonCodeManageVO> list	= commonCodeManageService.getSubCodeList(searchVo);
        resultMap.put("commonSubCodeList", list);
        resultMap.put("searchInfo", searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


    @ApiOperation("그룹 코드 저장 & 업데이트")
    @PostMapping("/saveMasterCodeList")
    public ResponseEntity<CommonResponseModel> saveMasterCodeList(@ApiParam("그룹 코드 저장 정보") @RequestBody LinkedHashMap<String,Object> saveVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.saveMasterCodeList");
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<CommonCodeManageVO> createRows = mapper.convertValue(saveVo.get("createdRows"), new TypeReference<List<CommonCodeManageVO>>(){});
        List<CommonCodeManageVO> updateRows = mapper.convertValue(saveVo.get("updatedRows"), new TypeReference<List<CommonCodeManageVO>>(){});

        CommonResponseModel resultModel = commonCodeManageService.saveMasterCodeList(createRows,updateRows);

        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
    }

    @ApiOperation("상세 코드 저장 & 업데이트")
    @PostMapping("/saveSubCodeList")
    public ResponseEntity<CommonResponseModel> saveSubCodeList(@ApiParam("서브 코드 저장 정보") @RequestBody LinkedHashMap<String,Object> saveVo
            , HttpServletResponse response){
        log.info("CommonCodeManageController.saveSubCodeList");
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<CommonCodeManageVO> createRows = mapper.convertValue(saveVo.get("createdRows"), new TypeReference<List<CommonCodeManageVO>>(){});
        List<CommonCodeManageVO> updateRows = mapper.convertValue(saveVo.get("updatedRows"), new TypeReference<List<CommonCodeManageVO>>(){});

        CommonResponseModel resultModel = commonCodeManageService.saveSubCodeList(createRows,updateRows);

        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
    }
}
