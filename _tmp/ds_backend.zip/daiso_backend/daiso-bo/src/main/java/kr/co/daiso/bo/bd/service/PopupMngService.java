package kr.co.daiso.bo.bd.service;

import kr.co.daiso.bo.bd.model.PopupDetailVO;
import kr.co.daiso.bo.bd.model.PopupVO;

import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.bd.service
 * fileName       : PopupMngService
 * author         : kjm
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14       kjm            최초생성
 */
public interface PopupMngService {

    // 팝업 목록 개수 조회
    int searchPopupListCount(PopupVO popupVO);

    // 팝업 목록 조회
    List<PopupVO> searchPopupList(PopupVO popupVO);

    // 팝업 상세 조회
    Map<String, Object> searchPopupDetail(String ppupCd);

    // 팝업 조회
    PopupVO searchPopup(String ppupCd);

    // 팝업 생성
    void insertPopup(Map<String, Object> paramMap);

    // 팝업 수정
    void updatePopup(Map<String, Object> paramMap);

    // 팝업 삭제
    void deletePopup(PopupVO popupVO);

    // 팝업 상세 삭제
    void deletePopupDetail(PopupDetailVO popupDetailVO);

}
