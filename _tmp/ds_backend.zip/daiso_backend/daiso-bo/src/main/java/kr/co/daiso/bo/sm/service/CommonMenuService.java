package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.sm.model.MenuVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.menu.service
 * fileName       : MenuService
 * author         : kjm
 * date           : 2021-12-08
 * description    : 메뉴관리 관련 기능
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       kjm            최초생성
 */
public interface CommonMenuService {

    // 메뉴 목록 조회
    List<MenuVO> getMenuList(MenuVO menuVO);

    // 메뉴 카운트 조회
    int getMenuListCount(MenuVO menuVO);

    // 메뉴 상세 조회
    MenuVO getMenuDetail(MenuVO menuVO);

    // 메뉴 정보 검색
    List<MenuVO> searchMenu(MenuVO menuVO);

    // 메뉴 정보 추가, 변경
    void updateMenu(MenuVO menuVO);

    // 메뉴 구조 변경
    void updateMenuTree(List<MenuVO> updateMenuList);

    List<AuthGrpAdmVO> getMenuAuthGrpList(MenuVO menuVO);

    // 메뉴 목록 조회(권한 포함)
    List<MenuVO> getMenuAndAuthList();
}
