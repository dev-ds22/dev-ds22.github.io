package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : BatchLogSearchVO
 * author         : Doo-Won Lee
 * date           : 2022-02-22
 * description    : Mail 전송 내역 검색 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-22      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MailLogSearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String receiver; //수신자 이메일
    private String title;    //제목
}
