package kr.co.daiso.bo.sample.mapper.mysql;

import kr.co.daiso.bo.mb.model.AccountInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SampleMysqlMapper {
    AccountInfo getAccount(String id);
}
