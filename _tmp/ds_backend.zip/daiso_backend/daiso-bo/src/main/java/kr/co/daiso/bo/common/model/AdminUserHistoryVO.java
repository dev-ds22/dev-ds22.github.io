package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AdminUserHistoryVO
 * author         : Doo-Won Lee
 * date           : 2022-02-08
 * description    : 사용자 이력 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-08      Doo-Won Lee     최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AdminUserHistoryVO extends CommonPagingVo {
    private String usrCd;           //사용자 ID
    private String usrNm;           //사용자명
    private String acesIp;          //접근IP
    private String regName;         //등록자명
    private String authGrntType;    //권한부여타입
    private String authGrntTypeNm;    //권한부여타입명
    private String authGrpCd;         //권한그룹코드
    private String authGrpNm;         //권한그룹명
    private String authGrntRsn;     //권한 부여사유
}
