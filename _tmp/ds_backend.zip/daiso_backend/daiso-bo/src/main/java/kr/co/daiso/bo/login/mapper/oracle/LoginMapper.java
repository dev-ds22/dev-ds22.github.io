package kr.co.daiso.bo.login.mapper.oracle;

import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import kr.co.daiso.bo.login.model.LoginReqVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.login.mapper.oracle
 * fileName       : LoginMapper
 * author         : Doo-Won Lee
 * date           : 2021-12-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-03      Doo-Won Lee    최초생성
 */
@Mapper
public interface LoginMapper {

    //관리자 정보 조회
    AdminAccountInfo getAdminUserInfo(LoginReqVO reqVo);

    //관리자로 접근 가능한 권한 그룹 조회
    List<String> getAdminAuthGrpCd();

    //Admin 유저 정보 수정
    boolean updateUser(AdminAccountInfo adminAccountInfo);

    //업무시간 외 사용신청 등록
    boolean insertExcWorktimeLog(ExcWorktimeLogVO logVO);

}
