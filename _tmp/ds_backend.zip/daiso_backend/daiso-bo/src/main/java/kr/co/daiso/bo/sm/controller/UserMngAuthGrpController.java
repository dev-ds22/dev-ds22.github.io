package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.bo.sm.model.UserMngAuthGrpVO;
import kr.co.daiso.bo.sm.service.UserMngAuthGrpService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : UserMngAuthGrpController
 * author         : kjm
 * date           : 2021-12-23
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-23       kjm            최초생성
 */

@Slf4j
@RestController
@RequestMapping("/mg/userMngAuthGrp")
public class UserMngAuthGrpController {

    @Autowired
    private UserMngAuthGrpService userMngAuthGrpService;

    @ApiOperation("권한그룹별 사용자 목록조회")
    @GetMapping("/searchUserList")
    public ResponseEntity searchUserList(UserMngAuthGrpVO userMngAuthGrpVO) {
        List<UserMngAuthGrpVO> searchUserList = userMngAuthGrpService.searchUserList(userMngAuthGrpVO);
        return new ResponseEntity(new CommonResponseModel<List<UserMngAuthGrpVO>>(searchUserList), HttpStatus.OK);
    }

    @ApiOperation("권한그룹별 사용자 저장")
    @PostMapping("/saveUserByAuthGrp")
    public ResponseEntity saveUserByAuthGrp(@RequestBody LinkedHashMap<String, Object> linkedHashMap) {
        userMngAuthGrpService.saveUserByAuthGrp(linkedHashMap);
        return new ResponseEntity(HttpStatus.OK);
    }
}
