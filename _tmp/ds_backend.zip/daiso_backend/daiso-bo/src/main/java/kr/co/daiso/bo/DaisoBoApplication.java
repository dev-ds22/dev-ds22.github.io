package kr.co.daiso.bo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import kr.co.daiso.common.config.DaisoBeanNameGenerator;

/**
 * packageName    : kr.co.daiso.bo
 * fileName       : DaisoBoApplication.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@SpringBootApplication
@ComponentScan(nameGenerator = DaisoBeanNameGenerator.class, basePackages = {"kr.co.daiso.common","kr.co.daiso.bo"})
//public class MgApplication {
//    public static void main(String[] args){
////        SpringApplication.run(MgApplication.class, args);
//        SpringApplication application = new SpringApplication(MgApplication.class);
//        application.addListeners(new ApplicationPidFileWriter());
//        application.run(args);
//    }
//}
public class DaisoBoApplication extends SpringBootServletInitializer {
    public static void main(String[] args){
//        SpringApplication.run(MgApplication.class, args);
//        System.setProperty("server.servlet.context-path", "/api");
        SpringApplication application = new SpringApplication(DaisoBoApplication.class);
//        application.addListeners(new ApplicationPidFileWriter());
        application.run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(DaisoBoApplication.class);
    }
}
