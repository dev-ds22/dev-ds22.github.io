package kr.co.daiso.bo.common.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.common.auth.service.AuthGrpService;
import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuScrSaveVO;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.common.controller
 * fileName       : AuthGrpAdmController
 * author         : leechangjoo
 * date           : 2021-12-08
 * description    : 권리그룹관리 Controller
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08          leechangjoo         최초생성
 **/

@Slf4j
@RestController
@RequestMapping("/common/authGrpAdm")
public class AuthGrpAdmController {

    @Autowired
    AuthGrpService authGrpService;

    @ApiOperation("권한 관리 그룹 리스트 조회")
    @GetMapping("/getAuthGrpAdmList")
    public ResponseEntity getAuthGrpAdmList(@ApiParam("관한 관리 그룹 리스트 정보") AuthGrpAdmVO authGrpAdmVO
            , HttpServletResponse response){

        authGrpAdmVO.setTotal(0);

        Map<String,Object> resultMap = new HashMap<>();
        List<AuthGrpAdmVO> result = authGrpService.getAuthGrpAdmList(authGrpAdmVO);

        resultMap.put("authGrpAdmList", result);

        if(result != null) {
            result.stream().forEach(System.out::println);
        }

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("공통팝업 권한 관리 그룹 리스트 조회")
    @GetMapping("/commonAuthGrpAdmListPopup")
    public ResponseEntity commonAuthGrpAdmListPopup(@ApiParam("관한 관리 그룹 리스트 정보") AuthGrpAdmVO authGrpAdmVO
            , HttpServletResponse response){

        authGrpAdmVO.setTotal(authGrpService.getAuthGrpAdmListCnt(authGrpAdmVO));

        Map<String,Object> resultMap = new HashMap<>();
        List<AuthGrpAdmVO> result = authGrpService.getCommonAuthGrpAdmListPopup(authGrpAdmVO);

        resultMap.put("authGrpAdmList", result);
        resultMap.put("authGrpAdmInfo", authGrpAdmVO);

        if(result != null) {
            result.stream().forEach(System.out::println);
        }

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


    @ApiOperation("권한 관리 그룹 저장")
    @RequestMapping("/saveAuthGrpAdm")
    public ResponseEntity<CommonResponseModel> saveAuthGrpAdm(@ApiParam("권한 관리 그룹 정보 저장") @RequestBody Map<String, Object> authGrpAdmMap, HttpServletResponse response){

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TypeReference< List<AuthGrpAdmVO>> typeRef = new TypeReference< List<AuthGrpAdmVO>>() {};


        List<AuthGrpAdmVO> authGrpAdmVOUpdate =
                mapper.convertValue(authGrpAdmMap.get("UPDATE"), typeRef);
        List<AuthGrpAdmVO> authGrpAdmVOCreate =
                mapper.convertValue(authGrpAdmMap.get("CREATE"), typeRef);

        CommonResponseModel resultModel = authGrpService.updateAuthGrpAdmList(authGrpAdmVOCreate, authGrpAdmVOUpdate);

        return  new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);

    }


    @ApiOperation("권한그룹별 메뉴 리스트 조회")
    @GetMapping("/getAuthGrpMenuAdmList")
    public ResponseEntity getAuthGrpMenuAdmList(@ApiParam("권한 그룹별 메뉴 리스트 조회 권한코드 정보") AuthGrpMenuAdmVO authGrpMenuAdmVO , HttpServletResponse response){

        Map<String,Object> resultMap = new HashMap<>();
        List<AuthGrpMenuAdmVO>  result = authGrpService.getAuthGrpMenuAdmList(authGrpMenuAdmVO);

        resultMap.put("authGrpMenuList", result);

        if(result != null){
            result.stream().forEach(System.out::println);
        }

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("권한 관리 그룹 메뉴 저장")
    @RequestMapping("/saveAuthGrpMenuAdm")
    public ResponseEntity<CommonResponseModel> saveAuthGrpMenuAdm(@ApiParam("권한 관리 그룹 정보 메뉴 저장") @RequestBody Map<String, Object> authGrpAdmMap, HttpServletResponse response){

        System.out.println(authGrpAdmMap.get("UPDATE"));

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TypeReference< List<AuthGrpMenuScrSaveVO>> typeRef = new TypeReference< List<AuthGrpMenuScrSaveVO>>() {};


        List<AuthGrpMenuScrSaveVO> authGrpAdmVOUpdate =
                mapper.convertValue(authGrpAdmMap.get("UPDATE"), typeRef);


        CommonResponseModel resultModel = authGrpService.updateAuthGrpMenuAdmList(authGrpAdmVOUpdate);

        return  new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);

    }
}
