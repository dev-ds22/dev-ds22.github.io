package kr.co.daiso.bo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * packageName    : kr.co.daiso.bo.config
 * fileName       : RedisConfig
 * author         : Doo-Won Lee
 * date           : 2021-10-29
 * description    : Redis 사용을 위한 configuration 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-29      Doo-Won Lee         최초생성
 */
@Slf4j
@Configuration
public class RedisConfig {

    @Value("${spring.redis.host}")
    private String redisHost;

    @Value("${spring.redis.port}")
    private int redisPort;

    @Value("${spring.server_type}")
    private String serverType;

    @Value("${spring.redis.sentinel.master}")
    private String sentinelMaster;

    @Value("${spring.redis.sentinel.nodes}")
    private String[] sentinelArray;

//    @Value("${spring.redis.password}")
    private String redisPwd;

    @Bean
    public RedisConnectionFactory redisConnectionFactory() {
    	RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
        switch(serverType){
            case "dev_cloud":
            case "stg_cloud":
            case "prd_cloud":
            case "stg":
            case "prd":
//            case "dev":
//            case "stg":
//            case "prd":
//            case "local":
//            default:
                redisStandaloneConfiguration.setHostName(redisHost);
                redisStandaloneConfiguration.setPort(redisPort);
//        redisStandaloneConfiguration.setPassword(redisPwd);
                return new LettuceConnectionFactory(redisStandaloneConfiguration);
            case "local":
            case "dev":
            default:
//                RedisSentinelConfiguration redisSentinelConfiguration = new RedisSentinelConfiguration()
//                        .master(sentinelMaster);
////                        .sentinel("192.168.210.31",5389)
////                        .sentinel("192.168.210.31",5399)
////                        .sentinel("192.168.210.31",5409);
//                for(String sentinelAddr : sentinelArray){
//                    String setinelHost = sentinelAddr.split(":")[0];
//                    String setinelPort = sentinelAddr.split(":")[1];
//                    redisSentinelConfiguration.sentinel(setinelHost,Integer.parseInt(setinelPort));
//                }
//                return new LettuceConnectionFactory(redisSentinelConfiguration);
                redisStandaloneConfiguration.setHostName(redisHost);
                redisStandaloneConfiguration.setPort(redisPort);
//        redisStandaloneConfiguration.setPassword(redisPwd);
                return new LettuceConnectionFactory(redisStandaloneConfiguration);
        }
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory());
        redisTemplate.setKeySerializer(new StringRedisSerializer());
//		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        return redisTemplate;
    }
}
