package kr.co.daiso.bo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.model.*;
import kr.co.daiso.bo.common.service.LogService;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.common.controller
 * fileName       : LogController
 * author         : Doo-Won Lee
 * date           : 2022-01-18
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-18      Doo-Won Lee     최초생성
 */
@Slf4j
@RestController
@RequestMapping("/cmnlog")
public class LogController {

    @Autowired
    LogService logService;

    private final String STR_LOG_LIST = "logList";
    private final String STR_SEARCH_INFO = "searchInfo";

    @ApiOperation("관리자 접속 로그 등록")
    @GetMapping("/admin-cnntn-log")
    public ResponseEntity<CommonResponseModel> regAdminCnntnLog(@ApiParam("관리자 메뉴 접속 로그 정보") AdminCnntnLogVO vo, HttpServletRequest req, HttpServletResponse res){
        return logService.regAdminCnntnLog(vo,req,res);
    }

    @ApiOperation("업무시간외접속로그 조회(페이징사용)")
    @GetMapping("/out-time-conn-log")
    public ResponseEntity<CommonResponseModel> getOutTimeConnLog(@ApiParam("그룹 코드 검색 정보") OutTimeLogSearchVO searchVo, HttpServletResponse response){
        Map<String, Object> resultMap = new HashMap<>();
        searchVo.setTotal(logService.getOutTimeConnLogCnt(searchVo));

        List<ExcWorktimeLogVO> list	= logService.getOutTimeConnLog(searchVo);

        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("관리자 권한 그룹 조회")
    @GetMapping("/admin-auth-grp")
    public ResponseEntity<CommonResponseModel> getAdminAuthGrpList(){
        Map<String, Object> resultMap = new HashMap<>();

        List<AuthGrpAdmVO> list	= logService.getAdminAuthGrpList();
        resultMap.put("authList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("관리자 접속로그 조회(페이징사용)")
    @GetMapping("/admin-conn-log")
    public ResponseEntity<CommonResponseModel> getAdminCnntnLog(@ApiParam("관리자 접속 로그 조회 정보") AdminCnntnLogSearchVO searchVo, HttpServletResponse response){
        Map<String, Object> resultMap = new HashMap<>();

        searchVo.setTotal(logService.getAdminCnntnLogCnt(searchVo));
        List<AdminCnntnLogVO> list	= logService.getAdminCnntnLog(searchVo);
        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("사용자 이력 조회(페이징사용)")
    @GetMapping("/usr-hist")
    public ResponseEntity<CommonResponseModel> getAdminUserHistory(@ApiParam("사용자 이력 조회 정보") AdminUserHistorySearchVO searchVo) throws Exception {
        Map<String, Object> resultMap = new HashMap<>();

        searchVo.setTotal(logService.getAdminUserHistoryCnt(searchVo));
        List<AdminUserHistoryVO> list	= logService.getAdminUserHistory(searchVo);
        resultMap.put("historyList", list);
        resultMap.put(STR_SEARCH_INFO, searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


    @ApiOperation("시스템 에러로그 조회(페이징사용)")
    @GetMapping("/systemerrlog")
    public ResponseEntity<CommonResponseModel> getExceptionLog(@ApiParam("시스템 에러로그 조회 정보") ExceptionLogSearchVO exceptionLogSearchVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        exceptionLogSearchVO.setTotal(logService.getExceptionLogCnt(exceptionLogSearchVO));
        List<ExceptionLogVO> list	= logService.getExceptionLog(exceptionLogSearchVO);

        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, exceptionLogSearchVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("다운로드 사유 조회(페이징사용)")
    @GetMapping("download-rsn")
    public ResponseEntity<CommonResponseModel> getDownloadRsn(@ApiParam("다운로드 사유 조회 정보") DownloadRsnSearchVO downloadRsnSearchVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        downloadRsnSearchVO.setTotal(logService.getDownloadRsnCnt(downloadRsnSearchVO));
        List<DownloadRsnVO> list	= logService.getDownloadRsn(downloadRsnSearchVO);
//        System.out.println(">>>>>>>>>" + downloadRsnSearchVO);

        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, downloadRsnSearchVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


    @ApiOperation("배치로그 조회(페이징사용)")
    @GetMapping("/batc-log")
    public ResponseEntity<CommonResponseModel> getBatchLog(@ApiParam("배치로그 조회 정보") BatchLogSearchVO searchVo) throws Exception {
        Map<String, Object> resultMap = new HashMap<>();

        searchVo.setTotal(logService.getBatchLogCount(searchVo));
        List<BatchLogVO>  list	= logService.getBatchLogList(searchVo);
        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("Mail전송 내역 조회(페이징사용)")
    @GetMapping("/mail-log")
    public ResponseEntity<CommonResponseModel> getMailLog(@ApiParam("Mail전송 내역 조회 정보") MailLogSearchVO searchVo) throws Exception {
        Map<String, Object> resultMap = new HashMap<>();

        searchVo.setTotal(logService.getMailSendLogCount(searchVo));
        List<MailSendLogVO>  list = logService.getMailSendLogList(searchVo);
        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, searchVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


}
