package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.BaseModel;
import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : DownloadRsnVO
 * author         : Byung-chul Park
 * date           : 2022-02-17
 * description    : 다운로드 사유 등록 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-17       Byung-chul Park   최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class DownloadRsnVO extends CommonPagingVo {

    private String usrId;      //사용자ID
    private String usrNm;      //사용자명
    private String rqstUrl;     //요청URL
    private String acesIp;      //접근IP
    private String dnldAtclNm;  //다운로드항목명
    private String dnldAtclDtl; //다운로드항목상세
    private String dnldRsn;     //다운로드사유
    private String dnldCnt;     //다운로드건수
    private String adminYn;     //관리자여부
}
