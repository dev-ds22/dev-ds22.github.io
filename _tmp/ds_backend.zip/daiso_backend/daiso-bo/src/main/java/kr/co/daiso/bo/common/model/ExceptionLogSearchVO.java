package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : ExceptionLogSearchVO
 * author         : Byung-Chul Park
 * date           : 2022-02-14
 * description    : 시스템 에러로그 조회검색VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-14      Byung-Chul Park   최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class ExceptionLogSearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String keyword;  //검색어
    private String authGrntType; //권한부여 타입
}
