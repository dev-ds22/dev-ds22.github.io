package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonModelSearchVO
 * author         : leechangjoo
 * date           : 2022-01-12
 * description    : 공통모델 검색용 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-12          leechangjoo         최초생성
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonModelSearchVO extends CommonPagingVo {

    private String sMnuftrCd;       //검색 제조사 코드
    private String sMnuftrNm;       //검색 제조사 코드명

    private String i_sMakeType;        // 국산차 수입차 구분 코드
    List<String> i_sMakeType_list;     // 국산차 수입차 구분 코드 리스트
    private String i_sCategoryCd;      // 차종코드
    private String i_sMakeCd;          // 제조사 코드
    List<String> i_sMakeCd_list;       // 제조사 코드 리스트
    private String i_sModelCd;         // 모델 코드
    List<String> i_sModelGrpCd_list;   // 모델 코드 리스트
    private String i_sClassHeadCd;     // 등급 코드
    private String i_sKeyWord;         //
    private String i_sModelGrpCd;      //
    private String i_sModelOrderFlag;  //
    private String i_sNoOrderFlag;
    private String i_sMakeCdOrder;  //
    private String i_sMakeTypeSortNmOrder;
    private String[] i_arrMakeCds;     // 제조사코드 배열
    private String[] i_arrCategoryCd;  // 차종코드 배열
    private String allDataYn;          // 전체목록 조회 여부


//    private String sSubCode;        //검색 서브 코드
//    private String sSubCodeNm;      //검색 서브 코드명

    private String useYn;           //사용 여부
    private String delYn;           //삭제 여부
    private String ucmsCdYn;        //UCMS 코드 여부

}
