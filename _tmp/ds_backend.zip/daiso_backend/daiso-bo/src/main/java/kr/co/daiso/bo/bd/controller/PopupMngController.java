package kr.co.daiso.bo.bd.controller;

import kr.co.daiso.common.model.CommonPagingVo;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.bd.model.PopupDetailVO;
import kr.co.daiso.bo.bd.model.PopupVO;
import kr.co.daiso.bo.bd.service.PopupMngService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.bd.controller
 * fileName       : PopupMngController.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@Api(tags = {"PopupMngController"})
@RestController
@RequestMapping("/bd")
public class PopupMngController {

    @Autowired
    PopupMngService popupMngService;

    @ApiOperation("팝업 목록 조회")
    @GetMapping("/popup/popuplist")
    public ResponseEntity searchPopupList(@ApiParam("팝업목록 검색조건") PopupVO popupVO) throws UnsupportedEncodingException {
        popupVO.setPpupNm(URLDecoder.decode(popupVO.getPpupNm(), "UTF-8"));
        Map<String, Object> resultMap = new HashMap<>();
        popupVO.setTotal(popupMngService.searchPopupListCount(popupVO));
        List<PopupVO> popupList = popupMngService.searchPopupList(popupVO);
        resultMap.put("popupList", popupList);
        resultMap.put("pagination", (CommonPagingVo) popupVO);
        return new ResponseEntity(new CommonResponseModel<>(resultMap), HttpStatus.OK);
    }

    @ApiOperation("팝업 상세 조회")
    @GetMapping("/popup/popupdetail/{ppupCd}")
    public ResponseEntity searchPopupDetail(@ApiParam("팝업상세 검색조건") @PathVariable String ppupCd) {
        Map<String, Object> popupDetailMap = popupMngService.searchPopupDetail(ppupCd);
        PopupVO popupVO = popupMngService.searchPopup(ppupCd);
        popupDetailMap.put("popupVO", popupVO);
        return new ResponseEntity(new CommonResponseModel<>(popupDetailMap), HttpStatus.OK);
    }

    @ApiOperation("팝업 등록")
    @PostMapping("/popup")
    public ResponseEntity insertPopup(@ApiParam("팝업 등록 내용") @RequestBody Map<String, Object> paramMap) {
        popupMngService.insertPopup(paramMap);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("팝업 수정")
    @PatchMapping("/popup")
    public ResponseEntity updatePopup(@ApiParam("팝업 수정 내용") @RequestBody Map<String, Object> paramMap) {
        popupMngService.updatePopup(paramMap);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("팝업 삭제")
    @DeleteMapping("/popup")
    public ResponseEntity deletePopup(@ApiParam("삭제 팝업 코드") @RequestBody PopupVO popupVO) {
        popupMngService.deletePopup(popupVO);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("팝업 상세 삭제")
    @DeleteMapping("/popup/detail")
    public ResponseEntity deletePopupDetail(@ApiParam("상세 삭제 팝업코드") @RequestBody PopupDetailVO popupDetailVO) {
        popupMngService.deletePopupDetail(popupDetailVO);
        return new ResponseEntity(HttpStatus.OK);
    }
}
