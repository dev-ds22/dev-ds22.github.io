package kr.co.daiso.bo.bd.service;

import kr.co.daiso.bo.bd.model.FaqVO;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.bd.service
 * fileName       : FaqMngService
 * author         : kjm
 * date           : 2022-01-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       kjm            최초생성
 */
public interface FaqMngService {

    // FAQ 목록 조회
    List<FaqVO> searchFaqList(FaqVO faqVO);

    // FAQ 목록 개수 조회
    int getFaqTotalCount(FaqVO faqVO);

    // FAQ 상세조회
    FaqVO searchFaqDetail(String sq);

    // FAQ 등록수정
    int updateFaq(FaqVO faqVO);

    // faq 그리드에서 수정
    void updateFaqOnGrid(LinkedHashMap<String, Object> linkedHashMap);
}
