package kr.co.daiso.bo.sample.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * packageName    : kr.co.daiso.bo.sample.controller
 * fileName       : SampleController2
 * author         : chungwoo35
 * date           : 2022-03-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-03-24          chungwoo35         최초생성
 */
@Slf4j
@Controller
@RequestMapping("/jsptest")
public class SampleController2 {

    @RequestMapping("/google")
    public String testGoogleCrolling(HttpServletRequest request, HttpServletResponse response){
        return "google";
    }
}
