package kr.co.daiso.bo.util;

import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.bo.common.mapper.oracle.LogMapper;
import kr.co.daiso.bo.common.mapper.oracle.UtilMapper;
import kr.co.daiso.bo.common.model.AdminCnntnLogVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : AdminCmnUtil
 * author         : Doo-Won Lee
 * date           : 2022-01-19
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-19      Doo-Won Lee     최초생성
 */
@Slf4j
@Component
public class AdminCmnUtil {

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    @Autowired
    LogMapper logMapper;

    @Autowired
    UtilMapper utilMapper;

    /**
     * methodName : insertAdminLog
     * author : Doo-Won Lee
     * description : 관리자 접속 로그를 등록한다.
     *
     * @param adminCnntnLogVO
     * @param request
     * @return boolean
     */
    @Transactional(rollbackFor = { Exception.class })
    public boolean insertAdminLog(AdminCnntnLogVO adminCnntnLogVO, HttpServletRequest request){
        adminCnntnLogVO.setUsrId(adminAccountInfoUtil.getUsrId());
        adminCnntnLogVO.setUsrNm(adminAccountInfoUtil.getUsrNm());
        adminCnntnLogVO.setAcesIp(CommonUtil.getClientIp(request));
        adminCnntnLogVO.setAuth(adminAccountInfoUtil.getUsrType());
        adminCnntnLogVO.setUsrAgent(request.getHeader("user-agent"));
        adminCnntnLogVO.setRgpsId(adminAccountInfoUtil.getUsrId());
        adminCnntnLogVO.setMdpsId(adminAccountInfoUtil.getUsrId());

        if (null==adminCnntnLogVO.getMenuId()) {
            adminCnntnLogVO.setMenuPath("");
        }
        else{
            try{
                //메뉴 아이디로 메뉴 경로 조회
                ScrnMenuVO menuVO = logMapper.getMenuInfoByMenuId(adminCnntnLogVO.getMenuId());
                adminCnntnLogVO.setMenuPath(menuVO.getFullMenuNm());
                if (null == adminCnntnLogVO.getAcesUrl()){ adminCnntnLogVO.setAcesUrl(menuVO.getScrnUrl()); }
            }
            catch(Exception e){
                adminCnntnLogVO.setMenuPath("Wrong MenuID");
                if (null == adminCnntnLogVO.getAcesUrl()){ adminCnntnLogVO.setAcesUrl(""); }
            }
        }
        if (null == adminCnntnLogVO.getAcesUrl()){ adminCnntnLogVO.setAcesUrl(""); }
        return logMapper.insertAdminLog(adminCnntnLogVO);
    }

    /**
     * methodName : checkHoliday
     * author : Doo-Won Lee
     * description : 해당일의 휴일여부를 조회한다.
     *
     * @param targetDate
     * @return String
     */
    public String checkHoliday(String targetDate){
        return utilMapper.checkHoliday(targetDate);
    }

    /**
     *  methodName : checkHoliday
     *  author : Doo-Won Lee
     *  description : Response에 바로가기 Url을 생성한다.
     *
     * @param request
     * @param response
     * @param url
     * @param fileName
     * @throws Exception
     */
    public void getInternetShortCut(HttpServletRequest request, HttpServletResponse response, String url, String fileName)  throws Exception{
        String browser = request.getHeader("User-Agent");
        if( browser != null && (browser.indexOf("Firefox/") != -1 || browser.indexOf("Safari/") != -1)){
            response.addHeader(HttpHeaders.CONTENT_TYPE, "Application/octet-stream");
            response.addHeader(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.builder("attachment")
                    .filename(fileName+".url", StandardCharsets.UTF_8)
                    .build().toString());
        } else {
            response.addHeader(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.builder("attachment")
                    .filename(fileName+".url", StandardCharsets.UTF_8)
                    .build().toString());
        }
        response.getWriter().println("[InternetShortcut]");
        response.getWriter().println("URL="+url);
//        response.getWriter().println("IDList=");
        response.getWriter().println("IconFile=http://www.daiso.com/resources/images/common/favicon.ico");
        response.getWriter().println("IconIndex=1");
    }
}
