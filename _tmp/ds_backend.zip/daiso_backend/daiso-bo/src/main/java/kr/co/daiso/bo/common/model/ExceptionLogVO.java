package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : ExceptionLogVO
 * author         : Doo-Won Lee
 * date           : 2022-02-14
 * description    : Error Log VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-14      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class ExceptionLogVO extends CommonPagingVo {

    private String rqstUrl;    //요청url
    private String rqstParam;   //요청파라미터 (request params)
    private String cmdData;     //커맨드객체데이터 (requestBody data & 로그인된 사용자 id)
    private String excpNm;      //예외명
    private String fileNm;      //파일명
    private String methodNm;    //메소드명
    private String classNm;     //클래스명
    private int lineNbr;         //라인수
}
