package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonCodeSearchVo
 * author         : Doo-Won Lee
 * date           : 2021-12-01
 * description    : 공통코드관리용 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01     Doo-Won Lee      최초생성
 */
@EqualsAndHashCode(callSuper=false)
@Data
public class CommonCodeManageVO extends BaseModel {

    //Code 공통정보
    private String	ucmsCdYn;       //Ucms 사용여부
    private String	useYn;          //사용여부
    private String	delYn;          //삭제여부

    //마스터코드 정보
    private String	masterCd;       //마스터 코드
    private String	masterCdNm;     //마스터 코드명
    private String	masterCdEngNm;  //마스터 코드 영문명

    //서브코드 정보
    private String	subCd;          //서브코드
    private String	subCdNm;        //서브코드명
    private String	subCdEngNm;     //서브코드 영문명
    private int sortOrdr;           //순번
    private String hrnkGrpCd;       //상위 그룹코드

    private String	addtFld1;       //추가 필드1
    private String	addtFld2;       //추가 필드2
    private String	addtFld3;       //추가 필드3

    private String	addtFld11;      //추가 필드11
    private String	addtFld12;      //추가 필드12
    private String	addtFld13;      //추가 필드13
    private String	addtFld14;      //추가 필드14
    private String	addtFld15;      //추가 필드15
    private String	addtFld16;      //추가 필드16
    private String	addtFld17;      //추가 필드17
    private String	addtFld18;      //추가 필드18
}
