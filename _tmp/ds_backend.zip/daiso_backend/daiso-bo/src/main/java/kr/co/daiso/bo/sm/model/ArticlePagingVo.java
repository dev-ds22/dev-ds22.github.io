package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ArticlePagingVo extends CommonPagingVo {
    private String subCd;/*서브코드*/
    private String subCdNm;/*약관이름*/
    private float atclVer;/*약관버전*/
}
