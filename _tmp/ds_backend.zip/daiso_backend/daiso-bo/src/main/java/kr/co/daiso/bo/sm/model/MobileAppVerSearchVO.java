package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : MobileAppVerSearchVO
 * author         : Byung-Chul Park
 * date           : 2022-02-22
 * description    : 모바일 APP버전관리 조회검색 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-22      Byung-Chul Park   최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MobileAppVerSearchVO extends CommonPagingVo {

    private String strtDttm;        //검색 시작일시
    private String endDttm;         //검색 종료일시
    private String osKeyword;       //검색어
    private String coerKeyword;     //검색어2
    private String authGrntType;    //권한부여 타입
}
