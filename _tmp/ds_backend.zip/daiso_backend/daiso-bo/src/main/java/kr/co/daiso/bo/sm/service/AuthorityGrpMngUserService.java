package kr.co.daiso.bo.sm.service;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.bo.sm.model.AuthorityGrpMngUserVO;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : AuthorityGrpMngUserService
 * author         : kjm
 * date           : 2021-12-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-15       kjm            최초생성
 */
public interface AuthorityGrpMngUserService {

    // 사용자 목록 조회
    List<AuthorityGrpMngUserVO> searchUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 상세 조회
    AuthorityGrpMngUserVO searchUserDetail(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 권한그룹 조회
    List<AuthorityGrpMngUserVO> searchAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 등록
    void signUpUser(AuthorityGrpMngUserVO authorityGrpMngUserVO) throws CommonException;

    // 사용자 정보 수정
    void modifyUser(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 권한그룹 저장
    void saveAuthGrp(LinkedHashMap<String, Object> linkedHashMap);
}
