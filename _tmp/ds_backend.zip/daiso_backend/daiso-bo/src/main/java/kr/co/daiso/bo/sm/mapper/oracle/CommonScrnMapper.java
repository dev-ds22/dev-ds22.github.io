package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CommonScrnSearchPagingVO;
import kr.co.daiso.bo.sm.model.CommonScrnVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : CommonScrnMapper
 * author         : Doo-Won Lee
 * date           : 2021-12-09
 * description    : 화면 관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-09      Doo-Won Lee        최초생성
 */
@Mapper
public interface CommonScrnMapper {

    //화면 검색 목록 카운트를 구한다.
    int getSearchScrnListCnt(CommonScrnSearchPagingVO searchVO);

    //화면 검색 목록을 구한다.
    List<CommonScrnVO> getSearchScrnList(CommonScrnSearchPagingVO searchVO);

    //화면 목록을 조회한다.
//    List<CommonScrnVO> getScreenList(CommonScrnSearchVO searchVO);

    //새로운 화면을 저장한다.
    int saveScreenInfo(CommonScrnVO saveVO);

    //화면 정보를 수정한다.
    int editScreenInfo(CommonScrnVO editVO);

    List<ScrnMenuVO> getMenulistByScrn(CommonScrnVO scrnVO);
}
