package kr.co.daiso.bo.sm.service;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.model.MobileAppVerSearchVO;
import kr.co.daiso.bo.sm.model.MobileAppVerVO;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : MobileAppVerService
 * author         : Byung-Chul Park
 * date           : 2022-02-28
 * description    : 모바일 앱버전 관리 관련 서비스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-28   Byung-Chul Park    최초생성
 */
public interface MobileAppVerService {


    //모바일 APP버전관리를 조회한다.
    public List<MobileAppVerVO> getMobileAppVer(MobileAppVerSearchVO mobileAppVerSearchVO);

    //모바일 APP버전관리 카운트를 조회한다.
    public int getMobileAppVerCnt(MobileAppVerSearchVO mobileAppVerSearchVO);

    //모바일 APP버전관리를 등록한다.
    public CommonResponseModel regMobileAppVer(LinkedHashMap<String, Object> mobileAppVerVO);

    //모바일 APP버전정보를 조회한다.
//    public List<MobileAppVerVO> getMobileAppVersion(MobileAppVerVO mobileAppVerVO);
    public MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO);

}
