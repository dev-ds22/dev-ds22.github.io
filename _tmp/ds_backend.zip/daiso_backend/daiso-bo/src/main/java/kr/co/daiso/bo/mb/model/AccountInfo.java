package kr.co.daiso.bo.mb.model;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/**
 * packageName    : kr.co.daiso.bo.mb.model
 * fileName       : AccountInfo
 * author         : Doo-Won Lee
 * date           : 2021-11-29
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-29     Doo-Won Lee         최초생성
 */
@SuppressWarnings("serial")
@Data
//@ToString(exclude = {"authorities"} )
public class AccountInfo implements UserDetails {

    private String id;
    private String password;
    private String name;
    private String dept; /* 부서코드 */
    private String jikgub; /* 직급코드 */
    private String sDate; /* 입사일 */
    private String chiefYn; /* 부서장여부 */
    private String retire; /* 퇴직여부 */
    private String retireDt; /* 퇴직일자 */
    private String email; /* 이메일 */
    private String deptNm; /* 부서명 */
    private String jikgubNm; /* 직급명 */

    private String role;    /* User Role 권한 그룹 */

//    private Collection<SimpleGrantedAuthority> authorities;
//    private Collection<SimpleGrantedAuthority> ttt;

    @Override
    public Collection<SimpleGrantedAuthority> getAuthorities() {
        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        if (null!=this.role)
            Arrays.stream(this.role.split(","))
                    .distinct()
                    .forEach(p -> {
                                GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + p);
                                authorities.add((SimpleGrantedAuthority) authority);
                            });
        return authorities;
    }

    @Override
    public String getUsername() {
        return this.id;
    }

//    public void setUsername(String userName) {
//        this.id = userName;
//    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
