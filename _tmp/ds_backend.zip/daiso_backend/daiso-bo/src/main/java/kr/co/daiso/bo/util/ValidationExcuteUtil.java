package kr.co.daiso.bo.util;

import kr.co.daiso.common.exception.ErrorResponse;
import kr.co.daiso.common.model.CommonResponseModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.ObjectError;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : ValidationExcuteUtil
 * author         : Doo-Won Lee
 * date           : 2022-01-10
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-10     Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public class ValidationExcuteUtil {

    @Autowired
    MessageSource messageSource;

    public ResponseEntity<CommonResponseModel> makeValidationResult(List<ObjectError> errors){

        CommonResponseModel errorResponseModel = new CommonResponseModel();
        if (errors.size()>0){
            ObjectError error = errors.get(0);
//        for (ObjectError error : errors) {
            String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
                    .map(c -> {
                        Object[] arguments = error.getArguments();
                        Locale locale = LocaleContextHolder.getLocale();
                        try {
                            return messageSource.getMessage(error.getDefaultMessage(), arguments, locale);
                        } catch (NoSuchMessageException ne) {
                            return null;
                        }
                    }).filter(Objects::nonNull)
                    .findFirst()
                    .orElse(error.getDefaultMessage());

            log.error("error message: {}", message);

            errorResponseModel.setData( ErrorResponse.toResponseEntity(HttpStatus.BAD_REQUEST,message));
//            break;
        }
        return new ResponseEntity<CommonResponseModel>(errorResponseModel,HttpStatus.OK);
    }
}
