package kr.co.daiso.bo.mb.service.impl;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.util.ExcelUtil;
import kr.co.daiso.bo.mb.mapper.oracle.MembMgtMapper;
import kr.co.daiso.bo.mb.model.MembAddInfoDTO;
import kr.co.daiso.bo.mb.model.MemberStaDTO;
import kr.co.daiso.bo.mb.model.TbMbMembBasVO;
import kr.co.daiso.bo.mb.service.MembMgtService;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;

/**
 * packageName    : kr.co.daiso.bo.mb.service.impl
 * fileName       : MemberMgtServiceImpl
 * author         : bsj
 * date           : 2022-01-11
 * description    : 관리자의 회원관리 서비스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       bsj            최초생성
 */
@Slf4j
@Service
@Transactional
public class MembMgtServiceImpl implements MembMgtService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private final MembMgtMapper membMgtMapper;
    private final ExcelUtil excelUtil;

    public MembMgtServiceImpl(MembMgtMapper membMgtMapper, ExcelUtil excelUtil) {
        this.membMgtMapper = membMgtMapper;
        this.excelUtil = excelUtil;
    }

    /**
     * 회원기본 테이블의 회원정보 리스트를 읽어온다.
     * @param mbMembBasVO 회원 조회조건
     * @return 회원정보 리스트
     */
    @Override
    public Map<String, Object> getMemberList(TbMbMembBasVO mbMembBasVO) {
        logger.info("## MembMgtServiceImpl | getMemberList()");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            // [1] 리스트 Total Count 조회
            int total = membMgtMapper.getMemberListTotalCount(mbMembBasVO);
            mbMembBasVO.setTotal(total);
            resultMap.put("totalCount", total);
            logger.info("회원목록 totalCount: {}", total);
            
            // [2] 리스트 조회
            List<TbMbMembBasVO> resultList = new ArrayList<>();
            resultList = membMgtMapper.getMemberList(mbMembBasVO);
            resultMap.put("membList", resultList);
            logger.info("회원목록 resultList:: {}" + resultList.toString());
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("회원정보 리스트 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
        return resultMap;
    }

    /**
     * 회원기본,회원휴면 테이블에서 특정회원의 기본상세정보를 조회한다
     * @param mbMembBasVO 회원ID
     * @return 회원상세 기본정보
     */
    @Override
    public TbMbMembBasVO getMemberDetlInfo(TbMbMembBasVO mbMembBasVO) {
        try {
            return membMgtMapper.getMemberDetlInfo(mbMembBasVO);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("회원상세 기본정보 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본,회원휴면 테이블에서 특정회원의 부가상세정보를 조회한다
     * @param vo 회원ID
     * @return 회원상세 부가정보
     */
    @Override
    public List<MembAddInfoDTO> getMemberDetlAddInfo(TbMbMembBasVO vo) {
        try {
            return membMgtMapper.getMemberDetlAddInfo(vo);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("회원상세 부가정보 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 특정회원의 비밀번호를 초기화한다.
     * 비밀번호를 암호화된 회원ID값으로 업데이트함.
     * @param mbMembBasVO 회원ID, pwd
     * @return 수정된 row수
     */
    @Override
    public int updateMemberPwdReset(TbMbMembBasVO mbMembBasVO) {
        try {
            return membMgtMapper.updateMemberPwdReset(mbMembBasVO);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("회원 비밀번호 초기화에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 유형(가입채널)별 가입자 통계를 조회한다.
     * @param
     * @return 유형별회원 통계
     */
    @Override
    public List<MemberStaDTO> getMemberStaByType() {
        try {
            return membMgtMapper.getMemberStaByType();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("유형별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본,휴면회원 테이블에서 상태별(가입/탈퇴/휴면) 회원통계를 조회한다.
     * @param
     * @return 상태별 회원통계
     */
    @Override
    public MemberStaDTO getMemberStaByStus() {
        try {
            return membMgtMapper.getMemberStaByStus();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("상태별(가입/탈퇴/휴면) 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 일자별/가입채널별 가입/탈퇴자 통계를 조회한다.
     * @param
     * @return 일자별 회원통계
     */
    @Override
    public List<MemberStaDTO> getMemberStaByDate() {
        try {
            return membMgtMapper.getMemberStaByDate();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("일자별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 월별/가입채널별 가입자/탈퇴자 통계를 조회한다.
     * @param
     * @return 월별 회원통계
     */
    @Override
    public List<MemberStaDTO> getMemberStaByMonth() {
        try {
            return membMgtMapper.getMemberStaByMonth();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("월별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 서브코드 테이블에서 가입채널목록(MEMBER_CHANNEL)을 조회한다.
     * @param
     * @return 가입채널목록
     */
    @Override
    public List<CommonCodeManageVO> getCmSubCodeList() {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("masterCd", "MEMBER_CHANNEL");
            map.put("addtFld1", "Y");
            return membMgtMapper.getCmSubCodeList(map);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("월별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 기간별 회원통계를 조회한다.
     * @param
     * @return 기간별 회원통계목록
     */
    @Override
    public List<MemberStaDTO> getMemberStaByPerd(MemberStaDTO dto) {
        try {
            return membMgtMapper.getMemberStaByPerd(dto);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("기간별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본,달력마스터 테이블에서 기간,일자,가입채널별 회원통계 리스트를 읽어온다.
     * @param memberStaDTO 기간 조회조건
     * @return 회원통계 리스트
     */
    @Override
    public Map<String, Object> getMemberStaByDttmList(MemberStaDTO memberStaDTO) {
        logger.info("## MembMgtServiceImpl | getMemberStaByDttmList()");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            // [1] 리스트 Total Count 조회
            int total = membMgtMapper.getMemberStaByDttmTotalCount(memberStaDTO);
            memberStaDTO.setTotal(total);
            resultMap.put("totalCount", total);

            // [2] 리스트 조회
            List<MemberStaDTO> resultList = new ArrayList<>();
            resultList = membMgtMapper.getMemberStaByDttm(memberStaDTO);
            resultMap.put("membByDttmList", resultList);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("기간,일자,가입채널별 회원통계 리스트 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
        return resultMap;
    }

    @Override
    public void downloadExcelMembSta(MemberStaDTO searchDto, HttpServletResponse response) {
        List<String> columneNames = new ArrayList<>();
        List<String> headerNames = new ArrayList<>();

        String[] headerNmStrArr  = new String[]{"일자", "PC가입자", "MO가입자", "APP가입자", "PC탈퇴자", "MO탈퇴자", "APP탈퇴자"};
        for(String headerData : headerNmStrArr){
            headerNames.add(headerData);
        }

        String[] columneNmStrArr  = new String[]{"dttm", "regCntPC", "regCntMO", "regCntApp", "wtdrCntPC", "wtdrCntMO", "wtdrCntApp"};
        for(String columnData : columneNmStrArr){
            columneNames.add(columnData);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Calendar cal = Calendar.getInstance();
        String fileName = sdf.format(cal.getTime());
        logger.info("fileName:: {}", fileName);

        Function<MemberStaDTO, List<MemberStaDTO>> function = membMgtMapper::getMemberStaByDttm;
        excelUtil.makeExcelFileToResponse(fileName,headerNames,columneNames, function, response, searchDto);
    }

    /**
     * 회원기본 테이블에서 일자별 통계를 조회한다.(대시보드 용)
     * @param
     * @return 일자별 회원통계
     */
    @Override
    public List<MemberStaDTO> getDashMemberStaByDate() {
        try {
            return membMgtMapper.getDashMemberStaByDate();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("일자별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * 회원기본 테이블에서 월별 통계를 조회한다.(대시보드 용)
     * @param
     * @return 월별 회원통계
     */
    @Override
    public List<MemberStaDTO> getDashMemberStaByMonth() {
        try {
            return membMgtMapper.getDashMemberStaByMonth();
        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("월별 회원통계 조회에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
    }
}
