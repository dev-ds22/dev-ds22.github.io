package kr.co.daiso.bo.common.mapper.oracle;

import kr.co.daiso.bo.common.model.*;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.mapper.oracle
 * fileName       : LogMapper
 * author         : Doo-Won Lee
 * date           : 2022-01-19
 * description    : 관리자 로그 관련 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-19    Doo-Won Lee      최초생성
 */

@Mapper
public interface LogMapper {

    //관리자 접속 로그를 등록한다.
    boolean insertAdminLog(AdminCnntnLogVO adminCnntnLogVO);

    //메뉴아이디로 메뉴정보(메뉴경로)를 구한다.
    ScrnMenuVO getMenuInfoByMenuId(String menuId);

    //업무시간외 접속 로그의 카운트를 구한다.
    int getOutTimeConnLogCnt(OutTimeLogSearchVO searchVO);

    //업무시간외 접속 로그를 구한다.
    List<ExcWorktimeLogVO> getOutTimeConnLog(OutTimeLogSearchVO searchVO);

    //관리자 권한 그룹 목록을 조회한다.
    List<AuthGrpAdmVO> getAdminAuthGrpList();

    //관리자 접속 로그 카운트를 조회한다.
    int getAdminCnntnLogCnt(AdminCnntnLogSearchVO adminCnntnLogSearchVO);

    //관리자 접속 로그를 조회한다.
    List<AdminCnntnLogVO> getAdminCnntnLog(AdminCnntnLogSearchVO adminCnntnLogSearchVO);

    //관리자 접속 로그카운트 조회한다.
    int getAdminUserHistoryCnt(AdminUserHistorySearchVO adminUserHistorySearchVO);

    //관리자 접속 로그를 조회한다.
    List<AdminUserHistoryVO> getAdminUserHistory(AdminUserHistorySearchVO adminUserHistorySearchVO);

    //Exception 로그를 등록한다.
    int regExceptionLog(ExceptionLogVO exceptionLogVO);

    //Exception 로그 카운트를 조회한다.
    int getExceptionLogCnt(ExceptionLogSearchVO exceptionLogSearchVO);

    //Exception 로그를 조회한다.
    List<ExceptionLogVO> getExceptionLog(ExceptionLogSearchVO exceptionLogSearchVO);

    //다운로드 사유를 등록한다.
    int regDownloadRsn(DownloadRsnVO downloadRsnVO);

    //다운로드 사유를 조회한다.
    List<DownloadRsnVO> getDownloadRsn(DownloadRsnSearchVO downloadRsnSearchVO);

    //다운로드 사유 카운트를 조회한다.
    int getDownloadRsnCnt(DownloadRsnSearchVO downloadRsnSearchVO);

    //E-mail 로그를 등록한다.
    int insertStaMailLog(MailSendLogVO mailSendLogVO);

    //배치 실행 목록 카운트를 조회한다.
    int getBatchLogCount(BatchLogSearchVO searchVO);

    //배치 실행 목록을 조회한다.
    List<BatchLogVO> getBatchLogList(BatchLogSearchVO searchVO);

    //Mail 전송 내역 목록 카운트를 조회한다.
    int getMailSendLogCount(MailLogSearchVO searchVO);

    //Mail 전송 내역 목록을 조회한다.
    List<MailSendLogVO> getMailSendLogList(MailLogSearchVO searchVO);


}
