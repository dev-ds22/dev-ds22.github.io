package kr.co.daiso.bo.bd.controller;

import kr.co.daiso.common.model.CommonPagingVo;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.bd.model.FaqVO;
import kr.co.daiso.bo.bd.service.FaqMngService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * packageName    : kr.co.daiso.bo.bd.controller
 * fileName       : FaqMngController.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@Slf4j
@RestController
@RequestMapping("/bd")
@Api(tags = {"FAQMngController"})
public class FaqMngController {

    @Autowired
    private FaqMngService faqMngService;

    @ApiOperation("faq 목록 조회")
    @GetMapping("/faq/faqlist")
    public ResponseEntity searchFaqList(@ApiParam("faq 목록검색 조건") FaqVO faqVO) throws UnsupportedEncodingException {
        faqVO.setTitl(URLDecoder.decode(faqVO.getTitl(), "UTF-8"));
        int faqTotalCount = faqMngService.getFaqTotalCount(faqVO);
        faqVO.setTotal(faqTotalCount);
        List<FaqVO> faqList = faqMngService.searchFaqList(faqVO);

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("faqList", faqList);
        resultMap.put("pagination", (CommonPagingVo)faqVO);
        return new ResponseEntity(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("faq 상세 조회")
    @GetMapping("/faq/{sq}")
    public ResponseEntity searchFaqDetail(@ApiParam("faq 상세 검색 조건") @PathVariable String sq) {
        return new ResponseEntity(new CommonResponseModel(faqMngService.searchFaqDetail(sq)), HttpStatus.OK);
    }

    @ApiOperation("faq 등록수정")
    @PostMapping("/faq")
    public ResponseEntity updateFaq(@ApiParam("faq 등록수정 조건") @Valid @RequestBody FaqVO faqVO) {

        if(faqMngService.updateFaq(faqVO) > 0) {
            return new ResponseEntity(HttpStatus.OK);
        }
        else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @ApiOperation("faq 그리드에서 수정")
    @PatchMapping("/faq/ongrid")
    public ResponseEntity updateFaqOnGrid(@ApiParam("faq 수정내용") @RequestBody LinkedHashMap<String,Object> linkedHashMap) {
        faqMngService.updateFaqOnGrid(linkedHashMap);
        return new ResponseEntity(HttpStatus.OK);
    }
}
