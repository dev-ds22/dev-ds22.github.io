package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CommonAuthBtnVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : CommonCodeMangeMapper
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 공통버튼 관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01        Doo-Won Lee         최초생성
 */
@Mapper
public interface CommonAuthButtonGrpMapper {

     //화면관리의 공통버튼 사용가능 여부를 구한다.
     CommonAuthBtnVO getAuthButtonScreenAvailable(CommonAuthBtnVO reqVo);

     //화면 권한별 공통버튼 사용가능 여부를 구한다.
     CommonAuthBtnVO getScrAuthButtonAvailable(CommonAuthBtnVO reqVo);
}
