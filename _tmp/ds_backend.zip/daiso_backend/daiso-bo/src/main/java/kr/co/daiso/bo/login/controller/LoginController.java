package kr.co.daiso.bo.login.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.login.model.LoginReqVO;
import kr.co.daiso.bo.login.service.LoginService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * packageName    : kr.co.daiso.bo.login.controller
 * fileName       : LoginController
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    : 관리자 로그인 관련 처리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02       Doo-Won Lee         최초생성
 */
@Slf4j
@RestController
public class LoginController {

    @Autowired
    LoginService loginService;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    @ApiOperation("로그인")
    @PostMapping("/login_process")
    public ResponseEntity<CommonResponseModel> adminLogin(@ApiParam("로그인 요청 정보") @RequestBody @Valid LoginReqVO loginVo
            , HttpServletResponse response, HttpServletRequest request){
        log.info("/login_process in controller");
        return loginService.loginProcess(loginVo,response,request);
    }

    @ApiOperation("패스워드 변경")
    @PutMapping("/password")
    public ResponseEntity<CommonResponseModel> changePassword(@ApiParam("패스워드 변경 정보") @RequestBody AdminAccountInfo adminAccountInfo
            , HttpServletResponse response, HttpServletRequest request){
        return loginService.changePassword(adminAccountInfo,response,request);
    }

    @ApiOperation("로그아웃")
    @PostMapping("/logout_process")
    public ResponseEntity<CommonResponseModel> adminLogout(@ApiParam("로그아웃 요청 정보") @RequestBody LoginReqVO logoutVo
            , HttpServletResponse response, HttpServletRequest request){
        return loginService.logoutProcess(logoutVo,response,request);
    }

    @ApiOperation("관리자 정보 조회")
    @GetMapping("/admininfo")
    public ResponseEntity<CommonResponseModel> getLoginAdmininfo(HttpServletResponse response, HttpServletRequest request){
        return loginService.getLoginAdmininfo(response,request);
    }
}
