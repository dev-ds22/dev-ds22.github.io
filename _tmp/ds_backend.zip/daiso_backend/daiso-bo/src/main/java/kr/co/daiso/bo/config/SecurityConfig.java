package kr.co.daiso.bo.config;

import kr.co.daiso.bo.auth.AdminAuthFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsUtils;

/**
 * packageName    : kr.co.daiso.fo.config
 * fileName       : SecurityConfig
 * author         : Doo-Won Lee
 * date           : 2021-10-26
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26       Doo-Won Lee         최초생성
 */
@RequiredArgsConstructor
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * 로그인이 필요한 URL 지정
     */
//    private static final String[] LOGIN_LIST = {
//            "/messageSample"
//    };

    /**
     * Spring Security 처리예외 URL 지정
     */
    private static final String[] IGNORE_LIST = {
//            "/images/**",
            "/**"
//            "/login_process"
    };

    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    /**
     * Spring Security 처리예외 설정
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers(IGNORE_LIST);
    }

    /**
     * Spring Security Configuration 설정. 로그인이 필요한 경우 JWT Token 체크를 위한 Filter를 거치도록 지정
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
            http
//                    .addFilter(corsConfig.corsFilter())
                .headers().frameOptions().sameOrigin().and()
                .httpBasic().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .requestMatchers(CorsUtils::isPreFlightRequest).permitAll()
                .antMatchers("/**").permitAll()
                .and()
                .csrf().disable()
                .cors().disable()
//                .and()
//                .addFilterBefore(new AdminAuthFilter()
//               .addFilterBefore(new AdminAuthFilter(jwtTokenProvider,cookieUtil,redisUtil,userDetailService,commonCodeManageService)
//                                    , UsernamePasswordAuthenticationFilter.class)
              //  .addFilterBefore(new KCarCsrfFileter(),CsrfFilter.class)
                .exceptionHandling()
                .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
    }

//    @Bean
//    public CorsConfigurationSource corsConfigurationSource(){
//        CorsConfiguration configuration = new CorsConfiguration();
//
//        configuration.addAllowedOrigin("*");
//        configuration.addAllowedMethod("*");
//        configuration.addAllowedHeader("*");
//        configuration.setAllowCredentials(true);
//        configuration.setMaxAge(Duration.ofSeconds(60));
//        configuration.addExposedHeader("Content-Disposition");
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**",configuration);
//        return source;
//    }
}
