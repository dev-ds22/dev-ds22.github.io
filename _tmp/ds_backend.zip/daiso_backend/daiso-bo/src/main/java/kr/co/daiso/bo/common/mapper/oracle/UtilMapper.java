package kr.co.daiso.bo.common.mapper.oracle;

import kr.co.daiso.bo.common.model.CmnCldrVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.mapper.oracle
 * fileName       : UtilMapper
 * author         : Doo-Won Lee
 * date           : 2022-01-27
 * description    : DB에서 유틸성정보를 다루는 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-27    Doo-Won Lee       최초생성
 */
@Mapper
public interface UtilMapper {

    //해당일을 포함하여 가장먼저 도래하는 영업일을 조회한다.
    List<CmnCldrVO> getFirstWoringDayAfterYesterDay(String startDate);

    //해당일의 휴일여부를 조회한다.
    String checkHoliday(String targetDate);
}
