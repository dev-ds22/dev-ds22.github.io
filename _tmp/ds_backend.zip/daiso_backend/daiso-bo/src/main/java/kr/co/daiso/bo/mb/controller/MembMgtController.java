package kr.co.daiso.bo.mb.controller;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.mb.model.MembAddInfoDTO;
import kr.co.daiso.bo.mb.model.MemberStaDTO;
import kr.co.daiso.bo.mb.model.TbMbMembBasVO;
import kr.co.daiso.bo.mb.service.MembMgtService;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.EncryptUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.mb.controller
 * fileName       : MemberMgtController
 * author         : bsj
 * date           : 2022-01-10
 * description    : 관리자의 회원관리 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-10      bsj           최초생성
 */
@RestController
@RequestMapping("/mb")
@Api(tags = {"MG 회원관리 컨트롤러"})
public class MembMgtController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private final MembMgtService membMgtService;
    private final EncryptUtil encryptUtil;
    private final AdminAccountInfoUtil adminAccountInfoUtil;

    public MembMgtController(MembMgtService membMgtService, EncryptUtil encryptUtil, AdminAccountInfoUtil adminAccountInfoUtil) {
        this.membMgtService = membMgtService;
        this.encryptUtil = encryptUtil;
        this.adminAccountInfoUtil = adminAccountInfoUtil;
    }

    @ApiOperation(value = "관리자페이지 회원목록조회", notes = "조회조건에 따른 회원목록 리스트 조회")
    @GetMapping("/get-member-list")
    public ResponseEntity getMemberList(@ApiParam("회원 검색조건") TbMbMembBasVO mbMembBasVO) {
//    public List<TbMbMembBasVO> getMemberList(@RequestBody TbMbMembBasVO mbMembBasVO) {
//    public List<TbMbMembBasVO> getMemberList() {
        logger.info("## getMemberList START");
        logger.info("## getMemberList | Params :: {}", mbMembBasVO);
        // [1] 로그인 여부 체크

        // [2] 관리자 여부 체크(시스템 관리자가 아닐경우 i_sCenterCode에 값입력?)

        // [3] 회원목록 조회
        Map<String, Object> resultMap = membMgtService.getMemberList(mbMembBasVO);

        // [4] 마스킹 처리

        // [5] 최종결과 리턴
        return new ResponseEntity(new CommonResponseModel<>(resultMap), HttpStatus.OK);
//        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap),HttpStatus.OK);
//        return membMgtService.getMemberList(mbMembBasVO);
    }

    @ApiOperation(value = "관리자페이지 회원상세조회", notes = "특정회원의 상세정보를 조회한다")
    @GetMapping("/get-member-info")
    public ResponseEntity getMemberDetlInfo(@ApiParam("회원ID") TbMbMembBasVO mbMembBasVO) {
        // [1] 로그인 여부 체크
        // [2] 관리자 여부 체크(시스템 관리자가 아닐경우 i_sCenterCode에 값입력?)
        // [3] 회원 기본정보 조회
        TbMbMembBasVO basInfo = membMgtService.getMemberDetlInfo(mbMembBasVO);
        // [4] 회원 부가정보 조회
        List<MembAddInfoDTO> addInfo = membMgtService.getMemberDetlAddInfo(mbMembBasVO);

        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("basInfo", basInfo);
        resultMap.put("addInfo", addInfo);
        return new ResponseEntity(new CommonResponseModel<>(resultMap), HttpStatus.OK);
    }

    @ApiOperation(value = "관리자페이지 회원비밀번호 초기화", notes = "특정회원의 비밀번호를 초기화한다")
    @PostMapping("/update-member-pwd-reset")
    public int updateMemberPwdReset(@ApiParam("회원ID") @RequestBody TbMbMembBasVO mbMembBasVO) {
        // [1] 관리자 여부 체크(시스템 관리자가 아닐경우 i_sCenterCode에 값입력?)
        // [2] 초기화 비밀번호 생성(회원ID를 암호화한 값)
        String tempPass = mbMembBasVO.getMembId();
        tempPass = encryptUtil.cmEnCrypt(tempPass);
        tempPass	= encryptUtil.getStringValue(encryptUtil.getHashEncryptSha256(tempPass));
        logger.info("암호화된 비밀번호: {}", tempPass); // 예) qre6HSKY5z10AIo3SrrWRTqRsQFlAPVeqrZt4FodFKo=

        // [3] 비밀번호 초기화 업데이트
        String usrId = adminAccountInfoUtil.getUsrId();
        mbMembBasVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
        mbMembBasVO.setPwd(tempPass);
        return membMgtService.updateMemberPwdReset(mbMembBasVO);
    }

    @ApiOperation(value = "관리자페이지 회원통계 조회", notes = "유형별/상태별/일자별/월별 회원통계를 조회한다")
    @GetMapping("/get-member-sta")
    public Map<String, Object> getMemberSta() {
        // [1] 유형별 조회
        List<MemberStaDTO> typeResult = membMgtService.getMemberStaByType();
        logger.info("유형별 통계결과: {}", typeResult.toString());

        // [2] 상태별(가입/탈퇴/휴면) 회원통계 조회
        MemberStaDTO stusResult = membMgtService.getMemberStaByStus();
        logger.info("상태별 통계결과: {}", stusResult.toString());

        // [3] 일자별 회원통계 조회
        List<MemberStaDTO> dateResult = membMgtService.getMemberStaByDate();
        logger.info("일자별 통계결과: {}", stusResult.toString());

        // [4] 월별 회원통계 조회
        List<MemberStaDTO> monthResult = membMgtService.getMemberStaByMonth();
        logger.info("월별 통계결과: {}", monthResult.toString());

        // [5] 가입채널 서브코드목록 조회
        List<CommonCodeManageVO> cmSubCdChnl = membMgtService.getCmSubCodeList();
        logger.info("가입채널목록: {}", cmSubCdChnl.toString());

        // [최종] 결과리턴
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("membByTypeList", typeResult);
        resultMap.put("membByStus", stusResult);
        resultMap.put("membByDateList", dateResult);
        resultMap.put("membByMonthList", monthResult);
        resultMap.put("cmSubCdChnl", cmSubCdChnl);
        return resultMap;
    }

//    @ApiOperation(value = "관리자페이지 기간별 회원통계 조회", notes = "기간별 회원통계를 조회한다")
//    @PostMapping("/get-member-sta/by-perd")
////    public Map<String, Object> getMemberStaByPerd(@RequestBody MemberStaDTO memberStaDTO) {
////    public Map<String, Object> getMemberStaByPerd(@RequestBody @ApiParam("기간별 회원통계 조회조건") MemberStaDTO memberStaDTO, List<String> joinChnlList) {
////    public Map<String, Object> getMemberStaByPerd(@RequestBody @ApiParam("기간별 회원통계 조회조건") List<String> joinChnlList) {
//    public Map<String, Object> getMemberStaByPerd(@RequestBody @ApiParam("기간별 회원통계 조회조건") MemberStaDTO memberStaDTO) {
//        logger.info("##getMemberStaByPerd | params: {}", memberStaDTO.toString());
////        logger.info("##getMemberStaByPerd | joinChnlList: {}", joinChnlList.toString());
//        Map<String, Object> resultMap = new HashMap<String, Object>();
//        return resultMap;
//    }

    @ApiOperation(value = "관리자페이지 기간/일자/채널별 회원통계 조회", notes = "기간/일자/채널별 회원통계를 조회한다")
    @PostMapping("/get-member-sta/by-perd")
    public Map<String, Object> getMemberStaByPerd(@RequestBody @ApiParam("기간별 회원통계 조회조건") MemberStaDTO memberStaDTO) {
        logger.info("##getMemberStaByPerd | params: {}", memberStaDTO.toString());
        /**
         * MemberStaDTO(..., joinChnlList=[C010, C220, C230, C990], startDttm=20210719, endDttm=20220119)
         */
        // [1] 기간별 통계조회
        List<MemberStaDTO> membByPerdList = membMgtService.getMemberStaByPerd(memberStaDTO);
        logger.info("##기간별 회원통계조회 결과: {}", membByPerdList.toString());

        // [2] 기간,일자,가입채널별 통계조회
        Map<String, Object> membByDttmMap = membMgtService.getMemberStaByDttmList(memberStaDTO);
        logger.info("##기간,일자,가입채널별 회원통계조회 결과: {}", membByDttmMap.toString());

        // [최종] 결과리턴
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("membByPerdList", membByPerdList);
        resultMap.put("membByDttmMap", membByDttmMap);
        return resultMap;
    }

    @ApiOperation(value = "관리자페이지 기간/일자/채널별 회원통계 엑셀다운로드", notes = "기간/일자/채널별 회원통계를 엑셀다운로드한다")
    @PostMapping("/get-member-sta/excel-download")
    public void downloadExcelMembSta(@ApiParam("엑셀 다운로드용 회원통계 데이터") @RequestBody MemberStaDTO searchDto
                                                                                        , HttpServletResponse response) {
        membMgtService.downloadExcelMembSta(searchDto, response);
    }

    @ApiOperation(value = "대시보드 회원통계 조회", notes = "일자별/월별 회원통계를 조회한다")
    @GetMapping("/get-dash-member-sta")
    public Map<String, Object> getDashMemberSta() {


        // [1] 대시보드 일자별 회원통계 조회
        List<MemberStaDTO> dateResult = membMgtService.getDashMemberStaByDate();
        logger.info("일자별 통계결과: {}", dateResult.toString());

        // [2] 대시보드 월별 회원통계 조회
        List<MemberStaDTO> monthResult = membMgtService.getDashMemberStaByMonth();
        logger.info("월별 통계결과: {}", monthResult.toString());
        

        // [최종] 결과리턴
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("membByDateList", dateResult);
        resultMap.put("membByMonthList", monthResult);
        return resultMap;
    }

}
