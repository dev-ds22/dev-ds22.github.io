package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import kr.co.daiso.common.model.CommonResponseModel;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : CommonCodeManageService
 * author         : Doo-Won Lee
 * date           : 2021-12-01
 * description    : 공통코드 관리 서비스 인터페이스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01       Doo-Won Lee     최초생성
 */
public interface CommonCodeManageService {

    // 마스터 코드의 카운트를 구한다.(2021-12-01)
    public int getMstCodeListCount(CommonCodeSearchVO searchVo);

    // 마스터 코드의 목록을 구한다. (2021-12-01)
    public List<CommonCodeManageVO> getMstCodeList(CommonCodeSearchVO searchVo);

    // 서브 코드의 카운트를 구한다.(2021-12-01)
    public int getSubCodeListCount(CommonCodeSearchVO searchVo);

    // 서브 코드의 목록을 구한다.(2021-12-01)
    public List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO searchVo);

    // Redis에 관리자 접속 가능 IP 목록을 저장한다.
    public void setAdminIpListToRedis();

    // 그룹코드를 저장 & 수정한다.
    public CommonResponseModel saveMasterCodeList(List<CommonCodeManageVO> createRows, List<CommonCodeManageVO> updateRows);

    // 서브코드를 저장 & 수정한다.
    public CommonResponseModel saveSubCodeList(List<CommonCodeManageVO> createRows, List<CommonCodeManageVO> updateRows);
}
