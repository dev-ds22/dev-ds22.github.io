package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.bo.sm.model.CommonScrnSearchPagingVO;
import kr.co.daiso.bo.sm.model.CommonScrnVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import kr.co.daiso.bo.sm.service.CommonScrnService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : CommonScrnController
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 관리자의 화면 관리 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08      Doo-Won Lee     최초생성
 */
@RestController
@RequestMapping("/sysmg/commonScrn")
@Api(tags = {"관리자의 화면 관리 컨트롤러"})
public class CommonScrnController {

    @Autowired
    CommonScrnService commonScrnService;

    @ApiOperation("화면검색(화면검색 팝업사용)")
    @GetMapping("/searchScreenPopup")
    public ResponseEntity<CommonResponseModel> searchScreenPopup(@ApiParam("화면 검색 정보") CommonScrnSearchPagingVO searchVO){
        Map<String, Object> resultMap = new HashMap<>();
        searchVO.setTotal(commonScrnService.getSearchScrnListCnt(searchVO));
//        System.out.println("getCurrentPage : "+searchVO.getCurrentPage());
//        System.out.println("getPageSize : "+searchVO.getPageSize());
        List<CommonScrnVO> list	= commonScrnService.getSearchScrnList(searchVO);
        resultMap.put("scrnList", list);
        resultMap.put("searchInfo", searchVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("화면검색(화면관리화면사용)")
    @GetMapping("/getScreenList")
    public ResponseEntity<CommonResponseModel> getScreenList(@ApiParam("화면 검색 정보") CommonScrnSearchPagingVO searchVO){
        Map<String, Object> resultMap = new HashMap<>();
        List<CommonScrnVO> list	= commonScrnService.getSearchScrnList(searchVO);
        resultMap.put("scrnList", list);
        resultMap.put("searchInfo", searchVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("화면저장")
    @PostMapping("/saveScreenInfo")
    public ResponseEntity<CommonResponseModel> saveScreenInfo(@ApiParam("저장할 화면 정보") @RequestBody CommonScrnVO saveVO){
        try {
            commonScrnService.saveScreenInfo(saveVO);
        }
        catch(DuplicateKeyException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("DUP");
            failResultModel.setReturnCode("400");
            return new ResponseEntity<CommonResponseModel>(failResultModel, HttpStatus.OK);
        }
        //SQLIntegrityConstraintViolationException
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(), HttpStatus.OK);
    }

    @ApiOperation("화면수정")
    @PostMapping("/editScreenInfo")
    public ResponseEntity<CommonResponseModel> editScreenInfo(@ApiParam("수정할 화면 정보") @RequestBody CommonScrnVO editVO){
        commonScrnService.editScreenInfo(editVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(), HttpStatus.OK);
    }

    @ApiOperation("화면 관련 메뉴목록 조회")
    @GetMapping("/menulistByScrn")
    public ResponseEntity<CommonResponseModel> menulistByScrn(@ApiParam("메뉴조회 화면 정보")CommonScrnVO scrnVO){
        Map<String, Object> resultMap = new HashMap<>();
        List<ScrnMenuVO> list	= commonScrnService.getMenulistByScrn(scrnVO);
        resultMap.put("menuList", list);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }
}
