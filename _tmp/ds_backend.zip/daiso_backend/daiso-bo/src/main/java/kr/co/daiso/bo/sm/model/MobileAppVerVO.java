package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : MobileAppVerVO
 * author         : Byung-chul Park
 * date           : 2022-02-28
 * description    : 모바일 APP버전관리 조회 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-28       Byung-chul Park   최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MobileAppVerVO extends CommonPagingVo {

    private String osDvsCd;     //OS구분코드
    private String appVer;      //앱버전
    private String coerYn;      //강제 여부
    private String storeLink;   //스토어 링크
}
