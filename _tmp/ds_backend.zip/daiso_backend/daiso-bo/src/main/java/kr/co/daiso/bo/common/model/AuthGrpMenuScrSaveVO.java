package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AuthGrpMenuScrSaveVO
 * author         : leechangjoo
 * date           : 2021-12-30
 * description    : 권한 그룹 메뉴 권한 및 화면 권한 추가 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-30          leechangjoo         최초생성
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class AuthGrpMenuScrSaveVO extends BaseModel {
    private String authGrpCd;	    /*권한그룹코드*/
    private String menuId;			/*메뉴ID*/
    private String scrnId;			/*화면ID*/
    private String iqyBtnUseYn;	    /*조회버튼사용여부*/
    private String initBtnUseYn;	/*초기화버튼사용여부*/
    private String newBtnUseYn;	    /*신규버튼사용여부*/
    private String strgBtnUseYn;	/*저장버튼사용여부*/
    private String delBtnUseYn;	    /*삭제버튼사용여부*/
    private String dnldBtnUseYn;	/*다운로드버튼사용여부*/

    private Object _attributes;     /*그리드상태값*/
}
