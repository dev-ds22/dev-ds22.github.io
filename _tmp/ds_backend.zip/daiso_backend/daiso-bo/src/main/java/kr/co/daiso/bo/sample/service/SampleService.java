package kr.co.daiso.bo.sample.service;

import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

public interface SampleService {

//     public ResponseEntity<CommonResponseModel> loginProcess(SampleLoginVO loginParams, HttpServletResponse response);
    public void excelUtilTest(MultipartFile file, HttpServletRequest req) throws Exception;

//    public void fileUploadTest(MultipartFile file, String path)  throws IOException;
}
