package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonModelVO
 * author         : leechangjoo
 * date           : 2022-01-12
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-12          leechangjoo         최초생성
 **/
@EqualsAndHashCode(callSuper=false)
@Data
public class CommonModelVO extends BaseModel {

    //제조사 정보
    private String	mnuftrCd;   //제조사 코드
    private String	mnuftrNm;   //제조사명
    private String	mnuftrEnm;  //제조사 영문명
    private String	mnuftrType; //제조사 타입

    //모델 정보
    private String	modelCd;     //모델 코드
    private String	modelNm;     //모델명
    private String	modelEnm;    //모델 영문명
    private String	makeModelcd; //모델명
    private String	modelGrpCd;  //모델그룹코드
    private String	modelGrpNm;  //모델그룹명

    //등급 정보
    private String	grdCd;       //등급코드
    private String	grdNm;       //등급이름
    private String	carctgrCd;   //카테고리코드
    private String	rpsImgUrl;   //대표이미지

    //세부등급 정보
    private String	grdDtlCd;    //세부등급코드
    private String	grdDtlNm;    //세부등급이름


    //서브코드 정보
//    private String	subCd;          //서브코드
//    private String	subCdNm;        //서브코드명
//    private String	subCdEngNm;     //서브코드 영문명
//    private int sortOrdr;           //순번
//    private String hrnkGrpCd;       //상위 그룹코드
//
//    private String	addtFld1;       //추가 필드1
//    private String	addtFld2;       //추가 필드2
//    private String	addtFld3;       //추가 필드3
//
//    private String	addtFld11;      //추가 필드11
//    private String	addtFld12;      //추가 필드12
//    private String	addtFld13;      //추가 필드13
//    private String	addtFld14;      //추가 필드14
//    private String	addtFld15;      //추가 필드15
//    private String	addtFld16;      //추가 필드16
//    private String	addtFld17;      //추가 필드17
//    private String	addtFld18;      //추가 필드18

}
