package kr.co.daiso.bo.sm.model;

import lombok.Data;

@Data
public class CommonUserVo {
    private String usrCd; /*사용자 코드*/
    private String usrNm; /*사용자 이름*/
    private String usrId; /*사용자 ID*/
    private String dept; /*부서명*/
    private String dept1; /*부서1*/
    private String dept2; /*부서2*/
    private String jobps; /*직급*/
}
