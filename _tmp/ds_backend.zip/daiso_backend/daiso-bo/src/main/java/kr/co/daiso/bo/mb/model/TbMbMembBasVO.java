package kr.co.daiso.bo.mb.model;

import kr.co.daiso.common.annotation.MaskingField;
import kr.co.daiso.common.model.BaseModel;
import kr.co.daiso.common.model.CommonPagingVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * packageName    : kr.co.daiso.bo.mb.model
 * fileName       : TbMbMembBasVO
 * author         : bsj
 * date           : 2022-01-10
 * description    : 회원기본 테이블(tb_mb_memb_bas)의 Entity
 *                  회원휴면 테이블(tb_mb_memb_dorm)과 동일
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-10       bsj           최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class TbMbMembBasVO extends CommonPagingVo {

    /*
    @ApiModelProperty 사용법
    > value - 파라메터 이름
    > name - Swagger에서 입력 받을 리얼 파라메터 명
    > notes - 부가설명
    > example - 지정된 임의 테스트 값을 입력 함
    > required - 필수 입력 여부
     */
    @ApiModelProperty(value = "회원코드", notes = "회원코드 데이터", example = "M2021000496024")
    private String membCd;
    @ApiModelProperty(value = "회원종류")
    private String membKnd;
    @ApiModelProperty(value = "회원ID")
    private String membId;
    @ApiModelProperty(value = "비밀번호")
    private String pwd;
    @ApiModelProperty(value = "회원명")
    @MaskingField(MaskingField.MaskingType.NAME)
    private String membNm;
    @ApiModelProperty(value = "약관동의여부")
    private String atclAgreYn;
    @ApiModelProperty(value = "개인정보동의여부")
    private String indvInfoAgreYn;
    @ApiModelProperty(value = "생년월일")
    private String birdt;
    @ApiModelProperty(value = "별명")
    private String nicknm;
    @ApiModelProperty(value = "연락처")
    private String ctad;
    @ApiModelProperty(value = "휴대폰번호")
    @MaskingField(MaskingField.MaskingType.PHONE_NUM)
    private String mbpno;
    @ApiModelProperty(value = "이메일")
    @MaskingField(MaskingField.MaskingType.EMAIL)
    private String email;
    @ApiModelProperty(value = "이메일수신동의여부")
    private String emailRcvAgreYn;
    @ApiModelProperty(value = "사진명")
    private String phtoNm;
    @ApiModelProperty(value = "사진경로")
    private String phtoPath;
    @ApiModelProperty(value = "사진확장자")
    private String phtoExt;
    @ApiModelProperty(value = "관심")
    private String intrst;
    @ApiModelProperty(value = "기타문의")
    private String etcInq;
    @ApiModelProperty(value = "카드번호")
    private String cdno;
    @ApiModelProperty(value = "탈퇴여부")
    private String wtdrYn;
    @ApiModelProperty(value = "탈퇴일자")
    private String wtdrDt;
    @ApiModelProperty(value = "탈퇴사유")
    private String wtdrRsn;
    @ApiModelProperty(value = "성별")
    private String sex;
    @ApiModelProperty(value = "가입채널")
    private String joinChnl;
    @ApiModelProperty(value = "총무닷컴ID")
    private String chmuId;
    @ApiModelProperty(value = "이동통신사")
    private String moblcrr;
    @ApiModelProperty(value = "시도구분")
    private String sidoDvs;
    @ApiModelProperty(value = "차량종류")
    private String carKnd;
    @ApiModelProperty(value = "제조사")
    private String mnuftr;
    @ApiModelProperty(value = "모델")
    private String model;
    @ApiModelProperty(value = "등급")
    private String grd;
    @ApiModelProperty(value = "상세등급")
    private String dtlGrd;
    @ApiModelProperty(value = "SMS수신동의여부")
    private String smsRcvAgreYn;
    @ApiModelProperty(value = "오버랩키")
    private String ovlapKey;
    @ApiModelProperty(value = "개인정보선택동의여부")
    private String indvInfoChcAgreYn;
    @ApiModelProperty(value = "비밀번호오류건수")
    private String pwdErrCnt;
    @ApiModelProperty(value = "사용자지역")
    private String usrRgn;
    @ApiModelProperty(value = "가입경로")
    private String joinPath;
    @ApiModelProperty(value = "가입경로직접입력")
    private String joinPathDrectInp;
    @ApiModelProperty(value = "최종접속일자")
    private String fnlCnntnDt;
    @ApiModelProperty(value = "구매희망일")
    private String pchsHopeDD;
    @ApiModelProperty(value = "달러사코드")
    private String dlercoCd;
    @ApiModelProperty(value = "전시장코드")
    private String shwroomCd;
    @ApiModelProperty(value = "매매사원증번호")
    private String dealEmpcrdNo;
    @ApiModelProperty(value = "최초로그인여부")
    private String fstLoginYn;
}
