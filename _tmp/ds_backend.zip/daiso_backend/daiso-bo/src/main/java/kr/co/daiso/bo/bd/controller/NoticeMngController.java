package kr.co.daiso.bo.bd.controller;

import kr.co.daiso.common.model.CommonPagingVo;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.bd.model.NoticeVO;
import kr.co.daiso.bo.bd.service.NoticeMngService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.bd.controller
 * fileName       : NoticeMngController.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@Slf4j
@Api(tags = {"NoticeMngController"})
@RestController
@RequestMapping("/bd")
public class NoticeMngController {

    @Autowired
    NoticeMngService noticeMngService;

    @ApiOperation("공지사항 목록조회")
    @GetMapping("/notice/noticelist")
    public ResponseEntity searchNoticeList(@ApiParam("공지사항목록 검색조건") NoticeVO noticeVO) throws UnsupportedEncodingException {
        noticeVO.setTitl(URLDecoder.decode(noticeVO.getTitl(), "UTF-8"));
        Map<String, Object> resultMap = new HashMap<>();

        noticeVO.setTotal(noticeMngService.getNoticeTotalCount(noticeVO));
        resultMap.put("pagination", (CommonPagingVo) noticeVO);

        List<NoticeVO> noticeList = noticeMngService.searchNoticeList(noticeVO);
        resultMap.put("noticeList", noticeList);

        return new ResponseEntity(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("공지사항 조회")
    @GetMapping("/notice/{bltbdCd}")
    public ResponseEntity searchNotice(@ApiParam("공지사항 검색조건") @PathVariable String bltbdCd) {
        NoticeVO noticeVO = noticeMngService.searchNotice(bltbdCd);
        return new ResponseEntity(new CommonResponseModel(noticeMngService.searchNotice(bltbdCd)), HttpStatus.OK);
    }

    @ApiOperation("공지사항 삭제")
    @DeleteMapping("/notice")
    public ResponseEntity deleteNotice(@ApiParam("공지사항 삭제조건") @RequestBody NoticeVO noticeVO) {
        return new ResponseEntity(new CommonResponseModel(noticeMngService.deleteNotice(noticeVO)), HttpStatus.OK);
    }

    @ApiOperation("공지사항 등록")
    @PostMapping("/notice")
    public ResponseEntity insertNotice(@ApiParam("공지사항 등록내용") @RequestBody NoticeVO noticeVO) {
        noticeMngService.insertNotice(noticeVO);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("공지사항 수정")
    @PatchMapping("/notice")
    public ResponseEntity updateNotice(@ApiParam("공지사항 수정내용") @RequestBody NoticeVO noticeVO) {
        noticeMngService.updateNotice(noticeVO);
        return new ResponseEntity(HttpStatus.OK);
    }
}
