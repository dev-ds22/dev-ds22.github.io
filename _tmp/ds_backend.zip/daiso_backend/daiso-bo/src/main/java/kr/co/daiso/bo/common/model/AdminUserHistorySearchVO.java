package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AdminUserHistorySearchVO
 * author         : Doo-Won Lee
 * date           : 2022-02-08
 * description    : 사용자 이력 조회검색VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-08      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AdminUserHistorySearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String keyword;  //검색어
    private String authGrntType; //권한부여 타입
}
