package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.ArticlePagingVo;
import kr.co.daiso.bo.sm.model.ArticleVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ArticleMapper {
    // 약관 리스트
    List<ArticleVo> getArticles(ArticlePagingVo searchVO);
    // 조회된 약관 갯수
    int getCount(ArticlePagingVo searchVO);
    // 약관 상세
    ArticleVo getDetail(ArticleVo vo);
    // 약관 등록
    int setArticle(ArticleVo articleVo);
    // 약관 수정
    int updateArticle(ArticleVo articleVo);
}
