package kr.co.daiso.bo.message.service;

import kr.co.daiso.bo.common.mapper.oracle.UtilMapper;
import kr.co.daiso.bo.common.model.CmnCldrVO;
import kr.co.daiso.bo.common.model.CommonPathInfo;
import kr.co.daiso.bo.message.mapper.oracle.AtaMapper;
import kr.co.daiso.bo.message.model.AtaVO;
import kr.co.daiso.bo.message.model.SmsVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.message.service
 * fileName       : AtaService
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */
@Slf4j
@Service
public class AtaService {

    @Value("${ata.sender_key}")
    private String ataSenderKey;

    @Value("${ata.sender_homekey}")
    private String ataSenderHomeKey;

    @Value("${ata.sender_prokey}")
    private String ataSenderProKey;

    @Value("${ata.send_yn}")
    private boolean ataSendYn;

    @Value("${ata.encer_tel}")
    private String ataEncarTel;

    @Value("${ata.test_tel}")
    private String ataTestTel;

    @Value("${dblink}")
    private String dblink;

    @Autowired
    AtaMapper ataMapper;

    @Autowired
    UtilMapper utilMapper;

    @Autowired
    SmsService smsService;

    @Autowired
    private Environment environment;

    // 템플릿이 필요한경우
    public AtaVO insertAta(AtaVO ataVO, Map<String,Object> map) throws Exception{
        ataVO.setDbLinkValue(dblink);
        String templateMessage = Optional.ofNullable(ataMapper.selectMessage(ataVO)).orElse(null);
        log.info("== message before ==\n" + templateMessage);
//        for(String key : map.keySet()){
//            templateMessage = templateMessage.replaceAll("#\\{" + key + "}", String.valueOf(map.get(key)));
//        }
        for(Map.Entry<String,Object> entry : map.entrySet()){
            templateMessage = templateMessage.replaceAll("#\\{" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }

        log.info("== message after ==\n" + templateMessage);
        ataVO.setContent(templateMessage);
        return this.insertAta(ataVO);
    }

    /**
     * 알림톡 등록
     * @param ataVO
     * @return AtaVO
     */
    public AtaVO insertAta(AtaVO ataVO) throws Exception{

        // 알림톡 실패시 sms 전송용
        // 메세지insert(전송할수없는 임의의상태X로)
        SmsVO smsVO = new SmsVO();
        smsVO.setSubject(ataVO.getSubject());

        ataVO.setDbLinkValue(dblink);
        String mt_pr = "";
        mt_pr = ataMapper.selectMtpr(ataVO);
        ataVO.setMtPr(mt_pr);                //
        ataVO.setMsgStatus("1");            // 메세지상태(1-전송대기, 2-결과대기, 3-완료)
        ataVO.setSubject(" ");                // 메세지제목
        ataVO.setServiceType("3");        // 3 카카오톡 알림톡
        ataVO.setMsgType("1008");            // 메시지종류(1008-카카오톡 알림톡, 1009-카카오톡 친구톡)
        ataVO.setCallback(ataEncarTel);     // 발신자전화번호

        boolean isReal = Arrays.stream(environment.getActiveProfiles()).anyMatch(profileName -> (profileName.equals("prd") || profileName.equals("prd_cloud")));
        // 수신자 설정
        if (!isReal) {
            ataVO.setRecipientNum(ataTestTel);
        }

        // 카카오톡 알림톡 발신 프로필 키
        if ("HOME".equals(ataVO.getTmplType())) {
            ataVO.setSenderKey(ataSenderHomeKey);
        } else if ("PRO".equals(ataSenderHomeKey)) {
            ataVO.setSenderKey(ataSenderProKey);
        } else {
            ataVO.setSenderKey(ataSenderKey);
        }

        // 직원대상 알림톡 발송시간 조정 08시 ~ 19시
        // 현재 시간 구하기
        String TEMPLATE_CODE = ataVO.getTemplateCode();
        String regDtm = "";
        if("EC00000009".equals(TEMPLATE_CODE)	// 내차사기 홈서비스 (상담후 결제)
                ||"EC00000016".equals(TEMPLATE_CODE)	// 차량배송안내
                ||"EC00000024".equals(TEMPLATE_CODE)	// '예약취소' 버튼 클릭시
                ||"EC00000025".equals(TEMPLATE_CODE)		// 방문예약신청
                ||"EC00000045".equals(TEMPLATE_CODE)	// 즉시결제
                ||"EC00000051".equals(TEMPLATE_CODE)	// 상담결제
        ){

            Calendar curDate = Calendar.getInstance();

            int regHour = 0;
            int startHour = 8;
            int endHour = 19;

            SimpleDateFormat hourFormat = new SimpleDateFormat("HH");
            SimpleDateFormat yMdFormat = new SimpleDateFormat("yyyyMMdd");
            SimpleDateFormat HmsFormat = new SimpleDateFormat("HHmmss");

            // 접수 시간
            regHour = Integer.parseInt(hourFormat.format(curDate.getTime()));

            Map<String, String> reqMap = new HashMap<>();
            // 접수 시간이 19시 이상인 경우는, 다음날 전송처리
            if(endHour <= regHour){
                curDate.add(Calendar.DATE, 1);
            }

            String startData = yMdFormat.format(curDate.getTime());
            reqMap.put("startData", startData);

            List<CmnCldrVO> availDays = utilMapper.getFirstWoringDayAfterYesterDay(startData);
            if (!CollectionUtils.isEmpty(availDays)) {
                String date = availDays.get(0).getRelvDate();
                /**
                 * 08시 00분 00초로 치환하는 케이스
                 * 1. 접수시간이 00~07시 사이인 경우
                 * 2. 접수시간이 19~23시 사이인 경우
                 * 3. 접수일자가 실제 영업일이 아닌 경우
                 */
                if(regHour<startHour || endHour<=regHour || ! startData.equals(date)) {
                    ataVO.setRegDate(date+"0"+startHour+"0000");
                }else{
                    ataVO.setRegDate(date + HmsFormat.format(curDate.getTime()));
                }
            }

        }
        ataMapper.insertAta(ataVO);

        // 알림톡 실패시 sms 전송용
        // 메세지insert(전송할수없는 임의의상태X로)
//        SmsVO smsVO = new SmsVO();
        smsVO.setCallback(CommonPathInfo.CAR_INFO_FROM_SMS);    // 보내는 번호
        smsVO.setDstaddr(ataVO.getRecipientNum());              // 받는 번호
        smsVO.setReceiverCd("customer");
        smsVO.setText(ataVO.getContent());
        smsVO.setMtPr(mt_pr);

        if (!StringUtils.hasText(regDtm)){
            smsVO.setRequestTime(regDtm);
        }

        smsService.insertSms(smsVO);
//        ClsCommonReqVo reqVo = new ClsCommonReqVo();
//        reqVo.setI_sTranCallBack(CommonPathInfo.CAR_INFO_FROM_SMS); // 보내는 번호 담당자 이천용
//        reqVo.setI_sTranPhone(ataVO.getRECIPIENT_NUM().replaceAll("-", "")); // 받는 번호
//        reqVo.setI_sReceiverCd("customer");//???
//        reqVo.setI_sMessage(ataVO.getCONTENT());
//        reqVo.setS_MT_PR(mt_pr);
//        if(!"".equals(regDtm)){
//            reqVo.setS_REQUEST_TIME(regDtm);
//        }
//
//        clsCommon.insertSms(reqVo);

        return ataVO;
    }

    // 알림톡 전송을위한 AtaVO 세팅
    public AtaVO setAtaVO(String tmplcd, String msg, String toTelno, String fromTelno, String tmplType){
//   ublic AtaVO setAtaVO(String tmplcd, String msg, String toTelno, String fromTelno, String buttonNm, String sUrl, String tmplType){ buttonNm, sUrl 사용안함으로 제외  2022-04-29
        AtaVO ataVO = new AtaVO();
        ataVO.setTemplateCode(tmplcd);					// 템플릿코드
        ataVO.setContent(msg);							// 내용
        ataVO.setRecipientNum(toTelno);				// 수신자전화번호
        ataVO.setTmplType(tmplType);				// 템플릿타입 (엔카직영, 홈엔카내차팔기, PRO)
        if(StringUtils.hasText(fromTelno)){
            ataVO.setCallback(fromTelno);				// 발신자전화번호
        }else{
            ataVO.setCallback(ataEncarTel);			// 수신번호없을시 대표전화번호
        }
//        ataVO = this.setButton(ataVO, buttonNm, sUrl);	// 버튼관련 처리
        return ataVO;
    }

    //알림톡전송 후 알림톡 키값 리턴
    public String sendAta(AtaVO ataVO){
        try{
            if(!StringUtils.hasText(ataVO.getRecipientNum())){	// 수신번호가 없으면 E901 에러가 남는다.
                return "";
            }
            if(ataSendYn){
                ataVO = this.insertAta(ataVO);
            }
            return ataVO.getMtPr();

        }catch(Exception e){
            log.error("ATA send error>"+ e.getMessage());
            return "";
        }
    }
}
