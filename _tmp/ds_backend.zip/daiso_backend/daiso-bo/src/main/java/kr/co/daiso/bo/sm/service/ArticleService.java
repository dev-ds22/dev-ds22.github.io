package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.ArticlePagingVo;
import kr.co.daiso.bo.sm.model.ArticleVo;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public interface ArticleService {
    /**
     * 약관 리스트를 조회한다
     *
     * @param searchVO 약관 코드 정보
     * @return 약관 리스트
     */
    public List<ArticleVo> getArticleList(ArticlePagingVo searchVO);

    /**
     * 조회된 약관의 갯수를 구한다
     *
     * @param searchVO 약관 코드 정보
     * @return 약관수
     */
    public int listCount(ArticlePagingVo searchVO);

    /**
     * 약관의 상세 정보를 조회한다
     *
     * @param articleVo 약관 코드, 약관 버전 정보
     * @return 약관 상세정보
     */
    public ArticleVo getArticle(ArticleVo articleVo);

    /**
     * 약관을 새로 등록한다
     * @param articleVo 입력받은 약관 정보
     *
     */
    public int saveArticle(ArticleVo articleVo);

    /**
     * 약관을 수정한다
     * @param articleVo 입력받은 약관 정보
     *
     */
    public int updateArticle(ArticleVo articleVo);
}
