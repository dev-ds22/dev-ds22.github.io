package kr.co.daiso.bo.bd.service.Impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.bd.mapper.oracle.PopupMngMapper;
import kr.co.daiso.bo.bd.model.PopupDetailVO;
import kr.co.daiso.bo.bd.model.PopupVO;
import kr.co.daiso.bo.bd.service.PopupMngService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.bd.service.Impl
 * fileName       : PopupMngServiceImpl
 * author         : kjm
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14       kjm            최초생성
 */
@Service
public class PopupMngServiceImpl implements PopupMngService {

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    @Autowired
    PopupMngMapper popupMngMapper;

    /**
     * methodName : searchPopupListCount
     * author : kjm
     * description : 팝업 목록 개수 조회
     *
     * @param popupVO
     * @return int
     */
    @Override
    public int searchPopupListCount(PopupVO popupVO) {
        return popupMngMapper.searchPopupListCount(popupVO);
    }

    /**
     * methodName : searchPopupList
     * author : kjm
     * description : 팝업 목록 조회
     *
     * @param popupVO
     * @return List<PopupVO>
     */
    @Override
    public List<PopupVO> searchPopupList(PopupVO popupVO) {
        return popupMngMapper.searchPopupList(popupVO);
    }

    /**
     * methodName : searchPopupDetail
     * author : kjm
     * description : 팝업 상세 조회
     *
     * @param ppupCd
     * @return Map<String, Object>
     */
    @Override
    public Map<String, Object> searchPopupDetail(String ppupCd) {
        PopupDetailVO popupDetailVO = new PopupDetailVO();
        popupDetailVO.setPpupCd(ppupCd);
        popupDetailVO.setPltformDcd("C001"); // pc
        PopupDetailVO pcDetail = popupMngMapper.searchPopupDetail(popupDetailVO);
        popupDetailVO.setPltformDcd("C002"); // mo
        PopupDetailVO moDetail = popupMngMapper.searchPopupDetail(popupDetailVO);
        Map<String, Object> popupDetailMap = new HashMap<>();
        popupDetailMap.put("pcDetail", pcDetail);
        popupDetailMap.put("moDetail", moDetail);
        return popupDetailMap;
    }

    /**
     * methodName : searchPopup
     * author : kjm
     * description : 팝업 조회
     *
     * @param ppupCd
     * @return PopupVO
     */
    @Override
    public PopupVO searchPopup(String ppupCd) {
        return popupMngMapper.searchPopup(ppupCd);
    }

    /**
     * methodName : insertPopup
     * author : kjm
     * description : 팝업 등록
     *
     * @param paramMap
     */
    @Override
    public void insertPopup(Map<String, Object> paramMap) {

        String userId =  adminAccountInfoUtil.getUsrId();

        ObjectMapper objectMapper = new ObjectMapper();
        PopupVO popupVO = objectMapper.convertValue(paramMap.get("popupVO"), PopupVO.class);
        PopupDetailVO pcDetail = objectMapper.convertValue(paramMap.get("pcDetail"), PopupDetailVO.class);
        PopupDetailVO moDetail = objectMapper.convertValue(paramMap.get("moDetail"), PopupDetailVO.class);

        String newPpupCd = popupMngMapper.newPpupCd();
        popupVO.setPpupCd(newPpupCd);
        popupVO.setPcStrtDt(pcDetail.getPpupStrtDt());
        popupVO.setPcEndDt(pcDetail.getPpupEndDt());
        popupVO.setPcSortSq(pcDetail.getSortOrdr());
        popupVO.setMblStrtDt(moDetail.getPpupStrtDt());
        popupVO.setMblEndDt(moDetail.getPpupEndDt());
        popupVO.setMblSortSq(moDetail.getSortOrdr());
        popupVO.setRgpsId(userId);
        popupVO.setMdpsId(userId);

        popupMngMapper.insertPopup(popupVO);

        pcDetail.setPpupCd(newPpupCd);
        pcDetail.setRgpsId(userId);
        pcDetail.setMdpsId(userId);

        moDetail.setPpupCd(newPpupCd);
        moDetail.setRgpsId(userId);
        moDetail.setMdpsId(userId);

        popupMngMapper.insertPopupDetail(pcDetail);
        popupMngMapper.insertPopupDetail(moDetail);
    }

    /**
     * methodName : updatePopup
     * author : kjm
     * description : 팝업 수정
     *
     * @param paramMap
     */
    @Override
    public void updatePopup(Map<String, Object> paramMap) {

        String userId =  adminAccountInfoUtil.getUsrId();

        ObjectMapper objectMapper = new ObjectMapper();
        PopupVO popupVO = objectMapper.convertValue(paramMap.get("popupVO"), PopupVO.class);
        PopupDetailVO pcDetail = objectMapper.convertValue(paramMap.get("pcDetail"), PopupDetailVO.class);
        PopupDetailVO moDetail = objectMapper.convertValue(paramMap.get("moDetail"), PopupDetailVO.class);

        popupVO.setMdpsId(userId);
        popupVO.setPcStrtDt(pcDetail.getPpupStrtDt());
        popupVO.setPcEndDt(pcDetail.getPpupEndDt());
        popupVO.setPcSortSq(pcDetail.getSortOrdr());
        popupVO.setMblStrtDt(moDetail.getPpupStrtDt());
        popupVO.setMblEndDt(moDetail.getPpupEndDt());
        popupVO.setMblSortSq(moDetail.getSortOrdr());
        popupMngMapper.updatePopup(popupVO);

        pcDetail.setPpupCd(popupVO.getPpupCd());
        pcDetail.setRgpsId(userId);
        pcDetail.setMdpsId(userId);
        popupMngMapper.updatePopupDetail(pcDetail);

        moDetail.setPpupCd(popupVO.getPpupCd());
        moDetail.setRgpsId(userId);
        moDetail.setMdpsId(userId);
        popupMngMapper.updatePopupDetail(moDetail);
    }

    /**
     * methodName : deletePopup
     * author : kjm
     * description : 팝업 삭제
     *
     * @param popupVO
     */
    @Override
    public void deletePopup(PopupVO popupVO) {
        String userId = adminAccountInfoUtil.getUsrId();
        popupVO.setMdpsId(userId);
        popupMngMapper.deletePopup(popupVO);
        PopupDetailVO popupDetailVO = new PopupDetailVO();
        popupDetailVO.setPpupCd(popupVO.getPpupCd());
        popupMngMapper.deletePopupDetail(popupDetailVO);
    }

    /**
     * methodName : deletePopupDetail
     * author : kjm
     * description : 팝업 상세 삭제
     *
     * @param popupDetailVO
     */
    @Override
    public void deletePopupDetail(PopupDetailVO popupDetailVO) {
        popupMngMapper.deletePopupDetail(popupDetailVO);
    }
}
