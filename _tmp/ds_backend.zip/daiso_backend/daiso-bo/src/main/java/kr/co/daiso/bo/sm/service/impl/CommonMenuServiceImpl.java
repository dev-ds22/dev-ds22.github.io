package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.sm.mapper.oracle.CommonMenuMapper;
import kr.co.daiso.bo.sm.model.MenuVO;
import kr.co.daiso.bo.sm.service.CommonMenuService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.menu.service
 * fileName       : MenuServiceImpl
 * author         : kjm
 * date           : 2021-12-08
 * description    : 메뉴관리 관련 기능
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       kjm            최초생성
 */
@Service
public class CommonMenuServiceImpl implements CommonMenuService {

    @Autowired
    CommonMenuMapper commonMenuMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;
    /**
     * methodName : getMenuList
     * author : kjm
     * description : 메뉴 목록 조회
     *
     * @param menuVO
     * @return List<MenuVO>
     */
    @Override
    public List<MenuVO> getMenuList(MenuVO menuVO) {
        return commonMenuMapper.getMenuList(menuVO);
    }

    /**
     * methodName : getMenuListCount
     * author : kjm
     * description : 메뉴 카운트 조회
     *
     * @param menuVO
     */
    @Override
    public int getMenuListCount(MenuVO menuVO) {
        return commonMenuMapper.getMenuListCount(menuVO);
    }

    /**
     * methodName : getMenuDetail
     * author : kjm
     * description : 메뉴 상세 조회
     *
     * @param menuVO
     * @return MenuVO
     */
    @Override
    public MenuVO getMenuDetail(MenuVO menuVO) {
        return commonMenuMapper.getMenuDetail(menuVO);
    }

    /**
     * methodName : searchMenu
     * author : kjm
     * description : 메뉴 정보 검색
     *
     * @param menuVO
     * @return List<MenuVO>
     */
    @Override
    public List<MenuVO> searchMenu(MenuVO menuVO) {
        return commonMenuMapper.getMenuList(menuVO);
    }

    /**
     * methodName : updateMenu
     * author : kjm
     * description : 메뉴 정보 추가, 변경
     *
     * @param menuVO
     */
    @Override
    public void updateMenu(MenuVO menuVO) {
        if(StringUtils.hasText(menuVO.getMenuNm())) {

            if(commonMenuMapper.childMenuCheck(menuVO) != 0) {
                menuVO.setScrnId(null);
                menuVO.setPgSq(null);
            }
            if (!menuVO.getSysDcd().equals("MG")) {
                commonMenuMapper.updatePage(menuVO);
            }
            commonMenuMapper.updateMenu(menuVO);
        }
    }

    /**
     * methodName : updateMenuTree
     * author : kjm
     * description : 메뉴 구조 변경
     *
     * @param updateMenuList
     */
    @Override
    public void updateMenuTree(List<MenuVO> updateMenuList) {
        updateMenuList.forEach(commonMenuMapper::updateMenuTree);
    }

    /**
     * methodName : getMenuAuthGrp
     * author : kjm
     * description : 메뉴-권한그룹 목록 조회
     *
     * @param menuVO
     * @return List<AuthGrpAdmVO>
     */
    @Override
    public List<AuthGrpAdmVO> getMenuAuthGrpList(MenuVO menuVO) {
        return commonMenuMapper.getMenuAuthGrpList(menuVO);
    }

    /**
     * methodName : getMenuAuthGrp
     * author : Doo-Won Lee
     * description : 메뉴&권한그룹 목록 조회
     *
     * @return List<MenuVO>
     */
    @Override
    public List<MenuVO> getMenuAndAuthList(){
        AdminAccountInfo adminAccountInfo = adminAccountInfoUtil.getAccountInfo();
        List<String> userAuthList = Arrays.asList(adminAccountInfoUtil.getUsrType().split(","));
        List<MenuVO> resultList = new ArrayList<>();
        List<MenuVO> selectList = commonMenuMapper.getMenuAndAuthList();
        for(int i=0;i<selectList.size();i++){
            if (null!=selectList.get(i).getAuthGrps()) {
                List<String> authList = Arrays.asList(selectList.get(i).getAuthGrps().split(","));
                for (int j = 0; j < userAuthList.size(); j++) {
                    if (authList.contains(userAuthList.get(j))) {
//                        if (null!=selectList.get(i).getIndvInfoRelYn() && selectList.get(i).getIndvInfoRelYn().equals("Y")){
                        if (org.apache.commons.lang3.StringUtils.equals("Y",selectList.get(i).getIndvInfoRelYn())){
                            if (org.apache.commons.lang3.StringUtils.equals("Y",adminAccountInfo.getIndvInfoDealYn())){
                                resultList.add(selectList.get(i));
                            }
                        }
                        else {
                            resultList.add(selectList.get(i));
                        }
                        break;
                    }
                }
            }
        }
        return resultList;
    }
}
