package kr.co.daiso.bo.bd.mapper.oracle;

import kr.co.daiso.bo.bd.model.FaqVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.bd.mapper.oracle
 * fileName       : FaqMngMapper
 * author         : kjm
 * date           : 2022-01-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       kjm            최초생성
 */
@Mapper
public interface FaqMngMapper {

    // FAQ 목록 조회
    public List<FaqVO> searchFaqList(FaqVO faqVO);

    // FAQ 목록 개수 조회
    int getFaqTotalCount(FaqVO faqVO);

    // FAQ 상세조회
    FaqVO searchFaqDetail(String sq);

    // 새로운 FAQ 번호 생성
    String getNewFaqSq();

    // FAQ 등록수정
    int updateFaq(FaqVO faqVO);

    // faq 정렬순서 수정
    void updateFaqOnGrid(FaqVO faqVO);
}
