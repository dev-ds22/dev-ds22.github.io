package kr.co.daiso.bo.sm.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.bo.sm.mapper.oracle.AuthorityGrpMngUserMapper;
import kr.co.daiso.bo.sm.model.AuthorityGrpMngUserVO;
import kr.co.daiso.bo.sm.model.UserMngAuthGrpVO;
import kr.co.daiso.bo.sm.service.AuthorityGrpMngUserService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.XdbUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : AuthorityGrpMngUserImpl
 * author         : kjm
 * date           : 2021-12-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-15       kjm            최초생성
 */
@Service
public class AuthorityGrpMngUserServiceImpl implements AuthorityGrpMngUserService {

    @Autowired
    private AuthorityGrpMngUserMapper authorityGrpMngUserMapper;

    @Autowired
    private AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : searchUserList
     * author : kjm
     * description : 사용자 목록 조회
     *
     * @param authorityGrpMngUserVO
     * @return List<AuthorityGrpMngUserVO>
     */
    @Override
    public List<AuthorityGrpMngUserVO> searchUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return authorityGrpMngUserMapper.searchUserList(authorityGrpMngUserVO);
    }

    /**
     * methodName : searchUserDetail
     * author : kjm
     * description : 사용자 상세 조회
     *
     * @param authorityGrpMngUserVO
     * @return AuthorityGrpMngUserVO
     */
    @Override
    public AuthorityGrpMngUserVO searchUserDetail(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return authorityGrpMngUserMapper.searchUserDetail(authorityGrpMngUserVO);
    }

    /**
     * methodName : searchAuthGrp
     * author : kjm
     * description : 사용자 권한그룹 조회
     *
     * @param authorityGrpMngUserVO
     * @return List<AuthorityGrpMngUserVO>
     */
    @Override
    public List<AuthorityGrpMngUserVO> searchAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return authorityGrpMngUserMapper.searchAuthGrp(authorityGrpMngUserVO);
    }

    /**
     * methodName : signUpUser
     * author : kjm
     * description : 사용자 등록
     *
     * @param authorityGrpMngUserVO
     */
    @Override
    public void signUpUser(AuthorityGrpMngUserVO authorityGrpMngUserVO) throws CommonException {
        List<AuthorityGrpMngUserVO> duplicatedUserList = duplicatedUserList(authorityGrpMngUserVO);

        String userId = adminAccountInfoUtil.getUsrId();

        if(duplicatedUserList.size() != 0) {
            String message = "";
            AuthorityGrpMngUserVO targetUserVO = duplicatedUserList.get(0);
            if(targetUserVO.getUsrId().equals(authorityGrpMngUserVO.getUsrId())) message = "아이디";
            else if(targetUserVO.getUsrCd().equals(authorityGrpMngUserVO.getUsrCd())) message = "사번";
            else if(targetUserVO.getEmailAddr().equals(authorityGrpMngUserVO.getEmailAddr())) message = "이메일";
            else if(targetUserVO.getMpno().equals(authorityGrpMngUserVO.getMpno())) message = "휴대폰번호";
            throw new CommonException(message, HttpStatus.BAD_REQUEST); // << 등록 실패 메시지
        }
        else {

            authorityGrpMngUserVO.setRgpsId(userId);
            authorityGrpMngUserVO.setMdpsId(userId);

            authorityGrpMngUserVO.setPwd(XdbUtil.getHashEncryptSha256("11111"));
            authorityGrpMngUserMapper.signUpUser(authorityGrpMngUserVO);

            authorityGrpMngUserVO.setAuthGrntType("UC");
            authorityGrpMngUserVO.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));
            authorityGrpMngUserMapper.insertAuthGrpUserHist(authorityGrpMngUserVO);
        }
    }

    /**
     * methodName : modifyUser
     * author : kjm
     * description : 사용자 정보 수정
     *
     * @param authorityGrpMngUserVO
     */
    @Override
    public void modifyUser(AuthorityGrpMngUserVO authorityGrpMngUserVO) {

        List<AuthorityGrpMngUserVO> duplicatedUserList = duplicatedUserList(authorityGrpMngUserVO);

        String userId = adminAccountInfoUtil.getUsrId();

        if(duplicatedUserList.size() > 1) {
            String message = "";
            AuthorityGrpMngUserVO targetUserVO = duplicatedUserList.get(0);
            if(targetUserVO.getUsrId().equals(authorityGrpMngUserVO.getUsrId())) message = "아이디";
            else if(targetUserVO.getUsrCd().equals(authorityGrpMngUserVO.getUsrCd())) message = "사번";
            else if(targetUserVO.getEmailAddr().equals(authorityGrpMngUserVO.getEmailAddr())) message = "이메일";
            else if(targetUserVO.getMpno().equals(authorityGrpMngUserVO.getMpno())) message = "휴대폰번호";
            throw new CommonException(message, HttpStatus.BAD_REQUEST); // << 등록 실패 메시지
        }
        else {

            authorityGrpMngUserVO.setRgpsId(userId);
            authorityGrpMngUserVO.setMdpsId(userId);

            authorityGrpMngUserMapper.modifyUser(authorityGrpMngUserVO);

            authorityGrpMngUserVO.setAuthGrntType("UM");
            authorityGrpMngUserVO.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));
            authorityGrpMngUserMapper.insertAuthGrpUserHist(authorityGrpMngUserVO);
        }
    }

    /**
     * methodName : saveAuthGrp
     * author : kjm
     * description : 권한그룹 저장
     *
     * @param linkedHashMap
     */
    @Override
    public void saveAuthGrp(LinkedHashMap<String, Object> linkedHashMap) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<AuthorityGrpMngUserVO> createdRows = objectMapper.convertValue(linkedHashMap.get("createdRows"), new TypeReference<List<AuthorityGrpMngUserVO>>() {});
//        List<AuthorityGrpMngUserVO> updatedRows =  objectMapper.convertValue(linkedHashMap.get("updatedRows"), new TypeReference<List<AuthorityGrpMngUserVO>>() {});
        List<AuthorityGrpMngUserVO> deletedRows =  objectMapper.convertValue(linkedHashMap.get("deletedRows"), new TypeReference<List<AuthorityGrpMngUserVO>>() {});
        AuthorityGrpMngUserVO authorityGrpMngUserVO = objectMapper.convertValue(linkedHashMap.get("authorityGrpMngUserVO"), new TypeReference<AuthorityGrpMngUserVO>() {});


        String userId = adminAccountInfoUtil.getUsrId();
        authorityGrpMngUserVO.setRgpsId(userId);
        authorityGrpMngUserVO.setMdpsId(userId);

        deletedRows.forEach(deletedRow -> {
            authorityGrpMngUserVO.setAuthGrpCd(deletedRow.getAuthGrpCd());
            authorityGrpMngUserVO.setAuthGrntType("AD");
            authorityGrpMngUserVO.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));
            authorityGrpMngUserMapper.deleteAuthGrp(authorityGrpMngUserVO);
            authorityGrpMngUserMapper.insertAuthGrpUserHist(authorityGrpMngUserVO);
        });
        createdRows.forEach(createdRow -> {
            authorityGrpMngUserVO.setAuthGrpCd(createdRow.getAuthGrpCd());
            authorityGrpMngUserVO.setAuthGrntType("AC");
            authorityGrpMngUserVO.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));
            authorityGrpMngUserMapper.insertAuthGrp(authorityGrpMngUserVO);
            authorityGrpMngUserMapper.insertAuthGrpUserHist(authorityGrpMngUserVO);
        });

    }

    /**
     * methodName : isNewUser
     * author : kjm
     * description : 중복되는 정보를 가진 회원목록 조회
     *
     * @param authorityGrpMngUserVO
     * @return boolean
     */
    public List<AuthorityGrpMngUserVO> duplicatedUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return authorityGrpMngUserMapper.duplicatedUserList(authorityGrpMngUserVO);
    }
}
