package kr.co.daiso.bo.util;

import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.exception.ErrorResponse;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.model.ExceptionLogVO;
import kr.co.daiso.bo.common.service.LogService;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.mybatis.spring.MyBatisSystemException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.ContentCachingRequestWrapper;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : GlobalExceptionHandler
 * author         : leechangjoo
 * date           : 2021-11-09
 * description    :전역 Exception
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-11-09          leechangjoo         최초생성
 * 2022-01-10       Doo-Won Lee     Validation 체크시 Message 처리 추가
 *
 **/
@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @Autowired
    MessageSource messageSource;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    @Autowired
    LogService logService;

    @ExceptionHandler(value = { Exception.class })
    protected ResponseEntity handleCommonException(Exception e) {

        insertExceptionLog(e);

        if(e instanceof CommonException) {
            CommonException commonException = (CommonException) e;
            if (null!=commonException.getErrorCode()){
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode());
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getHttpStatus());
                log.error("handleCommonException throw CommonException : {}", commonException.getErrorCode().getDetail());
                return ErrorResponse.toResponseEntity(commonException.getErrorCode().getHttpStatus(), commonException.getErrorCode().getDetail());
            }
            else{
                return ErrorResponse.toResponseEntity(commonException.getStatus(), commonException.getMessage());
            }
        }else if(e instanceof NullPointerException){
            log.error("handleException throw NullPointerException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, e.toString());
        }else if(e instanceof NumberFormatException){
            log.error("handleException throw NumberFormatException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof IOException){
            log.error("handleException throw IOException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }else if(e instanceof ArithmeticException){
            log.error("handleException throw ArithmeticException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        } else if(e instanceof IllegalStateException){
            log.error("handleException throw IllegalStateException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }
        else if(e instanceof MyBatisSystemException){
            log.error("handleException throw MyBatisSystemException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }
        else if(e instanceof FileSizeLimitExceededException){
            log.error("handleException throw FileSizeLimitExceededException :");
            e.printStackTrace();
            return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
        }
        return ErrorResponse.toResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR,  e.getCause().toString());
    }

    /**
     * 에러 발생시 에러로그를 서버에 등록한다.
     * @param e
     */
    private void insertExceptionLog(Exception e){

        ExceptionLogVO exceptionLogVO = new ExceptionLogVO();

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

        String requestUrl = req.getRequestURI();
        String exceptionMsg = e.toString();
        if (StringUtils.isNotEmpty(exceptionMsg) && exceptionMsg.getBytes(StandardCharsets.UTF_8).length>600){
            try {
                exceptionMsg = new String(Arrays.copyOfRange(exceptionMsg.getBytes(), 0, 600), "UTF-8");
            } catch (UnsupportedEncodingException ex) {
                ex.printStackTrace();
            }
        }

        String reqStr= req.getParameterMap().entrySet().stream()
                                .map(entry -> {
                                    String entryStr =  entry.getKey()+"=";
                                    if (entry.getValue().length>1){
                                        entryStr += String.join(",",entry.getValue());
                                    }
                                    else{
                                        entryStr+=entry.getValue()[0];
                                    }
                                    return entryStr;
                                })
                                .collect(Collectors.toList())
                                .stream().collect(Collectors.joining("&"));

        String resquestBody = null;
        String className = null;
        String methodName = null;
        int lineNumber = 0;
        String fileName = null;

        final ContentCachingRequestWrapper cachingRequest = (ContentCachingRequestWrapper) req;
        if (cachingRequest.getContentType() != null && cachingRequest.getContentType().contains("application/json")) {
            if (cachingRequest.getContentAsByteArray() != null && cachingRequest.getContentAsByteArray().length != 0){
                resquestBody = new String(cachingRequest.getContentAsByteArray());
            }
        }

        if (null==resquestBody) resquestBody = new String();
        String firstComma = (resquestBody.length()>0) ? ", " : "";
        resquestBody = resquestBody + firstComma + "tokenId:"+adminAccountInfoUtil.getloginId()+", tokenName:"+ adminAccountInfoUtil.getUsrNm();

        StackTraceElement[] stackTraces = e.getStackTrace();
        if (ArrayUtils.isNotEmpty(stackTraces)) {
            StackTraceElement stackTraceElement = stackTraces[0];

            className = stackTraceElement.getClassName();
            methodName = stackTraceElement.getMethodName();
            lineNumber = stackTraceElement.getLineNumber();
            fileName = stackTraceElement.getFileName();
        }

        exceptionLogVO.setRqstUrl(requestUrl);
        exceptionLogVO.setRqstParam(reqStr);
        exceptionLogVO.setCmdData(resquestBody);
        exceptionLogVO.setExcpNm(exceptionMsg);
        exceptionLogVO.setFileNm(fileName);
        exceptionLogVO.setMethodNm(methodName);
        exceptionLogVO.setClassNm(className);
        exceptionLogVO.setLineNbr(lineNumber);

        logService.regExceptionLog(exceptionLogVO);

    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers
                                                                , HttpStatus status, WebRequest request) {

//        log.error("what: {}",messageSource.getMessage("common.valid.lengthRange",new String[]{"Test","1","2"},Locale.KOREA));
        CommonResponseModel errorResponseModel = new CommonResponseModel();
        List<ObjectError> allErrors = ex.getBindingResult().getAllErrors();
        if (allErrors.size()>0){
            ObjectError error = allErrors.get(0);

//        for (ObjectError error : allErrors) {
//            log.error("error: {}", error);
//            // 코드 정보를 확인할 수 있다.
//            log.error("error arguments: {}",  Arrays.toString(error.getArguments()));
//            log.error("error arguments size: {}",error.getArguments().length);
//            log.error("error: {}", Arrays.toString(error.getCodes()));

            String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
                    .map(c -> {
                        Object[] arguments = error.getArguments();
                        Locale locale = LocaleContextHolder.getLocale();
                        try {
//                            log.error("error arguments: {}", Arrays.toString(arguments));
//                            log.error("error e.getDefaultMessage(): {}", error.getDefaultMessage());
                            return messageSource.getMessage(error.getDefaultMessage(), arguments, locale);
                        } catch (NoSuchMessageException ne) {
//                            log.error("NoSuchMessageException: {}", ne);
                            return null;
                        }
                    }).filter(Objects::nonNull)
                    .findFirst()
                    // 코드를 찾지 못할 경우 기본 메시지 사용.
                    .orElse(error.getDefaultMessage());

            log.error("error message: {}", message);

            errorResponseModel.setData( ErrorResponse.toResponseEntity(HttpStatus.BAD_REQUEST,message));
//            break;
        }
        return new ResponseEntity<Object>(errorResponseModel,HttpStatus.OK);

    }
}