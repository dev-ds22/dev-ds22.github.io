package kr.co.daiso.bo.mb.model;

import kr.co.daiso.common.annotation.MaskingField;
import kr.co.daiso.common.model.CommonPagingVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.mb.model
 * fileName       : MemberStaDTO
 * author         : bsj
 * date           : 2022-01-14
 * description    : 회원통계화면 DTO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14       bsj           최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MemberStaDTO extends CommonPagingVo {

    /* 유형별회원 */
    @ApiModelProperty(value = "가입채널명", notes = "가입채널명", example = "직영몰")
    private String joinChnlNm;
    @ApiModelProperty(value = "가입채널", example = "C010")
    private String joinChnl;
    @ApiModelProperty(value = "가입자수")
    private int cnt;

    /* 상태별(가입/탈퇴/휴면) 회원수 */
    @ApiModelProperty(value = "총가입회원")
    private int regCnt;
    @ApiModelProperty(value = "총탈퇴회원")
    private int wtdrCnt;
    @ApiModelProperty(value = "총휴면회원")
    private int dormCnt;

    /* 일자별/월별 회원 */
    @ApiModelProperty(value = "기준일자")
    private String stndDate;
    @ApiModelProperty(value = "직영몰 가입자수")
    private int mallRegCnt;
    @ApiModelProperty(value = "직영몰 탈퇴자수")
    private int mallWtdrCnt;
    @ApiModelProperty(value = "모바일 가입자수")
    private int mblRegCnt;
    @ApiModelProperty(value = "모바일 탈퇴자수")
    private int mblWtdrCnt;

    /* 기간별 회원통계 조회조건 */
//    @ApiModelProperty(value = "채널목록")
//    private List<String> joinChnlList;
    @ApiModelProperty(value = "시작일", example = "20211019")
    private String startDttm;
    @ApiModelProperty(value = "종료일", example = "20211020")
    private String endDttm;

    /* 기간별 회원 조회결과 */
    @ApiModelProperty(value = "일자", example = "20211020")
    private String dttm;
    @ApiModelProperty(value = "PC 가입자수")
    private String regCntPC;
    @ApiModelProperty(value = "MOBILE 가입자수")
    private String regCntMO;
    @ApiModelProperty(value = "APP 가입자수")
    private String regCntApp;
    @ApiModelProperty(value = "PC 탈퇴자수")
    private String wtdrCntPC;
    @ApiModelProperty(value = "MOBILE 탈퇴자수")
    private String wtdrCntMO;
    @ApiModelProperty(value = "APP 탈퇴자수")
    private String wtdrCntApp;

}
