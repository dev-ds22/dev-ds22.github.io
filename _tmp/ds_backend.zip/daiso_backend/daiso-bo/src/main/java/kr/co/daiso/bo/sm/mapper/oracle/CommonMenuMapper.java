package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.sm.model.MenuVO;
import org.mybatis.spring.annotation.MapperScan;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.menu.mapper.oracle
 * fileName       : MenuMapper
 * author         : kjm
 * date           : 2021-12-08
 * description    : 메뉴관리 관련 기능
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       kjm            최초생성3
 */

@MapperScan
public interface CommonMenuMapper {

    // 메뉴 목록 조회
    List<MenuVO> getMenuList(MenuVO menuVO);

    // 메뉴 목록 개수 조회
    int getMenuListCount(MenuVO menuVO);

    // 메뉴 상세 조회
    MenuVO getMenuDetail(MenuVO menuVO);

    // 메뉴 정보 추가, 변경
    void updateMenu(MenuVO menuVO);

    // 페이지
    void updatePage(MenuVO menuVO);

    // 메뉴 구조 변경
    void updateMenuTree(MenuVO menuVO);

    // 자식 메뉴 체크
    int childMenuCheck(MenuVO menuVO);

    // 메뉴 권한그룹 목록조회
    List<AuthGrpAdmVO> getMenuAuthGrpList(MenuVO menuVO);

    // 메뉴 목록 조회(권한 포함)
    List<MenuVO> getMenuAndAuthList();
}
