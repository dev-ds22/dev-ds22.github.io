package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.bo.sm.mapper.oracle.CommonCodeManageMapper;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.RedisUtil;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : CommonCodeManageServiceImpl
 * author         : Doo-Won Lee
 * date           : 2021-12-01
 * description    : 공통코드 관리 서비스 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-01       Doo-Won Lee        최초생성
 */
@Service
public class CommonCodeManageServiceImpl implements CommonCodeManageService {

    @Autowired
    CommonCodeManageMapper commonCodeManageMapper;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;
    /**
     * methodName : getMstCodeListCount
     * author : Doo-Won Lee
     * description : 마스터 코드의 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int getMstCodeListCount(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getMstCodeListCount(searchVo);
    }

    /**
     * methodName : getMstCodeList
     * author : Doo-Won Lee
     * description : 마스터 코드의 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonCodeManageVo>
     */
    @Override
    public List<CommonCodeManageVO> getMstCodeList(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getMstCodeList(searchVo);
    }

    /**
     * methodName : getSubCodeListCount
     * author : Doo-Won Lee
     * description : 서브 코드의 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int getSubCodeListCount(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getSubCodeListCount(searchVo);
    }

    /**
     * methodName : getSubCodeList
     * author : Doo-Won Lee
     * description : 서브 코드의 목록을 구한다
     *
     * @param searchVo
     * @return List<CommonCodeManageVo>
     */
    @Override
    public List<CommonCodeManageVO> getSubCodeList(CommonCodeSearchVO searchVo) {
        return commonCodeManageMapper.getSubCodeList(searchVo);
    }

    /**
     * methodName : getSubCodeList
     * author : Doo-Won Lee
     * description : 서브 코드의 중 관리자접속 가능 IP목록을 Redis에 저장한다.
     */
    @Override
    public void setAdminIpListToRedis() {
        CommonCodeSearchVO commonCodeSearchVo = new CommonCodeSearchVO();
        commonCodeSearchVo.setSMstCode("CONN_PSB_IP");
        commonCodeSearchVo.setUseYn("Y");
        commonCodeSearchVo.setDelYn("N");
        List<CommonCodeManageVO> psbIpList = getSubCodeList(commonCodeSearchVo);
        String psbIpListStr = null;
        if (psbIpList.size()>0) {
            psbIpListStr = psbIpList.stream()
                                    .map(CommonCodeManageVO::getSubCd)
                                    .collect(Collectors.joining(","));
        }
        redisUtil.setData(CommonConstants.REDIS_KEY_ADMIN_IP_LIST, psbIpListStr);
    }

    /**
     * methodName : saveMasterCodeList
     * author : Doo-Won Lee
     * description : 그룹코드를 저장 & 수정한다
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public CommonResponseModel saveMasterCodeList(List<CommonCodeManageVO> createRows, List<CommonCodeManageVO> updateRows) {
        String usrId = adminAccountInfoUtil.getUsrId();
        boolean ucmsCheck = false;
        for(CommonCodeManageVO insertVO : createRows){
            insertVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            insertVO.setRgpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            if ("Y".equals(insertVO.getUcmsCdYn())){
                ucmsCheck = true;
            }
        }

        for(CommonCodeManageVO updateVO : updateRows) {
            updateVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            if ("Y".equals(updateVO.getUcmsCdYn())){
                ucmsCheck = true;
            }
        }

        if (ucmsCheck){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("UCMS");
            failResultModel.setReturnCode("400");
            return failResultModel;
        }

        try {
            if (createRows.size() > 0)
                commonCodeManageMapper.insertMasterCode(createRows);
            if (updateRows.size() > 0)
                commonCodeManageMapper.updateMasterCode(updateRows);
        }catch(DuplicateKeyException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("DUP");
            failResultModel.setReturnCode("400");
            return failResultModel;
        }
        return new CommonResponseModel();
    }

    /**
     * methodName : saveMasterCodeList
     * author : Doo-Won Lee
     * description : 서브코드를 저장 & 수정한다
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public CommonResponseModel saveSubCodeList(List<CommonCodeManageVO> createRows, List<CommonCodeManageVO> updateRows) {
        String usrId = adminAccountInfoUtil.getUsrId();
        boolean ucmsCheck = false;
        for(CommonCodeManageVO insertVO : createRows){
            insertVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            insertVO.setRgpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            if ("Y".equals(insertVO.getUcmsCdYn())){
                ucmsCheck = true;
            }
        }

        for(CommonCodeManageVO updateVO : updateRows) {
            updateVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
            if ("Y".equals(updateVO.getUcmsCdYn())){
                ucmsCheck = true;
            }
        }

        if (ucmsCheck){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("UCMS");
            failResultModel.setReturnCode("400");
            return failResultModel;
        }

        try {
            if (createRows.size() > 0)
                commonCodeManageMapper.insertSubCode(createRows);
            if (updateRows.size() > 0)
                commonCodeManageMapper.updateSubCode(updateRows);
        }catch(DuplicateKeyException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("DUP");
            failResultModel.setReturnCode("400");
            return failResultModel;
        }
        return new CommonResponseModel();
    }
}
