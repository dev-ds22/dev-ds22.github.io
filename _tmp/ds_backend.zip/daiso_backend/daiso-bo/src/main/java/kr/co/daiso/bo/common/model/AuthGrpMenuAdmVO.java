package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AuthGrpMenuAdmVO
 * author         : leechangjoo
 * date           : 2021-12-22
 * description    : 권한그룹메뉴관리 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-22          leechangjoo         최초생성
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class AuthGrpMenuAdmVO extends BaseModel {

    private String tcmMenuId;			/*메뉴테이블 메뉴ID*/
    private String tcmMenuNm;			/*메뉴테이블 메뉴명*/
    private String tcmMenuLevl;		    /*메뉴테이블 메뉴레벨*/
    private String tcmHrnkMenuId;	    /*메뉴테이블 상위메뉴ID*/
    private String tcmSortOrdr;		    /*메뉴테이블 정렬순서*/
    private String tcmUseYn;			/*메뉴테이블 사용여부*/
    private String tcmExprYn;			/*메뉴테이블 표시여부*/
    private String tcagmAuthGrpCd;	    /*권한그룹메뉴테이블 권한그룹코드*/
    private String tcagsScrnId;		    /*권한그룹화면테이블 화면ID*/
    private String tcagsIqyBtnUseYn;	/*권한그룹화면테이블 조회버튼사용여부*/
    private String tcagsInitBtnUseYn;   /*권한그룹화면테이블 초기화버튼사용여부*/
    private String tcagsNewBtnUseYn;	/*권한그룹화면테이블 신규버튼사용여부*/
    private String tcagsStrgBtnUseYn;   /*권한그룹화면테이블 저장버튼사용여부*/
    private String tcagsDelBtnUseYn;    /*권한그룹화면테이블 삭제버튼사용여부*/
    private String tcagsDnldBtnUseYn;   /*권한그룹화면테이블 다운로드버튼사용여부*/
    private String tcsScrnId;			/*화면테이블 화면ID*/
    private String tcsScrnNm;			/*화면테이블 화면명*/
    private String tcsIqyBtnUseYn;	    /*화면테이블 조회버튼사용여부*/
    private String tcsInitBtnUseYn;	    /*화면테이블 초기화버튼사용여부*/
    private String tcsNewBtnUseYn;	    /*화면테이블 신규버튼사용여부*/
    private String tcsStrgBtnUseYn;	    /*화면테이블 저장버튼사용여부*/
    private String tcsDelBtnUseYn;	    /*화면테이블 삭제버튼사용여부*/
    private String tcsDnldBtnUseYn;	    /*화면테이블 다운로드버튼사용여부*/
    
    // 조회용
    private String authGrpCd;           /*권한그룹코드*/

}
