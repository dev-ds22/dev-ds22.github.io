package kr.co.daiso.bo.sample.service.impl;

import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.common.util.ExcelUtil;
import kr.co.daiso.bo.auth.JwtTokenProvider;
import kr.co.daiso.bo.sample.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@Slf4j
@Service
public class SampleServiceImpl implements SampleService {

    @Autowired
    JwtTokenProvider loginTokenProvider;

    @Autowired
    PasswordEncoder passwordEncoder;

    CookieUtil cookieUtil = new CookieUtil();

    ExcelUtil excelUtil = new ExcelUtil();

    @Override
    public void excelUtilTest(MultipartFile file, HttpServletRequest req) throws IOException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
//        List<SampleExcelUploadModel> list = excelUtil.makeDataFromExcelFile(file, req, SampleExcelUploadModel.class,2, CommonPathInfo.UPLOAD_ROOT);

//        ExcelConversionResultVO<TableMgtExcelUploadVO> resultVO = excelUtil.makeResultDataFromExcelFile(file, req, TableMgtExcelUploadVO.class,1, CommonPathInfo.UPLOAD_ROOT);
//        resultVO.getSuccessList().stream().map(model -> model.getNO())
//                .forEach(log::info);
//        resultVO.getFailList().stream().map(model -> model.getRowIdx()+":"+model.getExceptionMsg())
//                .forEach(log::info);
//        list.stream().map(model -> model.getName())
//                .forEach(log::info);
    }

//    @Override
//    public void fileUploadTest(MultipartFile file,  String path)  throws IOException{
////        File[] root = File.listRoots();
////        String realPath = root[0].getAbsolutePath()+path;
//        File folder = new File(path);
//        if (!folder.exists()) {
//            folder.mkdirs();
//        }
//        file.transferTo(new File(folder.getAbsolutePath(), file.getOriginalFilename()));
//    }
}


