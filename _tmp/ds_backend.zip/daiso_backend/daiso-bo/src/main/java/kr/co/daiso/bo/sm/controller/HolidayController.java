package kr.co.daiso.bo.sm.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.model.CalendarVo;
import kr.co.daiso.bo.sm.model.HolidayVo;
import kr.co.daiso.bo.sm.service.HolidayService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : HolidayController
 * author         : Injung,Kim
 * date           : 2022-01-13
 * description    : 직영점 휴일 관리 컨트롤러
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13     Injung,Kim      최초생성
 */

@RequestMapping("/sysmg/baseInfo/holiday")
@RestController
public class HolidayController {

    @Autowired
    HolidayService holidayService;

    @GetMapping("/calendar_list")
    @ApiOperation("저장된 달력 정보 가져오기")
    public ResponseEntity<CommonResponseModel> getStoredcalendar(@ApiParam("선택한 연도,직영점 코드") HolidayVo holidayVo){
        CommonResponseModel resultModel = new CommonResponseModel<>();
        resultModel = holidayService.getStoredcalendar(holidayVo);

//        System.out.println(calendarList);
        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
    }

    @GetMapping("/calendar_ucms")
    @ApiOperation("UCMS 달력마스터에서 달력 복사 후 조회하기")
    public ResponseEntity<CommonResponseModel> getcalendarFromUCMS(@ApiParam("선택한 연도,직영점 코드") HolidayVo holidayVo){
        CommonResponseModel resultModel= null;

        //UCMS 달력 데이터 가져오기
        List<CalendarVo> calendarMaster = holidayService.getUCMScalendarByYear(holidayVo);
        //달력 데이터 복사 후 리스트 조회
        if (calendarMaster.size() > 0) {
            int result = holidayService.saveNewCalendarByCntr(calendarMaster, holidayVo);
            if(result > 0){
                resultModel = new CommonResponseModel();
            }else{
                resultModel = new CommonResponseModel();
                resultModel.setSuccess(false);
                resultModel.setMessage("중복");
            }
        }
        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
    }

    @PostMapping("/calendar_holidays")
    @ApiOperation("변경된 휴일 목록 저장하기")
    public ResponseEntity<CommonResponseModel> saveUpdatedCalendar(@ApiParam("변경한 휴일 정보")@RequestBody LinkedHashMap<String,Object> holidayVo){
        ObjectMapper mapper = new ObjectMapper();

        //VO 데이터만 parsing
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<HolidayVo> updatedList = mapper.convertValue(holidayVo.get("updatedRows"), new TypeReference<List<HolidayVo>>() {
        });

        CommonResponseModel resultModel = holidayService.updateHolidays(updatedList);
        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);
    }

}
