package kr.co.daiso.bo.mb.model;

import kr.co.daiso.common.model.CommonPagingVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.mb.model
 * fileName       : MembAddInfoDTO
 * author         : bsj
 * date           : 2022-01-21
 * description    : 회원관리상세 부가정보 DTO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-21       bsj           최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MembAddInfoDTO extends TbMbMembBasVO {

    @ApiModelProperty(value = "거주지역명", example = "서울")
    private String usrRgnNm;

    @ApiModelProperty(value = "제조사명", notes = "관심차량 제조사명", example = "현대")
    private String mnuftrNm;

    @ApiModelProperty(value = "모델그룹명", notes = "관심차량 모델그룹명", example = "쏘나타")
    private String modelGrpNm;

    @ApiModelProperty(value = "상세모델명", notes = "관심차량 상세모델명", example = "LF 쏘나타")
    private String modelNm;

}
