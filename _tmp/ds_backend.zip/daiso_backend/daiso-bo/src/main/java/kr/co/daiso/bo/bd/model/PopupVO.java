package kr.co.daiso.bo.bd.model;

import kr.co.daiso.common.model.BaseModel;
import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.bd.model
 * fileName       : PopupVO
 * author         : kjm
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PopupVO extends CommonPagingVo {
    private String ppupCd;      // 팝업코드
    private String ppupDcd;     // 팝업구분코드
    private String ppupNm;      // 팝업명

    private String pcStrtDt;    // PC 시작일자
    private String pcEndDt;     // PC 종료일자
    private String pcSortSq;    // PC 정렬순번

    private String mblStrtDt;   // 모바일 시작일자
    private String mblEndDt;    // 모바일 종료일자
    private String mblSortSq;   // 모바일 정렬순번

    private String ppupUseYn;   // 팝업 사용여부
    private String pcPpupUseYn; // pc 팝업 활성화 여부 (날짜)
    private String moPpupUseYn; // mo 팝업 활성화 여부 (날짜)

    private String periodKey;       // 날짜 검색 기준 (시작일 or 종료일)
    private String searchStrtDt;    // 검색 시작일
    private String searchEndDt;     // 검색 종료일

}
