package kr.co.daiso.bo.sm.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import kr.co.daiso.common.model.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * packageName    : kr.co.daiso.bo.sm.model
 * fileName       : CalendarVo
 * author         : Injung, Kim
 * date           : 2021-12-20
 * description    : 휴일관리 테이블 VO(UCMS 달력)
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-20       Injung, Kim        최초생성
 */
@Data
@ApiModel(description = "UCMS 달력 VO")
public class CalendarVo extends BaseModel {
    @ApiModelProperty(value="달력일자")
    private String cldrDt;
    @ApiModelProperty(value="요일명")
    private String dowNm;
    @ApiModelProperty(value="요일코드")
    private int dowCd;
    @ApiModelProperty(value="휴일여부")
    private String hldyYn;
    @ApiModelProperty(value="휴일명")
    private String hldyNm;
}
