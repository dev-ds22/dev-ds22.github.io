package kr.co.daiso.bo.login.model;

import kr.co.daiso.common.annotation.MaskingClass;
import kr.co.daiso.common.annotation.MaskingField;
import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.login.model
 * fileName       : ExcWorktimeLogVO
 * author         : Doo-Won Lee
 * date           : 2022-01-18
 * description    : 업무시간외 사용이력 모델
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-18      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class ExcWorktimeLogVO extends CommonPagingVo {

    private String usrId;   //사용자ID
    private String usrNm;  //사용자명
    private String rsn;     //사유
    private String acesIp;  //접근IP
    private String deptNm;  //부서명

}
