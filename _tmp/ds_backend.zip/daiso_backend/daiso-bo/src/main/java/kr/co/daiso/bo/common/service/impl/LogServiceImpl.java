package kr.co.daiso.bo.common.service.impl;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.bo.common.mapper.oracle.LogMapper;
import kr.co.daiso.bo.common.model.*;
import kr.co.daiso.bo.common.service.LogService;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.AdminCmnUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.service.impl
 * fileName       : LogServiceImpl
 * author         : Doo-Won Lee
 * date           : 2022-01-18
 * description    : 관리자에서 로그를 처리하는 서비스의 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-18     Doo-Won Lee      최초생성
 */
@Slf4j
@Service
public class LogServiceImpl implements LogService {

    @Autowired
    AdminCmnUtil adminCmnUtil;

    @Autowired
    LogMapper logMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : regAdminCnntnLog
     * author : Doo-Won Lee
     * description : 관리자 접속 로그를 등록한다.
     *
     * @param vo
     * @param response
     * @return ResponseEntity<CommonResponseModel>
     */
    @Override
    public ResponseEntity<CommonResponseModel> regAdminCnntnLog(AdminCnntnLogVO vo, HttpServletRequest request, HttpServletResponse response) {
//        adminCmnUtil.insertAdminLog(vo,request);
        CommonResponseModel responseModel = new CommonResponseModel();
        responseModel.setSuccess(adminCmnUtil.insertAdminLog(vo,request));

        return new ResponseEntity<CommonResponseModel>(responseModel, HttpStatus.OK);
    }

    /**
     * methodName : getOutTimeConnLogCnt
     * author : Doo-Won Lee
     * description : 관리자 시간외 접속 로그의 카운트를 구한다..
     *
     * @param searchVO
     * @return int
     */
    @Override
    public int getOutTimeConnLogCnt(OutTimeLogSearchVO searchVO) {
        return logMapper.getOutTimeConnLogCnt(searchVO);
    }

    /**
     * methodName : getOutTimeConnLogCnt
     * author : Doo-Won Lee
     * description : 관리자 시간외 접속 로그를 구한다..
     *
     * @param searchVO
     * @return List<ExcWorktimeLogVO>
     */
    @Override
    public List<ExcWorktimeLogVO> getOutTimeConnLog(OutTimeLogSearchVO searchVO) {
        return logMapper.getOutTimeConnLog(searchVO);
    }

    /**
     * methodName : getOutTimeConnLogCnt
     * author : Doo-Won Lee
     * description : 관리자 권한 그룹 목록을 조회한다.
     *
     * @return List<AuthGrpAdmVO>
     */
    @Override
    public List<AuthGrpAdmVO> getAdminAuthGrpList(){
        return logMapper.getAdminAuthGrpList();
    }

    /**
     * methodName : getAdminCnntnLogCnt
     * author : Doo-Won Lee
     * description : 관리자 접속 로그 카운트를 조회한다.
     *
     * @param  adminCnntnLogSearchVO
     * @return List<AdminCnntnLogVO>
     */
    @Override
    public int getAdminCnntnLogCnt(AdminCnntnLogSearchVO adminCnntnLogSearchVO){
        return logMapper.getAdminCnntnLogCnt(adminCnntnLogSearchVO);
    }

    /**
     * methodName : getAdminCnntnLog
     * author : Doo-Won Lee
     * description : 관리자 접속 로그를 조회한다.
     *
     * @param  adminCnntnLogSearchVO
     * @return List<AdminCnntnLogVO>
     */
    @Override
    public List<AdminCnntnLogVO> getAdminCnntnLog(AdminCnntnLogSearchVO adminCnntnLogSearchVO){
        return logMapper.getAdminCnntnLog(adminCnntnLogSearchVO);
    }

    /**
     * methodName : getAdminCnntnLogCnt
     * author : Doo-Won Lee
     * description : 사용자 이력 카운트를 조회한다.
     *
     * @param  adminUserHistorySearchVO
     * @return List<AdminCnntnLogVO>
     */
    @Override
    public int getAdminUserHistoryCnt(AdminUserHistorySearchVO adminUserHistorySearchVO){
        return logMapper.getAdminUserHistoryCnt(adminUserHistorySearchVO);
    }

    /**
     * methodName : getAdminCnntnLog
     * author : Doo-Won Lee
     * description : 사용자 이력을 조회한다.
     *
     * @param  adminUserHistorySearchVO
     * @return List<AdminCnntnLogVO>
     */
    @Override
    public List<AdminUserHistoryVO> getAdminUserHistory(AdminUserHistorySearchVO adminUserHistorySearchVO){
        return logMapper.getAdminUserHistory(adminUserHistorySearchVO);
    }

    /**
     * methodName : regExceptionLog
     * author : Doo-Won Lee
     * description : Exception 로그를 등록한다.
     *
     * @param  exceptionLogVO
     * @return int
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int regExceptionLog(ExceptionLogVO exceptionLogVO) {
        exceptionLogVO.setRgpsId(adminAccountInfoUtil.getUsrId());
        exceptionLogVO.setMdpsId(adminAccountInfoUtil.getId());
        return logMapper.regExceptionLog(exceptionLogVO);
    }

    /**
     * methodName : getExceptionLog
     * author : Byung-chul Park
     * description : Exception 로그를 조회한다.
     *
     * @param  exceptionLogSearchVO
     * @return List<ExceptionLogVO>
     */
    @Override
    public List<ExceptionLogVO> getExceptionLog(ExceptionLogSearchVO exceptionLogSearchVO){
        return logMapper.getExceptionLog(exceptionLogSearchVO);
    }

    /**
     * methodName : getExceptionLogCnt
     * author : Byung-chul Park
     * description : Exception 로그카운트를 조회한다.
     *
     * @param  exceptionLogSearchVO
     * @return List<ExceptionLogVO>
     */
    @Override
    public int getExceptionLogCnt(ExceptionLogSearchVO exceptionLogSearchVO) {
        return logMapper.getExceptionLogCnt(exceptionLogSearchVO);
    }
    /**
     * methodName : regDownloadRsn
     * author : Byung-chul Park
     * description : 다운로드 사유를 등록한다.
     *
     * @param  request,dnldAtclNm,dnldAtclDtl,cnt
     * @return List<downLoadRsnVO>
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int regDownloadRsn(HttpServletRequest request, String dnldAtclNm, String dnldAtclDtl, int cnt) {
        DownloadRsnVO downloadRsnVO = new DownloadRsnVO();

        String encodingValue = new String(URLDecoder.decode(request.getParameter("dnldRsn")));
        log.info("encodingValue >>", encodingValue);
//        downloadRsnVO.setDnldRsn(request.getParameter("dnldRsn"));
        downloadRsnVO.setDnldRsn(encodingValue);
        downloadRsnVO.setUsrId(adminAccountInfoUtil.getUsrId());
        downloadRsnVO.setUsrNm(adminAccountInfoUtil.getUsrNm());
        downloadRsnVO.setRqstUrl(request.getRequestURI());
        downloadRsnVO.setAcesIp(CommonUtil.getClientIp(request));
        downloadRsnVO.setDnldAtclNm(dnldAtclNm);
        downloadRsnVO.setDnldAtclDtl(dnldAtclDtl);
        downloadRsnVO.setDnldCnt(String.valueOf(cnt));
        downloadRsnVO.setAdminYn("Y");
        downloadRsnVO.setRgpsId(adminAccountInfoUtil.getUsrId());
        downloadRsnVO.setMdpsId(adminAccountInfoUtil.getUsrId());

        return logMapper.regDownloadRsn(downloadRsnVO);
    }
    /**
     * methodName : getDownloadRsn
     * author : Byung-chul Park
     * description : 다운로드 사유를 조회한다.
     *
     * @param  downloadRsnSearchVO
     * @return List<downLoadRsnVO>
     */

    @Override
    public List<DownloadRsnVO> getDownloadRsn(DownloadRsnSearchVO downloadRsnSearchVO) {
        return logMapper.getDownloadRsn(downloadRsnSearchVO);
    }

    /**
     * methodName : getDownloadRsnCnt
     * author : Byung-chul Park
     * description : 다운로드 사유 카운트를 조회한다.
     *
     * @param  downloadRsnSearchVO
     * @return List<ExceptionLogVO>
     */
    @Override
    public int getDownloadRsnCnt(DownloadRsnSearchVO downloadRsnSearchVO) {
        return logMapper.getDownloadRsnCnt(downloadRsnSearchVO);
    }

    /**
     * methodName : regExceptionLog
     * author : Doo-Won Lee
     * description : E-mail 로그를 등록한다.
     *
     * @param  mailSendLogVO
     * @return int
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int insertStaMailLog(MailSendLogVO mailSendLogVO) {
        return logMapper.insertStaMailLog(mailSendLogVO);
    }

    /**
     * methodName : getBatchLogCount
     * author : Doo-Won Lee
     * description : 배치의 로그 갯수를 구한다.
     *
     * @param  searchVO
     * @return int
     */
    @Override
    public int getBatchLogCount(BatchLogSearchVO searchVO) {
        return logMapper.getBatchLogCount(searchVO);
    }

    /**
     * methodName : getBatchLogList
     * author : Doo-Won Lee
     * description : 배치의 로그 목록을 조회한다.
     *
     * @param  searchVO
     * @return List<BatchLogVO>
     */
    @Override
    public List<BatchLogVO> getBatchLogList(BatchLogSearchVO searchVO) { return logMapper.getBatchLogList(searchVO); }

    /**
     * methodName : getMailSendLogCount
     * author : Doo-Won Lee
     * description : Mail 전송 내역 카운트를 조회한다.
     *
     * @param  searchVO
     * @return int
     */
    @Override
    public int getMailSendLogCount(MailLogSearchVO searchVO) { return logMapper.getMailSendLogCount(searchVO); }

    /**
     * methodName : getMailSendLogList
     * author : Doo-Won Lee
     * description : Mail 전송 내역을 조회한다.
     *
     * @param  searchVO
     * @return int
     */
    @Override
    public List<MailSendLogVO> getMailSendLogList(MailLogSearchVO searchVO) { return logMapper.getMailSendLogList(searchVO); }


}
