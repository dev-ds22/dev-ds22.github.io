package kr.co.daiso.bo.mb.mapper.oracle;

import kr.co.daiso.bo.mb.model.MembAddInfoDTO;
import kr.co.daiso.bo.mb.model.MemberStaDTO;
import kr.co.daiso.bo.mb.model.TbMbMembBasVO;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.mb.mapper.oracle
 * fileName       : MembMgtMapper
 * author         : bsj
 * date           : 2022-01-11
 * description    : 회원관리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       bsj            최초생성
 */

@Mapper
public interface MembMgtMapper {

    // 회원목록 조회
    List<TbMbMembBasVO> getMemberList(TbMbMembBasVO vo);
    // 회원목록 Total
    int getMemberListTotalCount(TbMbMembBasVO vo);

    // 회원상세 기본정보 조회
    TbMbMembBasVO getMemberDetlInfo(TbMbMembBasVO vo);

    // 회원상세 부가정보 조회
    List<MembAddInfoDTO> getMemberDetlAddInfo(TbMbMembBasVO vo);

    // 회원 비밀번호 초기화
    int updateMemberPwdReset(TbMbMembBasVO vo);

    // 유형별 회원통계 조회
    List<MemberStaDTO> getMemberStaByType();

    // 상태별(가입/탈퇴/휴면) 회원통계 조회
    MemberStaDTO getMemberStaByStus();

    // 일자별 회원통계 조회
    List<MemberStaDTO> getMemberStaByDate();

    // 월별 회원통계 조회
    List<MemberStaDTO> getMemberStaByMonth();

    // 가입채널 서브코드 조회
    List<CommonCodeManageVO> getCmSubCodeList(Map<String, Object> map);

    // 기간별 회원통계 조회
    List<MemberStaDTO> getMemberStaByPerd(MemberStaDTO dto);

    // 기간,일자,가입채널별 회원통계목록 총건수 조회
    int getMemberStaByDttmTotalCount(MemberStaDTO dto);

    // 기간,일자,가입채널별 회원통계목록 조회
    List<MemberStaDTO> getMemberStaByDttm(MemberStaDTO dto);

    // 대시보드 일자별 회원통계 조회
    List<MemberStaDTO> getDashMemberStaByDate();

    // 대시보드 월별 회원통계 조회
    List<MemberStaDTO> getDashMemberStaByMonth();

}
