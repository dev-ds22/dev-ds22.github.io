package kr.co.daiso.bo.message.mapper.oracle;

import kr.co.daiso.bo.message.model.SmsVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * packageName    : kr.co.daiso.bo.message.mapper.oracle
 * fileName       : SmsMapper
 * author         : kjm
 * date           : 2022-01-04
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-04       kjm            최초생성
 */
@Mapper
public interface SmsMapper {
    void insertSmsQueue(SmsVO smsVO);

    void insertSmsMyDb(SmsVO smsVO);
}
