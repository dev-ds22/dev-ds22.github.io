package kr.co.daiso.bo.mb.service;

import kr.co.daiso.bo.mb.model.MembAddInfoDTO;
import kr.co.daiso.bo.mb.model.MemberStaDTO;
import kr.co.daiso.bo.mb.model.TbMbMembBasVO;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import io.swagger.annotations.ApiParam;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.mb.service
 * fileName       : MemberMgtService
 * author         : bsj
 * date           : 2022-01-11
 * description    : 관리자의 회원관리 서비스 인터페이스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       bsj            최초생성
 */
public interface MembMgtService {

    // 회원목록 조회
    Map<String, Object> getMemberList(TbMbMembBasVO vo);

    // 회원상세 기본정보 조회
    TbMbMembBasVO getMemberDetlInfo(TbMbMembBasVO vo);

    // 회원상세 부가정보 조회
    List<MembAddInfoDTO> getMemberDetlAddInfo(TbMbMembBasVO vo);

    // 회원 비밀번호 초기화
    int updateMemberPwdReset(TbMbMembBasVO vo);

    // 유형별 회원통계 조회
    List<MemberStaDTO> getMemberStaByType();

    // 상태별(가입/탈퇴/휴면) 회원통계 조회
    MemberStaDTO getMemberStaByStus();

    // 일자별 회원통계 조회
    List<MemberStaDTO> getMemberStaByDate();

    // 월별 회원통계 조회
    List<MemberStaDTO> getMemberStaByMonth();

    // 가입채널 서브코드 조회
    List<CommonCodeManageVO> getCmSubCodeList();

    // 기간별 회원통계 조회
    List<MemberStaDTO> getMemberStaByPerd(MemberStaDTO dto);
    
    // 기간,일자,가입채널별 회원통계 조회
    Map<String, Object> getMemberStaByDttmList(MemberStaDTO dto);

    // 기간,일자,가입채널별 회원통계 엑셀 다운로드
    void downloadExcelMembSta(MemberStaDTO searchDto, HttpServletResponse response);

    // 대시보드 일자별 회원통계 조회
    List<MemberStaDTO> getDashMemberStaByDate();

    // 대시보드 월별 회원통계 조회
    List<MemberStaDTO> getDashMemberStaByMonth();

}
