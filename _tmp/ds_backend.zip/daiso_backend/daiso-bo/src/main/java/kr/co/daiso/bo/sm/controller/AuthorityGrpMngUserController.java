package kr.co.daiso.bo.sm.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.bo.sm.model.AuthorityGrpMngUserVO;
import kr.co.daiso.bo.sm.service.AuthorityGrpMngUserService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;


/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : AuthorityGrpMngUser
 * author         : kjm
 * date           : 2021-12-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-15       kjm            최초생성
 */

@RestController
@RequestMapping("/mg/authGrpMngUser")
public class AuthorityGrpMngUserController {

    @Autowired
    AuthorityGrpMngUserService authorityGrpMngUserService;

    @ApiOperation("사용자 목록 조회")
    @GetMapping("/searchUserList")
    public ResponseEntity<CommonResponseModel> searchUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return new ResponseEntity<CommonResponseModel>(
                new CommonResponseModel<List<AuthorityGrpMngUserVO>>(authorityGrpMngUserService.searchUserList(authorityGrpMngUserVO)), HttpStatus.OK);
    }

    @ApiOperation("사용자 상세 조회")
    @GetMapping("/searchUserDetail")
    public ResponseEntity<CommonResponseModel> searchUserDetail(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return new ResponseEntity<CommonResponseModel>(
                new CommonResponseModel<AuthorityGrpMngUserVO>(authorityGrpMngUserService.searchUserDetail(authorityGrpMngUserVO)), HttpStatus.OK);
    }

    @ApiOperation("사용자 권한그룹 조회")
    @GetMapping("/searchAuthGrp")
    public ResponseEntity<CommonResponseModel> searchAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        return new ResponseEntity<CommonResponseModel>(
                new CommonResponseModel<List<AuthorityGrpMngUserVO>>(authorityGrpMngUserService.searchAuthGrp(authorityGrpMngUserVO)), HttpStatus.OK);
    }

    @ApiOperation("사용자 등록")
    @PostMapping("/signUpUser")
    public ResponseEntity signUpUser(@RequestBody AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        try {
            authorityGrpMngUserService.signUpUser(authorityGrpMngUserVO);
            return new ResponseEntity(HttpStatus.CREATED);
        } catch (CommonException e) {
            return new ResponseEntity(e.getMessage(), e.getStatus());
        }
    }

    @ApiOperation("사용자 정보 수정")
    @PostMapping("/modifyUser")
    public ResponseEntity modifyUser(@RequestBody AuthorityGrpMngUserVO authorityGrpMngUserVO) {
        authorityGrpMngUserService.modifyUser(authorityGrpMngUserVO);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("권한그룹 저장")
    @PostMapping("/saveAuthGrp")
    public ResponseEntity saveAuthGrp(@RequestBody LinkedHashMap<String, Object> linkedHashMap) throws JsonProcessingException {
        authorityGrpMngUserService.saveAuthGrp(linkedHashMap);
        return new ResponseEntity(HttpStatus.OK);
    }

}
