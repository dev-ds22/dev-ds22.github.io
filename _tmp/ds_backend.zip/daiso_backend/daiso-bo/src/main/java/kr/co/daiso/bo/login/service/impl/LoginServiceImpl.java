package kr.co.daiso.bo.login.service.impl;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.bo.auth.JwtTokenProvider;
import kr.co.daiso.bo.common.auth.service.AuthGrpService;
import kr.co.daiso.bo.common.model.AdminCnntnLogVO;
import kr.co.daiso.bo.login.mapper.oracle.LoginMapper;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import kr.co.daiso.bo.login.model.LoginReqVO;
import kr.co.daiso.bo.login.service.LoginService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.AdminCmnUtil;
import kr.co.daiso.bo.util.RedisUtil;
import kr.co.daiso.bo.util.XdbUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.login.service.impl
 * fileName       : LoginServiceImpl
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    : 관리자 로그인 처리 관련 서비스를 구현 클래스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02      Doo-Won Lee    최초생성
 */
@Slf4j
@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    LoginMapper loginMapper;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    AuthGrpService authGrpService;

    @Autowired
    CookieUtil cookieUtil;

    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @Autowired
    AdminCmnUtil adminCmnUtil;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;
    /**
     * methodName : getAdminAuthGrpCd
     * author : Doo-Won Lee
     * description : 관리자로 접근 가능한 권한 그룹 조회
     *
     * @return List<String>
     */
    @Override
    public List<String> getAdminAuthGrpCd(){
        return loginMapper.getAdminAuthGrpCd();
    }

    /**
     * methodName : loginProcess
     * author : Doo-Won Lee
     * description : 로그인 처리를 한다.
     *              returnCode { 000 : 정상,
     *                           001 : 로그인 실패(메시지 출력),
     *                           002 : 로그인 실패(업무시간외 사유 등록),
     *                           003 : 로그인 실패(비밀번호 재설정)
     *                          }
     *
     * @param loginParams
     * @param response
     * @return ResponseEntity<CommonResponseModel>
     */
    @Override
    public ResponseEntity<CommonResponseModel> loginProcess(LoginReqVO loginParams, HttpServletResponse response,HttpServletRequest request) {
        CommonResponseModel resultModel = new CommonResponseModel();

        String message = "";
        try{
            AdminAccountInfo adminAccountInfo = loginMapper.getAdminUserInfo(loginParams);
            String password = XdbUtil.getHashEncryptSha256(loginParams.getPassword());
            log.info("password :"+password);

            if (null==adminAccountInfo){
                message = "등록되지 않은 아이디 이거나 비밀번호가 틀립니다!";
                resultModel.setSuccess(true);
                resultModel.setReturnCode("001");
            }
            else if (password.equals("") || !password.equals(adminAccountInfo.getPassword())){
                message = "등록되지 않은 아이디 이거나 비밀번호가 틀립니다!";
                resultModel.setSuccess(true);
                resultModel.setReturnCode("001");
            }
            else if (!authGrpService.checkAdminAuthGroup(adminAccountInfo)){
                message = "접근권한이 없습니다!!!";
                resultModel.setSuccess(true);
                resultModel.setReturnCode("001");
            }
            else if (!"N".equals(adminAccountInfo.getRetireYn())){
                message = "접근권한이 없습니다!!";
                resultModel.setSuccess(true);
                resultModel.setReturnCode("001");
            }
            else if ("Y".equals(adminAccountInfo.getNtUseYn())){
                message = "해당 계정은 장기미사용으로 잠금처리 되었습니다.\\nIT개발팀에 문의하세요.";
                resultModel.setSuccess(true);
                resultModel.setReturnCode("001");
            }
            else if (adminAccountInfo.getNLeaveDays()<0){
                message = "비밀번호 변경기간이 지났습니다.\n비밀번호를 재설정 해주세요.";

                AdminAccountInfo returnAdminAccountInfo = new AdminAccountInfo();
                returnAdminAccountInfo.setUsrNm(adminAccountInfo.getUsrNm());
                returnAdminAccountInfo.setUsrCd(adminAccountInfo.getUsrCd());
                returnAdminAccountInfo.setUsrId(adminAccountInfo.getUsrId());
                returnAdminAccountInfo.setDept1(adminAccountInfo.getDept1());
                returnAdminAccountInfo.setId(adminAccountInfo.getId());

                resultModel.setSuccess(true);
                resultModel.setReturnCode("003");
                resultModel.setData(returnAdminAccountInfo);
            }
            else{
                message = "";

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
                String lastLogin = (null== adminAccountInfo.getFnlLoginDt()) ? dateFormat.format(Calendar.getInstance().getTime()) : adminAccountInfo.getFnlLoginDt().trim();

                // 3개월 이전
                Calendar loginDueDate = Calendar.getInstance();
                loginDueDate.add(Calendar.MONTH, -2);

                // 현재 날짜
                Calendar lastLoginDate = Calendar.getInstance();
                lastLoginDate.setTime(dateFormat.parse(lastLogin));
                lastLoginDate.add(Calendar.MONTH, 1);

                // 3개월 미접속시 잠금 처리 (장기미사용)
                boolean isExpired = loginDueDate.after(lastLoginDate);

                if (isExpired) {
                    message = "해당 계정은 장기미사용으로 인해 잠금처리 됩니다.\\n잠금해제는 IT개발팀에 문의해주세요.";

                    AdminAccountInfo inActiveUserInfo = new AdminAccountInfo();
                    inActiveUserInfo.setUsrCd(adminAccountInfo.getUsrCd());
                    inActiveUserInfo.setUsrId(adminAccountInfo.getUsrId());
                    inActiveUserInfo.setId(adminAccountInfo.getId());
                    inActiveUserInfo.setNtUseYn("Y");

                    loginMapper.updateUser(inActiveUserInfo);
                    resultModel.setSuccess(true);
                    resultModel.setReturnCode("001");
                }

                adminAccountInfo.setPassword(null);
                AdminAccountInfo returnAdminAccountInfo = new AdminAccountInfo();
                returnAdminAccountInfo.setUsrNm(adminAccountInfo.getUsrNm());
                returnAdminAccountInfo.setUsrCd(adminAccountInfo.getUsrCd());
                returnAdminAccountInfo.setUsrId(adminAccountInfo.getUsrId());
                returnAdminAccountInfo.setDept1(adminAccountInfo.getDept1());
                returnAdminAccountInfo.setId(adminAccountInfo.getId());

                // 업무시간 외 사용 팝업 처리
                String startTime	=	"190100";
                String endTime		=	"075959";

//                startTime	=	"090100";
//                endTime		=	"075959";


                Date currentDate=new Date();

                Calendar calendar = Calendar.getInstance();
                calendar.setTime(currentDate);

                int darOfWeekNumber = calendar.get(Calendar.DAY_OF_WEEK);
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int min = calendar.get(Calendar.MINUTE);
                int sec = calendar.get(Calendar.SECOND);

                SimpleDateFormat format = new SimpleDateFormat("HHmmss");

                String currentTime = format.format(calendar.getTime()); //한자리수는 앞에 0을 붙이기 위함
                if ("N".equals(loginParams.getOverworkYn())) {
                    if ((currentTime.compareTo(startTime) > 0) || (currentTime.compareTo(endTime) < 0) || (7 == darOfWeekNumber)) {
                        resultModel.setData(returnAdminAccountInfo);
                        resultModel.setSuccess(true);
                        resultModel.setReturnCode("002");
                    }
                    else{
                        message = "LOGIN SUCCESS.";
                        resultModel.setSuccess(true);
                        resultModel.setReturnCode("000");
                        resultModel.setData(returnAdminAccountInfo);
                        addLoginSuccessToken(adminAccountInfo,response);
                    }
                }
                else {
                    message = "LOGIN SUCCESS.";
                    resultModel.setSuccess(true);
                    resultModel.setReturnCode("000");
                    resultModel.setData(returnAdminAccountInfo);
                    addLoginSuccessToken(adminAccountInfo,response);

                    if ((currentTime.compareTo(startTime) > 0) || (currentTime.compareTo(endTime) < 0) || (7 == darOfWeekNumber)) {
                        //시간외 사용이력 저장
                        ExcWorktimeLogVO excWorktimeLogVO = new ExcWorktimeLogVO();

//                        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

                        excWorktimeLogVO.setRsn(loginParams.getReason());
                        excWorktimeLogVO.setAcesIp(CommonUtil.getClientIp(request));
                        excWorktimeLogVO.setDeptNm(adminAccountInfo.getDept1());
                        excWorktimeLogVO.setUsrNm(adminAccountInfo.getUsrNm());
                        excWorktimeLogVO.setUsrId(adminAccountInfo.getId());
                        excWorktimeLogVO.setRgpsId(adminAccountInfo.getId());
                        excWorktimeLogVO.setMdpsId(adminAccountInfo.getId());

                        loginMapper.insertExcWorktimeLog(excWorktimeLogVO);
                    }
                }

                if ("000".equals(resultModel.getReturnCode())){

                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(adminAccountInfo, null, adminAccountInfo.getAuthorities());
                    usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

                    //로그인 이력 저장
                    AdminCnntnLogVO loginCnntLogVO = new AdminCnntnLogVO();
                    loginCnntLogVO.setAcesUrl(request.getRequestURI());
                    adminCmnUtil.insertAdminLog(loginCnntLogVO, request);

                    //로그인 유저 로그인 날짜 업데이트
                    AdminAccountInfo updateAccountInfo = new AdminAccountInfo();
                    updateAccountInfo.setUsrCd(adminAccountInfo.getUsrCd());
                    updateAccountInfo.setFnlLoginDt(dateFormat.format(new Date()));

                    loginMapper.updateUser(updateAccountInfo);

                }
            }
            resultModel.setMessage(message);
         } catch (Exception e) {
            e.printStackTrace();
            resultModel.setSuccess(false);
            return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<CommonResponseModel>(resultModel,HttpStatus.OK);
    }

    /**
     * 로그인 성공시 토큰을 생성하여 Cookie, Redis에 추가한다.
     *
     * @param adminAccountInfo
     * @param response
     */
    private void addLoginSuccessToken(AdminAccountInfo adminAccountInfo, HttpServletResponse response){
        // Access Token, Refresh Token 생성
        final String accessToken = jwtTokenProvider.createAdminJwtToken(adminAccountInfo);
        final String refreshToken = jwtTokenProvider.createAdminRefreshToken(adminAccountInfo);

        cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_ACCESS_TOKEN_NAME, accessToken, CommonConstants.ADMIN_ACCESS_TOKEN_VALIDATION_SECOND);
        cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_REFRESH_TOKEN_NAME, refreshToken, CommonConstants.ADMIN_REFRESH_TOKEN_VALIDATION_SECOND);

        //중복 로그인 허가 하지 않는계정
        if (StringUtils.hasLength(adminAccountInfo.getMultiLoginPrmsnYn()) && "N".equals(adminAccountInfo.getMultiLoginPrmsnYn())) {
            //레디스에 Accesstoken을 저장하여 필터에서 확인시 일치하지 않으면 다른데서 로그인한 것
            //Refreshtoken의 경우 계정별 하나만 유지 하여 덮어써서 마지막 로그인한 정보만 유효하게 함
            redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_ADMIN_MULTIACCESS + adminAccountInfo.getId(), accessToken, CommonConstants.ADMIN_ACCESS_TOKEN_VALIDATION_SECOND);
            redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + adminAccountInfo.getId(), refreshToken, CommonConstants.ADMIN_REFRESH_TOKEN_VALIDATION_SECOND);
        } else {
            //중복 로그인 허가 계정
            //Accesstoken 자체는 저장 없이 쿠키 값만 확인
            //Refreshtoken의 경우 계정별로 여러개가 등록되어야 하여 중간에 id정보+refreshToken 추가
            redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + adminAccountInfo.getId() + ":" + refreshToken, refreshToken, CommonConstants.ADMIN_REFRESH_TOKEN_VALIDATION_SECOND);
        }
    }

    /**
     * methodName : changePassword
     * author : Doo-Won Lee
     * description : 비밀번호 재설정 처리를 한다.
     *              returnCode { 000 : 정상,
     *                           001 : 재설정 실패(메시지 출력),
     *                          }
     *
     * @param reqInfo
     * @param response
     * @param request
     * @return ResponseEntity<CommonResponseModel>
     */
    @Override
    public ResponseEntity<CommonResponseModel> changePassword(AdminAccountInfo reqInfo, HttpServletResponse response, HttpServletRequest request) {

        CommonResponseModel resultModel = new CommonResponseModel();

        Map<String, String> resultMap = new HashMap<>();

        LoginReqVO tempLoginReqVO = new LoginReqVO();
        tempLoginReqVO.setId(reqInfo.getId());
        AdminAccountInfo adminAccountInfo = loginMapper.getAdminUserInfo(tempLoginReqVO);

        if (null==adminAccountInfo || !adminAccountInfo.getUsrCd().equals(reqInfo.getUsrCd()) || !StringUtils.hasText(reqInfo.getPassword())){
            resultModel.setSuccess(true);
            resultModel.setReturnCode("001");
            resultModel.setMessage("비밀번호 변경에 필요한 필수정보를 찾을 수 없습니다.");
        }
        else{
            String encryptPassWord = XdbUtil.getHashEncryptSha256(reqInfo.getPassword());

            SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd");
            Date targetDate=new Date();

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(targetDate);
            calendar.add(Calendar.MONTH,3);

            String targetDateStr = format.format(calendar.getTime());
            adminAccountInfo.setPassword(encryptPassWord);
            adminAccountInfo.setPwdChngDt(targetDateStr);

            loginMapper.updateUser(adminAccountInfo);

            resultModel.setSuccess(true);
            resultModel.setReturnCode("000");
        }

        return new ResponseEntity<CommonResponseModel>(resultModel,HttpStatus.OK);
    }

    /**
     * methodName : logoutProcess
     * author : Doo-Won Lee
     * description : 로그아웃 처리를 한다.
     *
     * @param logoutParams
     * @param response
     * @return ResponseEntity<CommonResponseModel>
     */
    @Override
    public ResponseEntity<CommonResponseModel> logoutProcess(LoginReqVO logoutParams, HttpServletResponse response,HttpServletRequest request) {
        CommonResponseModel resultModel = new CommonResponseModel();

        String message = "";
        try{
            AdminAccountInfo adminAccountInfo =  adminAccountInfoUtil.getAccountInfo();
            final Cookie authTokenCookie = cookieUtil.getCookie(request, CommonConstants.ADMIN_ACCESS_TOKEN_NAME);
            final Cookie refreshTokenCookie = cookieUtil.getCookie(request, CommonConstants.ADMIN_REFRESH_TOKEN_NAME);
            String accessToken = Optional.ofNullable(authTokenCookie)
                                .map(Cookie::getValue)
                                .orElse(null);

            String refreshToken = Optional.ofNullable(refreshTokenCookie)
                    .map(Cookie::getValue)
                    .orElse(null);

            if ("Y".equals(adminAccountInfo.getMultiLoginPrmsnYn())){
                //MultiLogin 가능 계정

                //AccessToken Expire
                cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_ACCESS_TOKEN_NAME, null,0);

                //RefreshTokin Expire
                cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_REFRESH_TOKEN_NAME, null,0);
                redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + adminAccountInfo.getId() + ":" + refreshToken);
            }
            else{
                //MultiLogin 불가 계정
                //AccessToken Expire
                cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_ACCESS_TOKEN_NAME, null,0);
                redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_MULTIACCESS + adminAccountInfo.getId());

                //RefreshTokin Expire
                cookieUtil.addResponseCookie(response, CommonConstants.ADMIN_REFRESH_TOKEN_NAME, null,0);
                redisUtil.deleteData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + adminAccountInfo.getId());
            }
            message = "LOGOUT SUCCESS.";
            resultModel.setSuccess(true);
            resultModel.setReturnCode("000");
        } catch (Exception e) {
            e.printStackTrace();
            resultModel.setSuccess(false);
            return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<CommonResponseModel>(resultModel,HttpStatus.OK);
    }

    /**
     * methodName : logoutProcess
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 정보를 조회한다.
     *
     * @param request
     * @param response
     * @return ResponseEntity<CommonResponseModel>
     */
    @Override
    public ResponseEntity<CommonResponseModel> getLoginAdmininfo(HttpServletResponse response, HttpServletRequest request) {
        CommonResponseModel resultModel = new CommonResponseModel();

        AdminAccountInfo returnAdminAccountInfo = new AdminAccountInfo();
        returnAdminAccountInfo.setUsrNm(adminAccountInfoUtil.getUsrNm());
        returnAdminAccountInfo.setUsrCd(adminAccountInfoUtil.getUsrCd());
        returnAdminAccountInfo.setUsrId(adminAccountInfoUtil.getUsrId());
        returnAdminAccountInfo.setDept1(adminAccountInfoUtil.getDept1());
        returnAdminAccountInfo.setId(adminAccountInfoUtil.getId());

        resultModel.setData(returnAdminAccountInfo);
        return new ResponseEntity<CommonResponseModel>(resultModel,HttpStatus.OK);
    }
}
