package kr.co.daiso.bo.sm.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonAuthBtnVO
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 공통 버튼 그룹의 화면과 사용정보 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08      Doo-Won Lee        최초생성
 */
@Data
public class CommonAuthBtnVO {

    private String scrnId;                 //화면ID
    private String adminId;                //관리자ID
    private String UsrType;                //권한관리 그룹 리스트

    private String scrnIqyBtnUseYn;             //화면정보의 조회 버튼 여부 Table Data
    private String scrnInitBtnUseYn;            //화면정보의 초기화 버튼 여부 Table Data
    private String scrnNewBtnUseYn;             //화면정보의 신규 버튼 여부 Table Data
    private String scrnStrgBtnUseYn;            //화면정보의 저장 버튼 여부 Table Data
    private String scrnDelBtnUseYn;             //화면정보의 삭제 버튼 여부 Table Data
    private String scrnDnldBtnUseYn;            //화면정보의 다운로드 버튼 여부 Table Data

    private boolean isScrSerch = true;     //화면정보의 조회 버튼 여부
    private boolean isScrReset = true;     //화면정보의 초기화 버튼 여부
    private boolean isScrReg = true;       //화면정보의 신규 버튼 여부
    private boolean isScrSave = true;      //화면정보의 저장 버튼 여부
    private boolean isScrDel = true;       //화면정보의 삭제 버튼 여부
    private boolean isScrDownload = true;  //화면정보의 다운로드 버튼 여부

    private String iqyBtnUseYn;             //권한정보의 조회 버튼 여부 Table Data
    private String initBtnUseYn;            //권한정보의 초기화 버튼 여부 Table Data
    private String newBtnUseYn;             //권한정보의 신규 버튼 여부 Table Data
    private String strgBtnUseYn;            //권한정보의 저장 버튼 여부 Table Data
    private String delBtnUseYn;             //권한정보의 삭제 버튼 여부 Table Data
    private String dnldBtnUseYn;            //권한정보의 다운로드 버튼 여부 Table Data

    private boolean isAuthSerch = true;     //권한정보의 조회 버튼 여부
    private boolean isAuthReset = true;     //권한정보의 초기화 버튼 여부
    private boolean isAuthReg = true;       //권한정보의 신규 버튼 여부
    private boolean isAuthSave = true;      //권한정보의 저장 버튼 여부
    private boolean isAuthDel = true;       //권한정보의 삭제 버튼 여부
    private boolean isAuthDownload = true;  //권한정보의 다운로드 버튼 여부

    //화면정보의 조회 버튼 여부 Table Data
    public void setScrnIqyBtnUseYn(String scrnIqyBtnUseYn) {
        this.scrnIqyBtnUseYn = scrnIqyBtnUseYn;
        this.isScrSerch = "Y".equals(this.scrnIqyBtnUseYn);
    }

    //화면정보의 초기화 버튼 여부 Table Data
    public void setScrnInitBtnUseYn(String scrnInitBtnUseYn) {
        this.scrnInitBtnUseYn = scrnInitBtnUseYn;
        this.isScrReset = "Y".equals(this.scrnInitBtnUseYn);
    }

    //화면정보의 신규 버튼 여부 Table Data
    public void setScrnNewBtnUseYn(String scrnNewBtnUseYn) {
        this.scrnNewBtnUseYn = scrnNewBtnUseYn;
        this.isScrReg = "Y".equals(this.scrnNewBtnUseYn);
    }

    //화면정보의 저장 버튼 여부 Table Data
    public void setScrnStrgBtnUseYn(String scrnStrgBtnUseYn) {
        this.scrnStrgBtnUseYn = scrnStrgBtnUseYn;
        this.isScrSave = "Y".equals(this.scrnStrgBtnUseYn);
    }

    //화면정보의 삭제 버튼 여부 Table Data
    public void setScrnDelBtnUseYn(String scrnDelBtnUseYn) {
        this.scrnDelBtnUseYn = scrnDelBtnUseYn;
        this.isScrDel = "Y".equals(this.scrnDelBtnUseYn);
    }

    //화면정보의 다운로드 버튼 여부 Table Data
    public void setScrnDnldBtnUseYn(String scrnDnldBtnUseYn) {
        this.scrnDnldBtnUseYn = scrnDnldBtnUseYn;
        this.isScrDownload = "Y".equals(this.scrnDnldBtnUseYn);
    }

    //권한정보의 조회 버튼 여부 Table Data
    public void setIqyBtnUseYn(String iqyBtnUseYn) {
        this.iqyBtnUseYn = iqyBtnUseYn;
        this.isAuthSerch = "Y".equals(this.iqyBtnUseYn);
    }

    //권한정보의 초기화 버튼 여부 Table Data
    public void setInitBtnUseYn(String initBtnUseYn) {
        this.initBtnUseYn = initBtnUseYn;
        this.isAuthReset = "Y".equals(this.initBtnUseYn);
    }

    //권한정보의 신규 버튼 여부 Table Data
    public void setNewBtnUseYn(String newBtnUseYn) {
        this.newBtnUseYn = newBtnUseYn;
        this.isAuthReg = "Y".equals(this.newBtnUseYn);
    }

    //권한정보의 저장 버튼 여부 Table Data
    public void setStrgBtnUseYn(String strgBtnUseYn) {
        this.strgBtnUseYn = strgBtnUseYn;
        this.isAuthSave = "Y".equals(this.strgBtnUseYn);
    }

    //권한정보의 삭제 버튼 여부 Table Data
    public void setDelBtnUseYn(String delBtnUseYn) {
        this.delBtnUseYn = delBtnUseYn;
        this.isAuthDel = "Y".equals(this.delBtnUseYn);
    }

    //권한정보의 다운로드 버튼 여부 Table Data
    public void setDnldBtnUseYn(String dnldBtnUseYn) {
        this.dnldBtnUseYn = dnldBtnUseYn;
        this.isAuthDownload = "Y".equals(this.dnldBtnUseYn);
    }
}
