package kr.co.daiso.bo.common.service;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.model.*;
import kr.co.daiso.bo.login.model.ExcWorktimeLogVO;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.service
 * fileName       : LogService
 * author         : Doo-Won Lee
 * date           : 2022-01-18
 * description    : 관리자에서 로그를 처리하는 서비스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-18       Doo-Won Lee      최초생성
 */
public interface LogService {

    //관리자 접속로그를 등록한다.
    public ResponseEntity<CommonResponseModel> regAdminCnntnLog(AdminCnntnLogVO vo, HttpServletRequest request,HttpServletResponse response);

    //업무시간외 접속로그의 카운트를 구한다.
    public int getOutTimeConnLogCnt(OutTimeLogSearchVO searchVO);

    //업무시간외 접속로그목록을 조회한다.
    public List<ExcWorktimeLogVO> getOutTimeConnLog(OutTimeLogSearchVO searchVO);

    //관리자 권한 그룹 목록을 조회한다.
    public List<AuthGrpAdmVO> getAdminAuthGrpList();

    //관리자 접속 로그카운트 조회한다.
    public int getAdminCnntnLogCnt(AdminCnntnLogSearchVO adminCnntnLogSearchVO);

    //관리자 접속 로그를 조회한다.
    public List<AdminCnntnLogVO> getAdminCnntnLog(AdminCnntnLogSearchVO adminCnntnLogSearchVO);

    //관리자 접속 로그카운트 조회한다.
    public int getAdminUserHistoryCnt(AdminUserHistorySearchVO adminUserHistorySearchVO);

    //관리자 접속 로그를 조회한다.
    public List<AdminUserHistoryVO> getAdminUserHistory(AdminUserHistorySearchVO adminUserHistorySearchVO);

    //에러발생시 에러정보를 등록한다.
    public int regExceptionLog(ExceptionLogVO exceptionLogVO);

    //시스템 에러 로그를 조회한다.
    public List<ExceptionLogVO> getExceptionLog(ExceptionLogSearchVO exceptionLogSearchVO);

    //시스템 에러 로그카운트를 조회한다.
    public int getExceptionLogCnt(ExceptionLogSearchVO exceptionLogSearchVO);

    //다운로드 등록사유를 등록한다.
    public int regDownloadRsn(HttpServletRequest request, String dnldAtclNm, String dnldAtclDtl, int cnt);

    //다운로드 사유를 조회한다.
    public List<DownloadRsnVO> getDownloadRsn(DownloadRsnSearchVO downloadRsnSearchVO);

    //다운로드 사유 카운트를 조회한다.
    public int getDownloadRsnCnt(DownloadRsnSearchVO downloadRsnSearchVO);

    //E-mail 로그를 등록한다.
    int insertStaMailLog(MailSendLogVO mailSendLogVO);

    //배치 실행 목록 카운트를 조회한다.
    int getBatchLogCount(BatchLogSearchVO searchVO);

    //배치 실행 목록을 조회한다.
    List<BatchLogVO> getBatchLogList(BatchLogSearchVO searchVO);

    //Mail 전송 내역 목록 카운트를 조회한다.
    int getMailSendLogCount(MailLogSearchVO searchVO);

    //Mail 전송 내역 목록을 조회한다.
    List<MailSendLogVO> getMailSendLogList(MailLogSearchVO searchVO);


}
