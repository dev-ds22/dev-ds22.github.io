package kr.co.daiso.bo.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.common.util.CookieUtil;
import kr.co.daiso.bo.common.model.AdminCnntnLogVO;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import kr.co.daiso.bo.util.AdminCmnUtil;
import kr.co.daiso.bo.util.RedisUtil;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.auth
 * fileName       : AdminAuthFilter.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class AdminAuthFilter extends OncePerRequestFilter {

    @Autowired
    JwtTokenProvider loginTokenProvider;

    @Autowired
    CookieUtil cookieUtil;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    UserDetailService userDetailService;

//    @Autowired
//    CommonCodeManageService commonCodeManageService;

//    @Autowired
//    AdminCmnUtil adminCmnUtil;

	private static final String[] IGNORE_LOGIN_CHECK = {
            "/login_process","/password"
            ,"/sample/maptest","/admin/sample","/favicon.ico"
            ,"/swagger-ui/","/swagger-resources","/v3/api-docs" //swagger
            ,"/jsptest","/actuator"
            ,"/sample/JTest"
            , "/actuator/health", "/actuator/info"
	};

    private static final String[] CORS_WHITE_LIST = {
            "dev.daiso.com:3013"        //local
            ,"adm.daisodev.com"          //Dev
            ,"localhost:8013"  //daiso Test mg
//            ,"http://172.168.202.174:8090"
            ,"adm-qa.daisodev.com"
            ,"adm-qa.daiso.com"
            ,"adm.daiso.com"
    };

    private static final String[] IGNORE_LOG_ADDRESS = {
            "/login_process","/password", "/cmnlog/admin-cnntn-log"
            , "/sysmg/commonAuthBtn/getAuthButtonAvailable","/sysmg/commoncode/getSubCodeList","/mg/menu/menu-and-auth"
            ,"/cmnlog/admin-conn-log","/sample/maptest","/admin/sample"
            ,"/favicon.ico"
            ,"/swagger-ui/","/swagger-resources","/v3/api-docs"   //swagger
            ,"/jsptest","/actuator"
            ,"/sample/JTest"
    };

    private final String STR_ACTION_TYPE = "actionType";
    private final String STR_ORIGIN = "Origin";

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws ServletException, IOException {

//        log.info("********************2.4.10*Code Add***2022-04-07 09:21**********************");
        log.info("********************2.5.12*************************");
        log.info("request.getRequestURI() :"+request.getRequestURI());
        log.info("request.getRequestURI() :"+request.getMethod());
        log.info("IGNORE_LOG_ADDRESS :"+IGNORE_LOG_ADDRESS[0]);
        log.info("*********************bbbbb******************");
        ContentCachingRequestWrapper wrappingRequest = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper wrappingResponse = new ContentCachingResponseWrapper(response);

        boolean isPermission = true;
        boolean isPreflight = CorsUtils.isPreFlightRequest(request);
        //1. CommonPathInfo 세팅
        //2. 관리자 접속 IP확인
        if (checkAdminIp(request)){
            //3. 토큰 확인하여 중복 로그인 확인
            //4. 토큰으로 자동 로그인 처리 (토큰 관리)
            String accessJwtToken = getAuthToken(request,CommonConstants.ADMIN_ACCESS_TOKEN_NAME);
            // String accessUserId = null;
            String refreshJwtToken = null;
            String refreshUserId = null;
            //String redisAccessJwtToken = null;
            if (null!=accessJwtToken) {
                try {
                    String accessUserId = loginTokenProvider.getUserId(accessJwtToken);
                    if (null != accessUserId) {

                        boolean isEffectiveToken = true;
                        UserDetails userDetails = userDetailService.loadUserByUsername(accessJwtToken);
                        AdminAccountInfo adminAccountInfo = (AdminAccountInfo)userDetails;
                        //중복로그인 허가 하지 않는 계정
                        if (StringUtils.hasLength(adminAccountInfo.getMultiLoginPrmsnYn()) && "N".equals(adminAccountInfo.getMultiLoginPrmsnYn())) {
                            String redisAccessJwtToken = redisUtil.getData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_MULTIACCESS+adminAccountInfo.getId());
                            //다른 곳에서 로그인하여 AccessToken이 일치하지 않는경우
                            if (!accessJwtToken.equals(redisAccessJwtToken)){
                                isEffectiveToken = false;
                            }
                        }
                        if (isEffectiveToken) {
                            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                            usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                        }
                        else{
                            isPermission = false;
                            permissionFailProcess(request,response,"다른곳에서 로그인을 시도하여 로그아웃 처리되었습니다.");
                        }
                    }
                } catch (ExpiredJwtException e) {
                    log.info(e.getMessage());
                    // Access Token의 유효기간이 만료되면 Refresh Token의 값을 읽어온다.
                    refreshJwtToken = getAuthToken(request, CommonConstants.ADMIN_REFRESH_TOKEN_NAME);
                }
            }
            else{
                refreshJwtToken = getAuthToken(request, CommonConstants.ADMIN_REFRESH_TOKEN_NAME);
            }

            if (isPermission && refreshJwtToken != null) {
                try {
                    String redisRefreshUserKey = loginTokenProvider.getUserId(refreshJwtToken);
                    UserDetails userDetails = userDetailService.loadUserByUsername(refreshJwtToken);
                    AdminAccountInfo adminAccountInfo = (AdminAccountInfo)userDetails;
                    String redisRefreshToken; // = (String) redisUtil.getData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + redisRefreshUserKey);

                    //중복로그인 허가 하지 않는 계정
                    if (StringUtils.hasLength(adminAccountInfo.getMultiLoginPrmsnYn()) && "N".equals(adminAccountInfo.getMultiLoginPrmsnYn())) {
                        redisRefreshToken = (String) redisUtil.getData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH + adminAccountInfo.getId());
                    }
                    else{
                        redisRefreshToken = (String) redisUtil.getData(CommonConstants.PREFIX_REDIS_KEY_ADMIN_REFRESH +adminAccountInfo.getId()+":"+refreshJwtToken);
                    }

                    if (null!=redisRefreshUserKey && refreshJwtToken.equals(redisRefreshToken)){
                        //UserDetails userDetails = userDetailService.loadUserByUsername(refreshJwtToken);
                        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                        usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);

                        //AdminAccountInfo adminAccountInfo = (AdminAccountInfo)userDetails;
                        String newToken = loginTokenProvider.createAdminJwtToken(adminAccountInfo,CommonConstants.ADMIN_ACCESS_TOKEN_VALIDATION_SECOND);
        //                ResponseCookie newAccessTokenCookie = cookieUtil.createResponseCookie(CommonConstants.FO_ACCESS_TOKEN_NAME,newToken,CommonConstants.FO_ACCESS_TOKEN_VALIDATION_SECOND);
        //                response.addHeader(HttpHeaders.SET_COOKIE, newAccessTokenCookie.toString());
                        //중복로그인 허가 하지 않는 계정
                        if (StringUtils.hasLength(adminAccountInfo.getMultiLoginPrmsnYn()) && "N".equals(adminAccountInfo.getMultiLoginPrmsnYn())){
                            redisUtil.setDataExpire(CommonConstants.PREFIX_REDIS_KEY_ADMIN_MULTIACCESS+adminAccountInfo.getId(), newToken, CommonConstants.ADMIN_ACCESS_TOKEN_VALIDATION_SECOND);
                        }

                        cookieUtil.addResponseCookie(response,CommonConstants.ADMIN_ACCESS_TOKEN_NAME, newToken, CommonConstants.ADMIN_ACCESS_TOKEN_VALIDATION_SECOND);
                    }
                    else{
                        //refreshtoken이 있으나 일치하지 않는경우
                        isPermission = false;
                        permissionFailProcess(request,response,"토큰이 만료되어 로그인이 필요합니다.");
                    }
                }catch(ExpiredJwtException e){
                    log.info("refreshJwtToken Expired!!!!");
                    isPermission = false;
                    permissionFailProcess(request,response,"토큰이 만료되어 로그인이 필요합니다.");
                }
            }

            if (isPermission && null==accessJwtToken && null==refreshJwtToken) {
                if (!isPreflight) {
                    log.info("permission If Check"+request.getRequestURI());
//                    boolean ignoreUriAcess = Arrays.stream(IGNORE_LOGIN_CHECK).anyMatch(str -> str.equals(request.getRequestURI()));
                    boolean ignoreUriAcess = Arrays.stream(IGNORE_LOGIN_CHECK).anyMatch(str -> request.getRequestURI().indexOf(str)==0);
                    log.info("permission If Check"+ignoreUriAcess);
                    if (!ignoreUriAcess) {
                        isPermission = false;
                        permissionFailProcess(request, response, "로그인이 필요합니다.");
                    }
                }
            }
        }
        else{
            //IP 불일치
            isPermission = false;
            permissionFailProcess(request,response,"접근가능한 IP대역이 아닙니다.");
        }

        log.info("filter :"+isPermission);

        if (isPermission)  filterChain.doFilter(wrappingRequest, wrappingResponse);

//        filterChain.doFilter(request, response);
        wrappingResponse.copyBodyToResponse();

        if (isPermission){
//            boolean ignoreUriLog = Arrays.stream(IGNORE_LOG_ADDRESS).anyMatch(str -> str.equals(request.getRequestURI()));
            boolean ignoreUriLog = Arrays.stream(IGNORE_LOG_ADDRESS).anyMatch(str -> request.getRequestURI().indexOf(str)==0);
            if (!ignoreUriLog) {
                addConnLog(wrappingRequest, isPreflight);
            }
        }
    }

    private void addConnLog(ContentCachingRequestWrapper request, boolean isPreflight){
        log.info("addConnLog isPreflight:"+isPreflight);
        //로그를 쌓자
        if ("GET".equals(request.getMethod())){
//                    System.out.println(request.getParameter("actionType"));
            AdminCnntnLogVO loginCnntLogVO = new AdminCnntnLogVO();
            loginCnntLogVO.setAcesUrl(request.getRequestURI());
            loginCnntLogVO.setType(request.getParameter(STR_ACTION_TYPE));
//            adminCmnUtil.insertAdminLog(loginCnntLogVO, request);
        }
//        else if(!isPreflight){
        else if(!"OPTIONS".equals(request.getMethod())){
//                    System.out.println(request.getParameter("actionType"));
//            if("/sysmg/commonScrn/editScreenInfo".equals(request.getRequestURI())) {
                final ContentCachingRequestWrapper cachingRequest = (ContentCachingRequestWrapper) request;

                AdminCnntnLogVO loginCnntLogVO = new AdminCnntnLogVO();
                loginCnntLogVO.setAcesUrl(request.getRequestURI());

                if (cachingRequest.getContentType() != null && cachingRequest.getContentType().contains("application/json")) {
                    if (cachingRequest.getContentAsByteArray() != null && cachingRequest.getContentAsByteArray().length != 0) {
                        JSONParser parser = new JSONParser();
                        try {
//                            JSONObject json = (JSONObject) parser.parse(new String(cachingRequest.getContentAsByteArray()));
                            JSONObject json;

                            Object jsonObject = parser.parse(new String(cachingRequest.getContentAsByteArray()));
//                            Object jsonObject = parser.parse(Arrays.toString(cachingRequest.getContentAsByteArray()));
                            if (jsonObject instanceof JSONArray){
                                json = (JSONObject) ((JSONArray)jsonObject).get(0);
                            }
                            else {
                                json = (JSONObject)jsonObject;
                            }

                            if (null!=json.get(STR_ACTION_TYPE)) {
                                loginCnntLogVO.setType(json.get(STR_ACTION_TYPE).toString());
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }
//                adminCmnUtil.insertAdminLog(loginCnntLogVO, request);
//            }
        }
    }

    /**
     * methodName : getAuthToken
     * author : Doo-Won Lee
     * description : 쿠키에서 권한 토큰을 가져온다.
     *
     * @param request
     * @param tokenName
     * @return
     */
    private String getAuthToken(HttpServletRequest request, String tokenName){
        final Cookie authTokenCookie = cookieUtil.getCookie(request, tokenName);
     //   return Optional.ofNullable(authTokenCookie.getValue()).orElse(null);
        return Optional.ofNullable(authTokenCookie)
                .map(Cookie::getValue)
                .orElse(null);
    }

    /**
     * methodName : checkAdminIp
     * author : Doo-Won Lee
     * description : 관리자 사이트 로그인가능 IP여부 확인
     *
     * @param request
     * @return boolean
     */
    private boolean checkAdminIp( HttpServletRequest request ){
        try {
            String remoteAddr = CommonUtil.getClientIp(request);
            boolean pass = false;
            //ip = CmFunction.getByteString2(remoteAddr, 20);
            log.info("**********************************************");
            log.info("request.getRemoteAddr :" + request.getRemoteAddr());
    //        log.info("X-Real-IP :"+request.getHeader("X-Real-IP"));
    //        log.info("remoteAddr :"+remoteAddr);

            String redisGetAdminIPStr = redisUtil.getData(CommonConstants.REDIS_KEY_ADMIN_IP_LIST);
            if (!StringUtils.hasLength(redisGetAdminIPStr)) {
//                commonCodeManageService.setAdminIpListToRedis();
                redisGetAdminIPStr = redisUtil.getData(CommonConstants.REDIS_KEY_ADMIN_IP_LIST);
            }

            log.info("******************redisGetAdminIPStr******************" + redisGetAdminIPStr);
            
            if (redisGetAdminIPStr == null) {
            	return true;
            }
            
            List<String> psbIpList = Arrays.asList(redisGetAdminIPStr.split(","));

            for (String ipAddrss : psbIpList) {
                if (remoteAddr.indexOf(ipAddrss) > -1) {
                    pass = true;
                    log.info("ipAddrss :" + ipAddrss);
                    log.info("pass :" + pass);
                    break;
                }
            }
            log.info("**********************************************");
            return pass;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return true;
    }

    //Token이 없거나, IP대역이 안맞는 경우 처리
    private void permissionFailProcess(HttpServletRequest request, HttpServletResponse response, String message) throws  IOException{
//        log.info(request.getHeaderNames()+"");
        log.info(request.getHeader(STR_ORIGIN));

        cookieUtil.addResponseCookie(response,CommonConstants.ADMIN_ACCESS_TOKEN_NAME, null,0);
        cookieUtil.addResponseCookie(response,CommonConstants.ADMIN_REFRESH_TOKEN_NAME, null,0);
        boolean isWhiteOrigin = false;
        if (null == request.getHeader(STR_ORIGIN)){
            isWhiteOrigin = Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> request.getHeader("Referer").indexOf(str)>-1);
        } else{
            isWhiteOrigin = Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> request.getHeader(STR_ORIGIN).indexOf(str)>-1);
        }
//        boolean isWhiteOrigin = Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> str.indexOf(request.getHeader(STR_ORIGIN))>-1);
//        boolean isWhiteOrigin = Arrays.stream(CORS_WHITE_LIST).anyMatch(str -> request.getHeader(STR_ORIGIN).indexOf(str)>-1);

        log.info("STG 확인:"+isWhiteOrigin);
        if (isWhiteOrigin) {
            response.setHeader("Access-Control-Allow-Origin", request.getHeader(STR_ORIGIN));
        }
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Cache-Control","no-store");
        response.setCharacterEncoding("UTF-8");
        response.setStatus(HttpStatus.OK.value());
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("permission", "N");
        ObjectMapper mapper = new ObjectMapper();
        CommonResponseModel responseModel = new CommonResponseModel(resultMap);
        responseModel.setSuccess(false);
        responseModel.setMessage(message);
        response.getWriter().write(mapper.writeValueAsString(responseModel));
        response.flushBuffer();
        //mapper.writeValue(response.getWriter(), new ResponseEntity<CommonResponseModel>(responseModel, HttpStatus.OK));
    }
}
