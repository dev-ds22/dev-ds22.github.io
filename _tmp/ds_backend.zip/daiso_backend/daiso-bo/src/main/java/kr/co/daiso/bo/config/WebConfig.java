package kr.co.daiso.bo.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * packageName    : kr.co.daiso.bo.config
 * fileName       : WebConfig.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    : CORS registry 설정,  XSS - Json 처리 Config
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@RequiredArgsConstructor
@Configuration
public class WebConfig implements WebMvcConfigurer {

//    final LoggingInterceptor loggingInterceptor;

    @Autowired
    MessageSource messageSource;

    private final ObjectMapper objectMapper;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://dev.daiso.com:3013"
                        ,"http://adm.daisodev.com:8090"
                        ,"https://adm.daisodev.com"
                        ,"https://adm-qa.daisodev.com"
                        ,"https://adm-qa.daiso.com"
                        ,"https://adm.daiso.com"
                )
                .allowedMethods( "GET", "POST", "PUT", "DELETE", "PATCH")
                .exposedHeaders("Content-Disposition")
                .allowCredentials(true);
    }

    @Bean
    public MappingJackson2HttpMessageConverter jsonEscapeConverter(){
        ObjectMapper copy = objectMapper.copy();
        copy.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
        return new MappingJackson2HttpMessageConverter(copy);
    }

//    @Override
//    public void addInterceptors(InterceptorRegistry registry) {
//        registry.addInterceptor(loggingInterceptor)
//                .addPathPatterns("/**")
//                .excludePathPatterns("/vendor/**", "/css/*", "/img/*");
//    }

    @Override
    public Validator getValidator() {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource);
        return bean;
    }

    @Value("${spring.resource.path}")
    private String resourcePath;

    @Value("${spring.resource.requestPath}")
    private String requestPath;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //WebMvcConfigurer.super.addResourceHandlers(registry);
        registry.addResourceHandler(requestPath)
                .addResourceLocations(resourcePath);
//                .addResourceLocations(resourcePath,"file:src/main/webapp/");
    }
}
