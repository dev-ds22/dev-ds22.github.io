package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.bo.sm.mapper.oracle.CommonAuthButtonGrpMapper;
import kr.co.daiso.bo.sm.model.CommonAuthBtnVO;
import kr.co.daiso.bo.sm.service.CommonAuthButtonGrpService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : CommonAuthButtonGrpServiceImpl
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    :공통 버튼 그룹처리 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08     Doo-Won Lee        최초생성
 */
@Service
public class CommonAuthButtonGrpServiceImpl implements CommonAuthButtonGrpService {

    @Autowired
    CommonAuthButtonGrpMapper commonAuthButtonGrpMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : getAuthButtonAvailable
     * author : Doo-Won Lee
     * description : 공통버튼 사용가능 정보 조회
     *
     * @param reqVo
     * @return CommonAuthBtnVO
     */
    @Override
    public CommonAuthBtnVO getAuthButtonAvailable(CommonAuthBtnVO reqVo) {

        reqVo.setAdminId(adminAccountInfoUtil.getUsrId());

        //화면관리쪽 버튼 가능 여부 확인
        CommonAuthBtnVO resultVo = commonAuthButtonGrpMapper.getAuthButtonScreenAvailable(reqVo);

        //화면 권한별 공통버튼 사용가능 여부를 구한다.
        reqVo.setUsrType(adminAccountInfoUtil.getUsrType());
        CommonAuthBtnVO resultVoTemp = commonAuthButtonGrpMapper.getScrAuthButtonAvailable(reqVo);

        if(resultVoTemp != null){
            resultVo.setIqyBtnUseYn((resultVoTemp.getIqyBtnUseYn() != null) ?resultVoTemp.getIqyBtnUseYn() : "N");
            resultVo.setInitBtnUseYn((resultVoTemp.getInitBtnUseYn() != null) ?resultVoTemp.getInitBtnUseYn() : "N");
            resultVo.setNewBtnUseYn((resultVoTemp.getNewBtnUseYn() != null) ?resultVoTemp.getNewBtnUseYn() : "N");
            resultVo.setStrgBtnUseYn((resultVoTemp.getStrgBtnUseYn() != null) ?resultVoTemp.getStrgBtnUseYn() : "N");
            resultVo.setDelBtnUseYn((resultVoTemp.getDelBtnUseYn() != null) ?resultVoTemp.getDelBtnUseYn() : "N");
            resultVo.setDnldBtnUseYn((resultVoTemp.getDnldBtnUseYn() != null) ?resultVoTemp.getDnldBtnUseYn() : "N");
        }

        //return resultVo;
        return new CommonAuthBtnVO();
    }
}
