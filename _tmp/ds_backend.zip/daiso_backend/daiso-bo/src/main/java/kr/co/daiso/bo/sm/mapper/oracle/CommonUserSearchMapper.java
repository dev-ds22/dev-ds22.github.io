package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CommonUserSearchPagingVo;
import kr.co.daiso.bo.sm.model.CommonUserVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommonUserSearchMapper {
    // 검색한 유저수
    int countUsers(CommonUserSearchPagingVo userVo);
    // 이름으로 검색된 사용자 정보 리스트
    List<CommonUserVo> searchUsers(CommonUserSearchPagingVo userVo);
}
