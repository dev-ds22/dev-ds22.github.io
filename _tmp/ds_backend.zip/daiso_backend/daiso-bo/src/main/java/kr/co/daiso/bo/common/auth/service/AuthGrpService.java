package kr.co.daiso.bo.common.auth.service;

import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuScrSaveVO;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.common.model.CommonResponseModel;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.auth.service
 * fileName       : AuthGrpService
 * author         : Doo-Won Lee
 * date           : 2021-12-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-06      Doo-Won Lee        최초생성
 */
public interface AuthGrpService {

    //Redis에 관리자 사이트에 접근 가능한 권한 그룹코드를 저장한다.
    public void setAdminAuthGrpToRedis();

    //유저정보가 관리자 권한 그룹을 가지고 있는지 확인한다.
    public boolean checkAdminAuthGroup(AdminAccountInfo adminAccountInfo);

    //권한관리그룹 리스트를 카운트한다.
    public int getAuthGrpAdmListCnt(AuthGrpAdmVO authGrpAdmVO);

    //공통 팝업 권한관리그룹 리스트를 조회한다.
    public List<AuthGrpAdmVO> getCommonAuthGrpAdmListPopup(AuthGrpAdmVO authGrpAdmVO);

    //권한관리그룹 리스트를 조회한다.
    public List<AuthGrpAdmVO> getAuthGrpAdmList(AuthGrpAdmVO authGrpAdmVO);

    //권한관리그룹 리스트를 추가 수정 한다.
    public CommonResponseModel updateAuthGrpAdmList(List<AuthGrpAdmVO> createRows,List<AuthGrpAdmVO> updateRows );


    //권한그룹별 메뉴 리스트를 조회한다.
    List<AuthGrpMenuAdmVO> getAuthGrpMenuAdmList(AuthGrpMenuAdmVO authGrpMenuAdmVO);

    //권한관리그룹 메뉴 화면 권한을 수정 한다.
    public CommonResponseModel updateAuthGrpMenuAdmList(List<AuthGrpMenuScrSaveVO> updateRows);
}
