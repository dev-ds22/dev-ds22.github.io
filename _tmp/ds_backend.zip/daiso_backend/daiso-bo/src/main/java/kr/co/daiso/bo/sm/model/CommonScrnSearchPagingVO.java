package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommoScrnSearchVO
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 화면 검색 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08      Doo-Won Lee        최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonScrnSearchPagingVO extends CommonPagingVo {
    private String scrnId;                 //화면ID
    private String scrnNm;                 //화면명
    private String indvInfoRelYn;          //개인정보 포함여부
    private String useYn;                  //사용여부
    private String sysDcd;                 //시스템구분코드
    private String pmTypeCd;               //매체유형코드
}
