package kr.co.daiso.bo.common.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.SocialApiUtil;
import kr.co.daiso.bo.common.model.CommonPathInfo;
import kr.co.daiso.bo.util.FileUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.common.controller
 * fileName       : CmnUtilController
 * author         : Doo-Won Lee
 * date           : 2022-01-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11       Doo-Won Lee         최초생성
 */
@Slf4j
@RestController
@RequestMapping("/common")
public class CmnUtilController {

    @Autowired
    FileUtil fileUtil;

    @Autowired
    SocialApiUtil socialApiUtil;

    @Autowired
    private Environment environment;

    @ApiOperation("이미지 업로드")
    @RequestMapping("/img-file-upld")
//    @PostMapping("/img-file-upld")
    public ResponseEntity<CommonResponseModel> fileUpload(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{
        Map<String, String> resultMap = new HashMap<>();

//        boolean isLocal = Arrays.stream(environment.getActiveProfiles()).anyMatch(profileName -> profileName.equals("local"));
        CommonResponseModel failModel = new CommonResponseModel();
        if (fileUtil.isAllowUpload(file,failModel, FileUtil.DaisoFileType.IMAGE)){

            String datePath = req.getParameter("datePath");
            datePath = (datePath == null) ? "":datePath+"/";
            String newFileName = fileUtil.multipartFileUpload(file, CommonPathInfo.UPLOAD_IMAGE_PATH+datePath);  //파일만 업로드 처리
//            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+file.getOriginalFilename());

            String imagePath = CommonPathInfo.UPLOAD_IMAGE_PATH+datePath;
            switch(CommonPathInfo.SERVER_TYPE){
//                case "local":
//                case "dev":
//                case "dev_cloud":
//                    break;
                case "stg":
                case "stg_cloud":
                case "prd":
                case "prd_cloud":
                    imagePath = imagePath.replace("/BASE/daiso_nas","");
                    imagePath = imagePath.replace("/BASE/daiso","");
                    break;
                default:
                    break;
            }

            resultMap.put("filePath",imagePath+newFileName);
            resultMap.put("fileName",newFileName);
            resultMap.put("filePathOnly",imagePath);
        }
        else{
            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
        }

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("주소 GPS 좌표 변환")
    @GetMapping("/adderss-to-gps")
    public ResponseEntity<CommonResponseModel> getGpsByAddress(@ApiParam("GPS로 변환할 주소")  String address) throws Exception{
        Map<String, String> resultMap = new HashMap<>();
        resultMap = socialApiUtil.getKaKaoMapAddrToGeocode(address);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("파일 업로드 - IDC에서 업로드시(PC)")
    @PostMapping("/file-upld")
    public ResponseEntity<CommonResponseModel> idcFileUpload(@ApiParam("업로드 파일") MultipartFile file, HttpServletRequest req) throws Exception{
        return fileUtil.fileUpload(file, req);
    }
}
