package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.CommonModelSearchVO;
import kr.co.daiso.bo.sm.model.CommonModelVO;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sm.service
 * fileName       : CommonModelService
 * author         : leechangjoo
 * date           : 2022-01-14
 * description    :공통 모델 관리 서비스
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14          leechangjoo         최초생성
 **/
public interface CommonModelService {

    // 제조사 목록을 카운트를 구한다.
    public int iqyMnuftrListCnt(CommonModelSearchVO searchVo);

    // 제조사 목록을 구한다.
    public List<CommonModelVO> iqyMnuftrList(CommonModelSearchVO searchVo);

    // 모델 목록을 카운트를 구한다.
    int iqyModelListCnt(CommonModelSearchVO reqVo);

    // 모델 목록을 구한다.
    List<CommonModelVO> iqyModelList(CommonModelSearchVO reqVo);

    // 등급 목록을 구한다.
    List<CommonModelVO> iqyGrdList(CommonModelSearchVO reqVo);

    // 세부등급 목록을 구한다.
    List<CommonModelVO> iqyDetailGrdList(CommonModelSearchVO reqVo);

    // 모델그룹 목록을 구한다.
    List<CommonModelVO> iqyModelGroupList(CommonModelSearchVO reqVo);
}

