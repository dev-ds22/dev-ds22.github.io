package kr.co.daiso.bo.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * packageName    : kr.co.daiso.bo.config
 * fileName       : LoggingInterCeptor
 * author         : Doo-Won Lee
 * date           : 2022-01-07
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-07      Doo-Won Lee      최초생성
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class LoggingInterceptor implements HandlerInterceptor {
    private final ObjectMapper objectMapper;

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("afterCompletion");
        if (request.getClass().getName().contains("SecurityContextHolderAwareRequestWrapper")
        ||request.getClass().getName().contains("StandardMultipartHttpServletRequest")) return;

        final ContentCachingRequestWrapper cachingRequest = (ContentCachingRequestWrapper) request;
        final ContentCachingResponseWrapper cachingResponse = (ContentCachingResponseWrapper) response;
        if (cachingRequest.getContentType() != null && cachingRequest.getContentType().contains("application/json")) {
            if (cachingRequest.getContentAsByteArray() != null && cachingRequest.getContentAsByteArray().length != 0){
                log.info("Request Body : {}", objectMapper.readTree(cachingRequest.getContentAsByteArray()));
            }
        }
        if (cachingResponse.getContentType() != null && cachingResponse.getContentType().contains("application/json")) {
            if (cachingResponse.getContentAsByteArray() != null && cachingResponse.getContentAsByteArray().length != 0) {
                log.info("Response Body : {}", objectMapper.readTree(cachingResponse.getContentAsByteArray()));
            }
        }
    }

//    @Override
//    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
//        final ContentCachingResponseWrapper cachingResponse = (ContentCachingResponseWrapper) response;
//        if (cachingResponse.getContentType() != null && cachingResponse.getContentType().contains("application/json")) {
//            log.info("postHandle Response Body : {}", objectMapper.readTree(cachingResponse.getContentAsByteArray()));
//            Map<String,String> data = objectMapper.readValue(cachingResponse.getContentAsByteArray(), LinkedHashMap.class);
//            log.info(data.toString());
//            if (data.toString().indexOf("<img")>0){
//                log.info("대상");
//            }
//            else{
//                log.info("대상아님");
//            }
//        }
//
//        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
//    }
}
//public class LoggingInterceptor extends HandlerInterceptorAdapter {
//    private final ObjectMapper objectMapper;
//
//    @Override public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
//        if (request.getClass().getName().contains("SecurityContextHolderAwareRequestWrapper")
//                ||request.getClass().getName().contains("StandardMultipartHttpServletRequest")) return;
//
//        final ContentCachingRequestWrapper cachingRequest = (ContentCachingRequestWrapper) request;
//        final ContentCachingResponseWrapper cachingResponse = (ContentCachingResponseWrapper) response;
//        if (cachingRequest.getContentType() != null && cachingRequest.getContentType().contains("application/json")) {
//            if (cachingRequest.getContentAsByteArray() != null && cachingRequest.getContentAsByteArray().length != 0){
//                log.info("Request Body : {}", objectMapper.readTree(cachingRequest.getContentAsByteArray()));
//            }
//        }
//        if (cachingResponse.getContentType() != null && cachingResponse.getContentType().contains("application/json")) {
//            if (cachingResponse.getContentAsByteArray() != null && cachingResponse.getContentAsByteArray().length != 0) {
//                log.info("Response Body : {}", objectMapper.readTree(cachingResponse.getContentAsByteArray()));
//            }
//        }
//    }
//}