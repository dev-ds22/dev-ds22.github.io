package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : BatchLogSearchVO
 * author         : Doo-Won Lee
 * date           : 2022-02-15
 * description    : 배치 실행 로그 검색 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-15      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class BatchLogSearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String status;
}
