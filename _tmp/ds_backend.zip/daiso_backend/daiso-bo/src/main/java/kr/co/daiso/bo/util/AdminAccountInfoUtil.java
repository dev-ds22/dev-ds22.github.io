package kr.co.daiso.bo.util;

import kr.co.daiso.bo.login.model.AdminAccountInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : AdminAccountInfoUtil
 * author         : Doo-Won Lee
 * date           : 2021-12-17
 * description    : 로그인한 관리자의 정보제공 유틸
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-17     Doo-Won Lee        최초생성
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AdminAccountInfoUtil {
    Authentication auth = null;
    AdminAccountInfo accountInfo = new AdminAccountInfo();
    public AdminAccountInfo getAccountInfo() {
        auth = SecurityContextHolder.getContext().getAuthentication();
        if (null!=auth && !"anonymousUser".equals(auth.getPrincipal()) )
            accountInfo = (AdminAccountInfo)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        else accountInfo = null;
        return accountInfo;
    }

    /**
     * methodName : getUsrId
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 사용자ID를 구한다.
     *
     * @return String
     */
    public String getUsrId() {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getUsrId)
                .orElse(null);
    }

    /**
     * methodName : getloginId
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 로그인 아이디를 구한다.
     *
     * @return String
     */
    public String getloginId()  {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getId)
                .orElse(null);
    }

    /**
     * methodName : getUsrCd
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 UCMS 아이디를 구한다.
     *
     * @return String
     */
    public String getUsrCd() {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getUsrCd)
                .orElse(null);
    }

    /**
     * methodName : getUsrType
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 사용자 타입을 구한다.
     *
     * @return String
     */
    public String getUsrType()  {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getUsrType)
                .orElse(null);
    }

    /**
     * methodName : getUsrNm
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 사용자 명을 구한다.
     *
     * @return String
     */
    public String getUsrNm()  {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getUsrNm)
                .orElse(null);
    }

    /**
     * methodName : getUsrNm
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 부서명을 구한다.
     *
     * @return String
     */
    public String getDept1()  {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getDept1)
                .orElse(null);
    }

    /**
     * methodName : getUsrNm
     * author : Doo-Won Lee
     * description : 로그인된 관리자의 ID를 구한다.
     *
     * @return String
     */
    public String getId()  {
        return Optional.ofNullable(getAccountInfo())
                .map(AdminAccountInfo::getId)
                .orElse(null);
    }
}
