package kr.co.daiso.bo.util;

import kr.co.daiso.bo.common.model.CommonPathInfo;
// import com.softforum.xdbe.XdbHelper;
// import com.softforum.xdbe.xCrypto;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class XdbUtil {
	
//	public static String svrip = Util.XDB_URL;
	protected final static	Log LOGGER= LogFactory.getLog(XdbUtil.class);

	
	// Hash 암호화(비밀번호 : sha128)
	public static String getHashEncrypt(String originalStr) {
		String encryptStr = "";
		
		try {
			// XdbHelper tXdbHelper_P  = new XdbHelper();
			// encryptStr    = tXdbHelper_P.Hash (originalStr);
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getHashEncrypt Exception e: " + e);
		}
		finally {
			
		}
		return encryptStr;
	}
			
	// Hash 암호화(sha256)
	public static String getHashEncryptSha256(String originalStr) {
		String encryptStr = "";
		try {
			// encryptStr    = xCrypto.Hash(6,  originalStr);		// sha256
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getHashEncryptSha256 Exception e: " + e);
		}		
		return encryptStr;
	}
	
	// Hash 암호화
	// 2014/07 암호화 sha256으로 변경
	public static Boolean getHashEncryptCheck(String originalStr, String pwdStr) {
		Boolean pwdBoolean = false;
		String encryptStr = originalStr;
		
		try {
			// XdbHelper tXdbHelper_N = new XdbHelper();
			
			// 기존 pwd가 sha128으로 된 경우 128로 암호화 
			if (pwdStr.length() < 41) {	
				// encryptStr	= tXdbHelper_N.Hash (originalStr);	
			}else{
				// encryptStr	= xCrypto.Hash(6,  originalStr);		// sha256
			}
			// 비번이 동일한 경우
			if (encryptStr.equals(pwdStr)) {
				pwdBoolean = true;
			}			
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getHashEncrypt Exception e: " + e);
		}
		finally {
			
		}
		
		return pwdBoolean;
	}
	
	/**
	 * 일반 암호화(일반 정보)
	 * @param originalStr
	 * @return
	 */
	public static String getNormalEncrypt(String originalStr) {
		String encryptStr = "";
		OutputStreamWriter wr = null;
		BufferedReader	postRes = null;
		
		try {
//			XdbHelper tXdbHelper_N = getNormalcon();
//			
//			encryptStr    = tXdbHelper_N.Encrypt (originalStr);
			
			
			
			/* 암호화 오류로 임시로 처리함 */
			StringBuilder	resultBuffer	= new StringBuilder();
			String			data 			= "i_sActionFlag=TEST&i_sBoardCode=" + URLEncoder.encode(originalStr, "UTF-8");
			// POST방식으로 호출
			URL url =  new URL("http://www.daisoauction.com/test/getNormalEncrypt.do");
			URLConnection conn = url.openConnection();
			// If you invoke the method setDoOutput(true) on the URLConnection, it will always use the POST method.
			conn.setDoOutput(true);
			wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			wr.close();
			postRes			= new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
			String			buf				= "";
			while((buf = postRes.readLine()) != null){ //-1이 아니고 null
				resultBuffer.append(buf);
			}
			postRes.close();
			JSONObject	object		= (JSONObject)JSONValue.parse(resultBuffer.toString());
			encryptStr	= object.get("result").toString();
			/* 암호화 오류로 임시로 처리함 */
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try{ postRes.close(); }catch(IOException e){ e.printStackTrace(); }
			try{ wr.close(); }catch(IOException e){ e.printStackTrace(); }
		}
		
		
		return encryptStr;
	}
	
	/**
	 * 패턴 암호화(주민번호)
	 * @param originalStr
	 * @return
	 */
	public static String getPatternEncrypt(String originalStr) {
		String encryptStr = "";
		OutputStreamWriter wr = null;
		BufferedReader	postRes = null;
		
		try {
//			XdbHelper tXdbHelper_P = getPatterncon();
//			
//			encryptStr    = tXdbHelper_P.Encrypt (originalStr);
			
			
			
			/* 암호화 오류로 임시로 처리함 */
			StringBuilder	resultBuffer	= new StringBuilder();
			String			data 			= "i_sActionFlag=TEST&i_sBoardCode=" + URLEncoder.encode(originalStr, "UTF-8");
			// POST방식으로 호출
			URL url =  new URL("http://www.daisoauction.com/test/getPatternEncrypt.do");
			URLConnection conn = url.openConnection();
			// If you invoke the method setDoOutput(true) on the URLConnection, it will always use the POST method.
			conn.setDoOutput(true);
			wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			
			postRes			= new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
			String			buf				= "";
			while((buf = postRes.readLine()) != null){ //-1이 아니고 null
				resultBuffer.append(buf);
			}
			postRes.close();
			JSONObject	object		= (JSONObject)JSONValue.parse(resultBuffer.toString());
			encryptStr	= object.get("result").toString();
			/* 암호화 오류로 임시로 처리함 */
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getPatternEncrypt Exception e: " + e);
		}
		finally {
			try{ postRes.close(); }catch(IOException e){ e.printStackTrace(); }
			try{ wr.close(); }catch(IOException e){ e.printStackTrace(); }
		}
		
		
		return encryptStr;
	}
	
	/**
	 * 일반 암호화 디코드(일반 정보)
	 * @param encryptStr
	 * @return
	 */
	public static String getNormalDecrypt(String encryptStr) {
		String originalStr = "";
		OutputStreamWriter wr = null;
		BufferedReader	postRes = null;
		
		try {
//			XdbHelper tXdbHelper_N = getNormalcon();
//			
//			originalStr    = tXdbHelper_N.Decrypt (encryptStr);
			
			
			
			/* 암호화 오류로 임시로 처리함 */
			StringBuilder	resultBuffer	= new StringBuilder();
			String			data 			= "i_sActionFlag=TEST&i_sBoardCode=" + URLEncoder.encode(encryptStr, "UTF-8");
			// POST방식으로 호출
			URL url =  new URL("http://www.daisoauction.com/test/getNormalDecrypt.do");
			URLConnection conn = url.openConnection();
			// If you invoke the method setDoOutput(true) on the URLConnection, it will always use the POST method.
			conn.setDoOutput(true);
			wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			
			postRes			= new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
			String			buf				= "";
			while((buf = postRes.readLine()) != null){ //-1이 아니고 null
				resultBuffer.append(buf);
			}
			postRes.close();
			JSONObject	object		= (JSONObject)JSONValue.parse(resultBuffer.toString());
			originalStr	= object.get("result").toString();
			/* 암호화 오류로 임시로 처리함 */
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getNormalEncrypt Exception e: " + e);
		}
		finally {
			try{ postRes.close(); }catch(IOException e){ e.printStackTrace(); }
			try{ wr.close(); }catch(IOException e){ e.printStackTrace(); }
		}
		
		
		return originalStr;
	}
	
	/**
	 * 패턴 암호화 디코드(주민번호)
	 * @param encryptStr
	 * @return
	 */
	public static String getPatternDecrypt(String encryptStr) {
		String originalStr = "";
		OutputStreamWriter wr = null;
		BufferedReader	postRes = null;
		
		try {
//			XdbHelper tXdbHelper_P = getPatterncon();
//			
//			originalStr    = tXdbHelper_P.Decrypt (encryptStr);
			
			
			
			/* 암호화 오류로 임시로 처리함 */
			StringBuilder	resultBuffer	= new StringBuilder();
			String			data 			= "i_sActionFlag=TEST&i_sBoardCode=" + URLEncoder.encode(encryptStr, "UTF-8");
			// POST방식으로 호출
			URL url =  new URL("http://www.daisoauction.com/test/getPatternDecrypt.do");
			URLConnection conn = url.openConnection();
			// If you invoke the method setDoOutput(true) on the URLConnection, it will always use the POST method.
			conn.setDoOutput(true);
			wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			
			postRes			= new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
			String			buf				= "";
			while((buf = postRes.readLine()) != null){ //-1이 아니고 null
				resultBuffer.append(buf);
			}
			
			JSONObject	object		= (JSONObject)JSONValue.parse(resultBuffer.toString());
			originalStr	= object.get("result").toString();
			/* 암호화 오류로 임시로 처리함 */
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getPatternDecrypt Exception e: " + e);
		}
		finally {
			try{ postRes.close(); }catch(IOException e){ e.printStackTrace(); }
			try{ wr.close(); }catch(IOException e){ e.printStackTrace(); }
		}
		
		
		return originalStr;
	}	
	
	/**
	 * 일반 복호화
	 * @param encryptStr 암호화 문자열
	 * @return 복호화 문자열
	 */
	public static String getPosNormalDecrypt(String encryptStr) {
		String originalStr = "";
		
		try {
			// XdbHelper tXdbHelper_N = getNormalcon();
			// originalStr    = tXdbHelper_N.Decrypt (encryptStr);
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getPosNormalDecrypt Exception e: " + e);
		}
		finally {
			
		}
		
		
		return originalStr;
	}
	
	/**
	 * 일반 암호화
	 * @param originalStr 평문 문자열
	 * @return 암호화 문자열
	 */
	public static String getPosNormalEncrypt(String originalStr) {
		
		String encryptStr = "";
		
		try {
			// XdbHelper tXdbHelper_N = getNormalcon();			
			// encryptStr    = tXdbHelper_N.Encrypt (originalStr);
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("XdbUtil getPosNormalEncrypt Exception e: " + e);
		}
		finally {
			
		}
		
		
		return encryptStr;
	}
}
