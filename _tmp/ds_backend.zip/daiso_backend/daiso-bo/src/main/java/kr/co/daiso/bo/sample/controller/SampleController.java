package kr.co.daiso.bo.sample.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.daiso.bo.common.model.CommonPathInfo;
import kr.co.daiso.bo.common.service.LogService;
import kr.co.daiso.bo.message.model.AtaVO;
import kr.co.daiso.bo.message.model.SmsVO;
import kr.co.daiso.bo.message.service.AtaService;
import kr.co.daiso.bo.message.service.SmsService;
import kr.co.daiso.bo.sample.model.SampleValidateVO;
import kr.co.daiso.bo.sample.service.SampleService;
import kr.co.daiso.bo.sm.model.CommonCodeManageVO;
import kr.co.daiso.bo.sm.model.CommonCodeSearchVO;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import kr.co.daiso.bo.sm.service.CommonScrnService;
import kr.co.daiso.bo.util.AdminCmnUtil;
import kr.co.daiso.bo.util.FileUtil;
import kr.co.daiso.bo.util.ValidationExcuteUtil;
import kr.co.daiso.bo.util.XdbUtil;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.common.util.ExcelUtil;
import kr.co.daiso.common.util.MailUtil;
import kr.co.daiso.common.util.SocialApiUtil;
import kr.co.daiso.common.util.TestUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class SampleController {

    @Autowired
    SampleService sampleService;

    @Autowired
    CommonScrnService commonScrnService;

    @Autowired
    CommonCodeManageService commonCodeManageService;

    @Autowired
    ValidationExcuteUtil validationExcuteUtil;

    ExcelUtil excelUtil = new ExcelUtil();

    @Autowired
    FileUtil fileUtil;

    @Autowired
    AtaService ataService;

    @Autowired
    SmsService smsService;

    @Autowired
    AdminCmnUtil adminCmnUtil;

    @Autowired
    MailUtil mailUtil;

    @Autowired
    SocialApiUtil socialApiUtil;

    @Autowired
    LogService logService;

    @GetMapping("/admin/sample")
    public String apiSample(){
        TestUtil testUtil = new TestUtil();
        testUtil.testPrint();
        return "admin Test Sample  Tag3";
    }

    @PostMapping("/sample/fileUpload")
    public ResponseEntity<CommonResponseModel>  fileUpload(MultipartFile file, HttpServletRequest req) throws Exception{
        Map<String, String> resultMap = new HashMap<>();

        CommonResponseModel failModel = new CommonResponseModel();
        if (fileUtil.isAllowUpload(file,failModel)){
            String newFileName = fileUtil.multipartFileUpload(file, CommonPathInfo.UPLOAD_IMAGE_PATH);  //파일만 업로드 처리
//            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+file.getOriginalFilename());
            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+newFileName);
            resultMap.put("fileName",newFileName);
        }
        else{
            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
        }
        return  new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

//    @PostMapping("/admin/excelFileUpload")
//    public String excelFileUpload(MultipartFile file, HttpServletRequest req) throws Exception{
//        sampleService.excelUtilTest(file,req);                           //엑셀 업로드 테스트
////        sampleService.fileUploadTest(file, CommonPathInfo.UPLOAD_ROOT);  //파일만 업로드 처리
//        return  file.getOriginalFilename();
//    }

    @PostMapping("/admin/excelFileUpload")
    public ResponseEntity<CommonResponseModel> excelFileUpload(MultipartFile file, HttpServletRequest req) throws Exception{

        Map<String, String> resultMap = new HashMap<>();

        CommonResponseModel failModel = new CommonResponseModel();

        sampleService.excelUtilTest(file,req);  //엑셀 업로드 테스트

//        tableMgtService.tableMgtRemvalExcelFileUpload(file,req);
//        if (fileUtil.isAllowUpload(file,failModel)){
//            String newFileName = fileUtil.multipartFileUpload(file, CommonPathInfo.UPLOAD_IMAGE_PATH);  //파일만 업로드 처리
////            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+file.getOriginalFilename());
//            resultMap.put("filePath",CommonPathInfo.UPLOAD_IMAGE_PATH+newFileName);
//            resultMap.put("fileName",newFileName);
//            sampleService.excelUtilTest(file,req);  //엑셀 업로드 테스트
//        }
//        else{
//            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
//        }
        return  new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }


    @ApiOperation("Excel Download Sample")
    @GetMapping("/admin/sampleExcelService")
    public void apiSampleExcelService(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<String> columneNames = new ArrayList<>();
        List<String> headerNames = new ArrayList<>();

        headerNames.add("마스터코드");
        headerNames.add("마스터코드명");
        headerNames.add("마스터코드영문명");
//        columneNames.add("scrnId");
//        columneNames.add("scrnNm");
//        columneNames.add("scrnUrl");
//        columneNames.add("indvInfoRelYn");

        columneNames.add("masterCd");
        columneNames.add("masterCdNm");
        columneNames.add("masterCdEngNm");

//        CommonScrnSearchPagingVO searchVO = new CommonScrnSearchPagingVO();
        CommonCodeSearchVO searchVO = new CommonCodeSearchVO();

//        Function<CommonScrnSearchPagingVO,List<CommonScrnVO>> function = commonScrnService::getSearchScrnList;
        Function<CommonCodeSearchVO,List<CommonCodeManageVO>> function = commonCodeManageService::getMstCodeList;
        excelUtil.makeExcelFileToResponse("sampleService.xlsx",headerNames,columneNames, function, response, searchVO);

        int cnt = commonCodeManageService.getMstCodeListCount(searchVO);
        logService.regDownloadRsn(request, "마스터코드 목록","마스터코드, 마스터 코드명, 마스터코드 영문명", cnt);

    }

    @ApiOperation("Validation 샘플")
    @GetMapping("/sample/sampleValidate")
    public ResponseEntity<CommonResponseModel> sampleValidate(@ApiParam("Hibernate ValidationVO") @Valid SampleValidateVO sampleVO, BindingResult result) {
        if (result.hasErrors()){
            List<ObjectError> allErrors = result.getAllErrors();
             return validationExcuteUtil.makeValidationResult(allErrors);
        }
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel("Success"), HttpStatus.OK);
    }

    @ApiOperation("Validation 샘플2")
    @PostMapping("/sample/sampleValidate2")
    public ResponseEntity<CommonResponseModel> sampleValidate2(@RequestBody @ApiParam("Hibernate ValidationVO") @Valid SampleValidateVO sampleVO) {
        log.info("-----------/sample/sampleValidate2");
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel("Success"), HttpStatus.OK);
    }

    @ApiOperation("알림톡 테스트")
    @GetMapping("/sample/atatest")
    public void atatest() throws Exception{
        log.info("-----------//sample/atatest");
        AtaVO ataVO = new AtaVO();
        Map<String, Object> ataMap = new HashMap<String, Object>();
        String v_enc_task_ppos_mbpno = "01011111111";
        String v_customer_mpno = "01022222222";

        ataVO.setTemplateCode("EC00000024");
        ataVO.setRecipientNum(v_enc_task_ppos_mbpno.replaceAll("[-]",""));
        ataVO.setSubject("제목");

        ataMap.put("V_CARNM", "차번호");
        ataMap.put("V_CARNUM", "차번호1");
        ataMap.put("V_CUSTOMERNM", "구매자명");
        ataMap.put("V_CUSTOMER_MPNO", v_customer_mpno);
        ataMap.put("V_RESV_CNCL_DT", "취소일?");
        ataMap.put("V_RESV_CNCL_TM", "취소시간?");
        ataMap.put("V_URL", "https://localhost:3003");

        ataService.insertAta(ataVO,ataMap);

    }

    @ApiOperation("SMS 테스트")
    @GetMapping("/sample/smsTest")
    public void smsTest() throws Exception{
        log.info("-----------//sample/atatest");
        SmsVO smsVO = new SmsVO();
        Map<String, Object> ataMap = new HashMap<String, Object>();
        String v_enc_task_ppos_mbpno = "01011111111";
        smsVO.setSubject("제목");
        smsVO.setCallback(CommonPathInfo.CAR_INFO_FROM_SMS);    // 보내는 번호
        smsVO.setDstaddr(v_enc_task_ppos_mbpno.replaceAll("[-]",""));              // 받는 번호
        smsVO.setReceiverCd("customer");
        smsVO.setText("문자 내용 테스트");

        smsService.insertSms(smsVO);

    }

    @ApiOperation("휴일여부체크")
    @GetMapping("/sample/checkHoliday")
    public String checkHoliday(HttpServletRequest request) throws Exception {

      log.info("---------------Servlet Version:", request.getServletContext().getMajorVersion());
      return adminCmnUtil.checkHoliday("2022-02-08");
    }

    @ApiOperation("메일테스트체크")
    @GetMapping("/sample/mailTest")
    public void mailTest() throws Exception {
        mailUtil.send("이두원","m2m0006@daiso.com","m2m0006@daiso.com","","title","메일 내용");

        return;
    }
//    @ApiOperation("로그인")
//    @PostMapping("/sample/login_process")
//    public ResponseEntity<CommonResponseModel> sampleLogin(@ApiParam("로그인 요청 정보") @RequestBody @Valid SampleLoginVO loginVo
//            , HttpServletResponse response){
//        return sampleService.loginProcess(loginVo,response);
//    }

    @ApiOperation("Url 바로가기 테스트")
    @GetMapping("/sample/urldowntest")
    public void urldowntest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        adminCmnUtil.getInternetShortCut(request,response,"http://www.google.com","구글바로");

    }

    @ApiOperation("Map 테스트")
    @GetMapping("/sample/maptest")
    public void maptest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        socialApiUtil.getKaKaoMapAddrToGeocode("서울특별시 강남구 역삼로 238 (역삼동)");
    }

    @ApiOperation("file download 테스트")
    @GetMapping("/sample/filedownload")
    public void filedownload(@ApiParam("파일경로") String filePath, HttpServletRequest request, HttpServletResponse response) throws Exception {
        fileUtil.fileDownload(filePath,request,response);
    }

    @RequestMapping("/testEnc")
    public String testEnc(String str) {
        String result = str + "===>" + XdbUtil.getPosNormalEncrypt(str);
        return result;
    }

    @RequestMapping("/testDec")
    public String testDec(String str) {
        String result = str + "===>" + XdbUtil.getPosNormalDecrypt(str);
        return result;
    }
}
