package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CalendarVo;
import kr.co.daiso.bo.sm.model.HolidayVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface HolidayMapper {
    //UCMS 달력 마스터의 해당 연도 달력 데이터를 가져온다
    List<CalendarVo> selectcalendarByYear(HolidayVo holidayVo);

    //UCMS의 달력 마스터 데이터를 저장한다
    int insertcalendar(Map<String, Object> map);

    //해당 연도의 센터명으로 저장된 달력을 가져온다
    List<HolidayVo> selectCanlenderBycntr(HolidayVo holidayVo);

    //연도별 직영점별 생성된 달력에 입력된 휴일을 저장한다
    void updateHolidays(List<HolidayVo> updatedList);
}
