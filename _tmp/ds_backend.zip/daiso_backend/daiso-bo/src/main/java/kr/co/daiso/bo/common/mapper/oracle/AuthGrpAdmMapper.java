package kr.co.daiso.bo.common.mapper.oracle;

import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuScrSaveVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.common.mapper.oracle
 * fileName       : AuthGrpAdmMapper
 * author         : leechangjoo
 * date           : 2021-12-08
 * description    : 관한그룹관리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08          leechangjoo         최초생성
 **/
@Mapper
public interface AuthGrpAdmMapper {

    //권한그룹관리 리스트를 카운트를 구한다.
    int getAuthGrpAdmListCnt(AuthGrpAdmVO authGrpAdmVO);

    //공통 팝업 권한그룹관리 리스트를 구한다.
    List<AuthGrpAdmVO> getCommonAuthGrpAdmListPopup(AuthGrpAdmVO authGrpAdmVO);

    //권한그룹관리 리스트를 구한다.
    List<AuthGrpAdmVO> getAuthGrpAdmList(AuthGrpAdmVO authGrpAdmVO);

    //권한그룹관리 리스트를 추가한다.
    int insertAuthGrpAdmList(AuthGrpAdmVO authGrpAdmVO);

    //권한그룹관리 리스트를 수정한다.
    int updateAuthGrpAdmList(AuthGrpAdmVO authGrpAdmVO);


    //권한그룹별 메뉴관리 리스트를 가져온다.
    List<AuthGrpMenuAdmVO> getAuthGrpMenuAdmList(AuthGrpMenuAdmVO authGrpMenuAdmVO);

    //권한그룹관리 메뉴관리 리스트(True)를 카운트한다.
    int authGrpMenuAdmTureListCnt(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 메뉴관리 리스트(True)를 추가한다.
    int insertAuthGrpMenuAdmTureList(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 메뉴관리 리스트(False)를 삭제한다.
    int deleteAuthGrpMenuAdmFalseList(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 화면관리 리스트(True)를 카운트한다.
    int authGrpScrAdmTureListCnt(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 화면관리 리스트(TRUE)를 추가한다.
    int insertAuthGrpScrAdmTureList(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 화면관리 리스트(TRUE)를 수정한다.
    int updateAuthGrpScrAdmTureList(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

    //권한그룹관리 화면관리 리스트(False)를 삭제한다.
    int deleteAuthGrpScrAdmFalseList(AuthGrpMenuScrSaveVO authGrpMenuScrSaveVO);

}
