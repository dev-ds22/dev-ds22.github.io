package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.bo.sm.model.MenuVO;
import kr.co.daiso.bo.sm.service.CommonMenuService;
import kr.co.daiso.common.model.CommonPagingVo;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.menu.controller
 * fileName       : MenuController
 * author         : kjm
 * date           : 2021-12-08
 * description    : 메뉴관리 관련 기능
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       kjm            최초생성
 */
@RestController
@RequestMapping("/mg/menu")
public class CommonMenuController {

    @Autowired
    CommonMenuService commonMenuService;

    @ApiOperation("메뉴 목록 조회")
    @GetMapping("/getMenuList")
    public ResponseEntity getMenuList(MenuVO menuVO) {
        return new ResponseEntity(new CommonResponseModel<>(commonMenuService.getMenuList(menuVO)), HttpStatus.OK);
    }

    @ApiOperation("메뉴 상세 조회")
    @GetMapping("/getMenuDetail")
    public ResponseEntity getMenuDetail(MenuVO menuVO) {
        CommonResponseModel<MenuVO> commonResponseModel = new CommonResponseModel<>();
        commonResponseModel.setData(commonMenuService.getMenuDetail(menuVO));
        Map<String, Object> extraData = new HashMap<>();
        extraData.put("menuAuthGrp", commonMenuService.getMenuAuthGrpList(menuVO));
        commonResponseModel.setExtraData(extraData);
        return new ResponseEntity(commonResponseModel, HttpStatus.OK);
    }

    @ApiOperation("메뉴 정보 검색")
    @GetMapping("/searchMenu")
    public ResponseEntity searchMenu(MenuVO menuVO) {
        menuVO.setTotal(commonMenuService.getMenuListCount(menuVO));
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("pagination", (CommonPagingVo) menuVO);
        resultMap.put("menuList", commonMenuService.searchMenu(menuVO));
        return new ResponseEntity<>(new CommonResponseModel<>(resultMap), HttpStatus.OK);
    }

    @ApiOperation("메뉴 정보 추가 변경")
    @PostMapping("/updateMenu")
    public ResponseEntity updateMenu(@RequestBody MenuVO menuVO) {
        commonMenuService.updateMenu(menuVO);
        return new ResponseEntity(HttpStatus.OK);

    }

    @ApiOperation("메뉴 구조 수정")
    @PostMapping("/updateMenuTree")
    public ResponseEntity updateMenuTree(@RequestBody List<MenuVO> updateMenuList) {
        commonMenuService.updateMenuTree(updateMenuList);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ApiOperation("GNB 메뉴 조회")
    @GetMapping("/menu-and-auth")
    public ResponseEntity getMenuAndAuthList() {
        return new ResponseEntity(new CommonResponseModel<>(commonMenuService.getMenuAndAuthList()), HttpStatus.OK);
    }

}
