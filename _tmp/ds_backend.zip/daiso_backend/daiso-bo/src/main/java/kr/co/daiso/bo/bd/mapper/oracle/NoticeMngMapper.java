package kr.co.daiso.bo.bd.mapper.oracle;

import kr.co.daiso.bo.bd.model.NoticeVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.bd.mapper.oracle
 * fileName       : NoticeMngMapper
 * author         : kjm
 * date           : 2022-01-20
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-20       kjm            최초생성
 */
@Mapper
public interface NoticeMngMapper {

    // 공지사항 목록 개수조회
    int getNoticeTotalCount(NoticeVO noticeVO);

    // 공지사항 목록 조회
    List<NoticeVO> searchNoticeList(NoticeVO noticeVO);

    // 공지사항 상세 조회
    NoticeVO searchNotice(String bltbdCd);

    // 공지사항 삭제
    int deleteNotice(NoticeVO noticeVO);

    // 공지사항 등록
    void insertNotice(NoticeVO noticeVO);

    // 공지사항 수정
    void updateNotice(NoticeVO noticeVO);
}
