package kr.co.daiso.bo.sample.controller;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



/**
 * packageName    : kr.co.daiso.bo.sample.controller
 * fileName       : JasyptController
 * author         : Byung-chul Park
 * date           : 2022-05-19
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-05-19     Byung-chul Park   최초생성
 */
@Slf4j
@RestController
public class JasyptController {

    @ApiOperation("jasypt 테스트")
    @GetMapping("/sample/JTest")
    public void jasyptTest() {
        StandardPBEStringEncryptor pbeEnc = new StandardPBEStringEncryptor();
        pbeEnc.setAlgorithm("PBEWithMD5AndDES");
        pbeEnc.setPassword("daiso");

        //DEV
//        String url = "jdbc:oracle:thin:@172.168.202.20:1521:b2c";
//        String username = "daisomall_usr";
//        String password = "daisomall_pwd";

        //QA
//        String url = "jdbc:oracle:thin:@172.168.202.60:1521:b2c";
//        String username = "daisomall_qa_usr";
//        String password = "daisomall_qa_pwd";

        //dev2
//        String url = "jdbc:oracle:thin:@172.168.202.20:1521:b2c";
//        String username = "tmp_usr";
//        String password = "tmp_pwd";

        //PRD
        String url = "jdbc:oracle:thin:@172.168.202.60:1521:b2c";
        String username = "daisomall_usr";
        String password = "daisomall_pwd";

        log.info("기존 URL :: " + url + " | 변경 URL :: " + pbeEnc.encrypt(url));
        log.info("기존 use username :: " + pbeEnc.encrypt(username));
        log.info("기존 password :: " + password + " | 변경 rname :: \" + username + \" | 변경password :: " + pbeEnc.encrypt(password));
        return;
    }

}
