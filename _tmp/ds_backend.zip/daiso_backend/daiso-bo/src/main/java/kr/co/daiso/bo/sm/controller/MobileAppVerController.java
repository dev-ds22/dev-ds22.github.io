package kr.co.daiso.bo.sm.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.service.LogService;
import kr.co.daiso.bo.sm.model.MobileAppVerSearchVO;
import kr.co.daiso.bo.sm.model.MobileAppVerVO;
import kr.co.daiso.bo.sm.service.ArticleService;
import kr.co.daiso.bo.sm.service.MobileAppVerService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : MobileAppVer
 * author         : Byung-chul Park
 * date           : 2022-04-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-06       Byung-chul Park  최초생성
 */

@Slf4j
@RequestMapping("/sysmg/mobileAppVer")
@RestController
public class MobileAppVerController {

    @Autowired
    ArticleService articleService;
    @Autowired
    LogService logService;
    @Autowired
    MobileAppVerService mobileAppVerService;

    private final String STR_LOG_LIST = "logList";
    private final String STR_SEARCH_INFO = "searchInfo";

    @ApiOperation("모바일 APP버전관리 조회(페이징사용)")
    @GetMapping("mobile-app-ver")
    public ResponseEntity<CommonResponseModel> getMobileAppVer(@ApiParam("모바일 APP버전관리 조회 정보") MobileAppVerSearchVO mobileAppVerSearchVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        mobileAppVerSearchVO.setTotal(mobileAppVerService.getMobileAppVerCnt(mobileAppVerSearchVO));
        List<MobileAppVerVO> list	= mobileAppVerService.getMobileAppVer(mobileAppVerSearchVO);
        log.info(">>>>>>>>>" + mobileAppVerSearchVO);

        resultMap.put(STR_LOG_LIST, list);
        resultMap.put(STR_SEARCH_INFO, mobileAppVerSearchVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("모바일 APP버전관리 저장 & 업데이트")
    @PostMapping("/mobileAppVerReg")
    public ResponseEntity<CommonResponseModel> regMobileAppVer(@ApiParam("모바일 APP버전관리 정보")@RequestBody LinkedHashMap<String,Object> mobileAppVerVO){
        log.info("mobileAppVerVO >>>>>>>>>" + mobileAppVerVO);
      //mobileAppVerService.regMobileAppVer(mobileAppVerVO);
        CommonResponseModel resultModel = mobileAppVerService.regMobileAppVer(mobileAppVerVO);

        return new ResponseEntity<CommonResponseModel>(resultModel, HttpStatus.OK);

    }

    @ApiOperation("모바일 APP버전정보 조회")
    @GetMapping("mobile-app-version")
    public ResponseEntity<CommonResponseModel> getMobileAppVersion(@ApiParam("모바일 APP버전관리 조회 정보")MobileAppVerVO mobileAppVerVO, HttpServletResponse response) throws Exception{
        Map<String, Object> resultMap = new HashMap<>();

        MobileAppVerVO resultVo = mobileAppVerService.getMobileAppVersion(mobileAppVerVO);
//        List<MobileAppVerVO> list	= mobileAppVerService.getMobileAppVersion(mobileAppVerVO);

        log.info("mobileAppVerVO>>>>" + mobileAppVerVO);
        resultMap.put("result", resultVo);
//        resultMap.put(STR_LOG_LIST, list);
//        resultMap.put(STR_SEARCH_INFO, mobileAppVerVO);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

//    @ApiOperation("모바일 APP버전정보 조회")
//    @GetMapping("mobile-app-version")
//    public ResponseEntity<CommonResponseModel> getMobileAppVersion(@ApiParam("모바일 APP버전관리 조회 정보")  String osType, HttpServletResponse response) throws Exception{
//        Map<String, Object> resultMap = new HashMap<>();
//
//        MobileAppVerVO mobileAppVerVO = new MobileAppVerVO();
//        mobileAppVerVO.setOsDvsCd(osType);
//        List<MobileAppVerVO> list	= mobileAppVerService.getMobileAppVersion(mobileAppVerVO);
//        log.info(">>>>>>>>>" + mobileAppVerVO);
//
//        resultMap.put(STR_LOG_LIST, list);
//        resultMap.put(STR_SEARCH_INFO, mobileAppVerVO);
//        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
//    }

}
