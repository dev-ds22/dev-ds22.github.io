package kr.co.daiso.bo.bd.mapper.oracle;

import kr.co.daiso.bo.bd.model.PopupDetailVO;
import kr.co.daiso.bo.bd.model.PopupVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.bd.mapper.oracle
 * fileName       : PopupMapper
 * author         : kjm
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14       kjm            최초생성
 */
@Mapper
public interface PopupMngMapper {

    // 팝업 목록 개수 조회
    int searchPopupListCount(PopupVO popupVO);
    
    // 팝업 목록 조회
    List<PopupVO> searchPopupList(PopupVO popupVO);

    // 팝업 상세 조회
    PopupDetailVO searchPopupDetail(PopupDetailVO popupDetailVO);

    // 팝업 조회
    PopupVO searchPopup(String ppupCd);

    // 새 팝업 번호 조회 
    String newPpupCd();

    // 팝업 생성
    void insertPopup(PopupVO popupVO);

    // 팝업 상세 등록
    void insertPopupDetail(PopupDetailVO pcDetail);

    // 팝업 수정
    void updatePopup(PopupVO popupVO);

    // 팝업 상세 수정
    void updatePopupDetail(PopupDetailVO pcDetail);

    // 팝업 삭제
    void deletePopup(PopupVO popupVO);

    // 팝업 상세 삭제
    void deletePopupDetail(PopupDetailVO popupDetailVO);

   
}
