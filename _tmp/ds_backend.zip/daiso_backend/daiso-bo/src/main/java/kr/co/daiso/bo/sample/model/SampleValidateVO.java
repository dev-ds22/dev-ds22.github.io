package kr.co.daiso.bo.sample.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * packageName    : kr.co.daiso.bo.sample.model
 * fileName       : SampleValidateVO
 * author         : Doo-Won Lee
 * date           : 2022-01-10
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-10       Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SampleValidateVO extends BaseModel {

    @Size(min = 2, max = 14, message = "common.valid.lengthRange")
    private String lengthRangeCheck;

    @Size(min = 2, message = "common.valid.lengthMin")
    private String lengthMinCheck;

    @Size(max = 3, message = "common.valid.lengthMax")
    private String lengthMaxCheck;

    @NotNull(message = "common.valid.required")
    private String requireCheck;

}
