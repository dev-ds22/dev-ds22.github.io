package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.annotation.MaskingClass;
import kr.co.daiso.common.annotation.MaskingField;
import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AdminCnntnLogVO
 * author         : Doo-Won Lee
 * date           : 2022-01-18
 * description    : 관리자 접속 로그 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-18      Doo-Won Lee     최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AdminCnntnLogVO extends CommonPagingVo {
    private String usrId;       //사용자 ID
    private String usrNm;      //사용자명
    private String acesUrl;    //접근URL
    private String acesIp;      //접근IP
    private String menuPath;    //메뉴경로
    private String type;        //행위타입
    private String auth;        //권한
    private String authGrpNm;       //권한명
    private String usrAgent;    //browser Agent
    private String menuId;      //메뉴id
}
