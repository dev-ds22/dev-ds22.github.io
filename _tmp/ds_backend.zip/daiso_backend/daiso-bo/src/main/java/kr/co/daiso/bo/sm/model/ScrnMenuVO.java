package kr.co.daiso.bo.sm.model;

import lombok.Data;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : ScrnMenuVO
 * author         : Doo-Won Lee 
 * date           : 2021-12-28
 * description    : 화면과 연관된 메뉴 정보
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-28       Doo-Won Lee          최초생성
 */
@Data
public class ScrnMenuVO {
    private String menuId;          //메뉴 ID
    private String menuNm;          //메뉴 명
    private String fullMenuNm;      //메뉴 전체 경로명
    private String scrnUrl;         //메뉴 화면 경로명
}
