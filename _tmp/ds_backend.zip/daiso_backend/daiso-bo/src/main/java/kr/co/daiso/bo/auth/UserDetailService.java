package kr.co.daiso.bo.auth;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.common.constants.CommonConstants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Map;


/**
 * packageName    : kr.co.daiso.bo.auth
 * fileName       : UserDetailService.java
 * author         : Won-Tae Kim 
 * date           : 2022. 12. 14.
 * description    : UserDetailsService를 구현한다
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022. 12. 14.     Won-Tae Kim 	최초생성
 */
@Service
@RequiredArgsConstructor
public class UserDetailService implements UserDetailsService {

    @Autowired
    JwtTokenProvider tokenProvider;

    /**
     * methodName : loadUserByUsername
     * author : Doo-Won Lee
     * description : Token 정보로 유저 정보를 구한다.
     *
     * @param userToken
     * @return response cookie
     */
    @Override
    public UserDetails loadUserByUsername(String userToken) throws UsernameNotFoundException {
        Key secretKey = tokenProvider.getJwtSigningKey(CommonConstants.JWT_SECRET_KEY_ADMIN);

        ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        Map<String,Object> tokenAccount = (Map<String, Object>) Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(userToken).getBody().get("userInfo");
        Claims claims = Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(userToken).getBody();
      //  AccountInfo accountInfo = objectMapper.convertValue(tokenAccount,AccountInfo.class);

        return objectMapper.convertValue(tokenAccount, AdminAccountInfo.class);
    }
}
