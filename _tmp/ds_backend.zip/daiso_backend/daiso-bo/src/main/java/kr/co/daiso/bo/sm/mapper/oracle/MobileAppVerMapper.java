package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.MobileAppVerSearchVO;
import kr.co.daiso.bo.sm.model.MobileAppVerVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : LogMapper
 * author         : Byung-Chul Park
 * date           : 2022-04-06
 * description    : 모바일 앱 버전관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-04-06    Byung-Chul Park      최초생성
 */

@Mapper
public interface MobileAppVerMapper {


    //모바일 APP버전관리를 조회한다.
    List<MobileAppVerVO> getMobileAppVer(MobileAppVerSearchVO mobileAppVerSearchVO);

    //모바일 APP버전관리 카운트를 조회한다.
    int getMobileAppVerCnt(MobileAppVerSearchVO mobileAppVerSearchVO);

    //모바일 APP버전관리를 등록한다.
     void regMobileAppVer(List<MobileAppVerVO> regList);

    //모바일 APP버전정보를 조회한다.
    MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO);

//    List<MobileAppVerVO> getMobileAppVersion(MobileAppVerVO mobileAppVerVO);
}
