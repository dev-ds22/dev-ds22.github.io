package kr.co.daiso.bo.bd.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * packageName    : kr.co.daiso.bo.bd.model
 * fileName       : FaqVO
 * author         : kjm
 * date           : 2022-01-10
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-10       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class FaqVO extends CommonPagingVo {

    private String sq;          // 순번

    private String qstnClsf;    // 질문분류

    private String regMenuCd;   // 등록메뉴코드

    @NotNull(message = "common.valid.required")
    private String titl;        // 제목

    private String cnts;        // 내용

    private String delYn;       // 삭제여부

    private String sortOrdr;    // 정렬순서
}
