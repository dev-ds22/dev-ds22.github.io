package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : MailSendLogVO
 * author         : Doo-Won Lee
 * date           : 2022-02-14
 * description    : MailSendLogVO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-14      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class MailSendLogVO extends CommonPagingVo {

    private String sndrEmailAddr;                // 발신자이메일주소
    private String sndrNm;                       // 발신자명
    private String rcvrEmailAddr;                // 수신자이메일주소
    private String refrc;                        // 참조
    private String titl;                         // 제목
    private String cnts;                         // 내용
    private String regDt;                        // 등록일자
    private String rgpsIp;                       // 등록자아이피
    private String refrcIp;                      // 참조아이피
}
