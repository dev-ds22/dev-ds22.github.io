package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.bo.sm.mapper.oracle.CommonModelMapper;
import kr.co.daiso.bo.sm.model.CommonModelSearchVO;
import kr.co.daiso.bo.sm.model.CommonModelVO;
import kr.co.daiso.bo.sm.service.CommonModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sm.service.impl
 * fileName       : CommonModelServiceImpl
 * author         : leechangjoo
 * date           : 2022-01-14
 * description    : 공통모델 관리 서비스 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14          leechangjoo         최초생성
 **/
@Service
public class CommonModelServiceImpl implements CommonModelService {

    @Autowired
    CommonModelMapper commonModelMapper;
    /**
     * methodName : IqyMnuftrListCnt
     * author : leechangjoo
     * description : 제조사 목록 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int iqyMnuftrListCnt(CommonModelSearchVO searchVo) {
        return commonModelMapper.iqyMnuftrListCnt(searchVo);
    }

    /**
     * methodName : getMstCodeList
     * author : leechangjoo
     * description : 제조사 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonModelVO>
     */
    @Override
    public List<CommonModelVO> iqyMnuftrList(CommonModelSearchVO searchVo) {
        return commonModelMapper.iqyMnuftrList(searchVo);
    }


    /**
     * methodName : IqyModelListCnt
     * author : leechangjoo
     * description : 모델 목록 카운트를 구한다.
     *
     * @param searchVo
     * @return int
     */
    @Override
    public int iqyModelListCnt(CommonModelSearchVO searchVo) {
        if ( (searchVo.getI_sMakeCd() != null && !searchVo.getI_sMakeCd().equals(""))
                || (searchVo.getI_sCategoryCd() != null && !searchVo.getI_sCategoryCd().equals(""))
                || (searchVo.getI_arrCategoryCd() != null && searchVo.getI_arrCategoryCd().length > 0)
                || (searchVo.getI_sKeyWord() != null && !searchVo.getI_sKeyWord().equals(""))
                || (searchVo.getI_arrMakeCds() != null && searchVo.getI_arrMakeCds().length > 0)
                || (searchVo.getI_arrCategoryCd() != null && searchVo.getI_arrCategoryCd().length > 0)){

            return commonModelMapper.iqyModelListCnt(searchVo);
        }
        else{
            return 0;
        }
    }

    /**
     * methodName : IqyModelList
     * author : leechangjoo
     * description : 모델 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonModelVO>
     */
    @Override
    public List<CommonModelVO> iqyModelList(CommonModelSearchVO searchVo) {
        if ( (searchVo.getI_sMakeCd() != null && !searchVo.getI_sMakeCd().equals(""))
                || (searchVo.getI_sCategoryCd() != null && !searchVo.getI_sCategoryCd().equals(""))
                || (searchVo.getI_arrCategoryCd() != null && searchVo.getI_arrCategoryCd().length > 0)
                || (searchVo.getI_sKeyWord() != null && !searchVo.getI_sKeyWord().equals(""))
                || (searchVo.getI_arrMakeCds() != null && searchVo.getI_arrMakeCds().length > 0)
                || (searchVo.getI_arrCategoryCd() != null && searchVo.getI_arrCategoryCd().length > 0)
                || (searchVo.getI_sModelGrpCd_list() != null && searchVo.getI_sModelGrpCd_list().size() > 0)
                || (searchVo.getAllDataYn() != null && searchVo.getAllDataYn().equals("Y"))){

            return commonModelMapper.iqyModelList(searchVo);
        }
        else{
            return null;
        }
    }

    /**
     * methodName : IqyGrdList
     * author : leechangjoo
     * description : 등급 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonModelVO>
     */
    @Override
    public List<CommonModelVO> iqyGrdList(CommonModelSearchVO searchVo) {
        if (searchVo.getI_sMakeCd() != null && !searchVo.getI_sMakeCd().equals("")
                && searchVo.getI_sModelCd() != null && !searchVo.getI_sModelCd().equals("")){
            return commonModelMapper.iqyGrdList(searchVo);
        }
        else{
            return null;
        }
    }

    /**
     * methodName : IqyDetailGrdList
     * author : leechangjoo
     * description : 세부 등급 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonModelVO>
     */
    @Override
    public List<CommonModelVO> iqyDetailGrdList(CommonModelSearchVO searchVo) {
        if(searchVo.getI_sMakeCd() != null && !searchVo.getI_sMakeCd().equals("")
                && searchVo.getI_sModelCd() != null && !searchVo.getI_sModelCd().equals("")
                && searchVo.getI_sClassHeadCd() != null && !searchVo.getI_sClassHeadCd().equals("")){
            return commonModelMapper.iqyDetailGrdList(searchVo);
        }
        else{
            return null;
        }
    }

    /**
     * methodName : IqyModelGroupList
     * author : leechangjoo
     * description : 모델그룹 목록을 구한다.
     *
     * @param searchVo
     * @return List<CommonModelVO>
     */
    @Override
    public List<CommonModelVO> iqyModelGroupList(CommonModelSearchVO searchVo) {
        if ((searchVo.getI_sMakeCd() != null && !searchVo.getI_sMakeCd().equals("")) ||
            (searchVo.getI_sMakeCd_list() != null && searchVo.getI_sMakeCd_list().size() > 0) ||
             searchVo.getAllDataYn() != null && searchVo.getAllDataYn().equals("Y")){
            return commonModelMapper.iqyModelGroupList(searchVo);
        }
        return null;
    }
}
