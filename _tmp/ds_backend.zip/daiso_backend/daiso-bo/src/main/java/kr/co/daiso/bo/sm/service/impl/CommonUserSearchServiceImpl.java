package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.bo.sm.mapper.oracle.CommonUserSearchMapper;
import kr.co.daiso.bo.sm.model.CommonUserSearchPagingVo;
import kr.co.daiso.bo.sm.model.CommonUserVo;
import kr.co.daiso.bo.sm.service.CommonUserSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : CommonUserSearchServiceImpl
 * author         : Injung,Kim
 * date           : 2021-12-24
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-24      Injung,Kim         최초생성
 */
@Service
public class CommonUserSearchServiceImpl implements CommonUserSearchService {
    @Autowired
    CommonUserSearchMapper userSearchMapper;

    /**
     * 이름과 일치하는 사용자수
     * @param userVo 검색한 이름
     * @return 사용자 조회수
     */
    @Override
    public int getUsersCount(CommonUserSearchPagingVo userVo) {
        return userSearchMapper.countUsers(userVo);
    }

    /**
     * 이름과 일치하는 사용자 리스트
     * @param userVo 이름검색
     * @return 사용자 정보 리스트
     */
    @Override
    public List<CommonUserVo> getUsersInfo(CommonUserSearchPagingVo userVo) {
        List<CommonUserVo> list = userSearchMapper.searchUsers(userVo);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getDept1() == null) {
                list.get(i).setDept(list.get(i).getDept2());
            } else if (list.get(i).getDept2() == null) {
                list.get(i).setDept(list.get(i).getDept1());
            } else if (list.get(i).getDept1() != null && list.get(i).getDept2() != null) {
                list.get(i).setDept(list.get(i).getDept1() + ", " + list.get(i).getDept2());
            }
        }
        return list;
    }
}
