package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonScrnVO
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 화면 관리 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommonScrnVO extends BaseModel {
    private String scrnId;
    private String scrnNm;
    private String scrnUrl;
    private String indvInfoRelYn;
    private String useYn;
    private String sysDcd;
    private String pmTypeCd;
    private String iqyBtnUseYn;             //화면정보의 조회 버튼 여부
    private String initBtnUseYn;            //화면정보의 초기화 버튼 여부
    private String newBtnUseYn;             //화면정보의 신규 버튼 여부
    private String strgBtnUseYn;            //화면정보의 저장 버튼 여부
    private String delBtnUseYn;             //화면정보의 삭제 버튼 여부
    private String dnldBtnUseYn;            //화면정보의 다운로드 버튼 여부
}
