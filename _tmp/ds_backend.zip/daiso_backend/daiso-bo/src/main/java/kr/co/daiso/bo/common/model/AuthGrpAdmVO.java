package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : AuthGrpAdmVO
 * author         : leechangjoo
 * date           : 2021-12-08
 * description    : 그룹관한관리 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08          leechangjoo         최초생성
 **/

@Data
@EqualsAndHashCode(callSuper=false)
public class AuthGrpAdmVO extends CommonPagingVo {
    private String authGrpCd;	    	/* 권한그룹코드 */
	private String authGrpNm;			/* 권한그룹명 */
	private String adminYn;				/* 관라자여부 */
	private String useYn;				/* 사용여부 */
	private String authGrpNmSeach;		/* 권한그룹명조회 */
	private String sysDcd;			    /* 시스템구분*/
	private String pmTypeCd;			/* 매체구분*/
}
