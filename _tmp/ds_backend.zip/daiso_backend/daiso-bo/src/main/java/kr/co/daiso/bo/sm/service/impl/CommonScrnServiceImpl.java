package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.bo.sm.mapper.oracle.CommonScrnMapper;
import kr.co.daiso.bo.sm.model.CommonScrnSearchPagingVO;
import kr.co.daiso.bo.sm.model.CommonScrnVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import kr.co.daiso.bo.sm.service.CommonScrnService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : CommonScrnServiceImpl
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08      Doo-Won Lee         최초생성
 */
@Service
public class CommonScrnServiceImpl implements CommonScrnService {

    @Autowired
    CommonScrnMapper commonScrnMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : getSearchScrnListCnt
     * author : Doo-Won Lee
     * description : 화면검색의 카운트를 구한다.
     *
     * @param searchVO
     * @return int
     */
    @Override
    public int getSearchScrnListCnt(CommonScrnSearchPagingVO searchVO) {
        return commonScrnMapper.getSearchScrnListCnt(searchVO);
    }

    /**
     * methodName : getSearchScrnList
     * author : Doo-Won Lee
     * description : 화면검색 목록을 구한다.
     *
     * @param searchVO
     * @return List<CommonScrnVO>
     */
    @Override
    public List<CommonScrnVO> getSearchScrnList(CommonScrnSearchPagingVO searchVO) {
        return commonScrnMapper.getSearchScrnList(searchVO);
    }

    /**
     * methodName : saveScreenInfo
     * author : Doo-Won Lee
     * description : 새로운 화면을 저장한다
     *
     * @param saveVO
     * @return int
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int saveScreenInfo(CommonScrnVO saveVO) throws DuplicateKeyException {
        String usrId = adminAccountInfoUtil.getUsrId();
        saveVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
        saveVO.setRgpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
        return commonScrnMapper.saveScreenInfo(saveVO);
    }

    /**
     * methodName : editScreenInfo
     * author : Doo-Won Lee
     * description : 화면정보를 수정한다.
     *
     * @param editVO
     * @return int
     */
    @Override
    @Transactional(rollbackFor = { Exception.class })
    public int editScreenInfo(CommonScrnVO editVO) {
        String usrId = adminAccountInfoUtil.getUsrId();
        editVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
        return commonScrnMapper.editScreenInfo(editVO);
    }

    /**
     * methodName : editScreenInfo
     * author : Doo-Won Lee
     * description : 화면정보로 관련 메뉴 목록을 구한다..
     *
     * @param scrnVO
     * @return int
     */
    @Override
    public List<ScrnMenuVO> getMenulistByScrn(CommonScrnVO scrnVO){
        return commonScrnMapper.getMenulistByScrn(scrnVO);
    }
}
