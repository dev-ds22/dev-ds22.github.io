package kr.co.daiso.bo.common.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * packageName    : kr.co.daiso.common.model
 * fileName       : CommonPathInfo
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02       Doo-Won Lee       최초생성
 */
@Component
public class CommonPathInfo {

    //도메인 변수
    public static String DOMAIN;
    //사용 변수
    public static String	XDB_URL;  //XecureDB Url 현재 쓰는곳 전부 주석

    public static String SERVER_TYPE;

    //Mailer
    public static String MAILER_SERVER;
    public static String MAILER_USERID;
    public static String MAILER_PASSWD;

    //Upload
    public static String UPLOAD_ROOT;
    public static String UPLOAD_FILE_PATH;
    public static String UPLOAD_FILE_TEMP_PATH;
    public static String UPLOAD_INSURANCE_PATH;
    public static String UPLOAD_IMAGE_PATH;
    public static String UPLOAD_IMAGE_TEMP_PATH;

    //브랜드인증몰 Car image file
    public static String UPLOAD_CAR_IMG_BEFORE_PATH;
    public static String UPLOAD_CAR_IMG_AFTER_PATH;
    public static String UPLOAD_CAR_IMG_URL;
    public static String UPLOAD_ENCAR_IMG_URL;
//    public static String UPLOAD_CAR_WATER_MARK_PATH;
    //브랜드인증몰 썸네일 이미지 경로
//    public static String THUMBNAIL_IMG_PATH;

    //SMS 발송 관련
    public static String CAR_INFO_FROM_SMS_TITLE;
    public static String CAR_INFO_FROM_SMS;

    //Capital
    public static String CAPITAL_URL; // 신청 url 오픈용 https
    public static String CAPITAL_URL_ADD; // 신청 url 오픈용 url뒤

    public static String DB_LINK_NAME;

    //방문예약신청 url
    public static String RESERVATION_RGST_URL;
    public static String RESERVATION_CNCL_URL;
    public static String RESERVATION_STAT_URL;

    @Value("${domain}")
    public void setDevDomain(String domain) { DOMAIN = domain; }

    @Value("${spring.xdb_url}")
    public void setXdbUrl(String xdbUrl) {
        XDB_URL = xdbUrl;
    }

    @Value("${spring.server_type}")
    public void setServerType(String serverType) { SERVER_TYPE = serverType; }

    @Value("${spring.smtp.server}")
    public void setMailerServer(String mailerServer) { MAILER_SERVER = mailerServer; }

    @Value("${spring.smtp.mailer_id}")
    public void setMailerUserid(String mailerUserid) { MAILER_USERID = mailerUserid; }

    @Value("${spring.smtp.mailer_pwd}")
    public void setMailerPasswd(String mailerPasswd) { MAILER_PASSWD = mailerPasswd; }

    @Value("${spring.upload.rootpath}")
    public void setUploadRoot(String uploadRoot) { UPLOAD_ROOT = uploadRoot; }

    @Value("${spring.upload.filepath}")
    public void setUploadFilePath(String uploadFilePath) { UPLOAD_FILE_PATH = uploadFilePath; }

    @Value("${spring.upload.file_temp_path}")
    public void setUploadFileTempPath(String uploadFileTempPath) { UPLOAD_FILE_TEMP_PATH = uploadFileTempPath; }

    @Value("${spring.upload.insurance_path}")
    public void setUploadInsurancePath(String uploadInsurancePath) { UPLOAD_INSURANCE_PATH = uploadInsurancePath; }

    @Value("${spring.upload.img_path}")
    public void setUploadImagePath(String uploadImagePath) { UPLOAD_IMAGE_PATH = uploadImagePath; }

    @Value("${spring.upload.img_temp_path}")
    public void setUploadImageTempPath(String uploadImageTempPath) { UPLOAD_IMAGE_TEMP_PATH = uploadImageTempPath; }

//    public static void setUploadCarImgBeforePath(String uploadCarImgBeforePath) { UPLOAD_CAR_IMG_BEFORE_PATH = uploadCarImgBeforePath;  }

    @Value("${spring.upload.car_img_after_path}")
    public void setUploadCarImgAfterPath(String uploadCarImgAfterPath) { UPLOAD_CAR_IMG_AFTER_PATH = uploadCarImgAfterPath; }

    @Value("${spring.upload.car_img_url}")
    public void setUploadCarImgUrl(String uploadCarImgUrl) { UPLOAD_CAR_IMG_URL = uploadCarImgUrl; }

//    public static void setUploadEncarImgUrl(String uploadEncarImgUrl) { UPLOAD_ENCAR_IMG_URL = uploadEncarImgUrl; }

//    @Value("${spring.upload.car_water_mark_path}")
//    public void setUploadCarWaterMarkPath(String uploadCarWaterMarkPath) { UPLOAD_CAR_WATER_MARK_PATH = uploadCarWaterMarkPath; }

//    @Value("${spring.upload.thumb_img_path}")
//    public void setThumbnailImgPath(String thumbnailImgPath) { THUMBNAIL_IMG_PATH = thumbnailImgPath; }

    @Value("${sms.car_info_from_sms_title}")
    public void setCarInfoFromSmsTitle(String carInfoFromSmsTitle) { CAR_INFO_FROM_SMS_TITLE = carInfoFromSmsTitle; }

    @Value("${sms.car_info_from_sms}")
    public void setCarInfoFromSms(String carInfoFromSms) { CAR_INFO_FROM_SMS = carInfoFromSms;  }

    @Value("${capital.capital_url}")
    public void setCapitalUrl(String capitalUrl) { CAPITAL_URL = capitalUrl;  }

    @Value("${capital.capital_url_add}")
    public void setCapitalUrlAdd(String capitalUrlAdd) { CAPITAL_URL_ADD = capitalUrlAdd; }

    @Value("${dblink}")
    public void setDbLinkName(String dbLinkName) { DB_LINK_NAME = dbLinkName; }

    @Value("${reservation.rgst_url}")
    public void setReservationRgstUrl(String reservationRgstUrl) { RESERVATION_RGST_URL = reservationRgstUrl;  }

    @Value("${reservation.cncl_url}")
    public void setReservationCnclUrl(String reservationCnclUrl) { RESERVATION_CNCL_URL = reservationCnclUrl;  }

    @Value("${reservation.stat_url}")
    public void setReservationStatUrl(String reservationStatUrl) { RESERVATION_STAT_URL = reservationStatUrl;  }

    public static String	ROOT_URL;
    public static String	ROOT_FULL_URL;
    public static String	ROOT_FULL_SSL;
    public static String	MOBILE_FULL_URL;
    public static String	MOBILE_FULL_SSL;
    public static String	MOBILE_DOMAIN_URL;
    public static String	IMG_PATH;
    public static String	CSS_PATH;
    public static String	FLASH_PATH;
    public static String	SCRIPT_PATH;
    public static String	EDITOR_PATH;

    public static String	UPLOAD_CAR_IMAGE_PATH;
    public static String	UPLOAD_CAR_IMAGE_TEMP_PATH;
    public static String 	CHARSET		= "UTF-8";
    public static String	PASSCODE;
    public static String	SECRET_AES_KEY;

    public static String	IMG_URL;
    public static String	CDN_IF_URL;

    public static String	LEASE_CAR_IMG_URL;
    public static String	LEASE_BEFORE_PATH;
    public static String	LEASE_AFTER_PATH;
    public static String	SELF_IF_URL;
    public static String	SCRAP_IF_URL;

    public static String	RENT_CAR_IMG_URL;
    public static String	RENT_AFTER_PATH;
    public static String  	POST_URL;
    public static String  	POST_REGKEY;
    public static String  	POST_TARGET;
    public static String  	POST_COUNTPERPAGE;
    public static String  	POST_VALNM_REGKEY;
    public static String  	POST_VALNM_TARGET;
    public static String  	POST_VALNM_QUERY;
    public static String  	POST_VALNM_COUNTPERPAGE;
    public static String  	POST_VALNM_CURRENTPAGE;

    public static String CAR_INFO_FROM_NAME;
    public static String CAR_INFO_FROM_EMAIL;

    public static String SERVER_PROFILE;
    public static String STATUS;

    public static String BATCH_STATUS;
    public static String PCC_SERVICE_NO;
    public static String PCC_IPIN_SERVICE_NO;

    public static String PCC_MOBILE_SERVICE_NO;
    public static String PCC_MOBILE_IPIN_SERVICE_NO;

    /* 검색 API */
    public static String  KSF_SERVER_URL;
    public static String  KSF_SERVER_PORT;
    public static String  KSF_ACTION_SEARCH;
    public static String  KSF_SERVER_VOLUME;
    public static String  KSF_SERVER_TABLE;
    public static String  KSF_SERVER_MODEL_VOLUME;
    public static String  KSF_SERVER_MODEL_TABLE;
    /* 검색 API */

    /* Cache Update */
    private static String  CSS_CACHE_VERSION = "";
    private static String  SCRIPT_CACHE_VERSION = "";
    /* Cache Update */

    public static String UCMS_URL;

    public static String URECAR_URL;

    public static String CAR_HISTORY_URL;

    public static String CAPITAL_URL_HTTP; // 신청 url 오픈용 http
    public static String CAPITAL_API_URL; // 확인 url
    public static String CAPITAL_URL_CHECK; // 확인 url url뒤

    //PG사 설정파일
    public static String EASYPAY_MALL_ID;
    public static String EASYPAY_MALL_NAME;
    public static String EASYPAY_PG_URL;
    public static String EASYPAY_SP_URL;
    public static String EASYPAY_GW;
    public static String EASYPAY_CERT_FILE;
    public static String EASYPAY_LOG_DIR;
    public static String EASYPAY_OFFICE_URL;
    public static String AVAIL_CARD_CODE;

    /* 브랜드인증몰 - 20200731 Start */
    //차량검색 onlie 설정파일

    public static String  BC_AFTER_PATH;
    public static String  BC_BEFORE_PATH;
    public static String  BC_CAR_IMG_URL;


    public static String  CAR_IMG_BEFORE_PATH;
    public static String  CAR_IMG_AFTER_PATH;
    public static String  CAR_IMG_URL;
    public static String  ENCAR_IMG_URL;

    /* 브랜드인증몰 - 20200731 End */

    public static List<String> PASS_URL_LIST;

    // IF_UCMS_URL
    // 인터페이스 용 url
    public static String IF_UCMS_URL; // url 도메인
    public static String IF_UCMS_URL_AFTER; // 도메인 이후 url

    public static String VIRTUAL_AC_NAME; // 우리은행 가상계좌 계좌명

    public static String VIRTUAL_AC_DATA; // 가상계좌 확인 API

    // 제휴시세 중계 서버 ROOT URL
    public static String MYSELL_ALLIANCE_SERVER;

    // 제휴시세 조회 중계 서버
    public static String MYSELL_IF_SERVER;

    // 제휴시세 조회 중계 서버 - 카카오모빌리티
    public static String MYSELL_KM_IF_SERVER;

    public static String CONTAINER;



}
