package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.model.CommonModelSearchVO;
import kr.co.daiso.bo.sm.model.CommonModelVO;
import kr.co.daiso.bo.sm.service.CommonModelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sm.controller
 * fileName       : CommonModelController
 * author         : leechangjoo
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14          leechangjoo         최초생성
 **/
@RestController
@RequestMapping("/sm/common-model")
@Api(tags = {"공통모델 관리 컨트롤러"})
public class CommonModelController {

    @Autowired
    CommonModelService commonModelService;

    @ApiOperation("제조사 목록 조회")
    @GetMapping("/mnuftr-list")
    public ResponseEntity<CommonResponseModel> iqyMnuftrList(@ApiParam("제조사 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyMnuftrList");
        Map<String, Object> resultMap = new HashMap<>();

        int recordCnt	= commonModelService.iqyMnuftrListCnt(searchVo);
        List<CommonModelVO> list	= commonModelService.iqyMnuftrList(searchVo);
        resultMap.put("commonMnuftrlList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("모델 목록 조회")
    @GetMapping("/model-list")
    public ResponseEntity<CommonResponseModel> iqyModelList(@ApiParam("모델 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyModelList");
        Map<String, Object> resultMap = new HashMap<>();

        System.out.println("model");
        int recordCnt	= commonModelService.iqyModelListCnt(searchVo);
        List<CommonModelVO> list	= commonModelService.iqyModelList(searchVo);
        resultMap.put("resultList", list);


        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("등급 목록 조회")
    @GetMapping("/grd-list")
    public ResponseEntity<CommonResponseModel> iqyGrdList(@ApiParam("등급 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyGrdList");
        Map<String, Object> resultMap = new HashMap<>();

        System.out.println("grd");
        List<CommonModelVO> list = commonModelService.iqyGrdList(searchVo);
        resultMap.put("resultList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("세부 등급 목록 조회")
    @GetMapping("/detail-grd-list")
    public ResponseEntity<CommonResponseModel> iqyDetailGrdList(@ApiParam("세부 등급 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyDetailGrdList");
        Map<String, Object> resultMap = new HashMap<>();

        System.out.println("detailGrd");
        List<CommonModelVO> list = commonModelService.iqyDetailGrdList(searchVo);
        resultMap.put("resultList", list);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("모델 그룹 목록 조회")
    @GetMapping("/model-group-list")
    public ResponseEntity<CommonResponseModel> iqyModelGroupList(@ApiParam("모델 그룹 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyModelGroupList");
        Map<String, Object> resultMap = new HashMap<>();

        System.out.println("modelGroup");
        List<CommonModelVO> list	= commonModelService.iqyModelGroupList(searchVo);
        resultMap.put("resultList", list);


        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

    @ApiOperation("세부모델 목록 조회")
    @GetMapping("/detail-model-list")
    public ResponseEntity<CommonResponseModel> iqyDetailModelList(@ApiParam("세부 모델 코드 검색 정보") CommonModelSearchVO searchVo
            , HttpServletResponse response){
        System.out.println("CommonModelController.iqyDetailModelList");
        Map<String, Object> resultMap = new HashMap<>();

        System.out.println("detailModel");
        List<CommonModelVO> list	= commonModelService.iqyModelList(searchVo);
        resultMap.put("resultList", list);


        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

}

