package kr.co.daiso.bo.sm.service;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.model.CalendarVo;
import kr.co.daiso.bo.sm.model.HolidayVo;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : HolidayController
 * author         : Injung,Kim
 * date           : 2022-01-13
 * description    : 직영점 휴일 관리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13     Injung,Kim      최초생성
 */
public interface HolidayService {
    //UCMS 달력마스터에 저장된 달력을 가져온다
    public List<CalendarVo> getUCMScalendarByYear(HolidayVo holidayVo);

    //직영점 달력 테이블에 가져온 UCMS 달력을 복사한다
    int saveNewCalendarByCntr(List<CalendarVo> calendarMaster, HolidayVo holidayVo);

    //직영점별 해당 연도로 저장된 달력을 가져온다
    public CommonResponseModel getStoredcalendar(HolidayVo holidayVo);

    //직영점별 입력한 휴일을 저장한다
    public CommonResponseModel updateHolidays(List<HolidayVo> updatedList);

}
