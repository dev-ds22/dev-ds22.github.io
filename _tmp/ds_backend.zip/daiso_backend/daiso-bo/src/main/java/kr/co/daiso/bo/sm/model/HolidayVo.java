package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/**
 * packageName    : kr.co.daiso.bo.sm.model
 * fileName       : HolidayVo
 * author         : Injung, Kim
 * date           : 2021-12-20
 * description    : 휴일관리 테이블 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-20       Injung, Kim        최초생성
 */
@Data
@ApiModel(description = "휴일관리 테이블 VO")
public class HolidayVo extends BaseModel{
    @ApiModelProperty(value="선택연도")
    private int year;
    @ApiModelProperty(value="센터 서브코드")
    private String subCd;
    @ApiModelProperty(value="달력일자")
    private String cldrDt;
    @ApiModelProperty(value="요일명")
    private String dowNm;
    @ApiModelProperty(value="요일코드")
    private int dowCd;
    @ApiModelProperty(value="휴일여부")
    private String hldyYn;
    @ApiModelProperty(value="휴일명")
    private String hldyNm;
}
