package kr.co.daiso.bo.sm.model;

import lombok.Data;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : CommonCodeSaveVO
 * author         : Doo-Won Lee
 * date           : 2021-12-20
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-20       Doo-Won Lee    최초생성
 */
@Data
public class CommonCodeSaveVO {

    //공통코드 저장&수정시 새로 생성된 정보 리스트
    private List<CommonCodeManageVO> createCodeList;

    //공통코스 저장&수정시 수정된 정보 리스트
    private List<CommonCodeManageVO> updateCodeList;
}
