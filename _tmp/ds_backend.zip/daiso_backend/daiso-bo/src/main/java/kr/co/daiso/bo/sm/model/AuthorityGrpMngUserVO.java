package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.model
 * fileName       : AuthorityGrpMngUserVO
 * author         : kjm
 * date           : 2021-12-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-15       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class AuthorityGrpMngUserVO extends BaseModel {

    private String usrCd;           // 사번

    private String usrId;           // 사용자id

    private String usrNm;           // 이름

    private String emailAddr;       // 이메일주소

    private String dept1;           // 부서1

    private String dept2;           // 부서2

    private String mpno;            // 휴대전화번호

    private String modPsbYn;        // 수정가능여부

    private String indvInfoDealYn;  // 개인정보취급여부

    private String authGrpCd;       // 권한그룹코드

    private String authGrpNm;       // 권한그룹명

    private String pwd;             // 비밀번호
    
    private String authReason;      // 권한부여사유
    
    private String authGrntType;    // 권한부여유형

    private boolean checked;

    private String acesIp;          // 접근 IP
}
