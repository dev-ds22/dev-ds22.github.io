package kr.co.daiso.bo.login.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/**
 * packageName    : kr.co.daiso.bo.login.model
 * fileName       : AdminAccountInfo
 * author         : Doo-Won Lee
 * date           : 2021-12-03
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-03       Doo-Won Lee         최초생성
 */
@SuppressWarnings("serial")
@EqualsAndHashCode(callSuper=false)
@Data
public class AdminAccountInfo extends BaseModel implements UserDetails{

        private String usrCd;        // UCMS 아이디
        private String usrType;      // 사용자 타입
        private String usrTypeName;  // 사용자 타입 명
        private String usrId;        // 사용자 ID
        private String password;
        private String id;           // 로그인 아이디
        private String usrNm;

        private String emailAddr;    //이메일주소
        private String zipCd;        //우편번호
        private String addr;         //주소
        private String dtlAddr;      //상세주소
        private String tno;          //전화번호
        private String mpno;         //휴대전화번호
        private String emailChkYn;   //이메일체크여부

        private String usrStat;      //사용자상태
        private String usrStatName;  //사용자상태 명
        private String retireYn;     //퇴직여부
        private String phtoFileNm;   //사진파일명
        private String phtoFilePath; //사진파일경로
        private String phtoFileExt;  //사진파일확장자

        private String jobps;        //직급
        private String dept1;        //부서1
        private String dept2;        //부서2
        private String jbtl;         //직위
        private String cntrCd;       //센터코드
        private String cntrNm;       //센터명
        private String cntrRegion;   //센터 지역
        private String ssttSelerId;  //대체판매자ID
        private String valtorMsg;    //평가사메세지

        private String brthdyYr;     //생일연도
        private String brthdyMm;     //생일월
        private String brthdyDd;     //생일일

        private String loginSeonKey;    //로그인세션키
        private String multiLoginPrmsnYn;   //다중로그인허용여부
        private String pwdChngDt;
        private int nLeaveDays;
        private String fnlLoginDt;
        private String ntUseYn;
        private String indvInfoDealYn; //개인정보 취급여부

//		    ,   AUTH.V_MENU_TYPE
//			,   AUTH.V_READ_FLAG
//	        ,   AUTH.V_CREATE_FLAG
//	        ,   AUTH.V_UPDATE_FLAG
//	        ,   AUTH.V_DELETE_FLAG
//	        ,   AUTH.V_DOWNLOAD_FLAG

        private String role;    /* User Role 권한 그룹 */


        @Override
        public Collection<SimpleGrantedAuthority> getAuthorities() {
            Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
            if (null!=this.role)
                Arrays.stream(this.role.split(","))
                        .distinct()
                        .forEach(p -> {
                            GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + p);
                            authorities.add((SimpleGrantedAuthority) authority);
                        });
            return authorities;
        }

        @Override
        public String getUsername() {
            return this.id;
        }

//    public void setUsername(String userName) {
//        this.id = userName;
//    }

        @Override
        public boolean isAccountNonExpired() {
            return true;
        }

        @Override
        public boolean isAccountNonLocked() {
            return true;
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return true;
        }

        @Override
        public boolean isEnabled() {
            return true;
        }
}
