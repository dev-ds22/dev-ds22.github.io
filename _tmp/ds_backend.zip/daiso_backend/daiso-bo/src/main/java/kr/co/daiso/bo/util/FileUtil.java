package kr.co.daiso.bo.util;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.model.CommonPathInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.FileNameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : FileUtil
 * author         : Doo-Won Lee
 * date           : 2022-01-11
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-11      Doo-Won Lee         최초생성
 */
@Slf4j
@Component
public class FileUtil {

    @Autowired
    MessageSource messageSource;

    // 허용되는 마입타입 목록
    List<String> allowContentTypeList   = Arrays.asList("image", "application");
    // 허용되는 파일의 확장자 목록
    List<String> allowExtList   		= Arrays.asList(".jpeg", ".jpg", ".png", ".gif", ".hwp", ".xlsx", ".xls", ".csv", ".pdf", ".pptx", ".ppt", ".docx", ".word");
    // 허용되는 이미지 확장자 목록
    List<String> allowImgExtList   		= Arrays.asList(".jpeg", ".jpg", ".png", ".gif");
    // 허용되는 엑셀 확장자 목록
    List<String> allowExcelExtList   	= Arrays.asList(".xlsx", ".xls");
    // 허용되는 보험증서 확장자 목록
    List<String> allowInsuranceExtList   	= Arrays.asList(".jpeg", ".jpg", ".png",".pdf");


    public enum DaisoFileType{
        ALL("ALL", null),
        IMAGE("IMAGE", null),
        INSURANCE("INSURANCE", null),
        EXCEL("EXCEL", null),

        MARKETING("MARKETING", "COMPANY"),
        IR("IR","COMPANY"),
        EVENT("EVENT", "MANAGE"),
        REVIEW("REVIEW", "REVIEW"),
        CENTER("CENTER", "CENTER"),
        SLOT("SLOT", "SLOT"),
        NEWCARRENT("NEWCARRENT", "newcaRent"),
        POPUP("POPUP", null),
        THEME("THEME", "THEME"),
        ;

        private String type;

        private String pathPrefix;

        private DaisoFileType(){
            log.debug("DaisoFileType");
        }

        private DaisoFileType(String type, String pathPrefix){
            this.type = type;
            this.pathPrefix = pathPrefix;
        }

        public String getType(){
            return this.type;
        }
        public String getPathPrefix() { return this.pathPrefix; }
    }

    /**
     * methodName : isAllowUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드시 허용 여부 처리
     *
     * @param file, failModel
     */
    public boolean isAllowUpload(MultipartFile file, CommonResponseModel failModel){
        String contentType = file.getContentType();
        String fileExt = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

        Locale locale = LocaleContextHolder.getLocale();

        if (null!=contentType && null!=fileExt){

            String fileMimeType = contentType.split("/")[0];
            if ((allowContentTypeList.contains(fileMimeType) && allowExtList.contains(fileExt)) == false) {
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileType", null, locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
            long fileSize = file.getSize();
            if (fileSize>CommonConstants.LIMIT_SIZE_OF_UPLOAD){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileSize"
                                                                    , new String[]{String.valueOf(CommonConstants.LIMIT_SIZE_OF_UPLOAD/(1024*1024))}
                                                                    , locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
        }
        return true;
    }

    /**
     * methodName : isAllowUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드시 파일 타입에 맞는 허용 여부 처리
     *
     * @param file, failModel,type
     */
    public boolean isAllowUpload(MultipartFile file, CommonResponseModel failModel, DaisoFileType type){
        String contentType = file.getContentType();
        String fileExt = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

        Locale locale = LocaleContextHolder.getLocale();

        if (null!=contentType && null!=fileExt){

            String fileMimeType = contentType.split("/")[0];

            boolean isFileTypeAllow = true;

            if (!allowContentTypeList.contains(fileMimeType)){
                isFileTypeAllow = false;
            }
            else{
                switch(type){
                    case ALL:
                        if (!allowExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    case IMAGE:
                        if (!allowImgExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    case EXCEL:
                        if (!allowExcelExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                    default:
                        if (!allowExtList.contains(fileExt.toLowerCase())){
                            isFileTypeAllow = false;
                        }
                        break;
                }
            }

            if (!isFileTypeAllow){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileType", null, locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }

            long fileSize = file.getSize();
            if (fileSize>CommonConstants.LIMIT_SIZE_OF_UPLOAD){
                failModel.setSuccess(false);
                try {
                    failModel.setMessage( messageSource.getMessage("common.upload.isnoAllowFileSize"
                            , new String[]{String.valueOf(CommonConstants.LIMIT_SIZE_OF_UPLOAD/(1024*1024))}
                            , locale));
                } catch (NoSuchMessageException ne) {
                    failModel.setMessage("");
                }
                return false;
            }
        }
        return true;
    }

    /**
     * methodName : multipartFileUpload
     * author : Doo-Won Lee
     * description : MultiPartFile 업로드
     *
     * @param file, path
     * @return  String
     */
    public String multipartFileUpload(MultipartFile file, String path)  throws IOException {
        File folder = new File(path);
        String attachId = RandomStringUtils.randomAlphanumeric(20);
//        System.out.println(file.getOriginalFilename());
//        System.out.println(FileNameUtils.getBaseName(file.getOriginalFilename()));
//        System.out.println(FileNameUtils.getExtension(file.getOriginalFilename()));
        String newFileName = FileNameUtils.getBaseName(file.getOriginalFilename())+attachId+"."+FileNameUtils.getExtension(file.getOriginalFilename());
        if (!folder.exists()) {
            folder.mkdirs();
        }
        log.info("folder.getAbsolutePath():"+folder.getAbsolutePath());
        log.info("folder.getAbsolutePath()+/+newFileName:"+folder.getAbsolutePath()+"/"+newFileName);

        File newFile = new File(folder.getAbsolutePath()+"/"+newFileName);
        FileOutputStream fos = new FileOutputStream(newFile);

        try {
            fos.write(file.getBytes());
        }
        catch(IOException ie){
            throw ie;
        }finally {
            fos.close();
        }
//        file.transferTo(new File(folder.getAbsolutePath()+"/"+newFileName));

        return newFileName;
    }


    /**
     * methodName : fileDownload
     * author : Doo-Won Lee
     * description : File Download
     *
     * @param  filePath, request, response
     * @return  void
     */
    public void fileDownload(String filePath, HttpServletRequest request, HttpServletResponse response) throws IOException{
        File downFile = new File(filePath);
        log.info(downFile.getName());
        String newFileName = FileNameUtils.getBaseName(downFile.getName());
        log.info(newFileName);

        if(request.getHeader("User-Agent").indexOf("MSIE") > -1){
            newFileName = URLEncoder.encode(downFile.getName(), "UTF-8");
        } else {
            newFileName = new String(downFile.getName().getBytes(StandardCharsets.UTF_8));
        }
        response.addHeader(HttpHeaders.CONTENT_TYPE,"Application/octet-stream" );
        response.addHeader(HttpHeaders.CONTENT_ENCODING, "binary");
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.builder("attachment")
                                                                                .filename(newFileName, StandardCharsets.UTF_8)
                                                                                .build().toString());
        OutputStream out = response.getOutputStream();
        FileInputStream fis = null;
        fis = new FileInputStream(downFile);
        FileCopyUtils.copy(fis, out);
        fis.close();
        out.flush();
    }

    /**
     * methodName : fileUpload
     * author : Doo-Won Lee
     * description : 파일을 업로드 한다
     *
     * @param  file, req
     * @return  ResponseEntity<CommonResponseModel>
     */
    public ResponseEntity<CommonResponseModel> fileUpload(MultipartFile file, HttpServletRequest req) throws IOException{
        Map<String, String> resultMap = new HashMap<>();
        String fileTypeStr = req.getParameter("type");
        String filePathStr = req.getParameter("path");
        FileUtil.DaisoFileType daisoFileType = FileUtil.DaisoFileType.valueOf(fileTypeStr);

        String uploadFilePath = CommonPathInfo.UPLOAD_FILE_TEMP_PATH;
        CommonResponseModel failModel = new CommonResponseModel();

        if (isAllowUpload(file, failModel, daisoFileType)) {
            switch(daisoFileType) {
                case INSURANCE:
                    uploadFilePath = CommonPathInfo.UPLOAD_INSURANCE_PATH;
                    break;
                case IMAGE:
                    uploadFilePath = CommonPathInfo.UPLOAD_IMAGE_PATH;
                    break;
                case MARKETING:
                case EVENT:
                case REVIEW:
                case CENTER:
                case SLOT:
                case NEWCARRENT:
                case THEME:
                    uploadFilePath = CommonPathInfo.UPLOAD_IMAGE_PATH + ((daisoFileType.getPathPrefix() == null)? "" : daisoFileType.getPathPrefix())+ "/";
                    break;
                case IR:
                    uploadFilePath = CommonPathInfo.UPLOAD_FILE_PATH + ((daisoFileType.getPathPrefix() == null)? "" : daisoFileType.getPathPrefix())+ "/";
                    break;
                case POPUP:
                    uploadFilePath = CommonPathInfo.UPLOAD_IMAGE_TEMP_PATH + ((daisoFileType.getPathPrefix() == null)? "" : daisoFileType.getPathPrefix())+ "/";
                    break;
                default:
                    uploadFilePath = CommonPathInfo.UPLOAD_FILE_TEMP_PATH;
                    break;
            }

            if (null!=filePathStr && filePathStr.length()>0){
                uploadFilePath = uploadFilePath + filePathStr;
            }
            String  newFileName = multipartFileUpload(file, uploadFilePath);  //파일만 업로드 처리

            switch(CommonPathInfo.SERVER_TYPE){
//                case "local":
//                case "dev":
//                case "dev_cloud":
//                    break;
                case "stg":
                case "stg_cloud":
                case "prd":
                case "prd_cloud":
                    uploadFilePath = uploadFilePath.replace("/BASE/daiso_nas","");
                    uploadFilePath = uploadFilePath.replace("/BASE/daiso","");
                    break;
                default:
                    break;
            }

            resultMap.put("filePath", uploadFilePath + newFileName);
            resultMap.put("fileName", newFileName);
            resultMap.put("filePathOnly", uploadFilePath);

            log.info("expect return if:"+resultMap);
        } else {
            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
        }
        log.info("expect return normal:"+resultMap);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }
}
