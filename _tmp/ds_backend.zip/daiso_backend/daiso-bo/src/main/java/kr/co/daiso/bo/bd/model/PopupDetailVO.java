package kr.co.daiso.bo.bd.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.bd.model
 * fileName       : PopupDetailVO
 * author         : kjm
 * date           : 2022-01-17
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-17       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PopupDetailVO extends BaseModel {

    private String ppupDtlSq;
    private String ppupCd;
    private String ppupTitl;
    private String sortOrdr;
    private String imgUrl;
    private String linkUrl;
    private String spacePrcsYn;
    private String clsrPrcsYn;
    private String wdth;
    private String heit;
    private String ppupStrtDt;
    private String ppupEndDt;
    private String pltformDcd;
}
