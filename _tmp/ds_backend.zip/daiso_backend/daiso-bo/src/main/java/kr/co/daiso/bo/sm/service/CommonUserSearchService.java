package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.CommonUserSearchPagingVo;
import kr.co.daiso.bo.sm.model.CommonUserVo;

import java.util.List;

public interface CommonUserSearchService {
    /**
     *검색된 유저 수
     * @param userVo 검색한 이름
     * @return 총 검색수
     */
    public int getUsersCount(CommonUserSearchPagingVo userVo);
    /**
     * 이름으로 유저 검색
     * @return 검색된 유저 정보
     * @param userVo 이름 검색
     */
    public List<CommonUserVo> getUsersInfo(CommonUserSearchPagingVo userVo);


}
