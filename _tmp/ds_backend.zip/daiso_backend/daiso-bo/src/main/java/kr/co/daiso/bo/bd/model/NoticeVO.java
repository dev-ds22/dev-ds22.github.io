package kr.co.daiso.bo.bd.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.bd.model
 * fileName       : NoticeVO
 * author         : kjm
 * date           : 2022-01-20
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-20       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class NoticeVO extends CommonPagingVo {
    private String bltbdCd;     // 게시판코드
    private int sortOrdr;       // 정렬순서
    private int levl;           // 레벨
    private String usrCd;       // 사용자코드
    private String wrtrNm;      // 작성자명
    private String pwd;         // 비밀번호
    private String thrnkYn;     // 최상위여부
    private String titl;        // 제목
    private String cnts;        // 내용
    private String ipAddr;      // 아이피주소
    private int viewCnt;        // 조회수
    private String bltbdKnd;    // 게시판종류
    private String pcClsdCnts;  // PC휴무내용
    private String mblClsdCnts; // 모바일휴무내용
    private String clsdStrtDttm;// 휴무시작일시
    private String clsdEndDttm; // 휴무종료일시
    private String clsdBgColor; // 휴무배경색상
    private String brstCd;      // 지정코드
    private String pcCnts;      // PC내용
    private String mblCnts;     // 모바일내용
    private String strtDttm;    // 시작일시
    private String endDttm;     // 종료일시
    private String cntrNm;      // 지점명
}
