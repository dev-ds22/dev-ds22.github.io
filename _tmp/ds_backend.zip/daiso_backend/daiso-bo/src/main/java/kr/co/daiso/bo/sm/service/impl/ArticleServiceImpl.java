package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.bo.sm.mapper.oracle.ArticleMapper;
import kr.co.daiso.bo.sm.model.ArticlePagingVo;
import kr.co.daiso.bo.sm.model.ArticleVo;
import kr.co.daiso.bo.sm.service.ArticleService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

@Slf4j
@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    ArticleMapper articleMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    //약관 리스트를 조회한다
    @Override
    public List<ArticleVo> getArticleList(ArticlePagingVo searchVO) {
        List<ArticleVo> list = articleMapper.getArticles(searchVO);
        return list;
    }
    // 조회된 리스트의 갯수를 구한다
    @Override
    public int listCount(ArticlePagingVo searchVO) {
        return articleMapper.getCount(searchVO);
    }

    //클릭한 그리드행의 약관 상세정보를 조회한다
    @Override
    public ArticleVo getArticle(ArticleVo articleVo) {
        ArticleVo vo = articleMapper.getDetail(articleVo);
        return vo;
    }
    //약관을 저장한다
    @Override
    public int saveArticle(ArticleVo articleVo) {
        String usrId = adminAccountInfoUtil.getUsrId();
        articleVo.setRgpsId((usrId == null) ? CommonConstants.SYSTEM_ID : usrId);
        return articleMapper.setArticle(articleVo);
    }
    //약관을 수정한다
    @Override
    public int updateArticle(ArticleVo articleVo) {
        String usrId = adminAccountInfoUtil.getUsrId();
        articleVo.setMdpsId((usrId == null) ? CommonConstants.SYSTEM_ID : usrId);
        log.info("updatedArticle : {}", articleVo);
        return articleMapper.updateArticle(articleVo);
    }
}


