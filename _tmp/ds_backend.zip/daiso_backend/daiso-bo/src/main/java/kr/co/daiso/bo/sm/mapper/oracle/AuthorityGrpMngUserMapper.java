package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.AuthorityGrpMngUserVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : AuthorityGrpMngUserMapper
 * author         : kjm
 * date           : 2021-12-15
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-15       kjm            최초생성
 */
@Mapper
public interface AuthorityGrpMngUserMapper {

    // 사용자 목록 조회
    List<AuthorityGrpMngUserVO> searchUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 상세 조회
    AuthorityGrpMngUserVO searchUserDetail(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 권한그룹 조회
    List<AuthorityGrpMngUserVO> searchAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 중복되는 정보를 가진 회원목록 조회
    List<AuthorityGrpMngUserVO> duplicatedUserList(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 등록
    void signUpUser(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자 정보 수정
    void modifyUser(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자별 권한그룹 생성
    void insertAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자별 권한그룹 제거
    void deleteAuthGrp(AuthorityGrpMngUserVO authorityGrpMngUserVO);

    // 사용자별 권한그룹 히스토리
    void insertAuthGrpUserHist(AuthorityGrpMngUserVO authorityGrpMngUserVO);
}
