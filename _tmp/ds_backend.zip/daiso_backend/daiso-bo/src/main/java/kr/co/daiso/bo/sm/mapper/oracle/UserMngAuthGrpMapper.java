package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.UserMngAuthGrpVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : UserMngAuthGrpMapper
 * author         : kjm
 * date           : 2021-12-23
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-23       kjm            최초생성
 */
@Mapper
public interface UserMngAuthGrpMapper {

    // 권한그룹별 사용자 목록조회
    List<UserMngAuthGrpVO> searchUserList(UserMngAuthGrpVO userMngAuthGrpVO);

    // 사용자 권한 추가
    void insertUserByAuthGrp(UserMngAuthGrpVO createdRow);

    // 사용자 권한 제거
    void deleteUserByAuthGrp(UserMngAuthGrpVO deletedRow);

    // 사용자 권한부여 히스토리
    void insertUserAuthGrpHist(UserMngAuthGrpVO createdRow);
}
