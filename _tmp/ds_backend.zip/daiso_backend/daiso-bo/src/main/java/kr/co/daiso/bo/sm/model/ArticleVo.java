package kr.co.daiso.bo.sm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Date;
import java.time.OffsetDateTime;


/**
 * packageName    : kr.co.daiso.bo.sm.model
 * fileName       : ArticleVo
 * author         : Injung, Kim
 * date           : 2021-11-13
 * description    : 약관관리 테이블 VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-10-26       Injung, Kim        최초생성
 */
@Data
@ApiModel(description = "약관 관리 테이블 VO")
public class ArticleVo {
    @ApiModelProperty(value = "약관코드(서브코드)")
    private String subCd;
    @ApiModelProperty(value = "약관이름")
    private String subCdNm;
    @ApiModelProperty(value = "약관버전")
    private float atclVer;
    @ApiModelProperty(value = "약관내용")
    private String atclCnts;
    @ApiModelProperty(value = "임시저장여부")
    private char tempStrgYn;
    @ApiModelProperty(value = "약관적용날짜")
    private String aplyDt;
    @ApiModelProperty(value = "등록자 아이디")
    private String rgpsId;
    @ApiModelProperty(value = "등록날짜")
    private String regDttm;
    @ApiModelProperty(value = "수정자 아이디")
    private String mdpsId;
    @ApiModelProperty(value = "수정날짜")
    private String modDttm;










}
