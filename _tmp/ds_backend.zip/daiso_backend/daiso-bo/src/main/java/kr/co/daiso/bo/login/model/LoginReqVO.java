package kr.co.daiso.bo.login.model;

import kr.co.daiso.common.model.BaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * packageName    : kr.co.daiso.bo.login.model
 * fileName       : LoginReqVO
 * author         : Doo-Won Lee
 * date           : 2021-12-02
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-02      Doo-Won Lee         최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class LoginReqVO extends BaseModel {

    @NotNull(message = "common.valid.required")
    private String id;

    @NotNull(message = "common.valid.required")
    private String password;

    private String reason;      //업무시간외 로그인 사유

    private String overworkYn; //업무시간외 여부

    private String returnUrl;
}
