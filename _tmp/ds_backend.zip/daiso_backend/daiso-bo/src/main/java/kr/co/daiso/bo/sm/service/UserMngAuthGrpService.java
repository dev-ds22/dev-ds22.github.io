package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.UserMngAuthGrpVO;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : UserMngAuthGrpService
 * author         : kjm
 * date           : 2021-12-23
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-23       kjm            최초생성
 */
public interface UserMngAuthGrpService {

    // 권한그룹별 사용자 목록조회
    List<UserMngAuthGrpVO> searchUserList(UserMngAuthGrpVO userMngAuthGrpVO);

    // 권한그룹별 사용자 저장
    void saveUserByAuthGrp(LinkedHashMap<String, Object> linkedHashMap);
}
