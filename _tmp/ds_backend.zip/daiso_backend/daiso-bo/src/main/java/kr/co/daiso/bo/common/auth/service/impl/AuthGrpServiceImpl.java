package kr.co.daiso.bo.common.auth.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.bo.common.auth.service.AuthGrpService;
import kr.co.daiso.bo.common.mapper.oracle.AuthGrpAdmMapper;
import kr.co.daiso.bo.common.model.AuthGrpAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuAdmVO;
import kr.co.daiso.bo.common.model.AuthGrpMenuScrSaveVO;
import kr.co.daiso.bo.login.model.AdminAccountInfo;
import kr.co.daiso.bo.login.service.LoginService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.RedisUtil;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.model.CommonResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.common.auth.service.impl
 * fileName       : AuthGrpServiceImpl
 * author         : Doo-Won Lee
 * date           : 2021-12-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-06       Doo-Won Lee         최초생성
 */
@Slf4j
@Service
public class AuthGrpServiceImpl implements AuthGrpService {

    @Autowired
    LoginService loginService;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    AuthGrpAdmMapper authGrpAdmMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : setAdminAuthGrpToRedis
     * author : Doo-Won Lee
     * description : Redis에 관리자 사이트에 접근 가능한 권한 그룹코드를 저장한다.
     */
    @Override
    public void setAdminAuthGrpToRedis() {
        String adminAuthGrp = null;
        List<String> adminAuthGrpList = loginService.getAdminAuthGrpCd();
        if (adminAuthGrpList.size()>0) {
            adminAuthGrp = String.join(",", adminAuthGrpList);
        }
        redisUtil.setData(CommonConstants.REDIS_KEY_ADMIN_AUTH_GROUP, adminAuthGrp);
    }

    /**
     * methodName : checkAdminAuthGroup
     * author : Doo-Won Lee
     * description : 유저정보가 관리자 권한 그룹을 가지고 있는지 확인한다.
     */
    @Override
    public boolean checkAdminAuthGroup(AdminAccountInfo adminAccountInfo) {

        String adminAuthGrpListStr =  redisUtil.getData(CommonConstants.REDIS_KEY_ADMIN_AUTH_GROUP);

        if (!StringUtils.hasLength(adminAuthGrpListStr)){
            setAdminAuthGrpToRedis();
            adminAuthGrpListStr =  redisUtil.getData(CommonConstants.REDIS_KEY_ADMIN_AUTH_GROUP);
        }

        List<String> adminAuthGrpList = Arrays.asList(adminAuthGrpListStr.split(","));

        if (null!=adminAccountInfo.getUsrType()) {
            for (String adminAuthGrpStr : adminAuthGrpList) {
                if (adminAccountInfo.getUsrType().indexOf(adminAuthGrpStr) > -1) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * methodName : checkAdminAuthGroup
     * author : Chang-Joo Lee
     * description : 권한 관리 그룹 리스트를 카운트한다.
     */
    @Override
    public int getAuthGrpAdmListCnt(AuthGrpAdmVO authGrpAdmVO) {
        return authGrpAdmMapper.getAuthGrpAdmListCnt(authGrpAdmVO);
    }

    /**
     * methodName : checkAdminAuthGroup
     * author : Chang-Joo Lee
     * description : 공통 권한 관리 그룹 리스트를 조회한다.
     */
    @Override
    public List<AuthGrpAdmVO> getCommonAuthGrpAdmListPopup(AuthGrpAdmVO authGrpAdmVO) {
        return authGrpAdmMapper.getCommonAuthGrpAdmListPopup(authGrpAdmVO);
    }

    /**
     * methodName : checkAdminAuthGroup
     * author : Chang-Joo Lee
     * description : 권한 관리 그룹 리스트를 조회한다.
     */
    @Override
    public List<AuthGrpAdmVO> getAuthGrpAdmList(AuthGrpAdmVO authGrpAdmVO) {
        return authGrpAdmMapper.getAuthGrpAdmList(authGrpAdmVO);
    }
    /**
     * methodName : checkAdminAuthGroup
     * author : Chang-Joo Lee
     * description : 권한 그룹을 추가 저장 한다.
     */
    @Override
    @Transactional(rollbackFor = {Exception.class})
    public CommonResponseModel updateAuthGrpAdmList(List<AuthGrpAdmVO> createRows, List<AuthGrpAdmVO> updateRows ){

        String usrId = adminAccountInfoUtil.getUsrId();

        try{
            if (createRows.size() > 0){
                for(AuthGrpAdmVO  insertAuthGrpAdmVO : createRows) {
                    insertAuthGrpAdmVO.setMdpsId((null == usrId) ? CommonConstants.SYSTEM_ID : usrId);
                    insertAuthGrpAdmVO.setRgpsId((null == usrId) ? CommonConstants.SYSTEM_ID : usrId);
                    authGrpAdmMapper.insertAuthGrpAdmList(insertAuthGrpAdmVO);
                }
            }

            if(updateRows.size() > 0){
                for(AuthGrpAdmVO updateAuthGrpAdmVO : updateRows) {
                    updateAuthGrpAdmVO.setMdpsId((null==usrId)? CommonConstants.SYSTEM_ID : usrId);
                    authGrpAdmMapper.updateAuthGrpAdmList(updateAuthGrpAdmVO);
                }
            }
            setAdminAuthGrpToRedis(); //권한 그룹에 관리자 여부가 변경되므로  redis에 추가 Doo-Won Lee
        }catch (DuplicateKeyException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setSuccess(false);
            failResultModel.setMessage("DUP");
            failResultModel.setReturnCode("400");
            return failResultModel;
        }
        return new CommonResponseModel();
    }


    /**
     * methodName : getAuthGrpMenuAdmList
     * author : Chang-Joo Lee
     * description : 공통 권한 관리 그룹 메뉴 리스트를 조회한다.
     */
    @Override
    public  List<AuthGrpMenuAdmVO> getAuthGrpMenuAdmList(AuthGrpMenuAdmVO authGrpMenuAdmVO) {
        return authGrpAdmMapper.getAuthGrpMenuAdmList(authGrpMenuAdmVO);
    }


    /**
     * methodName : checkAdminAuthGroup
     * author : Chang-Joo Lee
     * description : 권한 그룹 메뉴 권한 및 화면 권한을 저장 삭제한다.
     */
    @Override
    @Transactional(rollbackFor = {Exception.class})
    public CommonResponseModel updateAuthGrpMenuAdmList(List<AuthGrpMenuScrSaveVO> updateRows){

        String usrId = adminAccountInfoUtil.getUsrId();
        boolean checkedFlag = false;
        if(updateRows.size() > 0){

                ObjectMapper mapper = new ObjectMapper();
                String flagScrId = null;
                for (int i = 0; i < updateRows.size() ; i++) {
                    AuthGrpMenuScrSaveVO updateAuthGrpAdmVO = updateRows.get(i);
                    Map<String, Object> gridAttMap = mapper.convertValue(updateAuthGrpAdmVO.get_attributes(), Map.class);
                    checkedFlag = (boolean)gridAttMap.get("checked");
                    flagScrId = updateAuthGrpAdmVO.getScrnId();

                    if(checkedFlag) {
                        log.info("체크O");
                        updateAuthGrpAdmVO.setMdpsId((null == usrId) ? CommonConstants.SYSTEM_ID : usrId);
                        updateAuthGrpAdmVO.setRgpsId((null == usrId) ? CommonConstants.SYSTEM_ID : usrId);
                        try{
                            System.out.println(authGrpAdmMapper.authGrpMenuAdmTureListCnt(updateAuthGrpAdmVO));
                            if(authGrpAdmMapper.authGrpMenuAdmTureListCnt(updateAuthGrpAdmVO) == 0){
                                authGrpAdmMapper.insertAuthGrpMenuAdmTureList(updateAuthGrpAdmVO);
                            }

                            if(flagScrId != null){
                                if(authGrpAdmMapper.authGrpScrAdmTureListCnt(updateAuthGrpAdmVO) == 0){
                                    authGrpAdmMapper.insertAuthGrpScrAdmTureList(updateAuthGrpAdmVO);
                                }else{
                                    authGrpAdmMapper.updateAuthGrpScrAdmTureList(updateAuthGrpAdmVO);
                                }
                            }
                        }catch(DuplicateKeyException e){

                        }
                    }else{
                        log.info("체크X");
                        try{
                            authGrpAdmMapper.deleteAuthGrpMenuAdmFalseList(updateAuthGrpAdmVO);
                            if(flagScrId != null) {
                                authGrpAdmMapper.deleteAuthGrpScrAdmFalseList(updateAuthGrpAdmVO);
                            }
                        }catch(DuplicateKeyException e){

                        }
                    }

                }


        }

        return new CommonResponseModel();
    }
}
