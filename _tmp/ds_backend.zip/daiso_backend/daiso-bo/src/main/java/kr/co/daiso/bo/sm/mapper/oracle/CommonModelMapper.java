package kr.co.daiso.bo.sm.mapper.oracle;

import kr.co.daiso.bo.sm.model.CommonModelSearchVO;
import kr.co.daiso.bo.sm.model.CommonModelVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.mapper.oracle
 * fileName       : CommonModelMapper
 * author         : leechangjoo
 * date           : 2022-01-12
 * description    : 공통모델 관리 Mapper
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-12          leechangjoo         최초생성
 **/
@Mapper
public interface CommonModelMapper {

    // 제조사 목록을 카운트를 구한다.
    int iqyMnuftrListCnt(CommonModelSearchVO reqVo);

    // 제조사 목록을 구한다.
    List<CommonModelVO> iqyMnuftrList(CommonModelSearchVO reqVo);

    // 모델 목록을 카운트를 구한다.
    int iqyModelListCnt(CommonModelSearchVO reqVo);

    // 모델 목록을 구한다.
    List<CommonModelVO> iqyModelList(CommonModelSearchVO reqVo);

    // 등급 목록을 구한다.
    List<CommonModelVO> iqyGrdList(CommonModelSearchVO reqVo);

    // 세부등급 목록을 구한다.
    List<CommonModelVO> iqyDetailGrdList(CommonModelSearchVO reqVo);

    // 모델그룹 목록을 구한다.
    List<CommonModelVO> iqyModelGroupList(CommonModelSearchVO reqVo);
}
