package kr.co.daiso.bo.util;

import java.security.MessageDigest;
import java.util.Base64;

import org.springframework.stereotype.Component;

// import com.softforum.xdbe.xCrypto;
import lombok.extern.slf4j.Slf4j;

/**
 * packageName    : kr.co.daiso.bo.util
 * fileName       : EncryptUtil
 * author         : bsj
 * date           : 2022-01-14
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-14     bsj             최초생성
 */
@Slf4j
@Component
public class EncryptUtil {

    /**
     * 암호화
     * @param encString 원본 문자열
     * @return 암호화된 문자열
     */
    public String cmEnCrypt(String encString){
        String			encrypted	= "";
        byte[] 			digested	= null;
        try {
            MessageDigest md			= MessageDigest.getInstance("MD5");
            md.update(new String(encString).getBytes("UTF-8"));
            digested	= md.digest();
            Base64.Encoder encoder = Base64.getEncoder();
            byte[] encodedBytes = encoder.encode(digested);
            encrypted	= new String(encodedBytes);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return encrypted;
    }

    /**
     * Hash 암호화
     */
    public static String getHashEncryptSha256(String originalStr) {
        String encryptStr = "";
        try {
            // encryptStr    = xCrypto.Hash(6,  originalStr);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return encryptStr;
    }

    public static String getStringValue(String i_sSource) {
        if ((null == i_sSource) || "".equals(i_sSource)) {
            return "";
        } else if ((null == i_sSource.trim()) || "".equals(i_sSource.trim())) {
            return "";
        }

        return i_sSource.trim();
    }
}
