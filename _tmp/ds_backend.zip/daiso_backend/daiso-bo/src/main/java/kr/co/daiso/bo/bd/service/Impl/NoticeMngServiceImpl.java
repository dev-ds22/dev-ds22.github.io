package kr.co.daiso.bo.bd.service.Impl;

import kr.co.daiso.bo.bd.mapper.oracle.NoticeMngMapper;
import kr.co.daiso.bo.bd.model.NoticeVO;
import kr.co.daiso.bo.bd.service.NoticeMngService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.bd.service.Impl
 * fileName       : NoticeMngServiceImpl
 * author         : kjm
 * date           : 2022-01-20
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-20       kjm            최초생성
 */
@Service
public class NoticeMngServiceImpl implements NoticeMngService {

    @Autowired
    NoticeMngMapper noticeMngMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : getNoticeTotalCount
     * author : kjm
     * description : 공지사항 목록 개수조회
     *
     * @param noticeVO
     * @return int
     */
    @Override
    public int getNoticeTotalCount(NoticeVO noticeVO) {
        return noticeMngMapper.getNoticeTotalCount(noticeVO);
    }

    /**
     * methodName : searchNoticeList
     * author : kjm
     * description : 공지사항 목록 조회
     *
     * @param noticeVO
     * @return List<NoticeVO>
     */
    @Override
    public List<NoticeVO> searchNoticeList(NoticeVO noticeVO) {
        return noticeMngMapper.searchNoticeList(noticeVO);
    }

    /**
     * methodName : searchNotice
     * author : kjm
     * description : 공지사항 상세 조회
     *
     * @param bltbdCd
     * @return NoticeVO
     */
    @Override
    public NoticeVO searchNotice(String bltbdCd) {
        return noticeMngMapper.searchNotice(bltbdCd);
    }

    /**
     * methodName : searchNotice
     * author : kjm
     * description : 공지사항 삭제
     *
     * @param noticeVO
     * @return int
     */
    @Override
    public int deleteNotice(NoticeVO noticeVO) {
        return noticeMngMapper.deleteNotice(noticeVO);
    }

    /**
     * methodName : insertNotice
     * author : kjm
     * description : 공지사항 등록
     *
     * @param noticeVO
     */
    @Override
    public void insertNotice(NoticeVO noticeVO) {
        String userId = adminAccountInfoUtil.getUsrId();
        noticeVO.setRgpsId(userId);
        noticeVO.setMdpsId(userId);
        noticeMngMapper.insertNotice(noticeVO);
    }

    /**
     * methodName : updateNotice
     * author : kjm
     * description : 공지사항 수정
     *
     * @param noticeVO
     */
    @Override
    public void updateNotice(NoticeVO noticeVO) {
        String userId = adminAccountInfoUtil.getUsrId();
        noticeVO.setMdpsId(userId);
        noticeMngMapper.updateNotice(noticeVO);
    }
}
