package kr.co.daiso.bo.sm.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.common.mapper.oracle.LogMapper;
import kr.co.daiso.bo.sm.mapper.oracle.MobileAppVerMapper;
import kr.co.daiso.bo.sm.model.MobileAppVerSearchVO;
import kr.co.daiso.bo.sm.model.MobileAppVerVO;
import kr.co.daiso.bo.sm.service.MobileAppVerService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import kr.co.daiso.bo.util.AdminCmnUtil;
import io.lettuce.core.ScriptOutputType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : MobileAppVerServiceImpl
 * author         : Byung-Chul Park
 * date           : 2022-02-28
 * description    : 모바일 앱버전 관리 서비스의 구현체
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-28    Byung-chul Park   최초생성
 */
@Slf4j
@Service
public class MobileAppVerServiceImpl implements MobileAppVerService {

    @Autowired
    AdminCmnUtil adminCmnUtil;

    @Autowired
    LogMapper logMapper;

    @Autowired
    MobileAppVerMapper mobileAppVerMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;


    /**
     * methodName : getMobileAppVer
     * author : Byung-chul Park
     * description : 모바일 APP버전관리를 조회한다.
     *
     * @param  mobileAppVerSearchVO
     * @return List<MobileAppVerVO>
     */
    @Override
    public List<MobileAppVerVO> getMobileAppVer(MobileAppVerSearchVO mobileAppVerSearchVO) {
        return mobileAppVerMapper.getMobileAppVer(mobileAppVerSearchVO);
    }

    /**
     * methodName : getMobileAppVerCnt
     * author : Byung-chul Park
     * description : 모바일 APP버전관리 카운트를 조회한다.
     *
     * @param  mobileAppVerSearchVO
     * @return List<mobileAppVerVO>
     */
    @Override
    public int getMobileAppVerCnt(MobileAppVerSearchVO mobileAppVerSearchVO) {
        return mobileAppVerMapper.getMobileAppVerCnt(mobileAppVerSearchVO);
    }

    /**
     * methodName : getMobileAppVersion
     * author : Byung-chul Park
     * description : 모바일 APP버전정보를 조회한다.
     *
     * @param  mobileAppVerVO
     * @return MobileAppVerVO
     */
    @Override
    public MobileAppVerVO getMobileAppVersion(MobileAppVerVO mobileAppVerVO) {
//        public List<MobileAppVerVO> getMobileAppVersion(MobileAppVerVO mobileAppVerVO) {
        return mobileAppVerMapper.getMobileAppVersion(mobileAppVerVO);
    }

    /**
     * methodName : regMobileAppVer
     * author : Byung-chul Park
     * description : 모바일 APP버전관리를 등록한다.
     *
     * @param
     * @return List<mobileAppVerVO>
     */
    @Override
    public CommonResponseModel regMobileAppVer(LinkedHashMap<String, Object> mobileAppVerVO) {


        ObjectMapper mapper = new ObjectMapper();

        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<MobileAppVerVO> updatedList = mapper.convertValue(mobileAppVerVO.get("updatedRows"), new TypeReference<List<MobileAppVerVO>>() {});
        List<MobileAppVerVO> regList = new ArrayList<MobileAppVerVO>();
        log.info("updatedList >>>>>>>>>" + updatedList);



        List<MobileAppVerVO> list	= mobileAppVerMapper.getMobileAppVer(null);
        for(int i = 0; i < updatedList.size(); i++){
            MobileAppVerVO updateVO = updatedList.get(i);
            String updateOs = updateVO.getOsDvsCd();
            String updateVer = updateVO.getAppVer();
            for(int j = 0; j <list.size(); j++){
                MobileAppVerVO targetVO = list.get(j);
                String targetOs = targetVO.getOsDvsCd();
                String targetVer = targetVO.getAppVer();

                if(updateOs.equals(targetOs)){

                    if(Double.parseDouble(updateVer) >= Double.parseDouble(targetVer)){

                        regList.add(updatedList.get(i));
                        log.info("regList >>>>" + regList);
                    }
                    else{
                        throw new CommonException("버전 오류", HttpStatus.BAD_REQUEST);
                    }
                }
            }

        }


        if(regList.size() > 0){
            mobileAppVerMapper.regMobileAppVer(regList);
            log.info("result");
            return new CommonResponseModel();
        }else{
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setReturnCode("400");
            failResultModel.setMessage("체크 박스.");
            failResultModel.setSuccess(false);
            return failResultModel;
        }


//        List<MobileAppVerVO> regList = new ArrayList<MobileAppVerVO>();
//
//        try{
//            if(updatedList.size() > 0){
//                System.out.println("updatedList.size()@@@"+ updatedList.size());
//                mobileAppVerMapper.regMobileAppVer(updatedList);
//            }
//        }catch (CommonException e){
//            CommonResponseModel failResultModel = new CommonResponseModel();
//            failResultModel.setReturnCode("400");
//            failResultModel.setMessage("VER");
//            failResultModel.setSuccess(false);
//            return failResultModel;
//        }

    }
}
