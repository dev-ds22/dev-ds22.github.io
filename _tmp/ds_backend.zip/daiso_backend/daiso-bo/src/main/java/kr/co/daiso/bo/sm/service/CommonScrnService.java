package kr.co.daiso.bo.sm.service;

import kr.co.daiso.bo.sm.model.CommonScrnSearchPagingVO;
import kr.co.daiso.bo.sm.model.CommonScrnVO;
import kr.co.daiso.bo.sm.model.ScrnMenuVO;
import org.springframework.dao.DuplicateKeyException;

import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service
 * fileName       : CommonScrnService
 * author         : Doo-Won Lee
 * date           : 2021-12-08
 * description    : 관리자 화면 관리 관련 서비스 interface
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       Doo-Won Lee    최초생성
 */
public interface CommonScrnService {

    //화면을 검색한 화면 리스트의 카운트를 구한다.(화면 검색 팝업)
    public int getSearchScrnListCnt(CommonScrnSearchPagingVO searchVO);
    //화면을 검색한 화면 리스트를  구한다.(화면 검색팝업)
    public List<CommonScrnVO> getSearchScrnList(CommonScrnSearchPagingVO searchVO);

    //새로운 화면을 저장한다.
    public int saveScreenInfo(CommonScrnVO saveVO) throws DuplicateKeyException;

    //화면 정보를 수정한다.
    public int editScreenInfo(CommonScrnVO saveVO);

    public List<ScrnMenuVO> getMenulistByScrn(CommonScrnVO scrnVO);
}
