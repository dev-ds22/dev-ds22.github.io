package kr.co.daiso.bo.sm.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.sysmg.menu.model
 * fileName       : MenuVO
 * author         : kjm
 * date           : 2021-12-08
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-08       kjm            최초생성
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MenuVO extends CommonPagingVo {

    private String menuId;

    private String menuNm;

    private String menuLevl;

    private String hrnkMenuId;

    private String sortOrdr;

    private String useYn;

    private String exprYn;

    private String rgpsId;

    private String regDttm;

    private String mdpsId;

    private String modDttm;

    private String sysDcd;

    private String pmTypeCd;

    private String scrnId;

    private String scrnNm;

    private String scrnUrl;

    private String authGrps; //메뉴 권한 그룹 추가 Doo-Won Lee 2022-01-25

    private String pgSq;    // 페이지 순번

    private String pgNm;

    private String pgDcd;

    private String indvInfoRelYn;

}
