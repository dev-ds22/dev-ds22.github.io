package kr.co.daiso.bo.config;

import kr.co.daiso.bo.common.auth.service.AuthGrpService;
import kr.co.daiso.bo.sm.service.CommonCodeManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

/**
 * packageName    : kr.co.daiso.bo.config
 * fileName       : InitConfig
 * author         : Doo-Won Lee
 * date           : 2021-12-06
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-06      Doo-Won Lee      최초생성
 */
@Slf4j
@Component
public class InitConfig {

    @Autowired
    AuthGrpService authGrpService;

    @Autowired
    CommonCodeManageService commonCodeManageService;

    @Autowired
    Environment environment;

    @Bean(initMethod = "init")
    public void InitSetting() throws Exception{
        log.info("Init!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        // authGrpService.setAdminAuthGrpToRedis();
        // commonCodeManageService.setAdminIpListToRedis();
        boolean isReal = Arrays.stream(environment.getActiveProfiles()).anyMatch(profileName -> profileName.equals("prd"));

        String springVersion = org.springframework.core.SpringVersion.getVersion();
        log.info("Spring version :", springVersion);
    }

}
