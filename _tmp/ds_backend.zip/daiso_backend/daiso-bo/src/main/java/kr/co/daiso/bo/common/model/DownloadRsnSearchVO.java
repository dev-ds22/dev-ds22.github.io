package kr.co.daiso.bo.common.model;

import kr.co.daiso.common.model.CommonPagingVo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * packageName    : kr.co.daiso.bo.common.model
 * fileName       : DownloadRsnSearchVO
 * author         : Byung-Chul Park
 * date           : 2022-02-22
 * description    : 다운로드 사유 조회검색VO
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-02-22      Byung-Chul Park   최초생성
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class DownloadRsnSearchVO extends CommonPagingVo {

    private String strtDttm; //검색 시작일시
    private String endDttm;  //검색 종료일시  
    private String keyword;  //검색어
    private String dnldKeyword; // 다운로드항목명
    private String authGrntType; //권한부여 타입
}
