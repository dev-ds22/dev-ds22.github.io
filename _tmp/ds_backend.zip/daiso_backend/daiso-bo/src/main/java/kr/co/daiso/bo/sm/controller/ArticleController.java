package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.model.ArticlePagingVo;
import kr.co.daiso.bo.sm.model.ArticleVo;
import kr.co.daiso.bo.sm.service.ArticleService;
import com.nhncorp.lucy.security.xss.XssPreventer;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.sql.SQLIntegrityConstraintViolationException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("/sysmg/article")
@RestController
public class ArticleController {

    @Autowired
    ArticleService articleService;

    @ApiOperation("약관 목록 조회")
    @GetMapping("/getArticlesList")
    public ResponseEntity<CommonResponseModel> getArticleList(@ApiParam("선택한 약관 코드") ArticlePagingVo searchVO, HttpServletResponse response){
        Map<String, Object> resultMap = new HashMap<String, Object>();
        searchVO.setTotal(articleService.listCount(searchVO));

        List<ArticleVo> list = articleService.getArticleList(searchVO);

        resultMap.put("article", list);
        resultMap.put("ArticleCount", searchVO);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap),HttpStatus.OK);
    }
    @ApiOperation("약관 상세 조회")
    @GetMapping("/getArticleDetail")
    public ResponseEntity<CommonResponseModel> getArticleDetail(ArticleVo articleVo, HttpServletResponse response) throws ParseException {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            ArticleVo vo = articleService.getArticle(articleVo);
//            String reconvertMsg = XssPreventer.unescape(vo.getAtclCnts());
            vo.setAplyDt(vo.getAplyDt().substring(0, 4) + "-" + vo.getAplyDt().substring(4, 6) + "-" + vo.getAplyDt().substring(6, 8));
            resultMap.put("detail", vo);
            return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
        }catch(NullPointerException e){
//            e.printStackTrace();
            CommonResponseModel nullModel = new CommonResponseModel();
            nullModel.setData("");
            return new ResponseEntity<CommonResponseModel>(nullModel, HttpStatus.OK);
        }

    }
    @ApiOperation("약관 새로저장")
    @PostMapping("/saveArticle")
    public ResponseEntity<CommonResponseModel> saveArticle(@ApiParam("등록할 약관정보") @RequestBody ArticleVo articleVo) {
        articleVo.setAplyDt(articleVo.getAplyDt().replace("-",""));
        try {
            articleService.saveArticle(articleVo);
        }catch (DataIntegrityViolationException e){
            //등록 정보 중복시 오류 처리
            CommonResponseModel failModel = new CommonResponseModel();
            failModel.setSuccess(false);
            failModel.setMessage("Duplicate");
            failModel.setReturnCode("400");
            return new ResponseEntity<CommonResponseModel>(failModel, HttpStatus.OK);
        }
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(),HttpStatus.OK);
    }
    @ApiOperation("약관정보 수정")
    @PostMapping("/updateArticle")
    public ResponseEntity<CommonResponseModel> updateArticle(@ApiParam("수정한 약관정보") @RequestBody ArticleVo articleVo){
        articleVo.setAplyDt(articleVo.getAplyDt().replace("-",""));
        articleService.updateArticle(articleVo);

        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(),HttpStatus.OK);
    }
}
