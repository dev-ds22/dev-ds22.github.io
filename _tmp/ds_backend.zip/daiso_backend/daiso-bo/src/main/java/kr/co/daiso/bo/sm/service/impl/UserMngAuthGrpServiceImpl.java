package kr.co.daiso.bo.sm.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kr.co.daiso.common.util.CommonUtil;
import kr.co.daiso.bo.sm.mapper.oracle.UserMngAuthGrpMapper;
import kr.co.daiso.bo.sm.model.UserMngAuthGrpVO;
import kr.co.daiso.bo.sm.service.UserMngAuthGrpService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * packageName    : kr.co.daiso.bo.sysmg.service.impl
 * fileName       : UserMngAuthGrpServiceImpl
 * author         : kjm
 * date           : 2021-12-23
 * description    :
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-23       kjm            최초생성
 */
@Slf4j
@Service
public class UserMngAuthGrpServiceImpl implements UserMngAuthGrpService {

    @Autowired
    private UserMngAuthGrpMapper userMngAuthGrpMapper;

    @Autowired
    private AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * methodName : searchUserList
     * author : kjm
     * description : 권한그룹별 사용자 목록조회
     *
     * @param userMngAuthGrpVO
     * @return List<UserMngAuthGrpVO>
     */
    @Override
    public List<UserMngAuthGrpVO> searchUserList(UserMngAuthGrpVO userMngAuthGrpVO) {
        return userMngAuthGrpMapper.searchUserList(userMngAuthGrpVO);
    }

    /**
     * methodName : saveUserByAuthGrp
     * author : kjm
     * description : 권한그룹별 사용자 저장
     *
     * @param linkedHashMap
     */
    @Override
    public void saveUserByAuthGrp(LinkedHashMap<String, Object> linkedHashMap) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        List<UserMngAuthGrpVO> createdRows = objectMapper.convertValue(linkedHashMap.get("createdRows"), new TypeReference<List<UserMngAuthGrpVO>>() {});
//        List<UserMngAuthGrpVO> updatedRows =  objectMapper.convertValue(linkedHashMap.get("updatedRows"), new TypeReference<List<UserMngAuthGrpVO>>() {});
        List<UserMngAuthGrpVO> deletedRows =  objectMapper.convertValue(linkedHashMap.get("deletedRows"), new TypeReference<List<UserMngAuthGrpVO>>() {});
        UserMngAuthGrpVO userMngAuthGrpVO = objectMapper.convertValue(linkedHashMap.get("userMngAuthGrpVO"), new TypeReference<UserMngAuthGrpVO>() {});


        String userId = adminAccountInfoUtil.getUsrId();

        createdRows.forEach(createdRow -> {
            createdRow.setAuthGrpCd(userMngAuthGrpVO.getAuthGrpCd());
            createdRow.setAuthGrntType("AC");
            createdRow.setRgpsId(userId);
            createdRow.setMdpsId(userId);
            createdRow.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));

            userMngAuthGrpMapper.insertUserByAuthGrp(createdRow);
            userMngAuthGrpMapper.insertUserAuthGrpHist(createdRow);
        });

        deletedRows.forEach(deletedRow -> {
            deletedRow.setAuthGrpCd(userMngAuthGrpVO.getAuthGrpCd());
            deletedRow.setAuthGrntType("AD");
            deletedRow.setRgpsId(userId);
            deletedRow.setMdpsId(userId);
            deletedRow.setAcesIp(CommonUtil.getClientIp(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()));

            userMngAuthGrpMapper.deleteUserByAuthGrp(deletedRow);
            userMngAuthGrpMapper.insertUserAuthGrpHist(deletedRow);
        });

    }
}
