package kr.co.daiso.bo.sm.service.impl;

import kr.co.daiso.common.constants.CommonConstants;
import kr.co.daiso.common.exception.CommonException;
import kr.co.daiso.common.model.CommonResponseModel;
import kr.co.daiso.bo.sm.mapper.oracle.HolidayMapper;
import kr.co.daiso.bo.sm.model.CalendarVo;
import kr.co.daiso.bo.sm.model.HolidayVo;
import kr.co.daiso.bo.sm.service.HolidayService;
import kr.co.daiso.bo.util.AdminAccountInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : HolidayController
 * author         : Injung,Kim
 * date           : 2022-01-13
 * description    : 직영점 휴일 관리
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2022-01-13     Injung,Kim      최초생성
 */
@Service
public class HolidayServiceImpl implements HolidayService {
    @Autowired
    HolidayMapper holidayMapper;

    @Autowired
    AdminAccountInfoUtil adminAccountInfoUtil;

    /**
     * 저장된 직영점별, 연도별 달력 정보를 조회한다
     * @param holidayVo 선택한 연도, 선택한 직영점 코드
     * @return 저장되어있는 달력 정보
     */
    @Override
    public CommonResponseModel getStoredcalendar(HolidayVo holidayVo) {
        //생성된 직영점 달력을 조회한다
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            List<HolidayVo> storedcalendar = holidayMapper.selectCanlenderBycntr(holidayVo);
            if(storedcalendar.size() > 0 ){
                resultMap.put("selectedCalendar", storedcalendar);
            }
        }catch(CommonException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setReturnCode("400");
            failResultModel.setMessage("달력 조회 실패");
            failResultModel.setSuccess(false);
            return failResultModel;
        }
        return new CommonResponseModel(resultMap);
    }
    /**
     * UCMS 달력마스터의 연도별 달력 정보를 가져온다
     * @param holidayVo 선택한 연도
     * @return 생성된 달력정보
     */
    @Override
    public List<CalendarVo> getUCMScalendarByYear(HolidayVo holidayVo) {
        //해당 연도의 UCMS 달력을 가져온다
        List<CalendarVo> calendarMaster = holidayMapper.selectcalendarByYear(holidayVo);
        return calendarMaster;
    }
    /**
     * UCMS 달력마스터의 연도별 달력 정보를 가져온다
     * @param holidayVo 선택한 연도, 선택한 직영점 코드
     * @return 생성된 달력정보
     */
    @Override
    @Transactional(rollbackFor = {Exception.class})
    public int saveNewCalendarByCntr(List<CalendarVo> calendarMaster, HolidayVo holidayVo) {
        //최초 생성자 입력
        String usrId = adminAccountInfoUtil.getUsrId();
//        for(CalendarVo calendarVo : calendarMaster){
//            holidayVo.setRgpsId((usrId == null) ? CommonConstants.SYSTEM_ID : usrId);
//        }
        Map<String, Object> map = new HashMap<String, Object>();
        if(calendarMaster.size() > 0) {
            map.put("calendarMaster", calendarMaster);
        }
        map.put("centerCode", holidayVo.getSubCd());
        map.put("userId", (usrId == null) ? CommonConstants.SYSTEM_ID : usrId);

        //해당 연도의 달력을 해당 센터코드로 생성한다
        try {
            if(holidayVo.getSubCd() != null && holidayVo.getYear() > 0) {
                return holidayMapper.insertcalendar(map);
            }
        } catch(DuplicateKeyException e) {
//            CommonResponseModel failResultModel = new CommonResponseModel();
//            failResultModel.setReturnCode("400");
//            failResultModel.setMessage("달력 중복");
//            failResultModel.setSuccess(false);
//            throw new CommonException("달력 중복", HttpStatus.BAD_REQUEST);
            return 0;
        }
//        Map<String, Object> resultMap = new HashMap<String, Object>();
        return 0;
    }

    /**
     * 작성한 휴일 정보를 저장한다
     * @param updatedList 수정된 휴일 정보 리스트
     * @return 휴일 저장 처리결과
     */
    @Override
    public CommonResponseModel updateHolidays(List<HolidayVo> updatedList) {
        String usrId = adminAccountInfoUtil.getUsrId();
        for(HolidayVo holidayVo: updatedList){
            holidayVo.setMdpsId((usrId == null) ? CommonConstants.SYSTEM_ID : usrId);
        }
        try {
            if (updatedList.size() > 0) {
                holidayMapper.updateHolidays(updatedList);
            }
        }catch (CommonException e){
            CommonResponseModel failResultModel = new CommonResponseModel();
            failResultModel.setReturnCode("400");
            failResultModel.setMessage("휴일 저장실패");
            failResultModel.setSuccess(false);
            return failResultModel;
        }
        return new CommonResponseModel();
    }

}
