package kr.co.daiso.bo.sm.controller;

import kr.co.daiso.bo.sm.model.CommonUserSearchPagingVo;
import kr.co.daiso.bo.sm.model.CommonUserVo;
import kr.co.daiso.bo.sm.service.CommonUserSearchService;
import kr.co.daiso.common.model.CommonResponseModel;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * packageName    : kr.co.daiso.bo.sysmg.controller
 * fileName       : CommonUserController
 * author         : Doo-Won Lee
 * date           : 2021-12-24
 * description    : Injung,Kim
 * =============================================================
 * DATE             AUTHOR          NOTE
 * -------------------------------------------------------------
 * 2021-12-24     Injung,Kim      최초생성
 */
@RestController
@RequestMapping("/sysmg/commonUser")
public class CommonUserController {
    @Autowired
    CommonUserSearchService userSearchService;
    private Object CommonUserVo;


    @ApiOperation("사용자 검색목록")
    @GetMapping("/userSearch")
    public ResponseEntity<CommonResponseModel> searchUser(@ApiParam("사용자 이름") CommonUserSearchPagingVo userVo, HttpServletResponse servletResponse){
        Map<String, Object> resultMap = new HashMap<>();
        //검색된 사용자 수
        userVo.setTotal(userSearchService.getUsersCount(userVo));
        //사용자 리스트
        List<CommonUserVo> list = userSearchService.getUsersInfo(userVo);
        resultMap.put("UserList", list);
        resultMap.put("UserCount", userVo);
        return new ResponseEntity<CommonResponseModel>(new CommonResponseModel(resultMap), HttpStatus.OK);
    }

}
