package com.example.camel.dynamic.vo;

import lombok.Data;

@Data
public class TestParamVO {
    private String id;
    private String name;
    private String type;
    private String actionFlag;
    private String targetRouteId;
}
